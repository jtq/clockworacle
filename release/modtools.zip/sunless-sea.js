(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
module.exports={
	"title": "Sunless Sea",
	"paths": {
		"templates": "src/templates",
		"modGameJson": "build/modtools/game-data/json",
		"builddir": {
			"mod": "build/clockworacle/entities",
			"ui": "build/modtools"
		}
	},
	"locations": {
		"imagesPath": "game-data/icons"
	},
	"baseGameIds": {
		"quality": 500000,
		"prelimEvent": 500010,
		"buyOracle": 5000020,
		"sellOracle": 500030,
		"event": 500035,
		"acquire": 600000,
		"learn": 700000,
		"suffer": 800000,
		"become": 900000
	}
}
},{}],2:[function(require,module,exports){
var config = require('../../config.json');
var Clump = require('./objects/clump');
var Lump = require('./objects/lump');

var io = require('./io');

var library = require('./library');
var loaded = {};

var types = {
  Quality: require('./objects/quality'),
  Event: require('./objects/event'),
  Interaction: require('./objects/interaction'),
  QualityEffect: require('./objects/quality-effect'),
  QualityRequirement: require('./objects/quality-requirement'),
  Area: require('./objects/area'),
  SpawnedEntity: require('./objects/spawned-entity'),
  CombatAttack: require('./objects/combat-attack'),
  Exchange: require('./objects/exchange'),
  Shop: require('./objects/shop'),
  Availability: require('./objects/availability'),
  Tile: require('./objects/tile'),
  TileVariant: require('./objects/tile-variant'),
  Port: require('./objects/port'),
  Setting: require('./objects/setting')
};

// Prepopulate library with Clumps of each type we know about
Object.keys(types).forEach(function(typeName) {
	var Type = types[typeName];
	if(!library[typeName]) {
		library[typeName] = new Clump([], Type);
		loaded[typeName] = new Clump([], Type);
	}
});

function get(Type, id, parent) {
	var typename = Type.name;	// Event, Quality, Interaction, etc

	var existingThingWithThisId = library[typename].id(id);
	if(existingThingWithThisId) {
		//console.log("Attached existing " + existingThingWithThisId + " to " + this.toString())
		var newParent = true;
		existingThingWithThisId.parents.forEach(function(p) {
			if(p.Id === parent.Id && p.constructor.name === parent.constructor.name) {
				newParent = false;
			}
		});
		if(newParent){
			existingThingWithThisId.parents.push(parent);
		}

		if(!existingThingWithThisId.wired) {
			existingThingWithThisId.wireUp(this);	// Pass in the api so object can add itself to the master-library
		}
		return existingThingWithThisId;
	}
	else {
		return null;
	}
}

function getOrCreate(Type, possNewThing, parent) {	// If an object already exists with this ID, use that.  Otherwise create a new object from the supplied details hash
	var typename = Type.name;	// Event, Quality, Interaction, etc
	if(possNewThing) {
  	var existingThingWithThisId = this.get(Type, possNewThing.Id, parent);
  	if(existingThingWithThisId) {
  		return existingThingWithThisId;
  	}
  	else {
			var newThing = new Type(possNewThing, parent);
			newThing.wireUp(this);
			//console.log("Recursively created " + newThing + " for " + this.toString());
			return newThing;
		}
	}
	else {
		return null;
	}
}

function wireUpObjects() {
	var api = this;
  Object.keys(types).forEach(function(type) {
    library[type].forEach(function(lump) {
      if(lump.wireUp) {
        lump.wireUp(api);
      }
    });
  });
}

var whatIs = function(id) {
  var possibilities = [];
  Object.keys(library).forEach(function(key) {
    if(library[key] instanceof Clump && library[key].id(id)) {
      possibilities.push(key);
    }
  });
  return possibilities;
};

function describeAdvancedExpression(expr) {
	var self = this;
	if(expr) {
		expr = expr.replace(/\[d:(\d+)\]/gi, "RANDOM[1-$1]");	// [d:x] = random number from 1-x(?)
		expr = expr.replace(/\[q:(\d+)\]/gi, function(match, backref, pos, whole_str) {
			var quality = self.library.Quality.id(backref);
			return "["+(quality ? quality.Name : 'INVALID')+"]";
		});

		return expr;
	}
	return null;
}

function readFromFile(Type, file, callback) {
	io.readFile(file, function (e) {
    var contents = e.target.result;
    
    var obj = JSON.parse(contents);
    loaded[Type.prototype.constructor.name] = new Clump(obj, Type);

    callback(contents, Type, loaded[Type.prototype.constructor.name]);
  });
}


module.exports = {
	'Clump': Clump,
	'Lump': Lump,
	'config': config,
	'types': types,
	'library': library,
	'loaded': loaded,
	'get': get,
	'whatIs': whatIs,
	'wireUpObjects': wireUpObjects,
	'getOrCreate': getOrCreate,
	'describeAdvancedExpression': describeAdvancedExpression,
	'readFromFile': readFromFile
};
},{"../../config.json":1,"./io":3,"./library":4,"./objects/area":5,"./objects/availability":6,"./objects/clump":7,"./objects/combat-attack":8,"./objects/event":9,"./objects/exchange":10,"./objects/interaction":11,"./objects/lump":12,"./objects/port":13,"./objects/quality":16,"./objects/quality-effect":14,"./objects/quality-requirement":15,"./objects/setting":17,"./objects/shop":18,"./objects/spawned-entity":19,"./objects/tile":21,"./objects/tile-variant":20}],3:[function(require,module,exports){
var fileObjectMap = {
    'events.json' : 'Event',
    'qualities.json' : 'Quality',
    'areas.json' : 'Area',
    'SpawnedEntities.json' : 'SpawnedEntity',
    'CombatAttacks.json' : 'CombatAttack',
    'exchanges.json' : 'Exchange',
    'Tiles.json': 'Tile'
  };

function readFile(file, callback) {
  file.text()
    .then(function(contents) {
      callback({ target: { result: contents } });
    })
    .catch(function(err) {
      setTimeout(function() { throw err; }, 0);
    });
}

var files_to_load = 0;
function resetFilesToLoad() {
	files_to_load = 0;
}
function incrementFilesToLoad() {
	files_to_load++;
}
function decrementFilesToLoad() {
	files_to_load--;
}
function countFilesToLoad() {
	return files_to_load;
}


module.exports = {
  readFile: readFile,
  resetFilesToLoad: resetFilesToLoad,
	incrementFilesToLoad: incrementFilesToLoad,
	decrementFilesToLoad: decrementFilesToLoad,
	countFilesToLoad: countFilesToLoad,
  fileObjectMap: fileObjectMap
};
},{}],4:[function(require,module,exports){
module.exports = {};
},{}],5:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Area(raw) {
	this.straightCopy = ["Name", "Description", "ImageName", "MoveMessage"];
	Lump.call(this, raw);
}
Object.keys(Lump.prototype).forEach(function(member) { Area.prototype[member] = Lump.prototype[member]; });

Area.prototype.wireUp = function(theApi) {
	api = theApi;
	Lump.prototype.wireUp.call(this);
};

Area.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Area.prototype.toDom = function(size) {

	size = size || "normal";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.ImageName !== null && this.Image !== "") {
		element.innerHTML = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.ImageName+".png' />";
	}

	element.innerHTML += "\n<h3 class='title'>"+this.Name+"</h3>\n<p class='description'>"+this.Description+"</p>";

	element.title = this.toString();

	return element;
};

module.exports = Area;
},{"./lump":12}],6:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Availability(raw, parent) {
	this.straightCopy = [
		'Cost',
		'SellPrice'
	];
	Lump.apply(this, arguments);

	this.quality = null;
	this.purchaseQuality = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Availability.prototype[member] = Lump.prototype[member]; });

Availability.prototype.wireUp = function(theApi) {

	api = theApi;

	this.quality = api.getOrCreate(api.types.Quality, this.attribs.Quality, this);
	this.purchaseQuality = api.getOrCreate(api.types.Quality, this.attribs.PurchaseQuality, this);

	Lump.prototype.wireUp.call(this, api);
};

Availability.prototype.isAdditive = function() {
	return this.Cost > 0;
};

Availability.prototype.isSubtractive = function() {
	return this.SellPrice > 0;
};

Availability.prototype.toString = function() {
	return this.constructor.name + " " + this.quality + " (buy: " + this.Cost + "x" + this.purchaseQuality.Name + " / sell: " + this.SellPrice + "x" + this.purchaseQuality.Name + ")";
};

Availability.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;
	
	var purchase_quality_element;

	if(!this.quality) {
		purchase_quality_element = document.createElement("span");
		purchase_quality_element.innerHTML = "[INVALID]";
	}
	else {
		purchase_quality_element = this.quality.toDom("small", false, "span");
	}

	var currency_quality_element = this.purchaseQuality.toDom("small", false, "span");
	currency_quality_element.className = "quantity item small";
	var currency_quality_markup = currency_quality_element.outerHTML;

	var currency_buy_amount_element = document.createElement("span");
	currency_buy_amount_element.className = "item quantity";
	currency_buy_amount_element.innerHTML = "Buy: " + (this.Cost ? this.Cost+"x" : "&#10007;");
	currency_buy_amount_element.title = this.toString();

	var currency_sell_amount_element = document.createElement("span");
	currency_sell_amount_element.className = "item quantity";
	currency_sell_amount_element.innerHTML = "Sell: " + (this.SellPrice ? this.SellPrice+"x" : "&#10007;");
	currency_sell_amount_element.title = this.toString();


	element.appendChild(purchase_quality_element);
	element.appendChild(currency_buy_amount_element);
	if(this.Cost) {
		element.appendChild($(currency_quality_markup)[0]);
	}
	element.appendChild(currency_sell_amount_element);
	if(this.SellPrice) {
		element.appendChild($(currency_quality_markup)[0]);
	}

	return element;
};

module.exports = Availability;
},{"./lump":12}],7:[function(require,module,exports){

function Clump(raw, Type, parent) {
	this.type = Type;
	this.items = {};
	var self = this;
	raw.forEach(function(item, index, collection) {
		if(!(item instanceof Type)) {
			item = new Type(item, parent);
		}
		else if(parent) {
			var newParent = true;
			item.parents.forEach(function(p) {
				if(p.Id === parent.Id && p.constructor.name === parent.constructor.name) {
					newParent = false;
				}
			});
			if(newParent){
				item.parents.push(parent);
			}
		}
		if(self.items[item.Id]) {
			console.warn(Type.name+" "+item.Id+" already exists in this clump.  Duplicated IDs for different objects in the game-json?");
		}
		self.items[item.Id] = item;
	});
}

Clump.prototype.empty = function() {
	return !!this.size();
};

Clump.prototype.size = function() {
	return Object.keys(this.items).length;
};

Clump.prototype.get = function(index) {
	for(var id in this.items) {
		if(index === 0) {
			return this.items[id];
		}
		index--;
	}
};

Clump.prototype.id = function(id) {
	return this.items[id];
};

Clump.prototype.each = function() {
	var args = Array.prototype.slice.call(arguments);
	return this.map(function(item) {

		if(args[0] instanceof Array) {	// Passed in array of fields, so return values concatenated with optional separator
			var separator = (typeof args[1] === "undefined") ? "-" : args[1];
			return args[0].map(function(f) { return item[f]; }).join(separator);
		}
		else if(args.length > 1) {	// Passed in separate fields, so return array of values
			return args.map(function(f) { return item[f]; });
		}
		else {
			return item[args[0]];
		}
	});
};

Clump.prototype.forEach = function(callback) {
	for(var id in this.items) {
		var item = this.items[id];
		callback(item, id, this.items);
	}
};

Clump.prototype.map = function(callback) {
	var self = this;
	var arrayOfItems = Object.keys(this.items).map(function(key) {
		return self.items[key];
	});
	return arrayOfItems.map.call(arrayOfItems, callback);
};

Clump.prototype.sortBy = function(field, reverse) {
	var self = this;
	var objs = Object.keys(this.items).map(function(key) {
		return self.items[key];
	}).sort(function(a, b) {
		if(a[field] < b[field]) {
			return -1;
		}
		if(a[field] === b[field]) {
			return 0;
		}
		if(a[field] > b[field]) {
			return 1;
		}
	});

	return reverse ? objs.reverse() : objs;
};

Clump.prototype.same = function() {
	var self = this;

	var clone = function(obj) {
    var target = {};
    for (var i in obj) {
    	if (obj.hasOwnProperty(i)) {
    		if(typeof obj[i] === "object") {
    			target[i] = clone(obj[i]);
    		}
    		else {
      		target[i] = obj[i];
      	}
      }
    }
    return target;
  };

	var template = clone(this.get(0).attribs);

	for(var id in this.items) {
		var otherObj = this.items[id].attribs;
		for(var key in template) {
			if(template[key] !== otherObj[key]) {
				delete(template[key]);
			}
		}
	}

	return template;
};

Clump.prototype.distinct = function(field) {
	var sampleValues = {};
	this.forEach(function(item) {
		var value = item[field];
		sampleValues[value] = value;	// Cheap de-duping with a hash
	});
	return Object.keys(sampleValues).map(function(key) { return sampleValues[key]; });
};

Clump.prototype.distinctRaw = function(field) {
	var sampleValues = {};
	this.forEach(function(item) {
		var value = item.attribs[field];
		sampleValues[value] = value;	// Cheap de-duping with a hash
	});
	return Object.keys(sampleValues).map(function(key) { return sampleValues[key]; });
};

Clump.prototype.query = function(field, value) {
	var matches = [];
	var test;

	// Work out what sort of comparison to do:

	if(typeof value === "function") {	// If value is a function, pass it the candidate and return the result
		test = function(candidate) {
			return !!value(candidate);
		};
	}
	else if(typeof value === "object") {
		if(value instanceof RegExp) {
			test = function(candidate) {
				return value.test(candidate);
			};
		}
		else if(value instanceof Array) {	// If value is an array, test for the presence of the candidate value in the array
			test = function(candidate) {
				return value.indexOf(candidate) !== -1;
			};
		}
		else {
			test = function(candidate) {
				return candidate === value;	// Handle null, undefined or object-reference comparison
			};
		}
	}
	else {	// Else if it's a simple type, try a strict equality comparison
		test = function(candidate) {
			return candidate === value;
		};
	}
	
	// Now iterate over the items, filtering using the test function we defined
	this.forEach(function(item) {
		if(
			(field !== null && test(item[field])) ||
			(field === null && test(item))
		) {
			matches.push(item);
		}
	});
	return new Clump(matches, this.type);	// And wrap the resulting array of objects in a new Clump object for sexy method chaining like x.query().forEach() or x.query().query()
};

Clump.prototype.queryRaw = function(field, value) {
	var matches = [];
	var test;

	// Work out what sort of comparison to do:

	if(typeof value === "function") {	// If value is a function, pass it the candidate and return the result
		test = function(candidate) {
			return !!value(candidate);
		};
	}
	else if(typeof value === "object") {
		if(value instanceof RegExp) {
			test = function(candidate) {
				return value.test(candidate);
			};
		}
		else if(value instanceof Array) {	// If value is an array, test for the presence of the candidate value in the array
			test = function(candidate) {
				return value.indexOf(candidate) !== -1;
			};
		}
		else {	// If value is a hash... what do we do?
			// Check the candidate for each field in the hash in turn, and include the candidate if any/all of them have the same value as the corresponding value-hash field?
			throw "No idea what to do with an object as the value";
		}
	}
	else {	// Else if it's a simple type, try a strict equality comparison
		test = function(candidate) {
			return candidate === value;
		};
	}
	
	// Now iterate over them all, filtering using the test function we defined
	this.forEach(function(item) {
		if(
			(field !== null && test(item.attribs[field])) ||
			(field === null && test(item.attribs))
		) {
			matches.push(item);
		}
	});
	return new Clump(matches, this.type);	// And wrap the resulting array of objects in a new Clump object for sexy method chaining like x.query().forEach() or x.query().query()
};

Clump.prototype.toString = function() {
	return this.type.name + " Clump (" + this.size() + " items)";
};

Clump.prototype.toDom = function(size, includeChildren, tag, firstChild) {

	size = size || "normal";
	tag = tag || "ul";

	var element = document.createElement(tag);
	element.className = this.constructor.name.toLowerCase()+"-list "+size;
	if(firstChild) {
		element.appendChild(firstChild);
	}
	this.sortBy("Name").forEach(function(i) {
		element.appendChild(i.toDom(size, includeChildren));
	});
	return element;
};

Clump.prototype.describe = function() {
	var self = this;
	return Object.keys(this.items).map(function(i) { return self.items[i].toString(); }).join(" and ");
};

module.exports = Clump;
},{}],8:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function CombatAttack(raw, parent) {
	this.straightCopy = [
		'Name',
		'Image',
		'RammingAttack',
		'OnlyWhenExposed',
		'Range',
		'Orientation',
		'Arc',
		'BaseHullDamage',
		'BaseLifeDamage',
		'ExposedQualityDamage',	// Value to add to the exposedQuality: positive increases quality level (eg Terror), negative decreases it (eg Crew)
		'StaggerAmount',
		'BaseWarmUp',
		'Animation',
		'AnimationNumber'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.qualityRequired = null;
	this.qualityCost = null;
	this.exposedQuality = null;
}

Object.keys(Lump.prototype).forEach(function(member) { CombatAttack.prototype[member] = Lump.prototype[member]; });

CombatAttack.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualityRequired = api.get(api.types.Quality, this.attribs.QualityRequiredId, this);
	this.qualityCost = api.get(api.types.Quality, this.attribs.QualityCostId, this);
	this.exposedQuality = api.get(api.types.Quality, this.attribs.ExposedQualityId, this);

	Lump.prototype.wireUp.call(this, api);
};

CombatAttack.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

CombatAttack.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var self = this;
	
	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"</h3>";

	if(this.qualityRequired || this.qualityCost) {
		html += "<div class='sidebar'>";

		if(this.qualityRequired) {
			html += "<h4>Required</h4>";
			html += (new Clump([this.qualityRequired], api.types.Quality)).toDom("small", false, "ul").outerHTML;
		}
		if(this.qualityCost) {
			html += "<h4>Cost</h4>";
			html += (new Clump([this.qualityCost], api.types.Quality)).toDom("small", false, "ul").outerHTML;
		}
		html += "</div>";
	}

	html += "<dl class='clump-list small'>";
	['Range', 'Arc', 'BaseHullDamage', 'BaseLifeDamage', 'StaggerAmount', 'BaseWarmUp'].forEach(function(key) {
		html += "<dt class='item'>"+key+"</dt><dd class='quantity'>"+self[key]+"</dd>";
	});
	html += "</dl>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = CombatAttack;
},{"./clump":7,"./lump":12}],9:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Event(raw, parent) {
	this.straightCopy = [
	'Name',
	'Description',
	'Teaser',
	'Image',
	'Category'
	];
	Lump.apply(this, arguments);

	this.tag = null;

	this.ExoticEffects = this.getExoticEffect(this.attribs.ExoticEffects);

	this.qualitiesRequired = null;
	this.qualitiesAffected = null;
	this.interactions = null;
	this.linkToEvent = null;

	this.limitedToArea = null;

	this.setting = null;
	
	//Deck
	//Stickiness
	//Transient
	//Urgency
}
Object.keys(Lump.prototype).forEach(function(member) { Event.prototype[member] = Lump.prototype[member]; });

Event.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualitiesRequired = new Clump(this.attribs.QualitiesRequired || [], api.types.QualityRequirement, this);
	this.qualitiesAffected = new Clump(this.attribs.QualitiesAffected || [], api.types.QualityEffect, this);
	this.interactions = new Clump(this.attribs.ChildBranches|| [], api.types.Interaction, this);

	this.linkToEvent = api.getOrCreate(api.types.Event, this.attribs.LinkToEvent, this);

	this.limitedToArea = api.getOrCreate(api.types.Area, this.attribs.LimitedToArea, this);

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);
	
	Lump.prototype.wireUp.call(this, api);
};

Event.prototype.toString = function(long) {
	return this.constructor.name + " " + (long ? " [" + this.Category + "] " : "") + this.Name + " (#" + this.Id + ")";
};

Event.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"\n"+(this.tag ? "<span class='tag "+this.tag+"'>"+this.tag+"</span>" : "")+"</h3>";

	if(size != "small" && (this.qualitiesRequired || this.qualitiesAffected)) {
		html += "<div class='sidebar'>";
		if(this.qualitiesRequired && this.qualitiesRequired.size()) {
			html += "<h4>Requirements</h4>\n";
			html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
		}
		if(this.qualitiesAffected && this.qualitiesAffected.size()) {
			html += "<h4>Effects</h4>\n";
			html += this.qualitiesAffected.toDom("small", false, "ul").outerHTML;
		}
		html += "</div>";
	}
	
	html += "<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString(true);

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var interactions = self.interactions;
				var linkToEvent = self.linkToEvent;
				if(linkToEvent) {
					var wrapperClump = new Clump([linkToEvent], api.types.Event);
					var linkToEvent_element = wrapperClump.toDom("normal", true);

					linkToEvent_element.classList.add("child-list");
					element.appendChild(linkToEvent_element);
				}
				else if(interactions && interactions.size() > 0) {
					var interactions_element = interactions.toDom("normal", true);

					interactions_element.classList.add("child-list");
					element.appendChild(interactions_element);
				}
			}
		});
	}

	return element;
};

module.exports = Event;
},{"./clump":7,"./lump":12}],10:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Exchange(raw, parent) {
	this.straightCopy = [
		'Id',
		'Name',
		'Description',
		'Image',
		'SettingIds'
	];
	Lump.apply(this, arguments);

	this.shops = null;
	this.settings = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Exchange.prototype[member] = Lump.prototype[member]; });

Exchange.prototype.wireUp = function(theApi) {

	api = theApi;

	var self = this;

	this.shops = new Clump(this.attribs.Shops || [], api.types.Shop, this);
	
	this.settings = api.library.Setting.query("Id", function(id) {
		return self.SettingIds.indexOf(id) !== -1;
	});
	this.settings.forEach(function (s) {
		self.parents.push(s);
	});
	
	this.ports = api.library.Port.query("SettingId", function(id) {
		return self.SettingIds.indexOf(id) !== -1;
	});
	this.ports.forEach(function (p) {
		self.parents.push(p);
	});

	Lump.prototype.wireUp.call(this);
};

Exchange.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Exchange.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.shops) {

					var child_elements = self.shops.toDom("normal", true);

					child_elements.classList.add("child-list");
					element.appendChild(child_elements);
				}
			}
		});
	}

	return element;
};

module.exports = Exchange;
},{"./clump":7,"./lump":12}],11:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Interaction(raw, parent) {
	this.straightCopy = [
	'Name',
	'Description',
	'ButtonText',
	'Image',

	'Ordering'
	];
	Lump.apply(this, arguments);

	this.qualitiesRequired = null;
	this.successEvent = null;
	this.defaultEvent = null;

}
Object.keys(Lump.prototype).forEach(function(member) { Interaction.prototype[member] = Lump.prototype[member]; });

Interaction.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualitiesRequired = new Clump(this.attribs.QualitiesRequired || [], api.types.QualityRequirement, this);
	this.successEvent = api.getOrCreate(api.types.Event, this.attribs.SuccessEvent, this);
	if(this.successEvent) {
		this.successEvent.tag = "success";
	}
	this.defaultEvent = api.getOrCreate(api.types.Event, this.attribs.DefaultEvent, this);
	var qualitiesRequired =  this.qualitiesRequired;
	if(this.defaultEvent && this.successEvent && qualitiesRequired && qualitiesRequired.size()) {
		this.defaultEvent.tag = "failure";
	}

	Lump.prototype.wireUp.call(this, api);
};

Interaction.prototype.toString = function() {
	return this.constructor.name + " [" + this.Ordering + "] " + this.Name + " (#" + this.Id + ")";
};

Interaction.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"</h3>";

	if(size != "small" && this.qualitiesRequired) {
		html += "<div class='sidebar'>";
		html += "<h4>Requirements</h4>";
		html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
		html += "</div>";
	}

	html += "<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom("normal", true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = Interaction;
},{"./clump":7,"./lump":12}],12:[function(require,module,exports){
var library = require('../library');
var Clump = require('./clump');

var api;

function Lump(raw, parent) {
	if(parent) {
		this.parents = parent instanceof Array ? parent : [parent];
	}
	else {
		this.parents = [];
	}

	if(!this.straightCopy) {
		this.straightCopy = [];
	}
	this.straightCopy.unshift('Id');

	this.attribs = raw;

	var self = this;
	this.straightCopy.forEach(function(attrib) {
		self[attrib] = raw[attrib];
		if(typeof self[attrib] === "undefined") {
			self[attrib] = null;
		}
	});
	delete(this.straightCopy);

	this.wired = false;

	if(!library[this.constructor.name]) {
		library[this.constructor.name] = new Clump([], this);
	}

	if(library[this.constructor.name].items[this.Id]) {	// Something with this ID already exists!

		var existingObject = library[this.constructor.name].items[this.Id];

		if(!isFunctionallySame(this.attribs, existingObject.attribs)) {	// Was it a functionally-identical redefinition of this object?
			console.warn("Duplicate ID", this.constructor.name+" "+this.Id+" already exists in the library - replacing", existingObject, "with redefinition", this);
		}
	}
	library[this.constructor.name].items[this.Id] = this;
}

var isFunctionallySame = function(obj1, obj2) {

	if(obj1 === obj2) {
		return true;
	}

	if(obj1 instanceof Object) {
		if(!(obj2 instanceof Object) || obj1.constructor !== obj2.constructor) {
			return false;
		}

		var allKeys = Object.keys(obj1).concat(Object.keys(obj2)).filter(function (value, index, self) { 
    	return self.indexOf(value) === index;
		});

		return allKeys.map(function(key) {
			return isFunctionallySame(obj1[key], obj2[key]);
		}).reduce(function(previousValue, currentValue) {
			return previousValue && currentValue;
		}, true);
	}

	return false;

};

Lump.prototype = {
	wireUp: function(theApi) {
		api = theApi;
		this.wired = true;
	},

	getStates: function(encoded) {
		if(typeof encoded === "string" && encoded !== "") {
			var map = {};
			encoded.split("~").forEach(function(state) {
				var pair = state.split("|");
				map[pair[0]] = pair[1];
			});
			return map;
		}
		else {
			return null;
		}
	},

	getExoticEffect: function(encoded) {
		if(typeof encoded === "string") {
			var effect={}, fields=["operation", "first", "second"];
			encoded.split(",").forEach(function(val, index) {
				effect[fields[index]] = val;
			});
			return effect;
		}
		else {
			return null;
		}
	},

	evalAdvancedExpression: function(expr) {
		expr = expr.replace(/\[d:(\d+)\]/gi, "Math.floor((Math.random()*$1)+1)");	// Replace [d:x] with JS to calculate random number on a Dx die
		/*jshint -W061 */
		return eval(expr);
		/*jshint +W061 */
	},

	isA: function(type) {
		return this instanceof type;
	},

	isOneOf: function(types) {
		var self = this;
		return types.map(function(type) {
			return self.isA(type);
		}).reduce(function(previousValue, currentValue, index, array){
			return previousValue || currentValue;
		}, false);
	},

	toString: function() {
		return this.constructor.name + " (#" + this.Id + ")";
	},

	isFunctionallySame: isFunctionallySame	// Convenience utility function
};

module.exports = Lump;
},{"../library":4,"./clump":7}],13:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Port(raw, parent) {
	this.straightCopy = [
		'Name',
		'Rotation',
		'Position',
		'DiscoveryValue',
		'IsStartingPort'
	];


	raw.Id = parent.Name+"/"+raw.Name;
	Lump.apply(this, arguments);

	this.SettingId = raw.Setting.Id;
	this.setting = null;

	this.area = null;

	this.exchanges = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Port.prototype[member] = Lump.prototype[member]; });

Port.prototype.wireUp = function(theApi) {
	
	api = theApi;
	var self = this;

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);
	
	this.area = api.getOrCreate(api.types.Area, this.attribs.Area, this);

	this.exchanges = api.library.Exchange.query("SettingIds", function(ids) { return ids.indexOf(self.SettingId) !== -1; });

	Lump.prototype.wireUp.call(this, api);
};

Port.prototype.toString = function(long) {
	return this.constructor.name + " " + this.Name + " (#" + this.Name + ")";
};

Port.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Name+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Port;
},{"./lump":12}],14:[function(require,module,exports){
var Lump = require('./lump');

var api;

function QualityEffect(raw, parent) {
	this.straightCopy = ["Level", "SetToExactly"];
	Lump.apply(this, arguments);

	// May involve Quality object references, so can't resolve until after all objects are wired up
	this.setToExactlyAdvanced = null;
	this.changeByAdvanced = null;	

	this.associatedQuality = null;
	
}
Object.keys(Lump.prototype).forEach(function(member) { QualityEffect.prototype[member] = Lump.prototype[member]; });

QualityEffect.prototype.wireUp = function(theApi) {

	api = theApi;

	this.associatedQuality = api.get(api.types.Quality, this.attribs.AssociatedQualityId, this);
	this.setToExactlyAdvanced = api.describeAdvancedExpression(this.attribs.SetToExactlyAdvanced);
	this.changeByAdvanced = api.describeAdvancedExpression(this.attribs.ChangeByAdvanced);

	Lump.prototype.wireUp.call(this, api);
};

QualityEffect.prototype.getQuantity = function() {
	var condition = "";
	
	if(this.setToExactlyAdvanced !== null) {
		condition = "+(" + this.setToExactlyAdvanced + ")";
	}
	else if(this.SetToExactly !== null) {
		condition = "= " + this.SetToExactly;
	}
	else if(this.changeByAdvanced !== null) {
		condition = "+(" + this.changeByAdvanced + ")";
	}
	else if(this.Level !== null) {
		if(this.Level < 0) {
			condition = this.Level;
		}
		else if(this.Level > 0) {
			condition = "+" + this.Level;
		}
	}
	
	return condition;
};

QualityEffect.prototype.isAdditive = function() {
	return this.setToExactlyAdvanced || this.SetToExactly || this.changeByAdvanced || (this.Level > 0);
};

QualityEffect.prototype.isSubtractive = function() {
	return !this.setToExactlyAdvanced && !this.SetToExactly && !this.changeByAdvanced && (this.Level <= 0);
};

QualityEffect.prototype.toString = function() {
	var quality = this.associatedQuality;
	return this.constructor.name + " ("+this.Id+") on " + quality + this.getQuantity();
};

QualityEffect.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	var quality_element = this.associatedQuality;

	if(!quality_element) {
		quality_element = document.createElement("span");
		quality_element.innerHTML = "[INVALID]";
	}
	else {
		quality_element = this.associatedQuality.toDom(size, false, "span");
	}

	var quantity_element = document.createElement("span");
	quantity_element.className = "item quantity";
	quantity_element.innerHTML = this.getQuantity();
	quantity_element.title = this.toString();

	element.appendChild(quality_element);
	element.appendChild(quantity_element);

	return element;
};

module.exports = QualityEffect;
},{"./lump":12}],15:[function(require,module,exports){
var Lump = require('./lump');

var api;

function QualityRequirement(raw, parent) {
	this.straightCopy = ['MinLevel', 'MaxLevel'];
	Lump.apply(this, arguments);

	this.difficultyAdvanced = null;
	this.minAdvanced = null;
	this.maxAdvanced = null;

	this.associatedQuality = null;
	this.chanceQuality = null;
}
Object.keys(Lump.prototype).forEach(function(member) { QualityRequirement.prototype[member] = Lump.prototype[member]; });

QualityRequirement.prototype.wireUp = function(theApi) {

	api = theApi;

	this.difficultyAdvanced = api.describeAdvancedExpression(this.attribs.DifficultyAdvanced);
	this.minAdvanced = api.describeAdvancedExpression(this.attribs.MinAdvanced);
	this.maxAdvanced = api.describeAdvancedExpression(this.attribs.MaxAdvanced);

	this.associatedQuality = api.get(api.types.Quality, this.attribs.AssociatedQualityId, this);

	this.chanceQuality = this.getChanceCap();

	Lump.prototype.wireUp.call(this, api);
};

QualityRequirement.prototype.getChanceCap = function() {
	var quality = null;
	if(!this.attribs.DifficultyLevel) {
		return null;
	}
	quality = this.associatedQuality;
	if(!quality) {
		return null;
	}
	
	return Math.round(this.attribs.DifficultyLevel * ((100 + quality.DifficultyScaler + 7)/100));
};

QualityRequirement.prototype.getQuantity = function() {
	var condition = "";

  if(this.difficultyAdvanced !== null) {
  	condition = this.difficultyAdvanced;
  }
  else if(this.minAdvanced !== null) {
  	condition = this.minAdvanced;
  }
  else if(this.maxAdvanced !== null) {
  	condition = this.maxAdvanced;
  }
	else if(this.chanceQuality !== null) {
		condition = this.chanceQuality + " for 100%";
	}
	else if(this.MaxLevel !== null && this.MinLevel !== null) {
		if(this.MaxLevel === this.MinLevel) {
			condition = "= " + this.MinLevel;
		}
		else {
			condition = this.MinLevel + "-" + this.MaxLevel;
		}
	}
	else {
		if(this.MinLevel !== null) {
			condition = "&ge; " + this.MinLevel;
		}
		if(this.MaxLevel !== null) {
			condition = "&le; " + this.MaxLevel;
		}
	}
	return condition;
};

QualityRequirement.prototype.toString = function() {
	var quality = this.associatedQuality;
	return this.constructor.name + " ("+this.Id+") on " + quality + " " + this.getQuantity();
};

QualityRequirement.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	var quality_element = this.associatedQuality;

	if(!quality_element) {
		quality_element = document.createElement("span");
		quality_element.innerHTML = "[INVALID]";
	}
	else {
		quality_element = this.associatedQuality.toDom(size, false, "span");
	}

	var quantity_element = document.createElement("span");
	quantity_element.className = "item quantity";
	quantity_element.innerHTML = this.getQuantity();
	quantity_element.title = this.toString();

	element.appendChild(quality_element);
	element.appendChild(quantity_element);

	return element;
};

module.exports = QualityRequirement;
},{"./lump":12}],16:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Quality(raw, parent) {
	this.straightCopy = [
		'Name',
		'Description',
		'Image',

		'Category',
		'Nature',
		'Tag',

		"IsSlot",

		'AllowedOn',
		"AvailableAt",

		'Cap',
		'DifficultyScaler',
		'Enhancements'
	];
	Lump.apply(this, arguments);

	this.States = this.getStates(raw.ChangeDescriptionText);
	this.LevelDescriptionText = this.getStates(raw.LevelDescriptionText);
	this.LevelImageText = this.getStates(raw.LevelImageText);

	this.useEvent = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Quality.prototype[member] = Lump.prototype[member]; });

Quality.prototype.wireUp = function(theApi) {

	api = theApi;

	this.useEvent = api.getOrCreate(api.types.Event, this.attribs.UseEvent, this);
	if(this.useEvent) {
		this.useEvent.tag = "use";
	}

	Lump.prototype.wireUp.call(this, api);
};

Quality.prototype.toString = function(long) {
	return this.constructor.name + " " + (long ? " [" + this.Nature + " > " + this.Category + " > " + this.Tag + "] " : "") + this.Name + " (#" + this.Id + ")";
};

Quality.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.useEvent) {

					var wrapperClump = new Clump([self.useEvent], api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = Quality;
},{"./clump":7,"./lump":12}],17:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Setting(raw, parent) {
	this.straightCopy = [
		'Id'
	];
	Lump.apply(this, arguments);

	this.shops = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Setting.prototype[member] = Lump.prototype[member]; });

Setting.prototype.wireUp = function(theApi) {

	api = theApi;

	Lump.prototype.wireUp.call(this);
};

Setting.prototype.toString = function() {
	return this.constructor.name + " #" + this.Id;
};

Setting.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Id+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Setting;
},{"./lump":12}],18:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Shop(raw, parent) {
	this.straightCopy = [
		'Id',
		'Name',
		'Description',
		'Image',
		'Ordering'
	];
	Lump.apply(this, arguments);

	this.availabilities = null;
	this.unlockCost = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Shop.prototype[member] = Lump.prototype[member]; });

Shop.prototype.wireUp = function(theApi) {

	api = theApi;

	this.availabilities = new Clump(this.attribs.Availabilities || [], api.types.Availability, this);

	Lump.prototype.wireUp.call(this);
};

Shop.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Shop.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.availabilities) {

					var child_elements = self.availabilities.toDom("normal", true);

					child_elements.classList.add("child-list");
					element.appendChild(child_elements);
				}
			}
		});
	}

	return element;
};

module.exports = Shop;
},{"./clump":7,"./lump":12}],19:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function SpawnedEntity(raw, parent) {
	this.straightCopy = [
		'Name',
		'HumanName',

		'Neutral',
		'PrefabName',
		'DormantBehaviour',
		'AwareBehaviour',

		'Hull',
		'Crew',
		'Life',
		'MovementSpeed',
		'RotationSpeed',
		'BeastieCharacteristicsName',
		'CombatItems',
		'LootPrefabName',
		'GleamValue'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.pacifyEvent = null;
	this.killQualityEvent = null;
	this.combatAttackNames = [];

	this.image = null;
}
Object.keys(Lump.prototype).forEach(function(member) { SpawnedEntity.prototype[member] = Lump.prototype[member]; });

SpawnedEntity.prototype.wireUp = function(theApi) {

	api = theApi;

	var self = this;
	
	this.combatAttackNames = (this.attribs.CombatAttackNames || []).map(function(name) {
		return api.get(api.types.CombatAttack, name, self);
	}).filter(function(attack) {
		return typeof attack === "object";
	});

	this.pacifyEvent = api.get(api.types.Event, this.attribs.PacifyEventId, this);
	if(this.pacifyEvent) {
		this.pacifyEvent.tag = "pacified";
	}

	this.killQualityEvent = api.get(api.types.Event, this.attribs.KillQualityEventId, this);
	if(this.killQualityEvent) {
		this.killQualityEvent.tag = "killed";
	}

	this.image = ((this.killQualityEvent && this.killQualityEvent.Image) || (this.pacifyEvent && this.pacifyEvent.Image));

	Lump.prototype.wireUp.call(this, api);
};

SpawnedEntity.prototype.toString = function() {
	return this.constructor.name + " " + this.HumanName + " (#" + this.Id + ")";
};

SpawnedEntity.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var self = this;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.HumanName+"</h3>";

	if(size !== "small") {
		if(this.qualitiesRequired) {
			html += "<div class='sidebar'>";
			html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
			html += "</div>";
		}

		html += "<dl class='clump-list small'>";

		['Hull', 'Crew', 'Life', 'MovementSpeed', 'RotationSpeed'].forEach(function(key) {
			html += "<dt class='item'>"+key+"</dt><dd class='quantity'>"+self[key]+"</dd>";
		});
		html += "</dl>";
	}

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = SpawnedEntity;
},{"./clump":7,"./lump":12}],20:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');
var Port = require('./port');
var Area = require('./area');

var api;

function TileVariant(raw, parent) {
	this.straightCopy = [
		'Name',
		'HumanName',
		'Description',

		'MaxTilePopulation',
		'MinTilePopulation',
		
		'SeaColour',
		'MusicTrackName',
		'ChanceOfWeather',
		'FogRevealThreshold'
	];

/*
LabelData: Array[6]
PhenomenaData: Array[1]
SpawnPoints: Array[2]
TerrainData: Array[14]
Weather: Array[1]
*/

	raw.Id = parent.Name+"/"+raw.Name;
	Lump.apply(this, arguments);

	this.SettingId = raw.Setting.Id;
	this.setting = null;

	this.ports = new Clump(this.attribs.PortData || [], Port, this);

	this.areas = null;
}
Object.keys(Lump.prototype).forEach(function(member) { TileVariant.prototype[member] = Lump.prototype[member]; });

TileVariant.prototype.wireUp = function(theApi) {

	api = theApi;

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);

	this.ports.forEach(function(p) { p.wireUp(api); });

	// Also create a list of all the areas of each of the ports in this object for convenience
	this.areas = new Clump(this.ports.map(function(p) { return p.area; }), api.types.Area, this);

	Lump.prototype.wireUp.call(this);
};

TileVariant.prototype.toString = function(long) {
	return this.constructor.name + " " + this.HumanName + " (#" + this.Name + ")";
};

TileVariant.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.HumanName+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = TileVariant;
},{"./area":5,"./clump":7,"./lump":12,"./port":13}],21:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');
var TileVariant = require('./tile-variant');
var Port = require('./port');
var Area = require('./area');

var api;

function Tile(raw, parent) {
	this.straightCopy = [
		'Name'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.tileVariants = new Clump(this.attribs.Tiles || [], TileVariant, this);
}
Object.keys(Lump.prototype).forEach(function(member) { Tile.prototype[member] = Lump.prototype[member]; });

Tile.prototype.wireUp = function(theApi) {

	api = theApi;

	this.tileVariants.forEach(function(tv) { tv.wireUp(api); });

	// Also create a list of all the ports and areas of each of the tilevariants in this object for convenience
	var all_ports = {};
	var all_areas = {};
	this.tileVariants.forEach(function(tv) {
		tv.ports.forEach(function(p) {
			all_ports[p.Id] = p;
			all_areas[p.area.Id] = p.area;
		});
	});
	this.ports = new Clump(Object.keys(all_ports).map(function(p) { return all_ports[p]; }), api.types.Port, this);
	this.areas = new Clump(Object.keys(all_areas).map(function(a) { return all_areas[a]; }), api.types.Area, this);

	Lump.prototype.wireUp.call(this);
};

Tile.prototype.toString = function(long) {
	return this.constructor.name + " " + this.Name + " (#" + this.Name + ")";
};

Tile.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Name+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Tile;
},{"./area":5,"./clump":7,"./lump":12,"./port":13,"./tile-variant":20}],22:[function(require,module,exports){
var api = require('./api');
var dragndrop = require('./ui/dragndrop');
var query = require('./ui/query');


$("#tabs .buttons li").on("click", function(e) {

  var type = $(this).attr("data-type");

  $("#tabs .panes .pane").hide(); // Hide all panes
  $("#tabs .buttons li").removeClass("active"); // Deactivate all buttons

  $("#tabs .panes ."+type.toLowerCase()).show();
  $("#tabs .buttons [data-type="+type+"]").addClass("active");
});

// Setup the dnd listeners.
var dropZone = document.getElementById('drop-zone');

dropZone.addEventListener('dragenter', dragndrop.handlers.dragOver, false);
dropZone.addEventListener('dragleave', dragndrop.handlers.dragEnd, false);
dropZone.addEventListener('dragover', dragndrop.handlers.dragOver, false);

dropZone.addEventListener('drop', dragndrop.handlers.dragDrop, false);

document.getElementById('paths-to-node').addEventListener('click', query.pathsToNodeUI, false);

// For convenience
window.api = api;
window.api.query = query;
},{"./api":2,"./ui/dragndrop":23,"./ui/query":24}],23:[function(require,module,exports){
var api = require('../api');
var Clump = require('../objects/clump');
var io = require('../io');

var render = require('./render');

function handleDragOver(evt) {
  evt.stopPropagation();
  evt.preventDefault();

  $("#drop-zone").addClass("drop-target");
}

function handleDragEnd(evt) {
  evt.stopPropagation();
  evt.preventDefault();

  $("#drop-zone").removeClass("drop-target");
}

function handleDragDrop(evt) {

  $("#drop-zone").removeClass("drop-target");

  evt.stopPropagation();
  evt.preventDefault();

  var files = evt.dataTransfer.files; // FileList object.

  // Files is a FileList of File objects. List some properties.
  var output = [];
  io.resetFilesToLoad();

  var processFile = function() {
    io.decrementFilesToLoad();

    if(io.countFilesToLoad() === 0) {
      api.wireUpObjects();
      render.lists();
    }
  };

  for (var i = 0; i < files.length; i++) {
    var f = files[i];
    var filename = escape(f.name);
    var typeName = io.fileObjectMap[filename];
    var Type = api.types[typeName];
    if(Type) {
      io.incrementFilesToLoad();
      api.readFromFile(Type, f, processFile);
      output.push('<li class="success"><strong>', escape(f.name), '</strong> (', f.type || 'n/a', ') - supported: ',
        f.size, ' bytes, last modified: ',
        f.lastModifiedDate ? f.lastModifiedDate.toLocaleDateString() : 'n/a',
        '</li>');
    }
    else {
      output.push('<li class="info"><strong>' , escape(f.name), '</strong> - not supported: skipping</li>');
    }
  }
  document.getElementById('import-file-list').innerHTML = '<ul>' + output.join('') + '</ul>';
}

module.exports = {
	handlers: {
		dragOver: handleDragOver,
		dragEnd: handleDragEnd,
		dragDrop: handleDragDrop
	}
};
},{"../api":2,"../io":3,"../objects/clump":7,"./render":25}],24:[function(require,module,exports){
var api = require('../api');
var Clump = require('../objects/clump');

function RouteNode(node) {
  this.node = node;
  this.children = [];
}

function pathsToNodeUI() {

  var type = document.getElementById('type');
  type = type.options[type.selectedIndex].value;

  var operation = document.getElementById('operation');
  operation = operation.options[operation.selectedIndex].value;

  var id = prompt("Id of "+type);

  if(!id) {  // Cancelled dialogue
    return;
  }

  var item = api.library[type].id(id);

  if(!item) {
    alert("Could not find "+type+" "+id);
    return;
  }

  var root = document.getElementById("query-tree");
  root.innerHTML = "";

  var title = $('.pane.query .pane-title').text("Query: "+item.toString());

  var routes = pathsToNode(item, {});

  if(routes && routes.children.length) {

    routes = filterPathsToNode(routes, operation);

    var top_children = document.createElement("ul");
    top_children.className += "clump-list small";

    routes.children.forEach(function(child_route) {
      var tree = renderPathsToNode(child_route, []);
      top_children.appendChild(tree);
    });

    root.appendChild(top_children);
  }
  else {
    alert("This "+type+" is a root node with no parents that satisfy the conditions");
  }
  
}

function pathsToNode(node, seen, parent) {

  if(seen[node.Id]) {   // Don't recurse into nodes we've already seen
    return false;
  }

  var ancestry = JSON.parse(JSON.stringify(seen));
  ancestry[node.Id] = true;

  var this_node = new RouteNode(/*node.linkToEvent ? node.linkToEvent :*/ node); // If this node is just a link to another one, skip over the useless link

  if(node instanceof api.types.SpawnedEntity) {
    return this_node;   // Leaf node in tree
  }
  else if(node instanceof api.types.Event && node.tag === "use") {
    return this_node;   // Leaf node in tree
  }
  else if(node instanceof api.types.Event && parent instanceof api.types.Event && (parent.tag === "killed" || parent.tag === "pacified")) { // If this is an event that's reachable by killing a monster, don't recurse any other causes (as they're usually misleading/circular)
    return false;
  }
  else if(node instanceof api.types.Setting) {
    return false;
  }
  else if (node instanceof api.types.Port) {
    return new RouteNode(node.area);
  }
  else if(node.limitedToArea && node.limitedToArea.Id !== 101956) {
    var area_name = node.limitedToArea.Name.toLowerCase();
    var event_name = (node.Name && node.Name.toLowerCase()) || "";
    if(area_name.indexOf(event_name) !== -1 || event_name.indexOf(area_name) !== -1) {  // If Area has similar name to Event, ignore the event and just substitute the area
      return new RouteNode(node.limitedToArea);
    }
    else {
      this_node.children.push(new RouteNode(node.limitedToArea));   // Else include both the Area and the Event
      return this_node;
    }
    
  }
  else {
    for(var i=0; i<node.parents.length; i++) {
      var the_parent = node.parents[i];
      var subtree = pathsToNode(the_parent, ancestry, node);
      if(subtree) {
        this_node.children.push(subtree);
      }
    }
    if(!this_node.children.length) {
      return false;
    }
  }

  return this_node;
}

function filterPathsToNode(routes, operation) {
  // Filter routes by operation
  if(routes && routes.children && operation !== "any") {
    routes.children = routes.children.filter(function(route_node) {

      lump = route_node.node;

      if(operation === "additive") {
        return lump.isOneOf([api.types.QualityEffect, api.types.Availability]) && lump.isAdditive();
      }
      else if(operation === "subtractive") {
        return lump.isOneOf([api.types.QualityEffect, api.types.Availability]) && lump.isSubtractive();
      }
    });
  }

  return routes;
}

function renderPathsToNode(routeNode, ancestry) {
  
  if(!(routeNode instanceof RouteNode)) {
    return null;
  }

  var element = routeNode.node.toDom("small", false);
  
  var child_list = document.createElement("ul");
  child_list.className += "clump-list small child-list";

  var new_ancestry = ancestry.slice();
  new_ancestry.push(routeNode.node);
  routeNode.children.forEach(function(child_route, index, children) {
    var child_content = renderPathsToNode(child_route, new_ancestry);
    child_list.appendChild(child_content);
  });

  if(routeNode.children.length) {
    element.appendChild(child_list);
  }
  else {
    var description = document.createElement("li");
    description.innerHTML = '<span class="route-description">HINT: ' + describeRoute(new_ancestry) + '</span>';

    var reqsTitle = document.createElement('h5');
    reqsTitle.innerHTML = "Requirements";
    description.appendChild(reqsTitle);

    var total_requirements = getRouteRequirements(new_ancestry);
    
    description.appendChild(total_requirements.toDom("small", false));
    element.appendChild(description);
  }

  return element;
}

function lower(text) {
  return text.slice(0,1).toLowerCase()+text.slice(1);
}

function describeRoute(ancestry) {
  var a = ancestry.slice().reverse();

  var guide = "";
  if(a[0] instanceof api.types.Area) {
    if(a[1] instanceof api.types.Event) {
      guide = "Seek "+a[1].Name+" in "+a[0].Name;
      if(a[2] instanceof api.types.Interaction) {
        guide += " and ";
        if("\"'".indexOf(a[2].Name[0]) !== -1) {
          guide += "exclaim ";
        }
        guide += lower(a[2].Name);
      }
      guide += ".";
    }
    else {
      guide = "Travel to "+a[0].Name;

      if(a[1] instanceof api.types.Interaction) {
        guide += " and "+lower(a[1].Name);
      }
      else if(a[1] instanceof api.types.Exchange && a[2] instanceof api.types.Shop) {
        guide += " and look for the "+a[2].Name+" Emporium in "+a[1].Name;
      }

      guide += ".";
    }
  }
  else if(a[0] instanceof api.types.SpawnedEntity) {
    guide = "Find and best a "+a[0].HumanName;
    if(a[2] instanceof api.types.Interaction) {
      guide += ", then " + lower(a[2].Name);
    }
    guide += ".";
  }
  else if(a[0] instanceof api.types.Event && a[0].tag === "use" && !(a[1] instanceof api.types.QualityRequirement)) {
    if(a[0].Name.match(/^\s*Speak/i)) {
      guide = a[0].Name;
    }
    else if(a[0].Name.match(/^\s*A/i)) {
      guide = "Acquire "+lower(a[0].Name);
    }
    else {
      guide = "Find a "+lower(a[0].Name);
    }
    guide += " and " + lower(a[1].Name) + ".";
  }

  return guide;
}

function detailRoute(ancestry) {
  var a = ancestry.slice().reverse();

  var guide = "";
  if(a[0] instanceof api.types.Area) {
    if(a[1] instanceof api.types.Event) {
      guide = "You must travel to "+a[0].Name+" and look for "+a[1].Name+".";
      if(a[2] instanceof api.types.Interaction) {
        guide += "  When you find it you should ";
        if("\"'".indexOf(a[2].Name[0]) !== -1) {
          guide += "say ";
        }
        guide += lower(a[2].Name);
      }
      guide += ".";
    }
    else {
      guide = "Make for "+a[0].Name;

      if(a[1] instanceof api.types.Interaction) {
        guide += " and "+lower(a[1].Name);
      }
      else if(a[1] instanceof api.types.Exchange && a[2] instanceof api.types.Shop) {
        guide += ".  Upon arrival go to "+a[1].Name+", and look for the shop "+a[2].Names;
      }

      guide += ".";
    }
  }
  else if(a[0] instanceof api.types.SpawnedEntity) {
    guide = "You must hunt the mythical zee-peril known as the "+a[0].HumanName+", engage it in battle and defeat it.";
    if(a[2] instanceof api.types.Interaction) {
      guide += "  Once you have conquered it you must " + lower(a[2].Name) + " to help secure your prize.";
    }
  }
  else if(a[0] instanceof api.types.Event && a[0].tag === "use" && !(a[1] instanceof api.types.QualityRequirement)) {
    if(a[0].Name.match(/^\s*Speak/i)) {
      guide = "First you must "+lower(a[0].Name);
    }
    else if(a[0].Name.match(/^\s*A/i)) {
      guide = "Source "+lower(a[0].Name);
    }
    else {
      guide = "Try to locate a "+lower(a[0].Name);
    }
    guide += ", and then " + lower(a[1].Name) + ".";
  }

  return guide;
}

function getRouteRequirements(ancestry) {

  var reqs = {};

  // Ancestry is ordered from last->first, so iterate backwards from final effect -> initial cause
  ancestry.forEach(function(step) {
    /* Simplification: if an event modifies a quality then assume that later requirements
    on the same quality are probably satisfied by that modification (eg, when qualities
    are incremented/decremented to control story-quest progress). */
    if(step.qualitiesAffected) {
      step.qualitiesAffected.forEach(function(effect) {
        delete(reqs[effect.associatedQuality.Id]);
      });
    }
    // Now add any requirements for the current stage (earlier requirements overwrite later ones on the same quality)
    if(step.qualitiesRequired) {
      step.qualitiesRequired.forEach(function(req) {
        if(req.associatedQuality) { // Check this is a valid QualityRequirement, and not one of the half-finished debug elements referring to anon-existant Quality
          reqs[req.associatedQuality.Id] = req;
        }
      });
    }
  });

  var result = Object.keys(reqs).map(function(key) { return reqs[key]; });

  return new Clump(result, api.types.QualityRequirement);
}

module.exports = {
  RouteNode: RouteNode,
  pathsToNodeUI: pathsToNodeUI,
  pathsToNode: pathsToNode,
  filterPathsToNode: filterPathsToNode,
  renderPathsToNode: renderPathsToNode,
  describeRoute: describeRoute,
  detailRoute: detailRoute,
  getRouteRequirements: getRouteRequirements
};
},{"../api":2,"../objects/clump":7}],25:[function(require,module,exports){
var api = require('../api');

function renderLists() {
  Object.keys(api.loaded).forEach(function(type) {
    renderList(api.loaded[type]); // Only display directly loaded (root-level) Lumps, to prevent the list becoming unwieldy
  });
}

function renderList(clump) {
	var root = document.getElementById(clump.type.name.toLowerCase()+"-list");
  if(root) {
	 root.appendChild(clump.toDom());
  }
}

module.exports = {
	list: renderList,
	lists: renderLists
};
},{"../api":2}]},{},[2,3,4,22,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,25])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJjb25maWcuanNvbiIsInNyYy9zY3JpcHRzL2FwaS5qcyIsInNyYy9zY3JpcHRzL2lvLmpzIiwic3JjL3NjcmlwdHMvbGlicmFyeS5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvYXJlYS5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvYXZhaWxhYmlsaXR5LmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9jbHVtcC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvY29tYmF0LWF0dGFjay5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvZXZlbnQuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL2V4Y2hhbmdlLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9pbnRlcmFjdGlvbi5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvbHVtcC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvcG9ydC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvcXVhbGl0eS1lZmZlY3QuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3F1YWxpdHktcmVxdWlyZW1lbnQuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3F1YWxpdHkuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3NldHRpbmcuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3Nob3AuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3NwYXduZWQtZW50aXR5LmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy90aWxlLXZhcmlhbnQuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3RpbGUuanMiLCJzcmMvc2NyaXB0cy91aS5qcyIsInNyYy9zY3JpcHRzL3VpL2RyYWduZHJvcC5qcyIsInNyYy9zY3JpcHRzL3VpL3F1ZXJ5LmpzIiwic3JjL3NjcmlwdHMvdWkvcmVuZGVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMxQ0E7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25GQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMUhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNUZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzVHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzVFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeklBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0VBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9EQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeFRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24oKXtmdW5jdGlvbiByKGUsbix0KXtmdW5jdGlvbiBvKGksZil7aWYoIW5baV0pe2lmKCFlW2ldKXt2YXIgYz1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlO2lmKCFmJiZjKXJldHVybiBjKGksITApO2lmKHUpcmV0dXJuIHUoaSwhMCk7dmFyIGE9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitpK1wiJ1wiKTt0aHJvdyBhLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsYX12YXIgcD1uW2ldPXtleHBvcnRzOnt9fTtlW2ldWzBdLmNhbGwocC5leHBvcnRzLGZ1bmN0aW9uKHIpe3ZhciBuPWVbaV1bMV1bcl07cmV0dXJuIG8obnx8cil9LHAscC5leHBvcnRzLHIsZSxuLHQpfXJldHVybiBuW2ldLmV4cG9ydHN9Zm9yKHZhciB1PVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmUsaT0wO2k8dC5sZW5ndGg7aSsrKW8odFtpXSk7cmV0dXJuIG99cmV0dXJuIHJ9KSgpIiwibW9kdWxlLmV4cG9ydHM9e1xyXG5cdFwidGl0bGVcIjogXCJTdW5sZXNzIFNlYVwiLFxyXG5cdFwicGF0aHNcIjoge1xyXG5cdFx0XCJ0ZW1wbGF0ZXNcIjogXCJzcmMvdGVtcGxhdGVzXCIsXHJcblx0XHRcIm1vZEdhbWVKc29uXCI6IFwiYnVpbGQvbW9kdG9vbHMvZ2FtZS1kYXRhL2pzb25cIixcclxuXHRcdFwiYnVpbGRkaXJcIjoge1xyXG5cdFx0XHRcIm1vZFwiOiBcImJ1aWxkL2Nsb2Nrd29yYWNsZS9lbnRpdGllc1wiLFxyXG5cdFx0XHRcInVpXCI6IFwiYnVpbGQvbW9kdG9vbHNcIlxyXG5cdFx0fVxyXG5cdH0sXHJcblx0XCJsb2NhdGlvbnNcIjoge1xyXG5cdFx0XCJpbWFnZXNQYXRoXCI6IFwiZ2FtZS1kYXRhL2ljb25zXCJcclxuXHR9LFxyXG5cdFwiYmFzZUdhbWVJZHNcIjoge1xyXG5cdFx0XCJxdWFsaXR5XCI6IDUwMDAwMCxcclxuXHRcdFwicHJlbGltRXZlbnRcIjogNTAwMDEwLFxyXG5cdFx0XCJidXlPcmFjbGVcIjogNTAwMDAyMCxcclxuXHRcdFwic2VsbE9yYWNsZVwiOiA1MDAwMzAsXHJcblx0XHRcImV2ZW50XCI6IDUwMDAzNSxcclxuXHRcdFwiYWNxdWlyZVwiOiA2MDAwMDAsXHJcblx0XHRcImxlYXJuXCI6IDcwMDAwMCxcclxuXHRcdFwic3VmZmVyXCI6IDgwMDAwMCxcclxuXHRcdFwiYmVjb21lXCI6IDkwMDAwMFxyXG5cdH1cclxufSIsInZhciBjb25maWcgPSByZXF1aXJlKCcuLi8uLi9jb25maWcuanNvbicpO1xyXG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL29iamVjdHMvY2x1bXAnKTtcclxudmFyIEx1bXAgPSByZXF1aXJlKCcuL29iamVjdHMvbHVtcCcpO1xyXG5cclxudmFyIGlvID0gcmVxdWlyZSgnLi9pbycpO1xyXG5cclxudmFyIGxpYnJhcnkgPSByZXF1aXJlKCcuL2xpYnJhcnknKTtcclxudmFyIGxvYWRlZCA9IHt9O1xyXG5cclxudmFyIHR5cGVzID0ge1xyXG4gIFF1YWxpdHk6IHJlcXVpcmUoJy4vb2JqZWN0cy9xdWFsaXR5JyksXHJcbiAgRXZlbnQ6IHJlcXVpcmUoJy4vb2JqZWN0cy9ldmVudCcpLFxyXG4gIEludGVyYWN0aW9uOiByZXF1aXJlKCcuL29iamVjdHMvaW50ZXJhY3Rpb24nKSxcclxuICBRdWFsaXR5RWZmZWN0OiByZXF1aXJlKCcuL29iamVjdHMvcXVhbGl0eS1lZmZlY3QnKSxcclxuICBRdWFsaXR5UmVxdWlyZW1lbnQ6IHJlcXVpcmUoJy4vb2JqZWN0cy9xdWFsaXR5LXJlcXVpcmVtZW50JyksXHJcbiAgQXJlYTogcmVxdWlyZSgnLi9vYmplY3RzL2FyZWEnKSxcclxuICBTcGF3bmVkRW50aXR5OiByZXF1aXJlKCcuL29iamVjdHMvc3Bhd25lZC1lbnRpdHknKSxcclxuICBDb21iYXRBdHRhY2s6IHJlcXVpcmUoJy4vb2JqZWN0cy9jb21iYXQtYXR0YWNrJyksXHJcbiAgRXhjaGFuZ2U6IHJlcXVpcmUoJy4vb2JqZWN0cy9leGNoYW5nZScpLFxyXG4gIFNob3A6IHJlcXVpcmUoJy4vb2JqZWN0cy9zaG9wJyksXHJcbiAgQXZhaWxhYmlsaXR5OiByZXF1aXJlKCcuL29iamVjdHMvYXZhaWxhYmlsaXR5JyksXHJcbiAgVGlsZTogcmVxdWlyZSgnLi9vYmplY3RzL3RpbGUnKSxcclxuICBUaWxlVmFyaWFudDogcmVxdWlyZSgnLi9vYmplY3RzL3RpbGUtdmFyaWFudCcpLFxyXG4gIFBvcnQ6IHJlcXVpcmUoJy4vb2JqZWN0cy9wb3J0JyksXHJcbiAgU2V0dGluZzogcmVxdWlyZSgnLi9vYmplY3RzL3NldHRpbmcnKVxyXG59O1xyXG5cclxuLy8gUHJlcG9wdWxhdGUgbGlicmFyeSB3aXRoIENsdW1wcyBvZiBlYWNoIHR5cGUgd2Uga25vdyBhYm91dFxyXG5PYmplY3Qua2V5cyh0eXBlcykuZm9yRWFjaChmdW5jdGlvbih0eXBlTmFtZSkge1xyXG5cdHZhciBUeXBlID0gdHlwZXNbdHlwZU5hbWVdO1xyXG5cdGlmKCFsaWJyYXJ5W3R5cGVOYW1lXSkge1xyXG5cdFx0bGlicmFyeVt0eXBlTmFtZV0gPSBuZXcgQ2x1bXAoW10sIFR5cGUpO1xyXG5cdFx0bG9hZGVkW3R5cGVOYW1lXSA9IG5ldyBDbHVtcChbXSwgVHlwZSk7XHJcblx0fVxyXG59KTtcclxuXHJcbmZ1bmN0aW9uIGdldChUeXBlLCBpZCwgcGFyZW50KSB7XHJcblx0dmFyIHR5cGVuYW1lID0gVHlwZS5uYW1lO1x0Ly8gRXZlbnQsIFF1YWxpdHksIEludGVyYWN0aW9uLCBldGNcclxuXHJcblx0dmFyIGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkID0gbGlicmFyeVt0eXBlbmFtZV0uaWQoaWQpO1xyXG5cdGlmKGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkKSB7XHJcblx0XHQvL2NvbnNvbGUubG9nKFwiQXR0YWNoZWQgZXhpc3RpbmcgXCIgKyBleGlzdGluZ1RoaW5nV2l0aFRoaXNJZCArIFwiIHRvIFwiICsgdGhpcy50b1N0cmluZygpKVxyXG5cdFx0dmFyIG5ld1BhcmVudCA9IHRydWU7XHJcblx0XHRleGlzdGluZ1RoaW5nV2l0aFRoaXNJZC5wYXJlbnRzLmZvckVhY2goZnVuY3Rpb24ocCkge1xyXG5cdFx0XHRpZihwLklkID09PSBwYXJlbnQuSWQgJiYgcC5jb25zdHJ1Y3Rvci5uYW1lID09PSBwYXJlbnQuY29uc3RydWN0b3IubmFtZSkge1xyXG5cdFx0XHRcdG5ld1BhcmVudCA9IGZhbHNlO1xyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHRcdGlmKG5ld1BhcmVudCl7XHJcblx0XHRcdGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkLnBhcmVudHMucHVzaChwYXJlbnQpO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmKCFleGlzdGluZ1RoaW5nV2l0aFRoaXNJZC53aXJlZCkge1xyXG5cdFx0XHRleGlzdGluZ1RoaW5nV2l0aFRoaXNJZC53aXJlVXAodGhpcyk7XHQvLyBQYXNzIGluIHRoZSBhcGkgc28gb2JqZWN0IGNhbiBhZGQgaXRzZWxmIHRvIHRoZSBtYXN0ZXItbGlicmFyeVxyXG5cdFx0fVxyXG5cdFx0cmV0dXJuIGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkO1xyXG5cdH1cclxuXHRlbHNlIHtcclxuXHRcdHJldHVybiBudWxsO1xyXG5cdH1cclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0T3JDcmVhdGUoVHlwZSwgcG9zc05ld1RoaW5nLCBwYXJlbnQpIHtcdC8vIElmIGFuIG9iamVjdCBhbHJlYWR5IGV4aXN0cyB3aXRoIHRoaXMgSUQsIHVzZSB0aGF0LiAgT3RoZXJ3aXNlIGNyZWF0ZSBhIG5ldyBvYmplY3QgZnJvbSB0aGUgc3VwcGxpZWQgZGV0YWlscyBoYXNoXHJcblx0dmFyIHR5cGVuYW1lID0gVHlwZS5uYW1lO1x0Ly8gRXZlbnQsIFF1YWxpdHksIEludGVyYWN0aW9uLCBldGNcclxuXHRpZihwb3NzTmV3VGhpbmcpIHtcclxuICBcdHZhciBleGlzdGluZ1RoaW5nV2l0aFRoaXNJZCA9IHRoaXMuZ2V0KFR5cGUsIHBvc3NOZXdUaGluZy5JZCwgcGFyZW50KTtcclxuICBcdGlmKGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkKSB7XHJcbiAgXHRcdHJldHVybiBleGlzdGluZ1RoaW5nV2l0aFRoaXNJZDtcclxuICBcdH1cclxuICBcdGVsc2Uge1xyXG5cdFx0XHR2YXIgbmV3VGhpbmcgPSBuZXcgVHlwZShwb3NzTmV3VGhpbmcsIHBhcmVudCk7XHJcblx0XHRcdG5ld1RoaW5nLndpcmVVcCh0aGlzKTtcclxuXHRcdFx0Ly9jb25zb2xlLmxvZyhcIlJlY3Vyc2l2ZWx5IGNyZWF0ZWQgXCIgKyBuZXdUaGluZyArIFwiIGZvciBcIiArIHRoaXMudG9TdHJpbmcoKSk7XHJcblx0XHRcdHJldHVybiBuZXdUaGluZztcclxuXHRcdH1cclxuXHR9XHJcblx0ZWxzZSB7XHJcblx0XHRyZXR1cm4gbnVsbDtcclxuXHR9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHdpcmVVcE9iamVjdHMoKSB7XHJcblx0dmFyIGFwaSA9IHRoaXM7XHJcbiAgT2JqZWN0LmtleXModHlwZXMpLmZvckVhY2goZnVuY3Rpb24odHlwZSkge1xyXG4gICAgbGlicmFyeVt0eXBlXS5mb3JFYWNoKGZ1bmN0aW9uKGx1bXApIHtcclxuICAgICAgaWYobHVtcC53aXJlVXApIHtcclxuICAgICAgICBsdW1wLndpcmVVcChhcGkpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxudmFyIHdoYXRJcyA9IGZ1bmN0aW9uKGlkKSB7XHJcbiAgdmFyIHBvc3NpYmlsaXRpZXMgPSBbXTtcclxuICBPYmplY3Qua2V5cyhsaWJyYXJ5KS5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xyXG4gICAgaWYobGlicmFyeVtrZXldIGluc3RhbmNlb2YgQ2x1bXAgJiYgbGlicmFyeVtrZXldLmlkKGlkKSkge1xyXG4gICAgICBwb3NzaWJpbGl0aWVzLnB1c2goa2V5KTtcclxuICAgIH1cclxuICB9KTtcclxuICByZXR1cm4gcG9zc2liaWxpdGllcztcclxufTtcclxuXHJcbmZ1bmN0aW9uIGRlc2NyaWJlQWR2YW5jZWRFeHByZXNzaW9uKGV4cHIpIHtcclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0aWYoZXhwcikge1xyXG5cdFx0ZXhwciA9IGV4cHIucmVwbGFjZSgvXFxbZDooXFxkKylcXF0vZ2ksIFwiUkFORE9NWzEtJDFdXCIpO1x0Ly8gW2Q6eF0gPSByYW5kb20gbnVtYmVyIGZyb20gMS14KD8pXHJcblx0XHRleHByID0gZXhwci5yZXBsYWNlKC9cXFtxOihcXGQrKVxcXS9naSwgZnVuY3Rpb24obWF0Y2gsIGJhY2tyZWYsIHBvcywgd2hvbGVfc3RyKSB7XHJcblx0XHRcdHZhciBxdWFsaXR5ID0gc2VsZi5saWJyYXJ5LlF1YWxpdHkuaWQoYmFja3JlZik7XHJcblx0XHRcdHJldHVybiBcIltcIisocXVhbGl0eSA/IHF1YWxpdHkuTmFtZSA6ICdJTlZBTElEJykrXCJdXCI7XHJcblx0XHR9KTtcclxuXHJcblx0XHRyZXR1cm4gZXhwcjtcclxuXHR9XHJcblx0cmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlYWRGcm9tRmlsZShUeXBlLCBmaWxlLCBjYWxsYmFjaykge1xyXG5cdGlvLnJlYWRGaWxlKGZpbGUsIGZ1bmN0aW9uIChlKSB7XHJcbiAgICB2YXIgY29udGVudHMgPSBlLnRhcmdldC5yZXN1bHQ7XHJcbiAgICBcclxuICAgIHZhciBvYmogPSBKU09OLnBhcnNlKGNvbnRlbnRzKTtcclxuICAgIGxvYWRlZFtUeXBlLnByb3RvdHlwZS5jb25zdHJ1Y3Rvci5uYW1lXSA9IG5ldyBDbHVtcChvYmosIFR5cGUpO1xyXG5cclxuICAgIGNhbGxiYWNrKGNvbnRlbnRzLCBUeXBlLCBsb2FkZWRbVHlwZS5wcm90b3R5cGUuY29uc3RydWN0b3IubmFtZV0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG5cclxubW9kdWxlLmV4cG9ydHMgPSB7XHJcblx0J0NsdW1wJzogQ2x1bXAsXHJcblx0J0x1bXAnOiBMdW1wLFxyXG5cdCdjb25maWcnOiBjb25maWcsXHJcblx0J3R5cGVzJzogdHlwZXMsXHJcblx0J2xpYnJhcnknOiBsaWJyYXJ5LFxyXG5cdCdsb2FkZWQnOiBsb2FkZWQsXHJcblx0J2dldCc6IGdldCxcclxuXHQnd2hhdElzJzogd2hhdElzLFxyXG5cdCd3aXJlVXBPYmplY3RzJzogd2lyZVVwT2JqZWN0cyxcclxuXHQnZ2V0T3JDcmVhdGUnOiBnZXRPckNyZWF0ZSxcclxuXHQnZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24nOiBkZXNjcmliZUFkdmFuY2VkRXhwcmVzc2lvbixcclxuXHQncmVhZEZyb21GaWxlJzogcmVhZEZyb21GaWxlXHJcbn07IiwidmFyIGZpbGVPYmplY3RNYXAgPSB7XHJcbiAgICAnZXZlbnRzLmpzb24nIDogJ0V2ZW50JyxcclxuICAgICdxdWFsaXRpZXMuanNvbicgOiAnUXVhbGl0eScsXHJcbiAgICAnYXJlYXMuanNvbicgOiAnQXJlYScsXHJcbiAgICAnU3Bhd25lZEVudGl0aWVzLmpzb24nIDogJ1NwYXduZWRFbnRpdHknLFxyXG4gICAgJ0NvbWJhdEF0dGFja3MuanNvbicgOiAnQ29tYmF0QXR0YWNrJyxcclxuICAgICdleGNoYW5nZXMuanNvbicgOiAnRXhjaGFuZ2UnLFxyXG4gICAgJ1RpbGVzLmpzb24nOiAnVGlsZSdcclxuICB9O1xyXG5cclxuZnVuY3Rpb24gcmVhZEZpbGUoZmlsZSwgY2FsbGJhY2spIHtcclxuICBmaWxlLnRleHQoKVxyXG4gICAgLnRoZW4oZnVuY3Rpb24oY29udGVudHMpIHtcclxuICAgICAgY2FsbGJhY2soeyB0YXJnZXQ6IHsgcmVzdWx0OiBjb250ZW50cyB9IH0pO1xyXG4gICAgfSlcclxuICAgIC5jYXRjaChmdW5jdGlvbihlcnIpIHtcclxuICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHsgdGhyb3cgZXJyOyB9LCAwKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG52YXIgZmlsZXNfdG9fbG9hZCA9IDA7XHJcbmZ1bmN0aW9uIHJlc2V0RmlsZXNUb0xvYWQoKSB7XHJcblx0ZmlsZXNfdG9fbG9hZCA9IDA7XHJcbn1cclxuZnVuY3Rpb24gaW5jcmVtZW50RmlsZXNUb0xvYWQoKSB7XHJcblx0ZmlsZXNfdG9fbG9hZCsrO1xyXG59XHJcbmZ1bmN0aW9uIGRlY3JlbWVudEZpbGVzVG9Mb2FkKCkge1xyXG5cdGZpbGVzX3RvX2xvYWQtLTtcclxufVxyXG5mdW5jdGlvbiBjb3VudEZpbGVzVG9Mb2FkKCkge1xyXG5cdHJldHVybiBmaWxlc190b19sb2FkO1xyXG59XHJcblxyXG5cclxubW9kdWxlLmV4cG9ydHMgPSB7XHJcbiAgcmVhZEZpbGU6IHJlYWRGaWxlLFxyXG4gIHJlc2V0RmlsZXNUb0xvYWQ6IHJlc2V0RmlsZXNUb0xvYWQsXHJcblx0aW5jcmVtZW50RmlsZXNUb0xvYWQ6IGluY3JlbWVudEZpbGVzVG9Mb2FkLFxyXG5cdGRlY3JlbWVudEZpbGVzVG9Mb2FkOiBkZWNyZW1lbnRGaWxlc1RvTG9hZCxcclxuXHRjb3VudEZpbGVzVG9Mb2FkOiBjb3VudEZpbGVzVG9Mb2FkLFxyXG4gIGZpbGVPYmplY3RNYXA6IGZpbGVPYmplY3RNYXBcclxufTsiLCJtb2R1bGUuZXhwb3J0cyA9IHt9OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XHJcblxyXG52YXIgYXBpO1xyXG5cclxuZnVuY3Rpb24gQXJlYShyYXcpIHtcclxuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcIk5hbWVcIiwgXCJEZXNjcmlwdGlvblwiLCBcIkltYWdlTmFtZVwiLCBcIk1vdmVNZXNzYWdlXCJdO1xyXG5cdEx1bXAuY2FsbCh0aGlzLCByYXcpO1xyXG59XHJcbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBBcmVhLnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XHJcblxyXG5BcmVhLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcclxuXHRhcGkgPSB0aGVBcGk7XHJcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcyk7XHJcbn07XHJcblxyXG5BcmVhLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xyXG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiBcIiArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XHJcbn07XHJcblxyXG5BcmVhLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUpIHtcclxuXHJcblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcclxuXHJcblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xyXG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcclxuXHJcblx0aWYodGhpcy5JbWFnZU5hbWUgIT09IG51bGwgJiYgdGhpcy5JbWFnZSAhPT0gXCJcIikge1xyXG5cdFx0ZWxlbWVudC5pbm5lckhUTUwgPSBcIjxpbWcgY2xhc3M9J2ljb24nIHNyYz0nXCIrYXBpLmNvbmZpZy5sb2NhdGlvbnMuaW1hZ2VzUGF0aCtcIi9cIit0aGlzLkltYWdlTmFtZStcIi5wbmcnIC8+XCI7XHJcblx0fVxyXG5cclxuXHRlbGVtZW50LmlubmVySFRNTCArPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XFxuPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xyXG5cclxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gQXJlYTsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xyXG5cclxudmFyIGFwaTtcclxuXHJcbmZ1bmN0aW9uIEF2YWlsYWJpbGl0eShyYXcsIHBhcmVudCkge1xyXG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xyXG5cdFx0J0Nvc3QnLFxyXG5cdFx0J1NlbGxQcmljZSdcclxuXHRdO1xyXG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcclxuXHJcblx0dGhpcy5xdWFsaXR5ID0gbnVsbDtcclxuXHR0aGlzLnB1cmNoYXNlUXVhbGl0eSA9IG51bGw7XHJcbn1cclxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IEF2YWlsYWJpbGl0eS5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xyXG5cclxuQXZhaWxhYmlsaXR5LnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcclxuXHJcblx0YXBpID0gdGhlQXBpO1xyXG5cclxuXHR0aGlzLnF1YWxpdHkgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5RdWFsaXR5LCB0aGlzKTtcclxuXHR0aGlzLnB1cmNoYXNlUXVhbGl0eSA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuUXVhbGl0eSwgdGhpcy5hdHRyaWJzLlB1cmNoYXNlUXVhbGl0eSwgdGhpcyk7XHJcblxyXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XHJcbn07XHJcblxyXG5BdmFpbGFiaWxpdHkucHJvdG90eXBlLmlzQWRkaXRpdmUgPSBmdW5jdGlvbigpIHtcclxuXHRyZXR1cm4gdGhpcy5Db3N0ID4gMDtcclxufTtcclxuXHJcbkF2YWlsYWJpbGl0eS5wcm90b3R5cGUuaXNTdWJ0cmFjdGl2ZSA9IGZ1bmN0aW9uKCkge1xyXG5cdHJldHVybiB0aGlzLlNlbGxQcmljZSA+IDA7XHJcbn07XHJcblxyXG5BdmFpbGFiaWxpdHkucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XHJcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5xdWFsaXR5ICsgXCIgKGJ1eTogXCIgKyB0aGlzLkNvc3QgKyBcInhcIiArIHRoaXMucHVyY2hhc2VRdWFsaXR5Lk5hbWUgKyBcIiAvIHNlbGw6IFwiICsgdGhpcy5TZWxsUHJpY2UgKyBcInhcIiArIHRoaXMucHVyY2hhc2VRdWFsaXR5Lk5hbWUgKyBcIilcIjtcclxufTtcclxuXHJcbkF2YWlsYWJpbGl0eS5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplKSB7XHJcblxyXG5cdHNpemUgPSBzaXplIHx8IFwic21hbGxcIjtcclxuXHJcblx0dmFyIGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XHJcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xyXG5cdFxyXG5cdHZhciBwdXJjaGFzZV9xdWFsaXR5X2VsZW1lbnQ7XHJcblxyXG5cdGlmKCF0aGlzLnF1YWxpdHkpIHtcclxuXHRcdHB1cmNoYXNlX3F1YWxpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xyXG5cdFx0cHVyY2hhc2VfcXVhbGl0eV9lbGVtZW50LmlubmVySFRNTCA9IFwiW0lOVkFMSURdXCI7XHJcblx0fVxyXG5cdGVsc2Uge1xyXG5cdFx0cHVyY2hhc2VfcXVhbGl0eV9lbGVtZW50ID0gdGhpcy5xdWFsaXR5LnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwic3BhblwiKTtcclxuXHR9XHJcblxyXG5cdHZhciBjdXJyZW5jeV9xdWFsaXR5X2VsZW1lbnQgPSB0aGlzLnB1cmNoYXNlUXVhbGl0eS50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInNwYW5cIik7XHJcblx0Y3VycmVuY3lfcXVhbGl0eV9lbGVtZW50LmNsYXNzTmFtZSA9IFwicXVhbnRpdHkgaXRlbSBzbWFsbFwiO1xyXG5cdHZhciBjdXJyZW5jeV9xdWFsaXR5X21hcmt1cCA9IGN1cnJlbmN5X3F1YWxpdHlfZWxlbWVudC5vdXRlckhUTUw7XHJcblxyXG5cdHZhciBjdXJyZW5jeV9idXlfYW1vdW50X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcclxuXHRjdXJyZW5jeV9idXlfYW1vdW50X2VsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIHF1YW50aXR5XCI7XHJcblx0Y3VycmVuY3lfYnV5X2Ftb3VudF9lbGVtZW50LmlubmVySFRNTCA9IFwiQnV5OiBcIiArICh0aGlzLkNvc3QgPyB0aGlzLkNvc3QrXCJ4XCIgOiBcIiYjMTAwMDc7XCIpO1xyXG5cdGN1cnJlbmN5X2J1eV9hbW91bnRfZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcclxuXHJcblx0dmFyIGN1cnJlbmN5X3NlbGxfYW1vdW50X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcclxuXHRjdXJyZW5jeV9zZWxsX2Ftb3VudF9lbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBxdWFudGl0eVwiO1xyXG5cdGN1cnJlbmN5X3NlbGxfYW1vdW50X2VsZW1lbnQuaW5uZXJIVE1MID0gXCJTZWxsOiBcIiArICh0aGlzLlNlbGxQcmljZSA/IHRoaXMuU2VsbFByaWNlK1wieFwiIDogXCImIzEwMDA3O1wiKTtcclxuXHRjdXJyZW5jeV9zZWxsX2Ftb3VudF9lbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xyXG5cclxuXHJcblx0ZWxlbWVudC5hcHBlbmRDaGlsZChwdXJjaGFzZV9xdWFsaXR5X2VsZW1lbnQpO1xyXG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY3VycmVuY3lfYnV5X2Ftb3VudF9lbGVtZW50KTtcclxuXHRpZih0aGlzLkNvc3QpIHtcclxuXHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoJChjdXJyZW5jeV9xdWFsaXR5X21hcmt1cClbMF0pO1xyXG5cdH1cclxuXHRlbGVtZW50LmFwcGVuZENoaWxkKGN1cnJlbmN5X3NlbGxfYW1vdW50X2VsZW1lbnQpO1xyXG5cdGlmKHRoaXMuU2VsbFByaWNlKSB7XHJcblx0XHRlbGVtZW50LmFwcGVuZENoaWxkKCQoY3VycmVuY3lfcXVhbGl0eV9tYXJrdXApWzBdKTtcclxuXHR9XHJcblxyXG5cdHJldHVybiBlbGVtZW50O1xyXG59O1xyXG5cclxubW9kdWxlLmV4cG9ydHMgPSBBdmFpbGFiaWxpdHk7IiwiXHJcbmZ1bmN0aW9uIENsdW1wKHJhdywgVHlwZSwgcGFyZW50KSB7XHJcblx0dGhpcy50eXBlID0gVHlwZTtcclxuXHR0aGlzLml0ZW1zID0ge307XHJcblx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdHJhdy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0sIGluZGV4LCBjb2xsZWN0aW9uKSB7XHJcblx0XHRpZighKGl0ZW0gaW5zdGFuY2VvZiBUeXBlKSkge1xyXG5cdFx0XHRpdGVtID0gbmV3IFR5cGUoaXRlbSwgcGFyZW50KTtcclxuXHRcdH1cclxuXHRcdGVsc2UgaWYocGFyZW50KSB7XHJcblx0XHRcdHZhciBuZXdQYXJlbnQgPSB0cnVlO1xyXG5cdFx0XHRpdGVtLnBhcmVudHMuZm9yRWFjaChmdW5jdGlvbihwKSB7XHJcblx0XHRcdFx0aWYocC5JZCA9PT0gcGFyZW50LklkICYmIHAuY29uc3RydWN0b3IubmFtZSA9PT0gcGFyZW50LmNvbnN0cnVjdG9yLm5hbWUpIHtcclxuXHRcdFx0XHRcdG5ld1BhcmVudCA9IGZhbHNlO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSk7XHJcblx0XHRcdGlmKG5ld1BhcmVudCl7XHJcblx0XHRcdFx0aXRlbS5wYXJlbnRzLnB1c2gocGFyZW50KTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0aWYoc2VsZi5pdGVtc1tpdGVtLklkXSkge1xyXG5cdFx0XHRjb25zb2xlLndhcm4oVHlwZS5uYW1lK1wiIFwiK2l0ZW0uSWQrXCIgYWxyZWFkeSBleGlzdHMgaW4gdGhpcyBjbHVtcC4gIER1cGxpY2F0ZWQgSURzIGZvciBkaWZmZXJlbnQgb2JqZWN0cyBpbiB0aGUgZ2FtZS1qc29uP1wiKTtcclxuXHRcdH1cclxuXHRcdHNlbGYuaXRlbXNbaXRlbS5JZF0gPSBpdGVtO1xyXG5cdH0pO1xyXG59XHJcblxyXG5DbHVtcC5wcm90b3R5cGUuZW1wdHkgPSBmdW5jdGlvbigpIHtcclxuXHRyZXR1cm4gISF0aGlzLnNpemUoKTtcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5zaXplID0gZnVuY3Rpb24oKSB7XHJcblx0cmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuaXRlbXMpLmxlbmd0aDtcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbihpbmRleCkge1xyXG5cdGZvcih2YXIgaWQgaW4gdGhpcy5pdGVtcykge1xyXG5cdFx0aWYoaW5kZXggPT09IDApIHtcclxuXHRcdFx0cmV0dXJuIHRoaXMuaXRlbXNbaWRdO1xyXG5cdFx0fVxyXG5cdFx0aW5kZXgtLTtcclxuXHR9XHJcbn07XHJcblxyXG5DbHVtcC5wcm90b3R5cGUuaWQgPSBmdW5jdGlvbihpZCkge1xyXG5cdHJldHVybiB0aGlzLml0ZW1zW2lkXTtcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5lYWNoID0gZnVuY3Rpb24oKSB7XHJcblx0dmFyIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMpO1xyXG5cdHJldHVybiB0aGlzLm1hcChmdW5jdGlvbihpdGVtKSB7XHJcblxyXG5cdFx0aWYoYXJnc1swXSBpbnN0YW5jZW9mIEFycmF5KSB7XHQvLyBQYXNzZWQgaW4gYXJyYXkgb2YgZmllbGRzLCBzbyByZXR1cm4gdmFsdWVzIGNvbmNhdGVuYXRlZCB3aXRoIG9wdGlvbmFsIHNlcGFyYXRvclxyXG5cdFx0XHR2YXIgc2VwYXJhdG9yID0gKHR5cGVvZiBhcmdzWzFdID09PSBcInVuZGVmaW5lZFwiKSA/IFwiLVwiIDogYXJnc1sxXTtcclxuXHRcdFx0cmV0dXJuIGFyZ3NbMF0ubWFwKGZ1bmN0aW9uKGYpIHsgcmV0dXJuIGl0ZW1bZl07IH0pLmpvaW4oc2VwYXJhdG9yKTtcclxuXHRcdH1cclxuXHRcdGVsc2UgaWYoYXJncy5sZW5ndGggPiAxKSB7XHQvLyBQYXNzZWQgaW4gc2VwYXJhdGUgZmllbGRzLCBzbyByZXR1cm4gYXJyYXkgb2YgdmFsdWVzXHJcblx0XHRcdHJldHVybiBhcmdzLm1hcChmdW5jdGlvbihmKSB7IHJldHVybiBpdGVtW2ZdOyB9KTtcclxuXHRcdH1cclxuXHRcdGVsc2Uge1xyXG5cdFx0XHRyZXR1cm4gaXRlbVthcmdzWzBdXTtcclxuXHRcdH1cclxuXHR9KTtcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5mb3JFYWNoID0gZnVuY3Rpb24oY2FsbGJhY2spIHtcclxuXHRmb3IodmFyIGlkIGluIHRoaXMuaXRlbXMpIHtcclxuXHRcdHZhciBpdGVtID0gdGhpcy5pdGVtc1tpZF07XHJcblx0XHRjYWxsYmFjayhpdGVtLCBpZCwgdGhpcy5pdGVtcyk7XHJcblx0fVxyXG59O1xyXG5cclxuQ2x1bXAucHJvdG90eXBlLm1hcCA9IGZ1bmN0aW9uKGNhbGxiYWNrKSB7XHJcblx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdHZhciBhcnJheU9mSXRlbXMgPSBPYmplY3Qua2V5cyh0aGlzLml0ZW1zKS5tYXAoZnVuY3Rpb24oa2V5KSB7XHJcblx0XHRyZXR1cm4gc2VsZi5pdGVtc1trZXldO1xyXG5cdH0pO1xyXG5cdHJldHVybiBhcnJheU9mSXRlbXMubWFwLmNhbGwoYXJyYXlPZkl0ZW1zLCBjYWxsYmFjayk7XHJcbn07XHJcblxyXG5DbHVtcC5wcm90b3R5cGUuc29ydEJ5ID0gZnVuY3Rpb24oZmllbGQsIHJldmVyc2UpIHtcclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0dmFyIG9ianMgPSBPYmplY3Qua2V5cyh0aGlzLml0ZW1zKS5tYXAoZnVuY3Rpb24oa2V5KSB7XHJcblx0XHRyZXR1cm4gc2VsZi5pdGVtc1trZXldO1xyXG5cdH0pLnNvcnQoZnVuY3Rpb24oYSwgYikge1xyXG5cdFx0aWYoYVtmaWVsZF0gPCBiW2ZpZWxkXSkge1xyXG5cdFx0XHRyZXR1cm4gLTE7XHJcblx0XHR9XHJcblx0XHRpZihhW2ZpZWxkXSA9PT0gYltmaWVsZF0pIHtcclxuXHRcdFx0cmV0dXJuIDA7XHJcblx0XHR9XHJcblx0XHRpZihhW2ZpZWxkXSA+IGJbZmllbGRdKSB7XHJcblx0XHRcdHJldHVybiAxO1xyXG5cdFx0fVxyXG5cdH0pO1xyXG5cclxuXHRyZXR1cm4gcmV2ZXJzZSA/IG9ianMucmV2ZXJzZSgpIDogb2JqcztcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5zYW1lID0gZnVuY3Rpb24oKSB7XHJcblx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cclxuXHR2YXIgY2xvbmUgPSBmdW5jdGlvbihvYmopIHtcclxuICAgIHZhciB0YXJnZXQgPSB7fTtcclxuICAgIGZvciAodmFyIGkgaW4gb2JqKSB7XHJcbiAgICBcdGlmIChvYmouaGFzT3duUHJvcGVydHkoaSkpIHtcclxuICAgIFx0XHRpZih0eXBlb2Ygb2JqW2ldID09PSBcIm9iamVjdFwiKSB7XHJcbiAgICBcdFx0XHR0YXJnZXRbaV0gPSBjbG9uZShvYmpbaV0pO1xyXG4gICAgXHRcdH1cclxuICAgIFx0XHRlbHNlIHtcclxuICAgICAgXHRcdHRhcmdldFtpXSA9IG9ialtpXTtcclxuICAgICAgXHR9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiB0YXJnZXQ7XHJcbiAgfTtcclxuXHJcblx0dmFyIHRlbXBsYXRlID0gY2xvbmUodGhpcy5nZXQoMCkuYXR0cmlicyk7XHJcblxyXG5cdGZvcih2YXIgaWQgaW4gdGhpcy5pdGVtcykge1xyXG5cdFx0dmFyIG90aGVyT2JqID0gdGhpcy5pdGVtc1tpZF0uYXR0cmlicztcclxuXHRcdGZvcih2YXIga2V5IGluIHRlbXBsYXRlKSB7XHJcblx0XHRcdGlmKHRlbXBsYXRlW2tleV0gIT09IG90aGVyT2JqW2tleV0pIHtcclxuXHRcdFx0XHRkZWxldGUodGVtcGxhdGVba2V5XSk7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdHJldHVybiB0ZW1wbGF0ZTtcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5kaXN0aW5jdCA9IGZ1bmN0aW9uKGZpZWxkKSB7XHJcblx0dmFyIHNhbXBsZVZhbHVlcyA9IHt9O1xyXG5cdHRoaXMuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XHJcblx0XHR2YXIgdmFsdWUgPSBpdGVtW2ZpZWxkXTtcclxuXHRcdHNhbXBsZVZhbHVlc1t2YWx1ZV0gPSB2YWx1ZTtcdC8vIENoZWFwIGRlLWR1cGluZyB3aXRoIGEgaGFzaFxyXG5cdH0pO1xyXG5cdHJldHVybiBPYmplY3Qua2V5cyhzYW1wbGVWYWx1ZXMpLm1hcChmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHNhbXBsZVZhbHVlc1trZXldOyB9KTtcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5kaXN0aW5jdFJhdyA9IGZ1bmN0aW9uKGZpZWxkKSB7XHJcblx0dmFyIHNhbXBsZVZhbHVlcyA9IHt9O1xyXG5cdHRoaXMuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XHJcblx0XHR2YXIgdmFsdWUgPSBpdGVtLmF0dHJpYnNbZmllbGRdO1xyXG5cdFx0c2FtcGxlVmFsdWVzW3ZhbHVlXSA9IHZhbHVlO1x0Ly8gQ2hlYXAgZGUtZHVwaW5nIHdpdGggYSBoYXNoXHJcblx0fSk7XHJcblx0cmV0dXJuIE9iamVjdC5rZXlzKHNhbXBsZVZhbHVlcykubWFwKGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gc2FtcGxlVmFsdWVzW2tleV07IH0pO1xyXG59O1xyXG5cclxuQ2x1bXAucHJvdG90eXBlLnF1ZXJ5ID0gZnVuY3Rpb24oZmllbGQsIHZhbHVlKSB7XHJcblx0dmFyIG1hdGNoZXMgPSBbXTtcclxuXHR2YXIgdGVzdDtcclxuXHJcblx0Ly8gV29yayBvdXQgd2hhdCBzb3J0IG9mIGNvbXBhcmlzb24gdG8gZG86XHJcblxyXG5cdGlmKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XHQvLyBJZiB2YWx1ZSBpcyBhIGZ1bmN0aW9uLCBwYXNzIGl0IHRoZSBjYW5kaWRhdGUgYW5kIHJldHVybiB0aGUgcmVzdWx0XHJcblx0XHR0ZXN0ID0gZnVuY3Rpb24oY2FuZGlkYXRlKSB7XHJcblx0XHRcdHJldHVybiAhIXZhbHVlKGNhbmRpZGF0ZSk7XHJcblx0XHR9O1xyXG5cdH1cclxuXHRlbHNlIGlmKHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIikge1xyXG5cdFx0aWYodmFsdWUgaW5zdGFuY2VvZiBSZWdFeHApIHtcclxuXHRcdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xyXG5cdFx0XHRcdHJldHVybiB2YWx1ZS50ZXN0KGNhbmRpZGF0ZSk7XHJcblx0XHRcdH07XHJcblx0XHR9XHJcblx0XHRlbHNlIGlmKHZhbHVlIGluc3RhbmNlb2YgQXJyYXkpIHtcdC8vIElmIHZhbHVlIGlzIGFuIGFycmF5LCB0ZXN0IGZvciB0aGUgcHJlc2VuY2Ugb2YgdGhlIGNhbmRpZGF0ZSB2YWx1ZSBpbiB0aGUgYXJyYXlcclxuXHRcdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xyXG5cdFx0XHRcdHJldHVybiB2YWx1ZS5pbmRleE9mKGNhbmRpZGF0ZSkgIT09IC0xO1xyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cdFx0ZWxzZSB7XHJcblx0XHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcclxuXHRcdFx0XHRyZXR1cm4gY2FuZGlkYXRlID09PSB2YWx1ZTtcdC8vIEhhbmRsZSBudWxsLCB1bmRlZmluZWQgb3Igb2JqZWN0LXJlZmVyZW5jZSBjb21wYXJpc29uXHJcblx0XHRcdH07XHJcblx0XHR9XHJcblx0fVxyXG5cdGVsc2Uge1x0Ly8gRWxzZSBpZiBpdCdzIGEgc2ltcGxlIHR5cGUsIHRyeSBhIHN0cmljdCBlcXVhbGl0eSBjb21wYXJpc29uXHJcblx0XHR0ZXN0ID0gZnVuY3Rpb24oY2FuZGlkYXRlKSB7XHJcblx0XHRcdHJldHVybiBjYW5kaWRhdGUgPT09IHZhbHVlO1xyXG5cdFx0fTtcclxuXHR9XHJcblx0XHJcblx0Ly8gTm93IGl0ZXJhdGUgb3ZlciB0aGUgaXRlbXMsIGZpbHRlcmluZyB1c2luZyB0aGUgdGVzdCBmdW5jdGlvbiB3ZSBkZWZpbmVkXHJcblx0dGhpcy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0pIHtcclxuXHRcdGlmKFxyXG5cdFx0XHQoZmllbGQgIT09IG51bGwgJiYgdGVzdChpdGVtW2ZpZWxkXSkpIHx8XHJcblx0XHRcdChmaWVsZCA9PT0gbnVsbCAmJiB0ZXN0KGl0ZW0pKVxyXG5cdFx0KSB7XHJcblx0XHRcdG1hdGNoZXMucHVzaChpdGVtKTtcclxuXHRcdH1cclxuXHR9KTtcclxuXHRyZXR1cm4gbmV3IENsdW1wKG1hdGNoZXMsIHRoaXMudHlwZSk7XHQvLyBBbmQgd3JhcCB0aGUgcmVzdWx0aW5nIGFycmF5IG9mIG9iamVjdHMgaW4gYSBuZXcgQ2x1bXAgb2JqZWN0IGZvciBzZXh5IG1ldGhvZCBjaGFpbmluZyBsaWtlIHgucXVlcnkoKS5mb3JFYWNoKCkgb3IgeC5xdWVyeSgpLnF1ZXJ5KClcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS5xdWVyeVJhdyA9IGZ1bmN0aW9uKGZpZWxkLCB2YWx1ZSkge1xyXG5cdHZhciBtYXRjaGVzID0gW107XHJcblx0dmFyIHRlc3Q7XHJcblxyXG5cdC8vIFdvcmsgb3V0IHdoYXQgc29ydCBvZiBjb21wYXJpc29uIHRvIGRvOlxyXG5cclxuXHRpZih0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1x0Ly8gSWYgdmFsdWUgaXMgYSBmdW5jdGlvbiwgcGFzcyBpdCB0aGUgY2FuZGlkYXRlIGFuZCByZXR1cm4gdGhlIHJlc3VsdFxyXG5cdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xyXG5cdFx0XHRyZXR1cm4gISF2YWx1ZShjYW5kaWRhdGUpO1xyXG5cdFx0fTtcclxuXHR9XHJcblx0ZWxzZSBpZih0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIpIHtcclxuXHRcdGlmKHZhbHVlIGluc3RhbmNlb2YgUmVnRXhwKSB7XHJcblx0XHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcclxuXHRcdFx0XHRyZXR1cm4gdmFsdWUudGVzdChjYW5kaWRhdGUpO1xyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cdFx0ZWxzZSBpZih2YWx1ZSBpbnN0YW5jZW9mIEFycmF5KSB7XHQvLyBJZiB2YWx1ZSBpcyBhbiBhcnJheSwgdGVzdCBmb3IgdGhlIHByZXNlbmNlIG9mIHRoZSBjYW5kaWRhdGUgdmFsdWUgaW4gdGhlIGFycmF5XHJcblx0XHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcclxuXHRcdFx0XHRyZXR1cm4gdmFsdWUuaW5kZXhPZihjYW5kaWRhdGUpICE9PSAtMTtcclxuXHRcdFx0fTtcclxuXHRcdH1cclxuXHRcdGVsc2Uge1x0Ly8gSWYgdmFsdWUgaXMgYSBoYXNoLi4uIHdoYXQgZG8gd2UgZG8/XHJcblx0XHRcdC8vIENoZWNrIHRoZSBjYW5kaWRhdGUgZm9yIGVhY2ggZmllbGQgaW4gdGhlIGhhc2ggaW4gdHVybiwgYW5kIGluY2x1ZGUgdGhlIGNhbmRpZGF0ZSBpZiBhbnkvYWxsIG9mIHRoZW0gaGF2ZSB0aGUgc2FtZSB2YWx1ZSBhcyB0aGUgY29ycmVzcG9uZGluZyB2YWx1ZS1oYXNoIGZpZWxkP1xyXG5cdFx0XHR0aHJvdyBcIk5vIGlkZWEgd2hhdCB0byBkbyB3aXRoIGFuIG9iamVjdCBhcyB0aGUgdmFsdWVcIjtcclxuXHRcdH1cclxuXHR9XHJcblx0ZWxzZSB7XHQvLyBFbHNlIGlmIGl0J3MgYSBzaW1wbGUgdHlwZSwgdHJ5IGEgc3RyaWN0IGVxdWFsaXR5IGNvbXBhcmlzb25cclxuXHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcclxuXHRcdFx0cmV0dXJuIGNhbmRpZGF0ZSA9PT0gdmFsdWU7XHJcblx0XHR9O1xyXG5cdH1cclxuXHRcclxuXHQvLyBOb3cgaXRlcmF0ZSBvdmVyIHRoZW0gYWxsLCBmaWx0ZXJpbmcgdXNpbmcgdGhlIHRlc3QgZnVuY3Rpb24gd2UgZGVmaW5lZFxyXG5cdHRoaXMuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XHJcblx0XHRpZihcclxuXHRcdFx0KGZpZWxkICE9PSBudWxsICYmIHRlc3QoaXRlbS5hdHRyaWJzW2ZpZWxkXSkpIHx8XHJcblx0XHRcdChmaWVsZCA9PT0gbnVsbCAmJiB0ZXN0KGl0ZW0uYXR0cmlicykpXHJcblx0XHQpIHtcclxuXHRcdFx0bWF0Y2hlcy5wdXNoKGl0ZW0pO1xyXG5cdFx0fVxyXG5cdH0pO1xyXG5cdHJldHVybiBuZXcgQ2x1bXAobWF0Y2hlcywgdGhpcy50eXBlKTtcdC8vIEFuZCB3cmFwIHRoZSByZXN1bHRpbmcgYXJyYXkgb2Ygb2JqZWN0cyBpbiBhIG5ldyBDbHVtcCBvYmplY3QgZm9yIHNleHkgbWV0aG9kIGNoYWluaW5nIGxpa2UgeC5xdWVyeSgpLmZvckVhY2goKSBvciB4LnF1ZXJ5KCkucXVlcnkoKVxyXG59O1xyXG5cclxuQ2x1bXAucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XHJcblx0cmV0dXJuIHRoaXMudHlwZS5uYW1lICsgXCIgQ2x1bXAgKFwiICsgdGhpcy5zaXplKCkgKyBcIiBpdGVtcylcIjtcclxufTtcclxuXHJcbkNsdW1wLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnLCBmaXJzdENoaWxkKSB7XHJcblxyXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XHJcblx0dGFnID0gdGFnIHx8IFwidWxcIjtcclxuXHJcblx0dmFyIGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XHJcblx0ZWxlbWVudC5jbGFzc05hbWUgPSB0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1saXN0IFwiK3NpemU7XHJcblx0aWYoZmlyc3RDaGlsZCkge1xyXG5cdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChmaXJzdENoaWxkKTtcclxuXHR9XHJcblx0dGhpcy5zb3J0QnkoXCJOYW1lXCIpLmZvckVhY2goZnVuY3Rpb24oaSkge1xyXG5cdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChpLnRvRG9tKHNpemUsIGluY2x1ZGVDaGlsZHJlbikpO1xyXG5cdH0pO1xyXG5cdHJldHVybiBlbGVtZW50O1xyXG59O1xyXG5cclxuQ2x1bXAucHJvdG90eXBlLmRlc2NyaWJlID0gZnVuY3Rpb24oKSB7XHJcblx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdHJldHVybiBPYmplY3Qua2V5cyh0aGlzLml0ZW1zKS5tYXAoZnVuY3Rpb24oaSkgeyByZXR1cm4gc2VsZi5pdGVtc1tpXS50b1N0cmluZygpOyB9KS5qb2luKFwiIGFuZCBcIik7XHJcbn07XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IENsdW1wOyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XHJcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcclxuXHJcbnZhciBhcGk7XHJcblxyXG5mdW5jdGlvbiBDb21iYXRBdHRhY2socmF3LCBwYXJlbnQpIHtcclxuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcclxuXHRcdCdOYW1lJyxcclxuXHRcdCdJbWFnZScsXHJcblx0XHQnUmFtbWluZ0F0dGFjaycsXHJcblx0XHQnT25seVdoZW5FeHBvc2VkJyxcclxuXHRcdCdSYW5nZScsXHJcblx0XHQnT3JpZW50YXRpb24nLFxyXG5cdFx0J0FyYycsXHJcblx0XHQnQmFzZUh1bGxEYW1hZ2UnLFxyXG5cdFx0J0Jhc2VMaWZlRGFtYWdlJyxcclxuXHRcdCdFeHBvc2VkUXVhbGl0eURhbWFnZScsXHQvLyBWYWx1ZSB0byBhZGQgdG8gdGhlIGV4cG9zZWRRdWFsaXR5OiBwb3NpdGl2ZSBpbmNyZWFzZXMgcXVhbGl0eSBsZXZlbCAoZWcgVGVycm9yKSwgbmVnYXRpdmUgZGVjcmVhc2VzIGl0IChlZyBDcmV3KVxyXG5cdFx0J1N0YWdnZXJBbW91bnQnLFxyXG5cdFx0J0Jhc2VXYXJtVXAnLFxyXG5cdFx0J0FuaW1hdGlvbicsXHJcblx0XHQnQW5pbWF0aW9uTnVtYmVyJ1xyXG5cdF07XHJcblx0cmF3LklkID0gcmF3Lk5hbWU7XHJcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xyXG5cclxuXHR0aGlzLnF1YWxpdHlSZXF1aXJlZCA9IG51bGw7XHJcblx0dGhpcy5xdWFsaXR5Q29zdCA9IG51bGw7XHJcblx0dGhpcy5leHBvc2VkUXVhbGl0eSA9IG51bGw7XHJcbn1cclxuXHJcbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBDb21iYXRBdHRhY2sucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcclxuXHJcbkNvbWJhdEF0dGFjay5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XHJcblxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHJcblx0dGhpcy5xdWFsaXR5UmVxdWlyZWQgPSBhcGkuZ2V0KGFwaS50eXBlcy5RdWFsaXR5LCB0aGlzLmF0dHJpYnMuUXVhbGl0eVJlcXVpcmVkSWQsIHRoaXMpO1xyXG5cdHRoaXMucXVhbGl0eUNvc3QgPSBhcGkuZ2V0KGFwaS50eXBlcy5RdWFsaXR5LCB0aGlzLmF0dHJpYnMuUXVhbGl0eUNvc3RJZCwgdGhpcyk7XHJcblx0dGhpcy5leHBvc2VkUXVhbGl0eSA9IGFwaS5nZXQoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5FeHBvc2VkUXVhbGl0eUlkLCB0aGlzKTtcclxuXHJcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcclxufTtcclxuXHJcbkNvbWJhdEF0dGFjay5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcclxuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xyXG59O1xyXG5cclxuQ29tYmF0QXR0YWNrLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbikge1xyXG5cclxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xyXG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XHJcblxyXG5cdHZhciBzZWxmID0gdGhpcztcclxuXHRcclxuXHR2YXIgaHRtbCA9IFwiXCI7XHJcblxyXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcclxuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XHJcblxyXG5cdGlmKHRoaXMuSW1hZ2UgIT09IG51bGwgJiYgdGhpcy5JbWFnZSAhPT0gXCJcIikge1xyXG5cdFx0aHRtbCA9IFwiPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCIucG5nJyAvPlwiO1xyXG5cdH1cclxuXHJcblx0aHRtbCArPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XHJcblxyXG5cdGlmKHRoaXMucXVhbGl0eVJlcXVpcmVkIHx8IHRoaXMucXVhbGl0eUNvc3QpIHtcclxuXHRcdGh0bWwgKz0gXCI8ZGl2IGNsYXNzPSdzaWRlYmFyJz5cIjtcclxuXHJcblx0XHRpZih0aGlzLnF1YWxpdHlSZXF1aXJlZCkge1xyXG5cdFx0XHRodG1sICs9IFwiPGg0PlJlcXVpcmVkPC9oND5cIjtcclxuXHRcdFx0aHRtbCArPSAobmV3IENsdW1wKFt0aGlzLnF1YWxpdHlSZXF1aXJlZF0sIGFwaS50eXBlcy5RdWFsaXR5KSkudG9Eb20oXCJzbWFsbFwiLCBmYWxzZSwgXCJ1bFwiKS5vdXRlckhUTUw7XHJcblx0XHR9XHJcblx0XHRpZih0aGlzLnF1YWxpdHlDb3N0KSB7XHJcblx0XHRcdGh0bWwgKz0gXCI8aDQ+Q29zdDwvaDQ+XCI7XHJcblx0XHRcdGh0bWwgKz0gKG5ldyBDbHVtcChbdGhpcy5xdWFsaXR5Q29zdF0sIGFwaS50eXBlcy5RdWFsaXR5KSkudG9Eb20oXCJzbWFsbFwiLCBmYWxzZSwgXCJ1bFwiKS5vdXRlckhUTUw7XHJcblx0XHR9XHJcblx0XHRodG1sICs9IFwiPC9kaXY+XCI7XHJcblx0fVxyXG5cclxuXHRodG1sICs9IFwiPGRsIGNsYXNzPSdjbHVtcC1saXN0IHNtYWxsJz5cIjtcclxuXHRbJ1JhbmdlJywgJ0FyYycsICdCYXNlSHVsbERhbWFnZScsICdCYXNlTGlmZURhbWFnZScsICdTdGFnZ2VyQW1vdW50JywgJ0Jhc2VXYXJtVXAnXS5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xyXG5cdFx0aHRtbCArPSBcIjxkdCBjbGFzcz0naXRlbSc+XCIra2V5K1wiPC9kdD48ZGQgY2xhc3M9J3F1YW50aXR5Jz5cIitzZWxmW2tleV0rXCI8L2RkPlwiO1xyXG5cdH0pO1xyXG5cdGh0bWwgKz0gXCI8L2RsPlwiO1xyXG5cclxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XHJcblxyXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XHJcblxyXG5cdGlmKGluY2x1ZGVDaGlsZHJlbikge1xyXG5cdFx0ZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oZSkge1xyXG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG5cclxuXHRcdFx0dmFyIGNoaWxkTGlzdCA9IGVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5jaGlsZC1saXN0XCIpO1xyXG5cdFx0XHRpZihjaGlsZExpc3QpIHtcclxuXHRcdFx0XHRlbGVtZW50LnJlbW92ZUNoaWxkKGNoaWxkTGlzdCk7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZSB7XHJcblx0XHRcdFx0dmFyIHN1Y2Nlc3NFdmVudCA9IHNlbGYuc3VjY2Vzc0V2ZW50O1xyXG5cdFx0XHRcdHZhciBkZWZhdWx0RXZlbnQgPSBzZWxmLmRlZmF1bHRFdmVudDtcclxuXHRcdFx0XHR2YXIgcXVhbGl0aWVzUmVxdWlyZWQgPSAgc2VsZi5xdWFsaXRpZXNSZXF1aXJlZDtcclxuXHRcdFx0XHR2YXIgZXZlbnRzID0gW107XHJcblx0XHRcdFx0aWYoc3VjY2Vzc0V2ZW50ICYmIHF1YWxpdGllc1JlcXVpcmVkICYmIHF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xyXG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goc3VjY2Vzc0V2ZW50KTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0aWYoZGVmYXVsdEV2ZW50KSB7XHJcblx0XHRcdFx0XHRldmVudHMucHVzaChkZWZhdWx0RXZlbnQpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpZihldmVudHMubGVuZ3RoKSB7XHJcblx0XHRcdFx0XHR2YXIgd3JhcHBlckNsdW1wID0gbmV3IENsdW1wKGV2ZW50cywgYXBpLnR5cGVzLkV2ZW50KTtcclxuXHRcdFx0XHRcdHZhciBjaGlsZF9ldmVudHMgPSB3cmFwcGVyQ2x1bXAudG9Eb20oc2l6ZSwgdHJ1ZSk7XHJcblxyXG5cdFx0XHRcdFx0Y2hpbGRfZXZlbnRzLmNsYXNzTGlzdC5hZGQoXCJjaGlsZC1saXN0XCIpO1xyXG5cdFx0XHRcdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChjaGlsZF9ldmVudHMpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0fVxyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gQ29tYmF0QXR0YWNrOyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XHJcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcclxuXHJcbnZhciBhcGk7XHJcblxyXG5mdW5jdGlvbiBFdmVudChyYXcsIHBhcmVudCkge1xyXG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xyXG5cdCdOYW1lJyxcclxuXHQnRGVzY3JpcHRpb24nLFxyXG5cdCdUZWFzZXInLFxyXG5cdCdJbWFnZScsXHJcblx0J0NhdGVnb3J5J1xyXG5cdF07XHJcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xyXG5cclxuXHR0aGlzLnRhZyA9IG51bGw7XHJcblxyXG5cdHRoaXMuRXhvdGljRWZmZWN0cyA9IHRoaXMuZ2V0RXhvdGljRWZmZWN0KHRoaXMuYXR0cmlicy5FeG90aWNFZmZlY3RzKTtcclxuXHJcblx0dGhpcy5xdWFsaXRpZXNSZXF1aXJlZCA9IG51bGw7XHJcblx0dGhpcy5xdWFsaXRpZXNBZmZlY3RlZCA9IG51bGw7XHJcblx0dGhpcy5pbnRlcmFjdGlvbnMgPSBudWxsO1xyXG5cdHRoaXMubGlua1RvRXZlbnQgPSBudWxsO1xyXG5cclxuXHR0aGlzLmxpbWl0ZWRUb0FyZWEgPSBudWxsO1xyXG5cclxuXHR0aGlzLnNldHRpbmcgPSBudWxsO1xyXG5cdFxyXG5cdC8vRGVja1xyXG5cdC8vU3RpY2tpbmVzc1xyXG5cdC8vVHJhbnNpZW50XHJcblx0Ly9VcmdlbmN5XHJcbn1cclxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IEV2ZW50LnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XHJcblxyXG5FdmVudC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XHJcblxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHJcblx0dGhpcy5xdWFsaXRpZXNSZXF1aXJlZCA9IG5ldyBDbHVtcCh0aGlzLmF0dHJpYnMuUXVhbGl0aWVzUmVxdWlyZWQgfHwgW10sIGFwaS50eXBlcy5RdWFsaXR5UmVxdWlyZW1lbnQsIHRoaXMpO1xyXG5cdHRoaXMucXVhbGl0aWVzQWZmZWN0ZWQgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlF1YWxpdGllc0FmZmVjdGVkIHx8IFtdLCBhcGkudHlwZXMuUXVhbGl0eUVmZmVjdCwgdGhpcyk7XHJcblx0dGhpcy5pbnRlcmFjdGlvbnMgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLkNoaWxkQnJhbmNoZXN8fCBbXSwgYXBpLnR5cGVzLkludGVyYWN0aW9uLCB0aGlzKTtcclxuXHJcblx0dGhpcy5saW5rVG9FdmVudCA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuRXZlbnQsIHRoaXMuYXR0cmlicy5MaW5rVG9FdmVudCwgdGhpcyk7XHJcblxyXG5cdHRoaXMubGltaXRlZFRvQXJlYSA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuQXJlYSwgdGhpcy5hdHRyaWJzLkxpbWl0ZWRUb0FyZWEsIHRoaXMpO1xyXG5cclxuXHR0aGlzLnNldHRpbmcgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLlNldHRpbmcsIHRoaXMuYXR0cmlicy5TZXR0aW5nLCB0aGlzKTtcclxuXHRcclxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzLCBhcGkpO1xyXG59O1xyXG5cclxuRXZlbnQucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xyXG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiBcIiArIChsb25nID8gXCIgW1wiICsgdGhpcy5DYXRlZ29yeSArIFwiXSBcIiA6IFwiXCIpICsgdGhpcy5OYW1lICsgXCIgKCNcIiArIHRoaXMuSWQgKyBcIilcIjtcclxufTtcclxuXHJcbkV2ZW50LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbikge1xyXG5cclxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xyXG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XHJcblxyXG5cdHZhciBodG1sID0gXCJcIjtcclxuXHJcblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xyXG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcclxuXHJcblx0aWYodGhpcy5JbWFnZSAhPT0gbnVsbCAmJiB0aGlzLkltYWdlICE9PSBcIlwiKSB7XHJcblx0XHRodG1sID0gXCI8aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5JbWFnZStcInNtYWxsLnBuZycgLz5cIjtcclxuXHR9XHJcblxyXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCJcXG5cIisodGhpcy50YWcgPyBcIjxzcGFuIGNsYXNzPSd0YWcgXCIrdGhpcy50YWcrXCInPlwiK3RoaXMudGFnK1wiPC9zcGFuPlwiIDogXCJcIikrXCI8L2gzPlwiO1xyXG5cclxuXHRpZihzaXplICE9IFwic21hbGxcIiAmJiAodGhpcy5xdWFsaXRpZXNSZXF1aXJlZCB8fCB0aGlzLnF1YWxpdGllc0FmZmVjdGVkKSkge1xyXG5cdFx0aHRtbCArPSBcIjxkaXYgY2xhc3M9J3NpZGViYXInPlwiO1xyXG5cdFx0aWYodGhpcy5xdWFsaXRpZXNSZXF1aXJlZCAmJiB0aGlzLnF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xyXG5cdFx0XHRodG1sICs9IFwiPGg0PlJlcXVpcmVtZW50czwvaDQ+XFxuXCI7XHJcblx0XHRcdGh0bWwgKz0gdGhpcy5xdWFsaXRpZXNSZXF1aXJlZC50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInVsXCIpLm91dGVySFRNTDtcclxuXHRcdH1cclxuXHRcdGlmKHRoaXMucXVhbGl0aWVzQWZmZWN0ZWQgJiYgdGhpcy5xdWFsaXRpZXNBZmZlY3RlZC5zaXplKCkpIHtcclxuXHRcdFx0aHRtbCArPSBcIjxoND5FZmZlY3RzPC9oND5cXG5cIjtcclxuXHRcdFx0aHRtbCArPSB0aGlzLnF1YWxpdGllc0FmZmVjdGVkLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xyXG5cdFx0fVxyXG5cdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xyXG5cdH1cclxuXHRcclxuXHRodG1sICs9IFwiPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xyXG5cclxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XHJcblxyXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKHRydWUpO1xyXG5cclxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcclxuXHRcdHZhciBzZWxmID0gdGhpcztcclxuXHRcdGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uKGUpIHtcclxuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHJcblx0XHRcdHZhciBjaGlsZExpc3QgPSBlbGVtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY2hpbGQtbGlzdFwiKTtcclxuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XHJcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2Uge1xyXG5cdFx0XHRcdHZhciBpbnRlcmFjdGlvbnMgPSBzZWxmLmludGVyYWN0aW9ucztcclxuXHRcdFx0XHR2YXIgbGlua1RvRXZlbnQgPSBzZWxmLmxpbmtUb0V2ZW50O1xyXG5cdFx0XHRcdGlmKGxpbmtUb0V2ZW50KSB7XHJcblx0XHRcdFx0XHR2YXIgd3JhcHBlckNsdW1wID0gbmV3IENsdW1wKFtsaW5rVG9FdmVudF0sIGFwaS50eXBlcy5FdmVudCk7XHJcblx0XHRcdFx0XHR2YXIgbGlua1RvRXZlbnRfZWxlbWVudCA9IHdyYXBwZXJDbHVtcC50b0RvbShcIm5vcm1hbFwiLCB0cnVlKTtcclxuXHJcblx0XHRcdFx0XHRsaW5rVG9FdmVudF9lbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJjaGlsZC1saXN0XCIpO1xyXG5cdFx0XHRcdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChsaW5rVG9FdmVudF9lbGVtZW50KTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0ZWxzZSBpZihpbnRlcmFjdGlvbnMgJiYgaW50ZXJhY3Rpb25zLnNpemUoKSA+IDApIHtcclxuXHRcdFx0XHRcdHZhciBpbnRlcmFjdGlvbnNfZWxlbWVudCA9IGludGVyYWN0aW9ucy50b0RvbShcIm5vcm1hbFwiLCB0cnVlKTtcclxuXHJcblx0XHRcdFx0XHRpbnRlcmFjdGlvbnNfZWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcclxuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoaW50ZXJhY3Rpb25zX2VsZW1lbnQpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0fVxyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gRXZlbnQ7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcclxudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xyXG5cclxudmFyIGFwaTtcclxuXHJcbmZ1bmN0aW9uIEV4Y2hhbmdlKHJhdywgcGFyZW50KSB7XHJcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXHJcblx0XHQnSWQnLFxyXG5cdFx0J05hbWUnLFxyXG5cdFx0J0Rlc2NyaXB0aW9uJyxcclxuXHRcdCdJbWFnZScsXHJcblx0XHQnU2V0dGluZ0lkcydcclxuXHRdO1xyXG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcclxuXHJcblx0dGhpcy5zaG9wcyA9IG51bGw7XHJcblx0dGhpcy5zZXR0aW5ncyA9IG51bGw7XHJcbn1cclxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IEV4Y2hhbmdlLnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XHJcblxyXG5FeGNoYW5nZS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XHJcblxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHJcblx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cclxuXHR0aGlzLnNob3BzID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5TaG9wcyB8fCBbXSwgYXBpLnR5cGVzLlNob3AsIHRoaXMpO1xyXG5cdFxyXG5cdHRoaXMuc2V0dGluZ3MgPSBhcGkubGlicmFyeS5TZXR0aW5nLnF1ZXJ5KFwiSWRcIiwgZnVuY3Rpb24oaWQpIHtcclxuXHRcdHJldHVybiBzZWxmLlNldHRpbmdJZHMuaW5kZXhPZihpZCkgIT09IC0xO1xyXG5cdH0pO1xyXG5cdHRoaXMuc2V0dGluZ3MuZm9yRWFjaChmdW5jdGlvbiAocykge1xyXG5cdFx0c2VsZi5wYXJlbnRzLnB1c2gocyk7XHJcblx0fSk7XHJcblx0XHJcblx0dGhpcy5wb3J0cyA9IGFwaS5saWJyYXJ5LlBvcnQucXVlcnkoXCJTZXR0aW5nSWRcIiwgZnVuY3Rpb24oaWQpIHtcclxuXHRcdHJldHVybiBzZWxmLlNldHRpbmdJZHMuaW5kZXhPZihpZCkgIT09IC0xO1xyXG5cdH0pO1xyXG5cdHRoaXMucG9ydHMuZm9yRWFjaChmdW5jdGlvbiAocCkge1xyXG5cdFx0c2VsZi5wYXJlbnRzLnB1c2gocCk7XHJcblx0fSk7XHJcblxyXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMpO1xyXG59O1xyXG5cclxuRXhjaGFuZ2UucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XHJcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5OYW1lICsgXCIgKCNcIiArIHRoaXMuSWQgKyBcIilcIjtcclxufTtcclxuXHJcbkV4Y2hhbmdlLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XHJcblxyXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XHJcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcclxuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xyXG5cclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0dmFyIGh0bWwgPSBcIlwiO1xyXG5cclxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XHJcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xyXG5cclxuXHRodG1sID0gXCJcXG48aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5JbWFnZStcIi5wbmcnIC8+XCI7XHJcblx0aHRtbCArPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XHJcblx0aHRtbCArPSBcIlxcbjxwIGNsYXNzPSdkZXNjcmlwdGlvbic+XCIrdGhpcy5EZXNjcmlwdGlvbitcIjwvcD5cIjtcclxuXHJcblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xyXG5cclxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xyXG5cclxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcclxuXHRcdGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uKGUpIHtcclxuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHJcblx0XHRcdHZhciBjaGlsZExpc3QgPSBlbGVtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY2hpbGQtbGlzdFwiKTtcclxuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XHJcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2Uge1xyXG5cdFx0XHRcdGlmKHNlbGYuc2hvcHMpIHtcclxuXHJcblx0XHRcdFx0XHR2YXIgY2hpbGRfZWxlbWVudHMgPSBzZWxmLnNob3BzLnRvRG9tKFwibm9ybWFsXCIsIHRydWUpO1xyXG5cclxuXHRcdFx0XHRcdGNoaWxkX2VsZW1lbnRzLmNsYXNzTGlzdC5hZGQoXCJjaGlsZC1saXN0XCIpO1xyXG5cdFx0XHRcdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChjaGlsZF9lbGVtZW50cyk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHR9XHJcblxyXG5cdHJldHVybiBlbGVtZW50O1xyXG59O1xyXG5cclxubW9kdWxlLmV4cG9ydHMgPSBFeGNoYW5nZTsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xyXG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XHJcblxyXG52YXIgYXBpO1xyXG5cclxuZnVuY3Rpb24gSW50ZXJhY3Rpb24ocmF3LCBwYXJlbnQpIHtcclxuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcclxuXHQnTmFtZScsXHJcblx0J0Rlc2NyaXB0aW9uJyxcclxuXHQnQnV0dG9uVGV4dCcsXHJcblx0J0ltYWdlJyxcclxuXHJcblx0J09yZGVyaW5nJ1xyXG5cdF07XHJcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xyXG5cclxuXHR0aGlzLnF1YWxpdGllc1JlcXVpcmVkID0gbnVsbDtcclxuXHR0aGlzLnN1Y2Nlc3NFdmVudCA9IG51bGw7XHJcblx0dGhpcy5kZWZhdWx0RXZlbnQgPSBudWxsO1xyXG5cclxufVxyXG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgSW50ZXJhY3Rpb24ucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcclxuXHJcbkludGVyYWN0aW9uLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcclxuXHJcblx0YXBpID0gdGhlQXBpO1xyXG5cclxuXHR0aGlzLnF1YWxpdGllc1JlcXVpcmVkID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5RdWFsaXRpZXNSZXF1aXJlZCB8fCBbXSwgYXBpLnR5cGVzLlF1YWxpdHlSZXF1aXJlbWVudCwgdGhpcyk7XHJcblx0dGhpcy5zdWNjZXNzRXZlbnQgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLkV2ZW50LCB0aGlzLmF0dHJpYnMuU3VjY2Vzc0V2ZW50LCB0aGlzKTtcclxuXHRpZih0aGlzLnN1Y2Nlc3NFdmVudCkge1xyXG5cdFx0dGhpcy5zdWNjZXNzRXZlbnQudGFnID0gXCJzdWNjZXNzXCI7XHJcblx0fVxyXG5cdHRoaXMuZGVmYXVsdEV2ZW50ID0gYXBpLmdldE9yQ3JlYXRlKGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLkRlZmF1bHRFdmVudCwgdGhpcyk7XHJcblx0dmFyIHF1YWxpdGllc1JlcXVpcmVkID0gIHRoaXMucXVhbGl0aWVzUmVxdWlyZWQ7XHJcblx0aWYodGhpcy5kZWZhdWx0RXZlbnQgJiYgdGhpcy5zdWNjZXNzRXZlbnQgJiYgcXVhbGl0aWVzUmVxdWlyZWQgJiYgcXVhbGl0aWVzUmVxdWlyZWQuc2l6ZSgpKSB7XHJcblx0XHR0aGlzLmRlZmF1bHRFdmVudC50YWcgPSBcImZhaWx1cmVcIjtcclxuXHR9XHJcblxyXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XHJcbn07XHJcblxyXG5JbnRlcmFjdGlvbi5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcclxuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgW1wiICsgdGhpcy5PcmRlcmluZyArIFwiXSBcIiArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XHJcbn07XHJcblxyXG5JbnRlcmFjdGlvbi5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4pIHtcclxuXHJcblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcclxuXHRpbmNsdWRlQ2hpbGRyZW4gPSBpbmNsdWRlQ2hpbGRyZW4gPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xyXG5cclxuXHR2YXIgaHRtbCA9IFwiXCI7XHJcblxyXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcclxuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XHJcblxyXG5cdGlmKHRoaXMuSW1hZ2UgIT09IG51bGwgJiYgdGhpcy5JbWFnZSAhPT0gXCJcIikge1xyXG5cdFx0aHRtbCA9IFwiPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCJzbWFsbC5wbmcnIC8+XCI7XHJcblx0fVxyXG5cclxuXHRodG1sICs9IFwiXFxuPGgzIGNsYXNzPSd0aXRsZSc+XCIrdGhpcy5OYW1lK1wiPC9oMz5cIjtcclxuXHJcblx0aWYoc2l6ZSAhPSBcInNtYWxsXCIgJiYgdGhpcy5xdWFsaXRpZXNSZXF1aXJlZCkge1xyXG5cdFx0aHRtbCArPSBcIjxkaXYgY2xhc3M9J3NpZGViYXInPlwiO1xyXG5cdFx0aHRtbCArPSBcIjxoND5SZXF1aXJlbWVudHM8L2g0PlwiO1xyXG5cdFx0aHRtbCArPSB0aGlzLnF1YWxpdGllc1JlcXVpcmVkLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xyXG5cdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xyXG5cdH1cclxuXHJcblx0aHRtbCArPSBcIjxwIGNsYXNzPSdkZXNjcmlwdGlvbic+XCIrdGhpcy5EZXNjcmlwdGlvbitcIjwvcD5cIjtcclxuXHJcblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xyXG5cclxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xyXG5cclxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcclxuXHRcdHZhciBzZWxmID0gdGhpcztcclxuXHRcdGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uKGUpIHtcclxuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHJcblx0XHRcdHZhciBjaGlsZExpc3QgPSBlbGVtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY2hpbGQtbGlzdFwiKTtcclxuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XHJcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2Uge1xyXG5cdFx0XHRcdHZhciBzdWNjZXNzRXZlbnQgPSBzZWxmLnN1Y2Nlc3NFdmVudDtcclxuXHRcdFx0XHR2YXIgZGVmYXVsdEV2ZW50ID0gc2VsZi5kZWZhdWx0RXZlbnQ7XHJcblx0XHRcdFx0dmFyIHF1YWxpdGllc1JlcXVpcmVkID0gIHNlbGYucXVhbGl0aWVzUmVxdWlyZWQ7XHJcblx0XHRcdFx0dmFyIGV2ZW50cyA9IFtdO1xyXG5cdFx0XHRcdGlmKHN1Y2Nlc3NFdmVudCAmJiBxdWFsaXRpZXNSZXF1aXJlZCAmJiBxdWFsaXRpZXNSZXF1aXJlZC5zaXplKCkpIHtcclxuXHRcdFx0XHRcdGV2ZW50cy5wdXNoKHN1Y2Nlc3NFdmVudCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGlmKGRlZmF1bHRFdmVudCkge1xyXG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goZGVmYXVsdEV2ZW50KTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0aWYoZXZlbnRzLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0dmFyIHdyYXBwZXJDbHVtcCA9IG5ldyBDbHVtcChldmVudHMsIGFwaS50eXBlcy5FdmVudCk7XHJcblx0XHRcdFx0XHR2YXIgY2hpbGRfZXZlbnRzID0gd3JhcHBlckNsdW1wLnRvRG9tKFwibm9ybWFsXCIsIHRydWUpO1xyXG5cclxuXHRcdFx0XHRcdGNoaWxkX2V2ZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcclxuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY2hpbGRfZXZlbnRzKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH0pO1xyXG5cdH1cclxuXHJcblx0cmV0dXJuIGVsZW1lbnQ7XHJcbn07XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IEludGVyYWN0aW9uOyIsInZhciBsaWJyYXJ5ID0gcmVxdWlyZSgnLi4vbGlicmFyeScpO1xyXG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XHJcblxyXG52YXIgYXBpO1xyXG5cclxuZnVuY3Rpb24gTHVtcChyYXcsIHBhcmVudCkge1xyXG5cdGlmKHBhcmVudCkge1xyXG5cdFx0dGhpcy5wYXJlbnRzID0gcGFyZW50IGluc3RhbmNlb2YgQXJyYXkgPyBwYXJlbnQgOiBbcGFyZW50XTtcclxuXHR9XHJcblx0ZWxzZSB7XHJcblx0XHR0aGlzLnBhcmVudHMgPSBbXTtcclxuXHR9XHJcblxyXG5cdGlmKCF0aGlzLnN0cmFpZ2h0Q29weSkge1xyXG5cdFx0dGhpcy5zdHJhaWdodENvcHkgPSBbXTtcclxuXHR9XHJcblx0dGhpcy5zdHJhaWdodENvcHkudW5zaGlmdCgnSWQnKTtcclxuXHJcblx0dGhpcy5hdHRyaWJzID0gcmF3O1xyXG5cclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0dGhpcy5zdHJhaWdodENvcHkuZm9yRWFjaChmdW5jdGlvbihhdHRyaWIpIHtcclxuXHRcdHNlbGZbYXR0cmliXSA9IHJhd1thdHRyaWJdO1xyXG5cdFx0aWYodHlwZW9mIHNlbGZbYXR0cmliXSA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG5cdFx0XHRzZWxmW2F0dHJpYl0gPSBudWxsO1xyXG5cdFx0fVxyXG5cdH0pO1xyXG5cdGRlbGV0ZSh0aGlzLnN0cmFpZ2h0Q29weSk7XHJcblxyXG5cdHRoaXMud2lyZWQgPSBmYWxzZTtcclxuXHJcblx0aWYoIWxpYnJhcnlbdGhpcy5jb25zdHJ1Y3Rvci5uYW1lXSkge1xyXG5cdFx0bGlicmFyeVt0aGlzLmNvbnN0cnVjdG9yLm5hbWVdID0gbmV3IENsdW1wKFtdLCB0aGlzKTtcclxuXHR9XHJcblxyXG5cdGlmKGxpYnJhcnlbdGhpcy5jb25zdHJ1Y3Rvci5uYW1lXS5pdGVtc1t0aGlzLklkXSkge1x0Ly8gU29tZXRoaW5nIHdpdGggdGhpcyBJRCBhbHJlYWR5IGV4aXN0cyFcclxuXHJcblx0XHR2YXIgZXhpc3RpbmdPYmplY3QgPSBsaWJyYXJ5W3RoaXMuY29uc3RydWN0b3IubmFtZV0uaXRlbXNbdGhpcy5JZF07XHJcblxyXG5cdFx0aWYoIWlzRnVuY3Rpb25hbGx5U2FtZSh0aGlzLmF0dHJpYnMsIGV4aXN0aW5nT2JqZWN0LmF0dHJpYnMpKSB7XHQvLyBXYXMgaXQgYSBmdW5jdGlvbmFsbHktaWRlbnRpY2FsIHJlZGVmaW5pdGlvbiBvZiB0aGlzIG9iamVjdD9cclxuXHRcdFx0Y29uc29sZS53YXJuKFwiRHVwbGljYXRlIElEXCIsIHRoaXMuY29uc3RydWN0b3IubmFtZStcIiBcIit0aGlzLklkK1wiIGFscmVhZHkgZXhpc3RzIGluIHRoZSBsaWJyYXJ5IC0gcmVwbGFjaW5nXCIsIGV4aXN0aW5nT2JqZWN0LCBcIndpdGggcmVkZWZpbml0aW9uXCIsIHRoaXMpO1xyXG5cdFx0fVxyXG5cdH1cclxuXHRsaWJyYXJ5W3RoaXMuY29uc3RydWN0b3IubmFtZV0uaXRlbXNbdGhpcy5JZF0gPSB0aGlzO1xyXG59XHJcblxyXG52YXIgaXNGdW5jdGlvbmFsbHlTYW1lID0gZnVuY3Rpb24ob2JqMSwgb2JqMikge1xyXG5cclxuXHRpZihvYmoxID09PSBvYmoyKSB7XHJcblx0XHRyZXR1cm4gdHJ1ZTtcclxuXHR9XHJcblxyXG5cdGlmKG9iajEgaW5zdGFuY2VvZiBPYmplY3QpIHtcclxuXHRcdGlmKCEob2JqMiBpbnN0YW5jZW9mIE9iamVjdCkgfHwgb2JqMS5jb25zdHJ1Y3RvciAhPT0gb2JqMi5jb25zdHJ1Y3Rvcikge1xyXG5cdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHR9XHJcblxyXG5cdFx0dmFyIGFsbEtleXMgPSBPYmplY3Qua2V5cyhvYmoxKS5jb25jYXQoT2JqZWN0LmtleXMob2JqMikpLmZpbHRlcihmdW5jdGlvbiAodmFsdWUsIGluZGV4LCBzZWxmKSB7IFxyXG4gICAgXHRyZXR1cm4gc2VsZi5pbmRleE9mKHZhbHVlKSA9PT0gaW5kZXg7XHJcblx0XHR9KTtcclxuXHJcblx0XHRyZXR1cm4gYWxsS2V5cy5tYXAoZnVuY3Rpb24oa2V5KSB7XHJcblx0XHRcdHJldHVybiBpc0Z1bmN0aW9uYWxseVNhbWUob2JqMVtrZXldLCBvYmoyW2tleV0pO1xyXG5cdFx0fSkucmVkdWNlKGZ1bmN0aW9uKHByZXZpb3VzVmFsdWUsIGN1cnJlbnRWYWx1ZSkge1xyXG5cdFx0XHRyZXR1cm4gcHJldmlvdXNWYWx1ZSAmJiBjdXJyZW50VmFsdWU7XHJcblx0XHR9LCB0cnVlKTtcclxuXHR9XHJcblxyXG5cdHJldHVybiBmYWxzZTtcclxuXHJcbn07XHJcblxyXG5MdW1wLnByb3RvdHlwZSA9IHtcclxuXHR3aXJlVXA6IGZ1bmN0aW9uKHRoZUFwaSkge1xyXG5cdFx0YXBpID0gdGhlQXBpO1xyXG5cdFx0dGhpcy53aXJlZCA9IHRydWU7XHJcblx0fSxcclxuXHJcblx0Z2V0U3RhdGVzOiBmdW5jdGlvbihlbmNvZGVkKSB7XHJcblx0XHRpZih0eXBlb2YgZW5jb2RlZCA9PT0gXCJzdHJpbmdcIiAmJiBlbmNvZGVkICE9PSBcIlwiKSB7XHJcblx0XHRcdHZhciBtYXAgPSB7fTtcclxuXHRcdFx0ZW5jb2RlZC5zcGxpdChcIn5cIikuZm9yRWFjaChmdW5jdGlvbihzdGF0ZSkge1xyXG5cdFx0XHRcdHZhciBwYWlyID0gc3RhdGUuc3BsaXQoXCJ8XCIpO1xyXG5cdFx0XHRcdG1hcFtwYWlyWzBdXSA9IHBhaXJbMV07XHJcblx0XHRcdH0pO1xyXG5cdFx0XHRyZXR1cm4gbWFwO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZSB7XHJcblx0XHRcdHJldHVybiBudWxsO1xyXG5cdFx0fVxyXG5cdH0sXHJcblxyXG5cdGdldEV4b3RpY0VmZmVjdDogZnVuY3Rpb24oZW5jb2RlZCkge1xyXG5cdFx0aWYodHlwZW9mIGVuY29kZWQgPT09IFwic3RyaW5nXCIpIHtcclxuXHRcdFx0dmFyIGVmZmVjdD17fSwgZmllbGRzPVtcIm9wZXJhdGlvblwiLCBcImZpcnN0XCIsIFwic2Vjb25kXCJdO1xyXG5cdFx0XHRlbmNvZGVkLnNwbGl0KFwiLFwiKS5mb3JFYWNoKGZ1bmN0aW9uKHZhbCwgaW5kZXgpIHtcclxuXHRcdFx0XHRlZmZlY3RbZmllbGRzW2luZGV4XV0gPSB2YWw7XHJcblx0XHRcdH0pO1xyXG5cdFx0XHRyZXR1cm4gZWZmZWN0O1xyXG5cdFx0fVxyXG5cdFx0ZWxzZSB7XHJcblx0XHRcdHJldHVybiBudWxsO1xyXG5cdFx0fVxyXG5cdH0sXHJcblxyXG5cdGV2YWxBZHZhbmNlZEV4cHJlc3Npb246IGZ1bmN0aW9uKGV4cHIpIHtcclxuXHRcdGV4cHIgPSBleHByLnJlcGxhY2UoL1xcW2Q6KFxcZCspXFxdL2dpLCBcIk1hdGguZmxvb3IoKE1hdGgucmFuZG9tKCkqJDEpKzEpXCIpO1x0Ly8gUmVwbGFjZSBbZDp4XSB3aXRoIEpTIHRvIGNhbGN1bGF0ZSByYW5kb20gbnVtYmVyIG9uIGEgRHggZGllXHJcblx0XHQvKmpzaGludCAtVzA2MSAqL1xyXG5cdFx0cmV0dXJuIGV2YWwoZXhwcik7XHJcblx0XHQvKmpzaGludCArVzA2MSAqL1xyXG5cdH0sXHJcblxyXG5cdGlzQTogZnVuY3Rpb24odHlwZSkge1xyXG5cdFx0cmV0dXJuIHRoaXMgaW5zdGFuY2VvZiB0eXBlO1xyXG5cdH0sXHJcblxyXG5cdGlzT25lT2Y6IGZ1bmN0aW9uKHR5cGVzKSB7XHJcblx0XHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0XHRyZXR1cm4gdHlwZXMubWFwKGZ1bmN0aW9uKHR5cGUpIHtcclxuXHRcdFx0cmV0dXJuIHNlbGYuaXNBKHR5cGUpO1xyXG5cdFx0fSkucmVkdWNlKGZ1bmN0aW9uKHByZXZpb3VzVmFsdWUsIGN1cnJlbnRWYWx1ZSwgaW5kZXgsIGFycmF5KXtcclxuXHRcdFx0cmV0dXJuIHByZXZpb3VzVmFsdWUgfHwgY3VycmVudFZhbHVlO1xyXG5cdFx0fSwgZmFsc2UpO1xyXG5cdH0sXHJcblxyXG5cdHRvU3RyaW5nOiBmdW5jdGlvbigpIHtcclxuXHRcdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xyXG5cdH0sXHJcblxyXG5cdGlzRnVuY3Rpb25hbGx5U2FtZTogaXNGdW5jdGlvbmFsbHlTYW1lXHQvLyBDb252ZW5pZW5jZSB1dGlsaXR5IGZ1bmN0aW9uXHJcbn07XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IEx1bXA7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcclxuXHJcbnZhciBhcGk7XHJcblxyXG5mdW5jdGlvbiBQb3J0KHJhdywgcGFyZW50KSB7XHJcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXHJcblx0XHQnTmFtZScsXHJcblx0XHQnUm90YXRpb24nLFxyXG5cdFx0J1Bvc2l0aW9uJyxcclxuXHRcdCdEaXNjb3ZlcnlWYWx1ZScsXHJcblx0XHQnSXNTdGFydGluZ1BvcnQnXHJcblx0XTtcclxuXHJcblxyXG5cdHJhdy5JZCA9IHBhcmVudC5OYW1lK1wiL1wiK3Jhdy5OYW1lO1xyXG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcclxuXHJcblx0dGhpcy5TZXR0aW5nSWQgPSByYXcuU2V0dGluZy5JZDtcclxuXHR0aGlzLnNldHRpbmcgPSBudWxsO1xyXG5cclxuXHR0aGlzLmFyZWEgPSBudWxsO1xyXG5cclxuXHR0aGlzLmV4Y2hhbmdlcyA9IG51bGw7XHJcbn1cclxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFBvcnQucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcclxuXHJcblBvcnQucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xyXG5cdFxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblxyXG5cdHRoaXMuc2V0dGluZyA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuU2V0dGluZywgdGhpcy5hdHRyaWJzLlNldHRpbmcsIHRoaXMpO1xyXG5cdFxyXG5cdHRoaXMuYXJlYSA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuQXJlYSwgdGhpcy5hdHRyaWJzLkFyZWEsIHRoaXMpO1xyXG5cclxuXHR0aGlzLmV4Y2hhbmdlcyA9IGFwaS5saWJyYXJ5LkV4Y2hhbmdlLnF1ZXJ5KFwiU2V0dGluZ0lkc1wiLCBmdW5jdGlvbihpZHMpIHsgcmV0dXJuIGlkcy5pbmRleE9mKHNlbGYuU2V0dGluZ0lkKSAhPT0gLTE7IH0pO1xyXG5cclxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzLCBhcGkpO1xyXG59O1xyXG5cclxuUG9ydC5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbihsb25nKSB7XHJcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5OYW1lICsgXCIgKCNcIiArIHRoaXMuTmFtZSArIFwiKVwiO1xyXG59O1xyXG5cclxuUG9ydC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCB0YWcpIHtcclxuXHJcblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcclxuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xyXG5cclxuXHR2YXIgaHRtbCA9IFwiXCI7XHJcblxyXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcclxuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XHJcblxyXG5cdGh0bWwgPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XHJcblxyXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcclxuXHJcblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcclxuXHJcblx0cmV0dXJuIGVsZW1lbnQ7XHJcbn07XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IFBvcnQ7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcclxuXHJcbnZhciBhcGk7XHJcblxyXG5mdW5jdGlvbiBRdWFsaXR5RWZmZWN0KHJhdywgcGFyZW50KSB7XHJcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXCJMZXZlbFwiLCBcIlNldFRvRXhhY3RseVwiXTtcclxuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XHJcblxyXG5cdC8vIE1heSBpbnZvbHZlIFF1YWxpdHkgb2JqZWN0IHJlZmVyZW5jZXMsIHNvIGNhbid0IHJlc29sdmUgdW50aWwgYWZ0ZXIgYWxsIG9iamVjdHMgYXJlIHdpcmVkIHVwXHJcblx0dGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCA9IG51bGw7XHJcblx0dGhpcy5jaGFuZ2VCeUFkdmFuY2VkID0gbnVsbDtcdFxyXG5cclxuXHR0aGlzLmFzc29jaWF0ZWRRdWFsaXR5ID0gbnVsbDtcclxuXHRcclxufVxyXG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgUXVhbGl0eUVmZmVjdC5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xyXG5cclxuUXVhbGl0eUVmZmVjdC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XHJcblxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHJcblx0dGhpcy5hc3NvY2lhdGVkUXVhbGl0eSA9IGFwaS5nZXQoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5Bc3NvY2lhdGVkUXVhbGl0eUlkLCB0aGlzKTtcclxuXHR0aGlzLnNldFRvRXhhY3RseUFkdmFuY2VkID0gYXBpLmRlc2NyaWJlQWR2YW5jZWRFeHByZXNzaW9uKHRoaXMuYXR0cmlicy5TZXRUb0V4YWN0bHlBZHZhbmNlZCk7XHJcblx0dGhpcy5jaGFuZ2VCeUFkdmFuY2VkID0gYXBpLmRlc2NyaWJlQWR2YW5jZWRFeHByZXNzaW9uKHRoaXMuYXR0cmlicy5DaGFuZ2VCeUFkdmFuY2VkKTtcclxuXHJcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcclxufTtcclxuXHJcblF1YWxpdHlFZmZlY3QucHJvdG90eXBlLmdldFF1YW50aXR5ID0gZnVuY3Rpb24oKSB7XHJcblx0dmFyIGNvbmRpdGlvbiA9IFwiXCI7XHJcblx0XHJcblx0aWYodGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCAhPT0gbnVsbCkge1xyXG5cdFx0Y29uZGl0aW9uID0gXCIrKFwiICsgdGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCArIFwiKVwiO1xyXG5cdH1cclxuXHRlbHNlIGlmKHRoaXMuU2V0VG9FeGFjdGx5ICE9PSBudWxsKSB7XHJcblx0XHRjb25kaXRpb24gPSBcIj0gXCIgKyB0aGlzLlNldFRvRXhhY3RseTtcclxuXHR9XHJcblx0ZWxzZSBpZih0aGlzLmNoYW5nZUJ5QWR2YW5jZWQgIT09IG51bGwpIHtcclxuXHRcdGNvbmRpdGlvbiA9IFwiKyhcIiArIHRoaXMuY2hhbmdlQnlBZHZhbmNlZCArIFwiKVwiO1xyXG5cdH1cclxuXHRlbHNlIGlmKHRoaXMuTGV2ZWwgIT09IG51bGwpIHtcclxuXHRcdGlmKHRoaXMuTGV2ZWwgPCAwKSB7XHJcblx0XHRcdGNvbmRpdGlvbiA9IHRoaXMuTGV2ZWw7XHJcblx0XHR9XHJcblx0XHRlbHNlIGlmKHRoaXMuTGV2ZWwgPiAwKSB7XHJcblx0XHRcdGNvbmRpdGlvbiA9IFwiK1wiICsgdGhpcy5MZXZlbDtcclxuXHRcdH1cclxuXHR9XHJcblx0XHJcblx0cmV0dXJuIGNvbmRpdGlvbjtcclxufTtcclxuXHJcblF1YWxpdHlFZmZlY3QucHJvdG90eXBlLmlzQWRkaXRpdmUgPSBmdW5jdGlvbigpIHtcclxuXHRyZXR1cm4gdGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCB8fCB0aGlzLlNldFRvRXhhY3RseSB8fCB0aGlzLmNoYW5nZUJ5QWR2YW5jZWQgfHwgKHRoaXMuTGV2ZWwgPiAwKTtcclxufTtcclxuXHJcblF1YWxpdHlFZmZlY3QucHJvdG90eXBlLmlzU3VidHJhY3RpdmUgPSBmdW5jdGlvbigpIHtcclxuXHRyZXR1cm4gIXRoaXMuc2V0VG9FeGFjdGx5QWR2YW5jZWQgJiYgIXRoaXMuU2V0VG9FeGFjdGx5ICYmICF0aGlzLmNoYW5nZUJ5QWR2YW5jZWQgJiYgKHRoaXMuTGV2ZWwgPD0gMCk7XHJcbn07XHJcblxyXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xyXG5cdHZhciBxdWFsaXR5ID0gdGhpcy5hc3NvY2lhdGVkUXVhbGl0eTtcclxuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgKFwiK3RoaXMuSWQrXCIpIG9uIFwiICsgcXVhbGl0eSArIHRoaXMuZ2V0UXVhbnRpdHkoKTtcclxufTtcclxuXHJcblF1YWxpdHlFZmZlY3QucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSkge1xyXG5cclxuXHRzaXplID0gc2l6ZSB8fCBcInNtYWxsXCI7XHJcblxyXG5cdHZhciBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xyXG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcclxuXHJcblx0dmFyIHF1YWxpdHlfZWxlbWVudCA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XHJcblxyXG5cdGlmKCFxdWFsaXR5X2VsZW1lbnQpIHtcclxuXHRcdHF1YWxpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xyXG5cdFx0cXVhbGl0eV9lbGVtZW50LmlubmVySFRNTCA9IFwiW0lOVkFMSURdXCI7XHJcblx0fVxyXG5cdGVsc2Uge1xyXG5cdFx0cXVhbGl0eV9lbGVtZW50ID0gdGhpcy5hc3NvY2lhdGVkUXVhbGl0eS50b0RvbShzaXplLCBmYWxzZSwgXCJzcGFuXCIpO1xyXG5cdH1cclxuXHJcblx0dmFyIHF1YW50aXR5X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcclxuXHRxdWFudGl0eV9lbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBxdWFudGl0eVwiO1xyXG5cdHF1YW50aXR5X2VsZW1lbnQuaW5uZXJIVE1MID0gdGhpcy5nZXRRdWFudGl0eSgpO1xyXG5cdHF1YW50aXR5X2VsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XHJcblxyXG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQocXVhbGl0eV9lbGVtZW50KTtcclxuXHRlbGVtZW50LmFwcGVuZENoaWxkKHF1YW50aXR5X2VsZW1lbnQpO1xyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gUXVhbGl0eUVmZmVjdDsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xyXG5cclxudmFyIGFwaTtcclxuXHJcbmZ1bmN0aW9uIFF1YWxpdHlSZXF1aXJlbWVudChyYXcsIHBhcmVudCkge1xyXG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gWydNaW5MZXZlbCcsICdNYXhMZXZlbCddO1xyXG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcclxuXHJcblx0dGhpcy5kaWZmaWN1bHR5QWR2YW5jZWQgPSBudWxsO1xyXG5cdHRoaXMubWluQWR2YW5jZWQgPSBudWxsO1xyXG5cdHRoaXMubWF4QWR2YW5jZWQgPSBudWxsO1xyXG5cclxuXHR0aGlzLmFzc29jaWF0ZWRRdWFsaXR5ID0gbnVsbDtcclxuXHR0aGlzLmNoYW5jZVF1YWxpdHkgPSBudWxsO1xyXG59XHJcbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBRdWFsaXR5UmVxdWlyZW1lbnQucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcclxuXHJcblF1YWxpdHlSZXF1aXJlbWVudC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XHJcblxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHJcblx0dGhpcy5kaWZmaWN1bHR5QWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLkRpZmZpY3VsdHlBZHZhbmNlZCk7XHJcblx0dGhpcy5taW5BZHZhbmNlZCA9IGFwaS5kZXNjcmliZUFkdmFuY2VkRXhwcmVzc2lvbih0aGlzLmF0dHJpYnMuTWluQWR2YW5jZWQpO1xyXG5cdHRoaXMubWF4QWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLk1heEFkdmFuY2VkKTtcclxuXHJcblx0dGhpcy5hc3NvY2lhdGVkUXVhbGl0eSA9IGFwaS5nZXQoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5Bc3NvY2lhdGVkUXVhbGl0eUlkLCB0aGlzKTtcclxuXHJcblx0dGhpcy5jaGFuY2VRdWFsaXR5ID0gdGhpcy5nZXRDaGFuY2VDYXAoKTtcclxuXHJcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcclxufTtcclxuXHJcblF1YWxpdHlSZXF1aXJlbWVudC5wcm90b3R5cGUuZ2V0Q2hhbmNlQ2FwID0gZnVuY3Rpb24oKSB7XHJcblx0dmFyIHF1YWxpdHkgPSBudWxsO1xyXG5cdGlmKCF0aGlzLmF0dHJpYnMuRGlmZmljdWx0eUxldmVsKSB7XHJcblx0XHRyZXR1cm4gbnVsbDtcclxuXHR9XHJcblx0cXVhbGl0eSA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XHJcblx0aWYoIXF1YWxpdHkpIHtcclxuXHRcdHJldHVybiBudWxsO1xyXG5cdH1cclxuXHRcclxuXHRyZXR1cm4gTWF0aC5yb3VuZCh0aGlzLmF0dHJpYnMuRGlmZmljdWx0eUxldmVsICogKCgxMDAgKyBxdWFsaXR5LkRpZmZpY3VsdHlTY2FsZXIgKyA3KS8xMDApKTtcclxufTtcclxuXHJcblF1YWxpdHlSZXF1aXJlbWVudC5wcm90b3R5cGUuZ2V0UXVhbnRpdHkgPSBmdW5jdGlvbigpIHtcclxuXHR2YXIgY29uZGl0aW9uID0gXCJcIjtcclxuXHJcbiAgaWYodGhpcy5kaWZmaWN1bHR5QWR2YW5jZWQgIT09IG51bGwpIHtcclxuICBcdGNvbmRpdGlvbiA9IHRoaXMuZGlmZmljdWx0eUFkdmFuY2VkO1xyXG4gIH1cclxuICBlbHNlIGlmKHRoaXMubWluQWR2YW5jZWQgIT09IG51bGwpIHtcclxuICBcdGNvbmRpdGlvbiA9IHRoaXMubWluQWR2YW5jZWQ7XHJcbiAgfVxyXG4gIGVsc2UgaWYodGhpcy5tYXhBZHZhbmNlZCAhPT0gbnVsbCkge1xyXG4gIFx0Y29uZGl0aW9uID0gdGhpcy5tYXhBZHZhbmNlZDtcclxuICB9XHJcblx0ZWxzZSBpZih0aGlzLmNoYW5jZVF1YWxpdHkgIT09IG51bGwpIHtcclxuXHRcdGNvbmRpdGlvbiA9IHRoaXMuY2hhbmNlUXVhbGl0eSArIFwiIGZvciAxMDAlXCI7XHJcblx0fVxyXG5cdGVsc2UgaWYodGhpcy5NYXhMZXZlbCAhPT0gbnVsbCAmJiB0aGlzLk1pbkxldmVsICE9PSBudWxsKSB7XHJcblx0XHRpZih0aGlzLk1heExldmVsID09PSB0aGlzLk1pbkxldmVsKSB7XHJcblx0XHRcdGNvbmRpdGlvbiA9IFwiPSBcIiArIHRoaXMuTWluTGV2ZWw7XHJcblx0XHR9XHJcblx0XHRlbHNlIHtcclxuXHRcdFx0Y29uZGl0aW9uID0gdGhpcy5NaW5MZXZlbCArIFwiLVwiICsgdGhpcy5NYXhMZXZlbDtcclxuXHRcdH1cclxuXHR9XHJcblx0ZWxzZSB7XHJcblx0XHRpZih0aGlzLk1pbkxldmVsICE9PSBudWxsKSB7XHJcblx0XHRcdGNvbmRpdGlvbiA9IFwiJmdlOyBcIiArIHRoaXMuTWluTGV2ZWw7XHJcblx0XHR9XHJcblx0XHRpZih0aGlzLk1heExldmVsICE9PSBudWxsKSB7XHJcblx0XHRcdGNvbmRpdGlvbiA9IFwiJmxlOyBcIiArIHRoaXMuTWF4TGV2ZWw7XHJcblx0XHR9XHJcblx0fVxyXG5cdHJldHVybiBjb25kaXRpb247XHJcbn07XHJcblxyXG5RdWFsaXR5UmVxdWlyZW1lbnQucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XHJcblx0dmFyIHF1YWxpdHkgPSB0aGlzLmFzc29jaWF0ZWRRdWFsaXR5O1xyXG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoXCIrdGhpcy5JZCtcIikgb24gXCIgKyBxdWFsaXR5ICsgXCIgXCIgKyB0aGlzLmdldFF1YW50aXR5KCk7XHJcbn07XHJcblxyXG5RdWFsaXR5UmVxdWlyZW1lbnQucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSkge1xyXG5cclxuXHRzaXplID0gc2l6ZSB8fCBcInNtYWxsXCI7XHJcblxyXG5cdHZhciBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xyXG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcclxuXHJcblx0dmFyIHF1YWxpdHlfZWxlbWVudCA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XHJcblxyXG5cdGlmKCFxdWFsaXR5X2VsZW1lbnQpIHtcclxuXHRcdHF1YWxpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xyXG5cdFx0cXVhbGl0eV9lbGVtZW50LmlubmVySFRNTCA9IFwiW0lOVkFMSURdXCI7XHJcblx0fVxyXG5cdGVsc2Uge1xyXG5cdFx0cXVhbGl0eV9lbGVtZW50ID0gdGhpcy5hc3NvY2lhdGVkUXVhbGl0eS50b0RvbShzaXplLCBmYWxzZSwgXCJzcGFuXCIpO1xyXG5cdH1cclxuXHJcblx0dmFyIHF1YW50aXR5X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcclxuXHRxdWFudGl0eV9lbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBxdWFudGl0eVwiO1xyXG5cdHF1YW50aXR5X2VsZW1lbnQuaW5uZXJIVE1MID0gdGhpcy5nZXRRdWFudGl0eSgpO1xyXG5cdHF1YW50aXR5X2VsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XHJcblxyXG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQocXVhbGl0eV9lbGVtZW50KTtcclxuXHRlbGVtZW50LmFwcGVuZENoaWxkKHF1YW50aXR5X2VsZW1lbnQpO1xyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gUXVhbGl0eVJlcXVpcmVtZW50OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XHJcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcclxuXHJcbnZhciBhcGk7XHJcblxyXG5mdW5jdGlvbiBRdWFsaXR5KHJhdywgcGFyZW50KSB7XHJcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXHJcblx0XHQnTmFtZScsXHJcblx0XHQnRGVzY3JpcHRpb24nLFxyXG5cdFx0J0ltYWdlJyxcclxuXHJcblx0XHQnQ2F0ZWdvcnknLFxyXG5cdFx0J05hdHVyZScsXHJcblx0XHQnVGFnJyxcclxuXHJcblx0XHRcIklzU2xvdFwiLFxyXG5cclxuXHRcdCdBbGxvd2VkT24nLFxyXG5cdFx0XCJBdmFpbGFibGVBdFwiLFxyXG5cclxuXHRcdCdDYXAnLFxyXG5cdFx0J0RpZmZpY3VsdHlTY2FsZXInLFxyXG5cdFx0J0VuaGFuY2VtZW50cydcclxuXHRdO1xyXG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcclxuXHJcblx0dGhpcy5TdGF0ZXMgPSB0aGlzLmdldFN0YXRlcyhyYXcuQ2hhbmdlRGVzY3JpcHRpb25UZXh0KTtcclxuXHR0aGlzLkxldmVsRGVzY3JpcHRpb25UZXh0ID0gdGhpcy5nZXRTdGF0ZXMocmF3LkxldmVsRGVzY3JpcHRpb25UZXh0KTtcclxuXHR0aGlzLkxldmVsSW1hZ2VUZXh0ID0gdGhpcy5nZXRTdGF0ZXMocmF3LkxldmVsSW1hZ2VUZXh0KTtcclxuXHJcblx0dGhpcy51c2VFdmVudCA9IG51bGw7XHJcbn1cclxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFF1YWxpdHkucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcclxuXHJcblF1YWxpdHkucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xyXG5cclxuXHRhcGkgPSB0aGVBcGk7XHJcblxyXG5cdHRoaXMudXNlRXZlbnQgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLkV2ZW50LCB0aGlzLmF0dHJpYnMuVXNlRXZlbnQsIHRoaXMpO1xyXG5cdGlmKHRoaXMudXNlRXZlbnQpIHtcclxuXHRcdHRoaXMudXNlRXZlbnQudGFnID0gXCJ1c2VcIjtcclxuXHR9XHJcblxyXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XHJcbn07XHJcblxyXG5RdWFsaXR5LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKGxvbmcpIHtcclxuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyAobG9uZyA/IFwiIFtcIiArIHRoaXMuTmF0dXJlICsgXCIgPiBcIiArIHRoaXMuQ2F0ZWdvcnkgKyBcIiA+IFwiICsgdGhpcy5UYWcgKyBcIl0gXCIgOiBcIlwiKSArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XHJcbn07XHJcblxyXG5RdWFsaXR5LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XHJcblxyXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XHJcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcclxuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xyXG5cclxuXHR2YXIgaHRtbCA9IFwiXCI7XHJcblxyXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcclxuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XHJcblxyXG5cdGh0bWwgPSBcIlxcbjxpbWcgY2xhc3M9J2ljb24nIHNyYz0nXCIrYXBpLmNvbmZpZy5sb2NhdGlvbnMuaW1hZ2VzUGF0aCtcIi9cIit0aGlzLkltYWdlK1wic21hbGwucG5nJyAvPlwiO1xyXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCI8L2gzPlwiO1xyXG5cdGh0bWwgKz0gXCJcXG48cCBjbGFzcz0nZGVzY3JpcHRpb24nPlwiK3RoaXMuRGVzY3JpcHRpb24rXCI8L3A+XCI7XHJcblxyXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcclxuXHJcblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcclxuXHJcblx0aWYoaW5jbHVkZUNoaWxkcmVuKSB7XHJcblx0XHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XHJcblx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcblxyXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XHJcblx0XHRcdGlmKGNoaWxkTGlzdCkge1xyXG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlIHtcclxuXHRcdFx0XHRpZihzZWxmLnVzZUV2ZW50KSB7XHJcblxyXG5cdFx0XHRcdFx0dmFyIHdyYXBwZXJDbHVtcCA9IG5ldyBDbHVtcChbc2VsZi51c2VFdmVudF0sIGFwaS50eXBlcy5FdmVudCk7XHJcblx0XHRcdFx0XHR2YXIgY2hpbGRfZXZlbnRzID0gd3JhcHBlckNsdW1wLnRvRG9tKHNpemUsIHRydWUpO1xyXG5cclxuXHRcdFx0XHRcdGNoaWxkX2V2ZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcclxuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY2hpbGRfZXZlbnRzKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH0pO1xyXG5cdH1cclxuXHJcblx0cmV0dXJuIGVsZW1lbnQ7XHJcbn07XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IFF1YWxpdHk7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcclxuXHJcbnZhciBhcGk7XHJcblxyXG5mdW5jdGlvbiBTZXR0aW5nKHJhdywgcGFyZW50KSB7XHJcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXHJcblx0XHQnSWQnXHJcblx0XTtcclxuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XHJcblxyXG5cdHRoaXMuc2hvcHMgPSBudWxsO1xyXG59XHJcbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBTZXR0aW5nLnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XHJcblxyXG5TZXR0aW5nLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcclxuXHJcblx0YXBpID0gdGhlQXBpO1xyXG5cclxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzKTtcclxufTtcclxuXHJcblNldHRpbmcucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XHJcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiICNcIiArIHRoaXMuSWQ7XHJcbn07XHJcblxyXG5TZXR0aW5nLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XHJcblxyXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XHJcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcclxuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xyXG5cclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0dmFyIGh0bWwgPSBcIlwiO1xyXG5cclxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XHJcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xyXG5cclxuXHRodG1sID0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLklkK1wiPC9oMz5cIjtcclxuXHJcblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xyXG5cclxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gU2V0dGluZzsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xyXG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XHJcblxyXG52YXIgYXBpO1xyXG5cclxuZnVuY3Rpb24gU2hvcChyYXcsIHBhcmVudCkge1xyXG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xyXG5cdFx0J0lkJyxcclxuXHRcdCdOYW1lJyxcclxuXHRcdCdEZXNjcmlwdGlvbicsXHJcblx0XHQnSW1hZ2UnLFxyXG5cdFx0J09yZGVyaW5nJ1xyXG5cdF07XHJcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xyXG5cclxuXHR0aGlzLmF2YWlsYWJpbGl0aWVzID0gbnVsbDtcclxuXHR0aGlzLnVubG9ja0Nvc3QgPSBudWxsO1xyXG59XHJcbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBTaG9wLnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XHJcblxyXG5TaG9wLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcclxuXHJcblx0YXBpID0gdGhlQXBpO1xyXG5cclxuXHR0aGlzLmF2YWlsYWJpbGl0aWVzID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5BdmFpbGFiaWxpdGllcyB8fCBbXSwgYXBpLnR5cGVzLkF2YWlsYWJpbGl0eSwgdGhpcyk7XHJcblxyXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMpO1xyXG59O1xyXG5cclxuU2hvcC5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcclxuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xyXG59O1xyXG5cclxuU2hvcC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4sIHRhZykge1xyXG5cclxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xyXG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XHJcblx0dGFnID0gdGFnIHx8IFwibGlcIjtcclxuXHJcblx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdHZhciBodG1sID0gXCJcIjtcclxuXHJcblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xyXG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcclxuXHJcblx0aHRtbCA9IFwiXFxuPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCIucG5nJyAvPlwiO1xyXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCI8L2gzPlwiO1xyXG5cdGh0bWwgKz0gXCJcXG48cCBjbGFzcz0nZGVzY3JpcHRpb24nPlwiK3RoaXMuRGVzY3JpcHRpb24rXCI8L3A+XCI7XHJcblxyXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcclxuXHJcblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcclxuXHJcblx0aWYoaW5jbHVkZUNoaWxkcmVuKSB7XHJcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XHJcblx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcblxyXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XHJcblx0XHRcdGlmKGNoaWxkTGlzdCkge1xyXG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlIHtcclxuXHRcdFx0XHRpZihzZWxmLmF2YWlsYWJpbGl0aWVzKSB7XHJcblxyXG5cdFx0XHRcdFx0dmFyIGNoaWxkX2VsZW1lbnRzID0gc2VsZi5hdmFpbGFiaWxpdGllcy50b0RvbShcIm5vcm1hbFwiLCB0cnVlKTtcclxuXHJcblx0XHRcdFx0XHRjaGlsZF9lbGVtZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcclxuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY2hpbGRfZWxlbWVudHMpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0fVxyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gU2hvcDsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xyXG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XHJcblxyXG52YXIgYXBpO1xyXG5cclxuZnVuY3Rpb24gU3Bhd25lZEVudGl0eShyYXcsIHBhcmVudCkge1xyXG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xyXG5cdFx0J05hbWUnLFxyXG5cdFx0J0h1bWFuTmFtZScsXHJcblxyXG5cdFx0J05ldXRyYWwnLFxyXG5cdFx0J1ByZWZhYk5hbWUnLFxyXG5cdFx0J0Rvcm1hbnRCZWhhdmlvdXInLFxyXG5cdFx0J0F3YXJlQmVoYXZpb3VyJyxcclxuXHJcblx0XHQnSHVsbCcsXHJcblx0XHQnQ3JldycsXHJcblx0XHQnTGlmZScsXHJcblx0XHQnTW92ZW1lbnRTcGVlZCcsXHJcblx0XHQnUm90YXRpb25TcGVlZCcsXHJcblx0XHQnQmVhc3RpZUNoYXJhY3RlcmlzdGljc05hbWUnLFxyXG5cdFx0J0NvbWJhdEl0ZW1zJyxcclxuXHRcdCdMb290UHJlZmFiTmFtZScsXHJcblx0XHQnR2xlYW1WYWx1ZSdcclxuXHRdO1xyXG5cdHJhdy5JZCA9IHJhdy5OYW1lO1xyXG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcclxuXHJcblx0dGhpcy5wYWNpZnlFdmVudCA9IG51bGw7XHJcblx0dGhpcy5raWxsUXVhbGl0eUV2ZW50ID0gbnVsbDtcclxuXHR0aGlzLmNvbWJhdEF0dGFja05hbWVzID0gW107XHJcblxyXG5cdHRoaXMuaW1hZ2UgPSBudWxsO1xyXG59XHJcbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBTcGF3bmVkRW50aXR5LnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XHJcblxyXG5TcGF3bmVkRW50aXR5LnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcclxuXHJcblx0YXBpID0gdGhlQXBpO1xyXG5cclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0XHJcblx0dGhpcy5jb21iYXRBdHRhY2tOYW1lcyA9ICh0aGlzLmF0dHJpYnMuQ29tYmF0QXR0YWNrTmFtZXMgfHwgW10pLm1hcChmdW5jdGlvbihuYW1lKSB7XHJcblx0XHRyZXR1cm4gYXBpLmdldChhcGkudHlwZXMuQ29tYmF0QXR0YWNrLCBuYW1lLCBzZWxmKTtcclxuXHR9KS5maWx0ZXIoZnVuY3Rpb24oYXR0YWNrKSB7XHJcblx0XHRyZXR1cm4gdHlwZW9mIGF0dGFjayA9PT0gXCJvYmplY3RcIjtcclxuXHR9KTtcclxuXHJcblx0dGhpcy5wYWNpZnlFdmVudCA9IGFwaS5nZXQoYXBpLnR5cGVzLkV2ZW50LCB0aGlzLmF0dHJpYnMuUGFjaWZ5RXZlbnRJZCwgdGhpcyk7XHJcblx0aWYodGhpcy5wYWNpZnlFdmVudCkge1xyXG5cdFx0dGhpcy5wYWNpZnlFdmVudC50YWcgPSBcInBhY2lmaWVkXCI7XHJcblx0fVxyXG5cclxuXHR0aGlzLmtpbGxRdWFsaXR5RXZlbnQgPSBhcGkuZ2V0KGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLktpbGxRdWFsaXR5RXZlbnRJZCwgdGhpcyk7XHJcblx0aWYodGhpcy5raWxsUXVhbGl0eUV2ZW50KSB7XHJcblx0XHR0aGlzLmtpbGxRdWFsaXR5RXZlbnQudGFnID0gXCJraWxsZWRcIjtcclxuXHR9XHJcblxyXG5cdHRoaXMuaW1hZ2UgPSAoKHRoaXMua2lsbFF1YWxpdHlFdmVudCAmJiB0aGlzLmtpbGxRdWFsaXR5RXZlbnQuSW1hZ2UpIHx8ICh0aGlzLnBhY2lmeUV2ZW50ICYmIHRoaXMucGFjaWZ5RXZlbnQuSW1hZ2UpKTtcclxuXHJcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcclxufTtcclxuXHJcblNwYXduZWRFbnRpdHkucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XHJcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5IdW1hbk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xyXG59O1xyXG5cclxuU3Bhd25lZEVudGl0eS5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4pIHtcclxuXHJcblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcclxuXHRpbmNsdWRlQ2hpbGRyZW4gPSBpbmNsdWRlQ2hpbGRyZW4gPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xyXG5cclxuXHR2YXIgc2VsZiA9IHRoaXM7XHJcblxyXG5cdHZhciBodG1sID0gXCJcIjtcclxuXHJcblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xyXG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcclxuXHJcblx0aWYodGhpcy5JbWFnZSAhPT0gbnVsbCAmJiB0aGlzLkltYWdlICE9PSBcIlwiKSB7XHJcblx0XHRodG1sID0gXCI8aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5pbWFnZStcInNtYWxsLnBuZycgLz5cIjtcclxuXHR9XHJcblxyXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLkh1bWFuTmFtZStcIjwvaDM+XCI7XHJcblxyXG5cdGlmKHNpemUgIT09IFwic21hbGxcIikge1xyXG5cdFx0aWYodGhpcy5xdWFsaXRpZXNSZXF1aXJlZCkge1xyXG5cdFx0XHRodG1sICs9IFwiPGRpdiBjbGFzcz0nc2lkZWJhcic+XCI7XHJcblx0XHRcdGh0bWwgKz0gdGhpcy5xdWFsaXRpZXNSZXF1aXJlZC50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInVsXCIpLm91dGVySFRNTDtcclxuXHRcdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xyXG5cdFx0fVxyXG5cclxuXHRcdGh0bWwgKz0gXCI8ZGwgY2xhc3M9J2NsdW1wLWxpc3Qgc21hbGwnPlwiO1xyXG5cclxuXHRcdFsnSHVsbCcsICdDcmV3JywgJ0xpZmUnLCAnTW92ZW1lbnRTcGVlZCcsICdSb3RhdGlvblNwZWVkJ10uZm9yRWFjaChmdW5jdGlvbihrZXkpIHtcclxuXHRcdFx0aHRtbCArPSBcIjxkdCBjbGFzcz0naXRlbSc+XCIra2V5K1wiPC9kdD48ZGQgY2xhc3M9J3F1YW50aXR5Jz5cIitzZWxmW2tleV0rXCI8L2RkPlwiO1xyXG5cdFx0fSk7XHJcblx0XHRodG1sICs9IFwiPC9kbD5cIjtcclxuXHR9XHJcblxyXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcclxuXHJcblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcclxuXHJcblx0aWYoaW5jbHVkZUNoaWxkcmVuKSB7XHJcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XHJcblx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcblxyXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XHJcblx0XHRcdGlmKGNoaWxkTGlzdCkge1xyXG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlIHtcclxuXHRcdFx0XHR2YXIgc3VjY2Vzc0V2ZW50ID0gc2VsZi5zdWNjZXNzRXZlbnQ7XHJcblx0XHRcdFx0dmFyIGRlZmF1bHRFdmVudCA9IHNlbGYuZGVmYXVsdEV2ZW50O1xyXG5cdFx0XHRcdHZhciBxdWFsaXRpZXNSZXF1aXJlZCA9ICBzZWxmLnF1YWxpdGllc1JlcXVpcmVkO1xyXG5cdFx0XHRcdHZhciBldmVudHMgPSBbXTtcclxuXHRcdFx0XHRpZihzdWNjZXNzRXZlbnQgJiYgcXVhbGl0aWVzUmVxdWlyZWQgJiYgcXVhbGl0aWVzUmVxdWlyZWQuc2l6ZSgpKSB7XHJcblx0XHRcdFx0XHRldmVudHMucHVzaChzdWNjZXNzRXZlbnQpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpZihkZWZhdWx0RXZlbnQpIHtcclxuXHRcdFx0XHRcdGV2ZW50cy5wdXNoKGRlZmF1bHRFdmVudCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGlmKGV2ZW50cy5sZW5ndGgpIHtcclxuXHRcdFx0XHRcdHZhciB3cmFwcGVyQ2x1bXAgPSBuZXcgQ2x1bXAoZXZlbnRzLCBhcGkudHlwZXMuRXZlbnQpO1xyXG5cdFx0XHRcdFx0dmFyIGNoaWxkX2V2ZW50cyA9IHdyYXBwZXJDbHVtcC50b0RvbShzaXplLCB0cnVlKTtcclxuXHJcblx0XHRcdFx0XHRjaGlsZF9ldmVudHMuY2xhc3NMaXN0LmFkZChcImNoaWxkLWxpc3RcIik7XHJcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2V2ZW50cyk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHR9XHJcblxyXG5cdHJldHVybiBlbGVtZW50O1xyXG59O1xyXG5cclxubW9kdWxlLmV4cG9ydHMgPSBTcGF3bmVkRW50aXR5OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XHJcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcclxudmFyIFBvcnQgPSByZXF1aXJlKCcuL3BvcnQnKTtcclxudmFyIEFyZWEgPSByZXF1aXJlKCcuL2FyZWEnKTtcclxuXHJcbnZhciBhcGk7XHJcblxyXG5mdW5jdGlvbiBUaWxlVmFyaWFudChyYXcsIHBhcmVudCkge1xyXG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xyXG5cdFx0J05hbWUnLFxyXG5cdFx0J0h1bWFuTmFtZScsXHJcblx0XHQnRGVzY3JpcHRpb24nLFxyXG5cclxuXHRcdCdNYXhUaWxlUG9wdWxhdGlvbicsXHJcblx0XHQnTWluVGlsZVBvcHVsYXRpb24nLFxyXG5cdFx0XHJcblx0XHQnU2VhQ29sb3VyJyxcclxuXHRcdCdNdXNpY1RyYWNrTmFtZScsXHJcblx0XHQnQ2hhbmNlT2ZXZWF0aGVyJyxcclxuXHRcdCdGb2dSZXZlYWxUaHJlc2hvbGQnXHJcblx0XTtcclxuXHJcbi8qXHJcbkxhYmVsRGF0YTogQXJyYXlbNl1cclxuUGhlbm9tZW5hRGF0YTogQXJyYXlbMV1cclxuU3Bhd25Qb2ludHM6IEFycmF5WzJdXHJcblRlcnJhaW5EYXRhOiBBcnJheVsxNF1cclxuV2VhdGhlcjogQXJyYXlbMV1cclxuKi9cclxuXHJcblx0cmF3LklkID0gcGFyZW50Lk5hbWUrXCIvXCIrcmF3Lk5hbWU7XHJcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xyXG5cclxuXHR0aGlzLlNldHRpbmdJZCA9IHJhdy5TZXR0aW5nLklkO1xyXG5cdHRoaXMuc2V0dGluZyA9IG51bGw7XHJcblxyXG5cdHRoaXMucG9ydHMgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlBvcnREYXRhIHx8IFtdLCBQb3J0LCB0aGlzKTtcclxuXHJcblx0dGhpcy5hcmVhcyA9IG51bGw7XHJcbn1cclxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFRpbGVWYXJpYW50LnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XHJcblxyXG5UaWxlVmFyaWFudC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XHJcblxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHJcblx0dGhpcy5zZXR0aW5nID0gYXBpLmdldE9yQ3JlYXRlKGFwaS50eXBlcy5TZXR0aW5nLCB0aGlzLmF0dHJpYnMuU2V0dGluZywgdGhpcyk7XHJcblxyXG5cdHRoaXMucG9ydHMuZm9yRWFjaChmdW5jdGlvbihwKSB7IHAud2lyZVVwKGFwaSk7IH0pO1xyXG5cclxuXHQvLyBBbHNvIGNyZWF0ZSBhIGxpc3Qgb2YgYWxsIHRoZSBhcmVhcyBvZiBlYWNoIG9mIHRoZSBwb3J0cyBpbiB0aGlzIG9iamVjdCBmb3IgY29udmVuaWVuY2VcclxuXHR0aGlzLmFyZWFzID0gbmV3IENsdW1wKHRoaXMucG9ydHMubWFwKGZ1bmN0aW9uKHApIHsgcmV0dXJuIHAuYXJlYTsgfSksIGFwaS50eXBlcy5BcmVhLCB0aGlzKTtcclxuXHJcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcyk7XHJcbn07XHJcblxyXG5UaWxlVmFyaWFudC5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbihsb25nKSB7XHJcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5IdW1hbk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XHJcbn07XHJcblxyXG5UaWxlVmFyaWFudC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCB0YWcpIHtcclxuXHJcblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcclxuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xyXG5cclxuXHR2YXIgaHRtbCA9IFwiXCI7XHJcblxyXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcclxuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XHJcblxyXG5cdGh0bWwgPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuSHVtYW5OYW1lK1wiPC9oMz5cIjtcclxuXHJcblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xyXG5cclxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gVGlsZVZhcmlhbnQ7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcclxudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xyXG52YXIgVGlsZVZhcmlhbnQgPSByZXF1aXJlKCcuL3RpbGUtdmFyaWFudCcpO1xyXG52YXIgUG9ydCA9IHJlcXVpcmUoJy4vcG9ydCcpO1xyXG52YXIgQXJlYSA9IHJlcXVpcmUoJy4vYXJlYScpO1xyXG5cclxudmFyIGFwaTtcclxuXHJcbmZ1bmN0aW9uIFRpbGUocmF3LCBwYXJlbnQpIHtcclxuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcclxuXHRcdCdOYW1lJ1xyXG5cdF07XHJcblx0cmF3LklkID0gcmF3Lk5hbWU7XHJcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xyXG5cclxuXHR0aGlzLnRpbGVWYXJpYW50cyA9IG5ldyBDbHVtcCh0aGlzLmF0dHJpYnMuVGlsZXMgfHwgW10sIFRpbGVWYXJpYW50LCB0aGlzKTtcclxufVxyXG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgVGlsZS5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xyXG5cclxuVGlsZS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XHJcblxyXG5cdGFwaSA9IHRoZUFwaTtcclxuXHJcblx0dGhpcy50aWxlVmFyaWFudHMuZm9yRWFjaChmdW5jdGlvbih0dikgeyB0di53aXJlVXAoYXBpKTsgfSk7XHJcblxyXG5cdC8vIEFsc28gY3JlYXRlIGEgbGlzdCBvZiBhbGwgdGhlIHBvcnRzIGFuZCBhcmVhcyBvZiBlYWNoIG9mIHRoZSB0aWxldmFyaWFudHMgaW4gdGhpcyBvYmplY3QgZm9yIGNvbnZlbmllbmNlXHJcblx0dmFyIGFsbF9wb3J0cyA9IHt9O1xyXG5cdHZhciBhbGxfYXJlYXMgPSB7fTtcclxuXHR0aGlzLnRpbGVWYXJpYW50cy5mb3JFYWNoKGZ1bmN0aW9uKHR2KSB7XHJcblx0XHR0di5wb3J0cy5mb3JFYWNoKGZ1bmN0aW9uKHApIHtcclxuXHRcdFx0YWxsX3BvcnRzW3AuSWRdID0gcDtcclxuXHRcdFx0YWxsX2FyZWFzW3AuYXJlYS5JZF0gPSBwLmFyZWE7XHJcblx0XHR9KTtcclxuXHR9KTtcclxuXHR0aGlzLnBvcnRzID0gbmV3IENsdW1wKE9iamVjdC5rZXlzKGFsbF9wb3J0cykubWFwKGZ1bmN0aW9uKHApIHsgcmV0dXJuIGFsbF9wb3J0c1twXTsgfSksIGFwaS50eXBlcy5Qb3J0LCB0aGlzKTtcclxuXHR0aGlzLmFyZWFzID0gbmV3IENsdW1wKE9iamVjdC5rZXlzKGFsbF9hcmVhcykubWFwKGZ1bmN0aW9uKGEpIHsgcmV0dXJuIGFsbF9hcmVhc1thXTsgfSksIGFwaS50eXBlcy5BcmVhLCB0aGlzKTtcclxuXHJcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcyk7XHJcbn07XHJcblxyXG5UaWxlLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKGxvbmcpIHtcclxuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XHJcbn07XHJcblxyXG5UaWxlLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIHRhZykge1xyXG5cclxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xyXG5cdHRhZyA9IHRhZyB8fCBcImxpXCI7XHJcblxyXG5cdHZhciBodG1sID0gXCJcIjtcclxuXHJcblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xyXG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcclxuXHJcblx0aHRtbCA9IFwiXFxuPGgzIGNsYXNzPSd0aXRsZSc+XCIrdGhpcy5OYW1lK1wiPC9oMz5cIjtcclxuXHJcblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xyXG5cclxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xyXG5cclxuXHRyZXR1cm4gZWxlbWVudDtcclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gVGlsZTsiLCJ2YXIgYXBpID0gcmVxdWlyZSgnLi9hcGknKTtcclxudmFyIGRyYWduZHJvcCA9IHJlcXVpcmUoJy4vdWkvZHJhZ25kcm9wJyk7XHJcbnZhciBxdWVyeSA9IHJlcXVpcmUoJy4vdWkvcXVlcnknKTtcclxuXHJcblxyXG4kKFwiI3RhYnMgLmJ1dHRvbnMgbGlcIikub24oXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XHJcblxyXG4gIHZhciB0eXBlID0gJCh0aGlzKS5hdHRyKFwiZGF0YS10eXBlXCIpO1xyXG5cclxuICAkKFwiI3RhYnMgLnBhbmVzIC5wYW5lXCIpLmhpZGUoKTsgLy8gSGlkZSBhbGwgcGFuZXNcclxuICAkKFwiI3RhYnMgLmJ1dHRvbnMgbGlcIikucmVtb3ZlQ2xhc3MoXCJhY3RpdmVcIik7IC8vIERlYWN0aXZhdGUgYWxsIGJ1dHRvbnNcclxuXHJcbiAgJChcIiN0YWJzIC5wYW5lcyAuXCIrdHlwZS50b0xvd2VyQ2FzZSgpKS5zaG93KCk7XHJcbiAgJChcIiN0YWJzIC5idXR0b25zIFtkYXRhLXR5cGU9XCIrdHlwZStcIl1cIikuYWRkQ2xhc3MoXCJhY3RpdmVcIik7XHJcbn0pO1xyXG5cclxuLy8gU2V0dXAgdGhlIGRuZCBsaXN0ZW5lcnMuXHJcbnZhciBkcm9wWm9uZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkcm9wLXpvbmUnKTtcclxuXHJcbmRyb3Bab25lLmFkZEV2ZW50TGlzdGVuZXIoJ2RyYWdlbnRlcicsIGRyYWduZHJvcC5oYW5kbGVycy5kcmFnT3ZlciwgZmFsc2UpO1xyXG5kcm9wWm9uZS5hZGRFdmVudExpc3RlbmVyKCdkcmFnbGVhdmUnLCBkcmFnbmRyb3AuaGFuZGxlcnMuZHJhZ0VuZCwgZmFsc2UpO1xyXG5kcm9wWm9uZS5hZGRFdmVudExpc3RlbmVyKCdkcmFnb3ZlcicsIGRyYWduZHJvcC5oYW5kbGVycy5kcmFnT3ZlciwgZmFsc2UpO1xyXG5cclxuZHJvcFpvbmUuYWRkRXZlbnRMaXN0ZW5lcignZHJvcCcsIGRyYWduZHJvcC5oYW5kbGVycy5kcmFnRHJvcCwgZmFsc2UpO1xyXG5cclxuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3BhdGhzLXRvLW5vZGUnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHF1ZXJ5LnBhdGhzVG9Ob2RlVUksIGZhbHNlKTtcclxuXHJcbi8vIEZvciBjb252ZW5pZW5jZVxyXG53aW5kb3cuYXBpID0gYXBpO1xyXG53aW5kb3cuYXBpLnF1ZXJ5ID0gcXVlcnk7IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4uL2FwaScpO1xyXG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuLi9vYmplY3RzL2NsdW1wJyk7XHJcbnZhciBpbyA9IHJlcXVpcmUoJy4uL2lvJyk7XHJcblxyXG52YXIgcmVuZGVyID0gcmVxdWlyZSgnLi9yZW5kZXInKTtcclxuXHJcbmZ1bmN0aW9uIGhhbmRsZURyYWdPdmVyKGV2dCkge1xyXG4gIGV2dC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICBldnQucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgJChcIiNkcm9wLXpvbmVcIikuYWRkQ2xhc3MoXCJkcm9wLXRhcmdldFwiKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaGFuZGxlRHJhZ0VuZChldnQpIHtcclxuICBldnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgZXZ0LnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICQoXCIjZHJvcC16b25lXCIpLnJlbW92ZUNsYXNzKFwiZHJvcC10YXJnZXRcIik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhhbmRsZURyYWdEcm9wKGV2dCkge1xyXG5cclxuICAkKFwiI2Ryb3Atem9uZVwiKS5yZW1vdmVDbGFzcyhcImRyb3AtdGFyZ2V0XCIpO1xyXG5cclxuICBldnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgZXZ0LnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gIHZhciBmaWxlcyA9IGV2dC5kYXRhVHJhbnNmZXIuZmlsZXM7IC8vIEZpbGVMaXN0IG9iamVjdC5cclxuXHJcbiAgLy8gRmlsZXMgaXMgYSBGaWxlTGlzdCBvZiBGaWxlIG9iamVjdHMuIExpc3Qgc29tZSBwcm9wZXJ0aWVzLlxyXG4gIHZhciBvdXRwdXQgPSBbXTtcclxuICBpby5yZXNldEZpbGVzVG9Mb2FkKCk7XHJcblxyXG4gIHZhciBwcm9jZXNzRmlsZSA9IGZ1bmN0aW9uKCkge1xyXG4gICAgaW8uZGVjcmVtZW50RmlsZXNUb0xvYWQoKTtcclxuXHJcbiAgICBpZihpby5jb3VudEZpbGVzVG9Mb2FkKCkgPT09IDApIHtcclxuICAgICAgYXBpLndpcmVVcE9iamVjdHMoKTtcclxuICAgICAgcmVuZGVyLmxpc3RzKCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBmaWxlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgdmFyIGYgPSBmaWxlc1tpXTtcclxuICAgIHZhciBmaWxlbmFtZSA9IGVzY2FwZShmLm5hbWUpO1xyXG4gICAgdmFyIHR5cGVOYW1lID0gaW8uZmlsZU9iamVjdE1hcFtmaWxlbmFtZV07XHJcbiAgICB2YXIgVHlwZSA9IGFwaS50eXBlc1t0eXBlTmFtZV07XHJcbiAgICBpZihUeXBlKSB7XHJcbiAgICAgIGlvLmluY3JlbWVudEZpbGVzVG9Mb2FkKCk7XHJcbiAgICAgIGFwaS5yZWFkRnJvbUZpbGUoVHlwZSwgZiwgcHJvY2Vzc0ZpbGUpO1xyXG4gICAgICBvdXRwdXQucHVzaCgnPGxpIGNsYXNzPVwic3VjY2Vzc1wiPjxzdHJvbmc+JywgZXNjYXBlKGYubmFtZSksICc8L3N0cm9uZz4gKCcsIGYudHlwZSB8fCAnbi9hJywgJykgLSBzdXBwb3J0ZWQ6ICcsXHJcbiAgICAgICAgZi5zaXplLCAnIGJ5dGVzLCBsYXN0IG1vZGlmaWVkOiAnLFxyXG4gICAgICAgIGYubGFzdE1vZGlmaWVkRGF0ZSA/IGYubGFzdE1vZGlmaWVkRGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoKSA6ICduL2EnLFxyXG4gICAgICAgICc8L2xpPicpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIG91dHB1dC5wdXNoKCc8bGkgY2xhc3M9XCJpbmZvXCI+PHN0cm9uZz4nICwgZXNjYXBlKGYubmFtZSksICc8L3N0cm9uZz4gLSBub3Qgc3VwcG9ydGVkOiBza2lwcGluZzwvbGk+Jyk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdpbXBvcnQtZmlsZS1saXN0JykuaW5uZXJIVE1MID0gJzx1bD4nICsgb3V0cHV0LmpvaW4oJycpICsgJzwvdWw+JztcclxufVxyXG5cclxubW9kdWxlLmV4cG9ydHMgPSB7XHJcblx0aGFuZGxlcnM6IHtcclxuXHRcdGRyYWdPdmVyOiBoYW5kbGVEcmFnT3ZlcixcclxuXHRcdGRyYWdFbmQ6IGhhbmRsZURyYWdFbmQsXHJcblx0XHRkcmFnRHJvcDogaGFuZGxlRHJhZ0Ryb3BcclxuXHR9XHJcbn07IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4uL2FwaScpO1xyXG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuLi9vYmplY3RzL2NsdW1wJyk7XHJcblxyXG5mdW5jdGlvbiBSb3V0ZU5vZGUobm9kZSkge1xyXG4gIHRoaXMubm9kZSA9IG5vZGU7XHJcbiAgdGhpcy5jaGlsZHJlbiA9IFtdO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYXRoc1RvTm9kZVVJKCkge1xyXG5cclxuICB2YXIgdHlwZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0eXBlJyk7XHJcbiAgdHlwZSA9IHR5cGUub3B0aW9uc1t0eXBlLnNlbGVjdGVkSW5kZXhdLnZhbHVlO1xyXG5cclxuICB2YXIgb3BlcmF0aW9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ29wZXJhdGlvbicpO1xyXG4gIG9wZXJhdGlvbiA9IG9wZXJhdGlvbi5vcHRpb25zW29wZXJhdGlvbi5zZWxlY3RlZEluZGV4XS52YWx1ZTtcclxuXHJcbiAgdmFyIGlkID0gcHJvbXB0KFwiSWQgb2YgXCIrdHlwZSk7XHJcblxyXG4gIGlmKCFpZCkgeyAgLy8gQ2FuY2VsbGVkIGRpYWxvZ3VlXHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICB2YXIgaXRlbSA9IGFwaS5saWJyYXJ5W3R5cGVdLmlkKGlkKTtcclxuXHJcbiAgaWYoIWl0ZW0pIHtcclxuICAgIGFsZXJ0KFwiQ291bGQgbm90IGZpbmQgXCIrdHlwZStcIiBcIitpZCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICB2YXIgcm9vdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicXVlcnktdHJlZVwiKTtcclxuICByb290LmlubmVySFRNTCA9IFwiXCI7XHJcblxyXG4gIHZhciB0aXRsZSA9ICQoJy5wYW5lLnF1ZXJ5IC5wYW5lLXRpdGxlJykudGV4dChcIlF1ZXJ5OiBcIitpdGVtLnRvU3RyaW5nKCkpO1xyXG5cclxuICB2YXIgcm91dGVzID0gcGF0aHNUb05vZGUoaXRlbSwge30pO1xyXG5cclxuICBpZihyb3V0ZXMgJiYgcm91dGVzLmNoaWxkcmVuLmxlbmd0aCkge1xyXG5cclxuICAgIHJvdXRlcyA9IGZpbHRlclBhdGhzVG9Ob2RlKHJvdXRlcywgb3BlcmF0aW9uKTtcclxuXHJcbiAgICB2YXIgdG9wX2NoaWxkcmVuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInVsXCIpO1xyXG4gICAgdG9wX2NoaWxkcmVuLmNsYXNzTmFtZSArPSBcImNsdW1wLWxpc3Qgc21hbGxcIjtcclxuXHJcbiAgICByb3V0ZXMuY2hpbGRyZW4uZm9yRWFjaChmdW5jdGlvbihjaGlsZF9yb3V0ZSkge1xyXG4gICAgICB2YXIgdHJlZSA9IHJlbmRlclBhdGhzVG9Ob2RlKGNoaWxkX3JvdXRlLCBbXSk7XHJcbiAgICAgIHRvcF9jaGlsZHJlbi5hcHBlbmRDaGlsZCh0cmVlKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJvb3QuYXBwZW5kQ2hpbGQodG9wX2NoaWxkcmVuKTtcclxuICB9XHJcbiAgZWxzZSB7XHJcbiAgICBhbGVydChcIlRoaXMgXCIrdHlwZStcIiBpcyBhIHJvb3Qgbm9kZSB3aXRoIG5vIHBhcmVudHMgdGhhdCBzYXRpc2Z5IHRoZSBjb25kaXRpb25zXCIpO1xyXG4gIH1cclxuICBcclxufVxyXG5cclxuZnVuY3Rpb24gcGF0aHNUb05vZGUobm9kZSwgc2VlbiwgcGFyZW50KSB7XHJcblxyXG4gIGlmKHNlZW5bbm9kZS5JZF0pIHsgICAvLyBEb24ndCByZWN1cnNlIGludG8gbm9kZXMgd2UndmUgYWxyZWFkeSBzZWVuXHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG5cclxuICB2YXIgYW5jZXN0cnkgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHNlZW4pKTtcclxuICBhbmNlc3RyeVtub2RlLklkXSA9IHRydWU7XHJcblxyXG4gIHZhciB0aGlzX25vZGUgPSBuZXcgUm91dGVOb2RlKC8qbm9kZS5saW5rVG9FdmVudCA/IG5vZGUubGlua1RvRXZlbnQgOiovIG5vZGUpOyAvLyBJZiB0aGlzIG5vZGUgaXMganVzdCBhIGxpbmsgdG8gYW5vdGhlciBvbmUsIHNraXAgb3ZlciB0aGUgdXNlbGVzcyBsaW5rXHJcblxyXG4gIGlmKG5vZGUgaW5zdGFuY2VvZiBhcGkudHlwZXMuU3Bhd25lZEVudGl0eSkge1xyXG4gICAgcmV0dXJuIHRoaXNfbm9kZTsgICAvLyBMZWFmIG5vZGUgaW4gdHJlZVxyXG4gIH1cclxuICBlbHNlIGlmKG5vZGUgaW5zdGFuY2VvZiBhcGkudHlwZXMuRXZlbnQgJiYgbm9kZS50YWcgPT09IFwidXNlXCIpIHtcclxuICAgIHJldHVybiB0aGlzX25vZGU7ICAgLy8gTGVhZiBub2RlIGluIHRyZWVcclxuICB9XHJcbiAgZWxzZSBpZihub2RlIGluc3RhbmNlb2YgYXBpLnR5cGVzLkV2ZW50ICYmIHBhcmVudCBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCAmJiAocGFyZW50LnRhZyA9PT0gXCJraWxsZWRcIiB8fCBwYXJlbnQudGFnID09PSBcInBhY2lmaWVkXCIpKSB7IC8vIElmIHRoaXMgaXMgYW4gZXZlbnQgdGhhdCdzIHJlYWNoYWJsZSBieSBraWxsaW5nIGEgbW9uc3RlciwgZG9uJ3QgcmVjdXJzZSBhbnkgb3RoZXIgY2F1c2VzIChhcyB0aGV5J3JlIHVzdWFsbHkgbWlzbGVhZGluZy9jaXJjdWxhcilcclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcbiAgZWxzZSBpZihub2RlIGluc3RhbmNlb2YgYXBpLnR5cGVzLlNldHRpbmcpIHtcclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcbiAgZWxzZSBpZiAobm9kZSBpbnN0YW5jZW9mIGFwaS50eXBlcy5Qb3J0KSB7XHJcbiAgICByZXR1cm4gbmV3IFJvdXRlTm9kZShub2RlLmFyZWEpO1xyXG4gIH1cclxuICBlbHNlIGlmKG5vZGUubGltaXRlZFRvQXJlYSAmJiBub2RlLmxpbWl0ZWRUb0FyZWEuSWQgIT09IDEwMTk1Nikge1xyXG4gICAgdmFyIGFyZWFfbmFtZSA9IG5vZGUubGltaXRlZFRvQXJlYS5OYW1lLnRvTG93ZXJDYXNlKCk7XHJcbiAgICB2YXIgZXZlbnRfbmFtZSA9IChub2RlLk5hbWUgJiYgbm9kZS5OYW1lLnRvTG93ZXJDYXNlKCkpIHx8IFwiXCI7XHJcbiAgICBpZihhcmVhX25hbWUuaW5kZXhPZihldmVudF9uYW1lKSAhPT0gLTEgfHwgZXZlbnRfbmFtZS5pbmRleE9mKGFyZWFfbmFtZSkgIT09IC0xKSB7ICAvLyBJZiBBcmVhIGhhcyBzaW1pbGFyIG5hbWUgdG8gRXZlbnQsIGlnbm9yZSB0aGUgZXZlbnQgYW5kIGp1c3Qgc3Vic3RpdHV0ZSB0aGUgYXJlYVxyXG4gICAgICByZXR1cm4gbmV3IFJvdXRlTm9kZShub2RlLmxpbWl0ZWRUb0FyZWEpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIHRoaXNfbm9kZS5jaGlsZHJlbi5wdXNoKG5ldyBSb3V0ZU5vZGUobm9kZS5saW1pdGVkVG9BcmVhKSk7ICAgLy8gRWxzZSBpbmNsdWRlIGJvdGggdGhlIEFyZWEgYW5kIHRoZSBFdmVudFxyXG4gICAgICByZXR1cm4gdGhpc19ub2RlO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgfVxyXG4gIGVsc2Uge1xyXG4gICAgZm9yKHZhciBpPTA7IGk8bm9kZS5wYXJlbnRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHZhciB0aGVfcGFyZW50ID0gbm9kZS5wYXJlbnRzW2ldO1xyXG4gICAgICB2YXIgc3VidHJlZSA9IHBhdGhzVG9Ob2RlKHRoZV9wYXJlbnQsIGFuY2VzdHJ5LCBub2RlKTtcclxuICAgICAgaWYoc3VidHJlZSkge1xyXG4gICAgICAgIHRoaXNfbm9kZS5jaGlsZHJlbi5wdXNoKHN1YnRyZWUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZighdGhpc19ub2RlLmNoaWxkcmVuLmxlbmd0aCkge1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdGhpc19ub2RlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmaWx0ZXJQYXRoc1RvTm9kZShyb3V0ZXMsIG9wZXJhdGlvbikge1xyXG4gIC8vIEZpbHRlciByb3V0ZXMgYnkgb3BlcmF0aW9uXHJcbiAgaWYocm91dGVzICYmIHJvdXRlcy5jaGlsZHJlbiAmJiBvcGVyYXRpb24gIT09IFwiYW55XCIpIHtcclxuICAgIHJvdXRlcy5jaGlsZHJlbiA9IHJvdXRlcy5jaGlsZHJlbi5maWx0ZXIoZnVuY3Rpb24ocm91dGVfbm9kZSkge1xyXG5cclxuICAgICAgbHVtcCA9IHJvdXRlX25vZGUubm9kZTtcclxuXHJcbiAgICAgIGlmKG9wZXJhdGlvbiA9PT0gXCJhZGRpdGl2ZVwiKSB7XHJcbiAgICAgICAgcmV0dXJuIGx1bXAuaXNPbmVPZihbYXBpLnR5cGVzLlF1YWxpdHlFZmZlY3QsIGFwaS50eXBlcy5BdmFpbGFiaWxpdHldKSAmJiBsdW1wLmlzQWRkaXRpdmUoKTtcclxuICAgICAgfVxyXG4gICAgICBlbHNlIGlmKG9wZXJhdGlvbiA9PT0gXCJzdWJ0cmFjdGl2ZVwiKSB7XHJcbiAgICAgICAgcmV0dXJuIGx1bXAuaXNPbmVPZihbYXBpLnR5cGVzLlF1YWxpdHlFZmZlY3QsIGFwaS50eXBlcy5BdmFpbGFiaWxpdHldKSAmJiBsdW1wLmlzU3VidHJhY3RpdmUoKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gcm91dGVzO1xyXG59XHJcblxyXG5mdW5jdGlvbiByZW5kZXJQYXRoc1RvTm9kZShyb3V0ZU5vZGUsIGFuY2VzdHJ5KSB7XHJcbiAgXHJcbiAgaWYoIShyb3V0ZU5vZGUgaW5zdGFuY2VvZiBSb3V0ZU5vZGUpKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIHZhciBlbGVtZW50ID0gcm91dGVOb2RlLm5vZGUudG9Eb20oXCJzbWFsbFwiLCBmYWxzZSk7XHJcbiAgXHJcbiAgdmFyIGNoaWxkX2xpc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwidWxcIik7XHJcbiAgY2hpbGRfbGlzdC5jbGFzc05hbWUgKz0gXCJjbHVtcC1saXN0IHNtYWxsIGNoaWxkLWxpc3RcIjtcclxuXHJcbiAgdmFyIG5ld19hbmNlc3RyeSA9IGFuY2VzdHJ5LnNsaWNlKCk7XHJcbiAgbmV3X2FuY2VzdHJ5LnB1c2gocm91dGVOb2RlLm5vZGUpO1xyXG4gIHJvdXRlTm9kZS5jaGlsZHJlbi5mb3JFYWNoKGZ1bmN0aW9uKGNoaWxkX3JvdXRlLCBpbmRleCwgY2hpbGRyZW4pIHtcclxuICAgIHZhciBjaGlsZF9jb250ZW50ID0gcmVuZGVyUGF0aHNUb05vZGUoY2hpbGRfcm91dGUsIG5ld19hbmNlc3RyeSk7XHJcbiAgICBjaGlsZF9saXN0LmFwcGVuZENoaWxkKGNoaWxkX2NvbnRlbnQpO1xyXG4gIH0pO1xyXG5cclxuICBpZihyb3V0ZU5vZGUuY2hpbGRyZW4ubGVuZ3RoKSB7XHJcbiAgICBlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2xpc3QpO1xyXG4gIH1cclxuICBlbHNlIHtcclxuICAgIHZhciBkZXNjcmlwdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcclxuICAgIGRlc2NyaXB0aW9uLmlubmVySFRNTCA9ICc8c3BhbiBjbGFzcz1cInJvdXRlLWRlc2NyaXB0aW9uXCI+SElOVDogJyArIGRlc2NyaWJlUm91dGUobmV3X2FuY2VzdHJ5KSArICc8L3NwYW4+JztcclxuXHJcbiAgICB2YXIgcmVxc1RpdGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDUnKTtcclxuICAgIHJlcXNUaXRsZS5pbm5lckhUTUwgPSBcIlJlcXVpcmVtZW50c1wiO1xyXG4gICAgZGVzY3JpcHRpb24uYXBwZW5kQ2hpbGQocmVxc1RpdGxlKTtcclxuXHJcbiAgICB2YXIgdG90YWxfcmVxdWlyZW1lbnRzID0gZ2V0Um91dGVSZXF1aXJlbWVudHMobmV3X2FuY2VzdHJ5KTtcclxuICAgIFxyXG4gICAgZGVzY3JpcHRpb24uYXBwZW5kQ2hpbGQodG90YWxfcmVxdWlyZW1lbnRzLnRvRG9tKFwic21hbGxcIiwgZmFsc2UpKTtcclxuICAgIGVsZW1lbnQuYXBwZW5kQ2hpbGQoZGVzY3JpcHRpb24pO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGVsZW1lbnQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGxvd2VyKHRleHQpIHtcclxuICByZXR1cm4gdGV4dC5zbGljZSgwLDEpLnRvTG93ZXJDYXNlKCkrdGV4dC5zbGljZSgxKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZGVzY3JpYmVSb3V0ZShhbmNlc3RyeSkge1xyXG4gIHZhciBhID0gYW5jZXN0cnkuc2xpY2UoKS5yZXZlcnNlKCk7XHJcblxyXG4gIHZhciBndWlkZSA9IFwiXCI7XHJcbiAgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5BcmVhKSB7XHJcbiAgICBpZihhWzFdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkV2ZW50KSB7XHJcbiAgICAgIGd1aWRlID0gXCJTZWVrIFwiK2FbMV0uTmFtZStcIiBpbiBcIithWzBdLk5hbWU7XHJcbiAgICAgIGlmKGFbMl0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcclxuICAgICAgICBndWlkZSArPSBcIiBhbmQgXCI7XHJcbiAgICAgICAgaWYoXCJcXFwiJ1wiLmluZGV4T2YoYVsyXS5OYW1lWzBdKSAhPT0gLTEpIHtcclxuICAgICAgICAgIGd1aWRlICs9IFwiZXhjbGFpbSBcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZ3VpZGUgKz0gbG93ZXIoYVsyXS5OYW1lKTtcclxuICAgICAgfVxyXG4gICAgICBndWlkZSArPSBcIi5cIjtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBndWlkZSA9IFwiVHJhdmVsIHRvIFwiK2FbMF0uTmFtZTtcclxuXHJcbiAgICAgIGlmKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcclxuICAgICAgICBndWlkZSArPSBcIiBhbmQgXCIrbG93ZXIoYVsxXS5OYW1lKTtcclxuICAgICAgfVxyXG4gICAgICBlbHNlIGlmKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuRXhjaGFuZ2UgJiYgYVsyXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5TaG9wKSB7XHJcbiAgICAgICAgZ3VpZGUgKz0gXCIgYW5kIGxvb2sgZm9yIHRoZSBcIithWzJdLk5hbWUrXCIgRW1wb3JpdW0gaW4gXCIrYVsxXS5OYW1lO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBndWlkZSArPSBcIi5cIjtcclxuICAgIH1cclxuICB9XHJcbiAgZWxzZSBpZihhWzBdIGluc3RhbmNlb2YgYXBpLnR5cGVzLlNwYXduZWRFbnRpdHkpIHtcclxuICAgIGd1aWRlID0gXCJGaW5kIGFuZCBiZXN0IGEgXCIrYVswXS5IdW1hbk5hbWU7XHJcbiAgICBpZihhWzJdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkludGVyYWN0aW9uKSB7XHJcbiAgICAgIGd1aWRlICs9IFwiLCB0aGVuIFwiICsgbG93ZXIoYVsyXS5OYW1lKTtcclxuICAgIH1cclxuICAgIGd1aWRlICs9IFwiLlwiO1xyXG4gIH1cclxuICBlbHNlIGlmKGFbMF0gaW5zdGFuY2VvZiBhcGkudHlwZXMuRXZlbnQgJiYgYVswXS50YWcgPT09IFwidXNlXCIgJiYgIShhWzFdIGluc3RhbmNlb2YgYXBpLnR5cGVzLlF1YWxpdHlSZXF1aXJlbWVudCkpIHtcclxuICAgIGlmKGFbMF0uTmFtZS5tYXRjaCgvXlxccypTcGVhay9pKSkge1xyXG4gICAgICBndWlkZSA9IGFbMF0uTmFtZTtcclxuICAgIH1cclxuICAgIGVsc2UgaWYoYVswXS5OYW1lLm1hdGNoKC9eXFxzKkEvaSkpIHtcclxuICAgICAgZ3VpZGUgPSBcIkFjcXVpcmUgXCIrbG93ZXIoYVswXS5OYW1lKTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBndWlkZSA9IFwiRmluZCBhIFwiK2xvd2VyKGFbMF0uTmFtZSk7XHJcbiAgICB9XHJcbiAgICBndWlkZSArPSBcIiBhbmQgXCIgKyBsb3dlcihhWzFdLk5hbWUpICsgXCIuXCI7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gZ3VpZGU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRldGFpbFJvdXRlKGFuY2VzdHJ5KSB7XHJcbiAgdmFyIGEgPSBhbmNlc3RyeS5zbGljZSgpLnJldmVyc2UoKTtcclxuXHJcbiAgdmFyIGd1aWRlID0gXCJcIjtcclxuICBpZihhWzBdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkFyZWEpIHtcclxuICAgIGlmKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuRXZlbnQpIHtcclxuICAgICAgZ3VpZGUgPSBcIllvdSBtdXN0IHRyYXZlbCB0byBcIithWzBdLk5hbWUrXCIgYW5kIGxvb2sgZm9yIFwiK2FbMV0uTmFtZStcIi5cIjtcclxuICAgICAgaWYoYVsyXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5JbnRlcmFjdGlvbikge1xyXG4gICAgICAgIGd1aWRlICs9IFwiICBXaGVuIHlvdSBmaW5kIGl0IHlvdSBzaG91bGQgXCI7XHJcbiAgICAgICAgaWYoXCJcXFwiJ1wiLmluZGV4T2YoYVsyXS5OYW1lWzBdKSAhPT0gLTEpIHtcclxuICAgICAgICAgIGd1aWRlICs9IFwic2F5IFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBndWlkZSArPSBsb3dlcihhWzJdLk5hbWUpO1xyXG4gICAgICB9XHJcbiAgICAgIGd1aWRlICs9IFwiLlwiO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGd1aWRlID0gXCJNYWtlIGZvciBcIithWzBdLk5hbWU7XHJcblxyXG4gICAgICBpZihhWzFdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkludGVyYWN0aW9uKSB7XHJcbiAgICAgICAgZ3VpZGUgKz0gXCIgYW5kIFwiK2xvd2VyKGFbMV0uTmFtZSk7XHJcbiAgICAgIH1cclxuICAgICAgZWxzZSBpZihhWzFdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkV4Y2hhbmdlICYmIGFbMl0gaW5zdGFuY2VvZiBhcGkudHlwZXMuU2hvcCkge1xyXG4gICAgICAgIGd1aWRlICs9IFwiLiAgVXBvbiBhcnJpdmFsIGdvIHRvIFwiK2FbMV0uTmFtZStcIiwgYW5kIGxvb2sgZm9yIHRoZSBzaG9wIFwiK2FbMl0uTmFtZXM7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGd1aWRlICs9IFwiLlwiO1xyXG4gICAgfVxyXG4gIH1cclxuICBlbHNlIGlmKGFbMF0gaW5zdGFuY2VvZiBhcGkudHlwZXMuU3Bhd25lZEVudGl0eSkge1xyXG4gICAgZ3VpZGUgPSBcIllvdSBtdXN0IGh1bnQgdGhlIG15dGhpY2FsIHplZS1wZXJpbCBrbm93biBhcyB0aGUgXCIrYVswXS5IdW1hbk5hbWUrXCIsIGVuZ2FnZSBpdCBpbiBiYXR0bGUgYW5kIGRlZmVhdCBpdC5cIjtcclxuICAgIGlmKGFbMl0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcclxuICAgICAgZ3VpZGUgKz0gXCIgIE9uY2UgeW91IGhhdmUgY29ucXVlcmVkIGl0IHlvdSBtdXN0IFwiICsgbG93ZXIoYVsyXS5OYW1lKSArIFwiIHRvIGhlbHAgc2VjdXJlIHlvdXIgcHJpemUuXCI7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGVsc2UgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCAmJiBhWzBdLnRhZyA9PT0gXCJ1c2VcIiAmJiAhKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuUXVhbGl0eVJlcXVpcmVtZW50KSkge1xyXG4gICAgaWYoYVswXS5OYW1lLm1hdGNoKC9eXFxzKlNwZWFrL2kpKSB7XHJcbiAgICAgIGd1aWRlID0gXCJGaXJzdCB5b3UgbXVzdCBcIitsb3dlcihhWzBdLk5hbWUpO1xyXG4gICAgfVxyXG4gICAgZWxzZSBpZihhWzBdLk5hbWUubWF0Y2goL15cXHMqQS9pKSkge1xyXG4gICAgICBndWlkZSA9IFwiU291cmNlIFwiK2xvd2VyKGFbMF0uTmFtZSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgZ3VpZGUgPSBcIlRyeSB0byBsb2NhdGUgYSBcIitsb3dlcihhWzBdLk5hbWUpO1xyXG4gICAgfVxyXG4gICAgZ3VpZGUgKz0gXCIsIGFuZCB0aGVuIFwiICsgbG93ZXIoYVsxXS5OYW1lKSArIFwiLlwiO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGd1aWRlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRSb3V0ZVJlcXVpcmVtZW50cyhhbmNlc3RyeSkge1xyXG5cclxuICB2YXIgcmVxcyA9IHt9O1xyXG5cclxuICAvLyBBbmNlc3RyeSBpcyBvcmRlcmVkIGZyb20gbGFzdC0+Zmlyc3QsIHNvIGl0ZXJhdGUgYmFja3dhcmRzIGZyb20gZmluYWwgZWZmZWN0IC0+IGluaXRpYWwgY2F1c2VcclxuICBhbmNlc3RyeS5mb3JFYWNoKGZ1bmN0aW9uKHN0ZXApIHtcclxuICAgIC8qIFNpbXBsaWZpY2F0aW9uOiBpZiBhbiBldmVudCBtb2RpZmllcyBhIHF1YWxpdHkgdGhlbiBhc3N1bWUgdGhhdCBsYXRlciByZXF1aXJlbWVudHNcclxuICAgIG9uIHRoZSBzYW1lIHF1YWxpdHkgYXJlIHByb2JhYmx5IHNhdGlzZmllZCBieSB0aGF0IG1vZGlmaWNhdGlvbiAoZWcsIHdoZW4gcXVhbGl0aWVzXHJcbiAgICBhcmUgaW5jcmVtZW50ZWQvZGVjcmVtZW50ZWQgdG8gY29udHJvbCBzdG9yeS1xdWVzdCBwcm9ncmVzcykuICovXHJcbiAgICBpZihzdGVwLnF1YWxpdGllc0FmZmVjdGVkKSB7XHJcbiAgICAgIHN0ZXAucXVhbGl0aWVzQWZmZWN0ZWQuZm9yRWFjaChmdW5jdGlvbihlZmZlY3QpIHtcclxuICAgICAgICBkZWxldGUocmVxc1tlZmZlY3QuYXNzb2NpYXRlZFF1YWxpdHkuSWRdKTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICAvLyBOb3cgYWRkIGFueSByZXF1aXJlbWVudHMgZm9yIHRoZSBjdXJyZW50IHN0YWdlIChlYXJsaWVyIHJlcXVpcmVtZW50cyBvdmVyd3JpdGUgbGF0ZXIgb25lcyBvbiB0aGUgc2FtZSBxdWFsaXR5KVxyXG4gICAgaWYoc3RlcC5xdWFsaXRpZXNSZXF1aXJlZCkge1xyXG4gICAgICBzdGVwLnF1YWxpdGllc1JlcXVpcmVkLmZvckVhY2goZnVuY3Rpb24ocmVxKSB7XHJcbiAgICAgICAgaWYocmVxLmFzc29jaWF0ZWRRdWFsaXR5KSB7IC8vIENoZWNrIHRoaXMgaXMgYSB2YWxpZCBRdWFsaXR5UmVxdWlyZW1lbnQsIGFuZCBub3Qgb25lIG9mIHRoZSBoYWxmLWZpbmlzaGVkIGRlYnVnIGVsZW1lbnRzIHJlZmVycmluZyB0byBhbm9uLWV4aXN0YW50IFF1YWxpdHlcclxuICAgICAgICAgIHJlcXNbcmVxLmFzc29jaWF0ZWRRdWFsaXR5LklkXSA9IHJlcTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICB2YXIgcmVzdWx0ID0gT2JqZWN0LmtleXMocmVxcykubWFwKGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gcmVxc1trZXldOyB9KTtcclxuXHJcbiAgcmV0dXJuIG5ldyBDbHVtcChyZXN1bHQsIGFwaS50eXBlcy5RdWFsaXR5UmVxdWlyZW1lbnQpO1xyXG59XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuICBSb3V0ZU5vZGU6IFJvdXRlTm9kZSxcclxuICBwYXRoc1RvTm9kZVVJOiBwYXRoc1RvTm9kZVVJLFxyXG4gIHBhdGhzVG9Ob2RlOiBwYXRoc1RvTm9kZSxcclxuICBmaWx0ZXJQYXRoc1RvTm9kZTogZmlsdGVyUGF0aHNUb05vZGUsXHJcbiAgcmVuZGVyUGF0aHNUb05vZGU6IHJlbmRlclBhdGhzVG9Ob2RlLFxyXG4gIGRlc2NyaWJlUm91dGU6IGRlc2NyaWJlUm91dGUsXHJcbiAgZGV0YWlsUm91dGU6IGRldGFpbFJvdXRlLFxyXG4gIGdldFJvdXRlUmVxdWlyZW1lbnRzOiBnZXRSb3V0ZVJlcXVpcmVtZW50c1xyXG59OyIsInZhciBhcGkgPSByZXF1aXJlKCcuLi9hcGknKTtcclxuXHJcbmZ1bmN0aW9uIHJlbmRlckxpc3RzKCkge1xyXG4gIE9iamVjdC5rZXlzKGFwaS5sb2FkZWQpLmZvckVhY2goZnVuY3Rpb24odHlwZSkge1xyXG4gICAgcmVuZGVyTGlzdChhcGkubG9hZGVkW3R5cGVdKTsgLy8gT25seSBkaXNwbGF5IGRpcmVjdGx5IGxvYWRlZCAocm9vdC1sZXZlbCkgTHVtcHMsIHRvIHByZXZlbnQgdGhlIGxpc3QgYmVjb21pbmcgdW53aWVsZHlcclxuICB9KTtcclxufVxyXG5cclxuZnVuY3Rpb24gcmVuZGVyTGlzdChjbHVtcCkge1xyXG5cdHZhciByb290ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoY2x1bXAudHlwZS5uYW1lLnRvTG93ZXJDYXNlKCkrXCItbGlzdFwiKTtcclxuICBpZihyb290KSB7XHJcblx0IHJvb3QuYXBwZW5kQ2hpbGQoY2x1bXAudG9Eb20oKSk7XHJcbiAgfVxyXG59XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuXHRsaXN0OiByZW5kZXJMaXN0LFxyXG5cdGxpc3RzOiByZW5kZXJMaXN0c1xyXG59OyJdfQ==
