# Game icons/artwork

Please copy all the images from the artwork folder under your game-data directory (usually `C:\Users\USERNAME\AppData\LocalLow\Failbetter Games\Sunless Sea\images\sn\icons`, or similar) into this directory.

This is an optional step, as the icons are only used by the HTML UI and are not required by the mod.  However if you want to mess about exploring the game files in the UI it's highly advised as it makes things a lot prettier and easier to recognise.
