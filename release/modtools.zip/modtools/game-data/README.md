# Game data files location

This is the location the build system (and the HTML UI it generates) expects to find the game config JSON and game icons/artwork (which obviously can't be distributed with the mod source-code for copyright reasons).

Please see the main README file for more information.
