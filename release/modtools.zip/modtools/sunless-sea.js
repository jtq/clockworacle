(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
module.exports={
	"title": "Sunless Sea",
	"paths": {
		"templates": "src/templates",
		"modGameJson": "build/modtools/game-data/json",
		"builddir": {
			"mod": "build/clockworacle/entities",
			"ui": "build/modtools"
		}
	},
	"locations": {
		"imagesPath": "game-data/icons"
	},
	"baseGameIds": {
		"quality": 500000,
		"prelimEvent": 500010,
		"buyOracle": 5000020,
		"sellOracle": 500030,
		"event": 500035,
		"acquire": 600000,
		"learn": 700000,
		"suffer": 800000,
		"become": 900000
	}
}
},{}],2:[function(require,module,exports){
'use strict'

exports.byteLength = byteLength
exports.toByteArray = toByteArray
exports.fromByteArray = fromByteArray

var lookup = []
var revLookup = []
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i]
  revLookup[code.charCodeAt(i)] = i
}

revLookup['-'.charCodeAt(0)] = 62
revLookup['_'.charCodeAt(0)] = 63

function placeHoldersCount (b64) {
  var len = b64.length
  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // the number of equal signs (place holders)
  // if there are two placeholders, than the two characters before it
  // represent one byte
  // if there is only one, then the three characters before it represent 2 bytes
  // this is just a cheap hack to not do indexOf twice
  return b64[len - 2] === '=' ? 2 : b64[len - 1] === '=' ? 1 : 0
}

function byteLength (b64) {
  // base64 is 4/3 + up to two characters of the original data
  return b64.length * 3 / 4 - placeHoldersCount(b64)
}

function toByteArray (b64) {
  var i, j, l, tmp, placeHolders, arr
  var len = b64.length
  placeHolders = placeHoldersCount(b64)

  arr = new Arr(len * 3 / 4 - placeHolders)

  // if there are placeholders, only get up to the last complete 4 chars
  l = placeHolders > 0 ? len - 4 : len

  var L = 0

  for (i = 0, j = 0; i < l; i += 4, j += 3) {
    tmp = (revLookup[b64.charCodeAt(i)] << 18) | (revLookup[b64.charCodeAt(i + 1)] << 12) | (revLookup[b64.charCodeAt(i + 2)] << 6) | revLookup[b64.charCodeAt(i + 3)]
    arr[L++] = (tmp >> 16) & 0xFF
    arr[L++] = (tmp >> 8) & 0xFF
    arr[L++] = tmp & 0xFF
  }

  if (placeHolders === 2) {
    tmp = (revLookup[b64.charCodeAt(i)] << 2) | (revLookup[b64.charCodeAt(i + 1)] >> 4)
    arr[L++] = tmp & 0xFF
  } else if (placeHolders === 1) {
    tmp = (revLookup[b64.charCodeAt(i)] << 10) | (revLookup[b64.charCodeAt(i + 1)] << 4) | (revLookup[b64.charCodeAt(i + 2)] >> 2)
    arr[L++] = (tmp >> 8) & 0xFF
    arr[L++] = tmp & 0xFF
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp
  var output = []
  for (var i = start; i < end; i += 3) {
    tmp = (uint8[i] << 16) + (uint8[i + 1] << 8) + (uint8[i + 2])
    output.push(tripletToBase64(tmp))
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp
  var len = uint8.length
  var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
  var output = ''
  var parts = []
  var maxChunkLength = 16383 // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)))
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1]
    output += lookup[tmp >> 2]
    output += lookup[(tmp << 4) & 0x3F]
    output += '=='
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + (uint8[len - 1])
    output += lookup[tmp >> 10]
    output += lookup[(tmp >> 4) & 0x3F]
    output += lookup[(tmp << 2) & 0x3F]
    output += '='
  }

  parts.push(output)

  return parts.join('')
}

},{}],3:[function(require,module,exports){

},{}],4:[function(require,module,exports){
(function (global){
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */

'use strict'

var base64 = require('base64-js')
var ieee754 = require('ieee754')
var isArray = require('isarray')

exports.Buffer = Buffer
exports.SlowBuffer = SlowBuffer
exports.INSPECT_MAX_BYTES = 50

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Use Object implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * Due to various browser bugs, sometimes the Object implementation will be used even
 * when the browser supports typed arrays.
 *
 * Note:
 *
 *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
 *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
 *
 *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
 *
 *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
 *     incorrect length in some situations.

 * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
 * get the Object implementation, which is slower but behaves correctly.
 */
Buffer.TYPED_ARRAY_SUPPORT = global.TYPED_ARRAY_SUPPORT !== undefined
  ? global.TYPED_ARRAY_SUPPORT
  : typedArraySupport()

/*
 * Export kMaxLength after typed array support is determined.
 */
exports.kMaxLength = kMaxLength()

function typedArraySupport () {
  try {
    var arr = new Uint8Array(1)
    arr.__proto__ = {__proto__: Uint8Array.prototype, foo: function () { return 42 }}
    return arr.foo() === 42 && // typed array instances can be augmented
        typeof arr.subarray === 'function' && // chrome 9-10 lack `subarray`
        arr.subarray(1, 1).byteLength === 0 // ie10 has broken `subarray`
  } catch (e) {
    return false
  }
}

function kMaxLength () {
  return Buffer.TYPED_ARRAY_SUPPORT
    ? 0x7fffffff
    : 0x3fffffff
}

function createBuffer (that, length) {
  if (kMaxLength() < length) {
    throw new RangeError('Invalid typed array length')
  }
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    // Return an augmented `Uint8Array` instance, for best performance
    that = new Uint8Array(length)
    that.__proto__ = Buffer.prototype
  } else {
    // Fallback: Return an object instance of the Buffer class
    if (that === null) {
      that = new Buffer(length)
    }
    that.length = length
  }

  return that
}

/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */

function Buffer (arg, encodingOrOffset, length) {
  if (!Buffer.TYPED_ARRAY_SUPPORT && !(this instanceof Buffer)) {
    return new Buffer(arg, encodingOrOffset, length)
  }

  // Common case.
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new Error(
        'If encoding is specified then the first argument must be a string'
      )
    }
    return allocUnsafe(this, arg)
  }
  return from(this, arg, encodingOrOffset, length)
}

Buffer.poolSize = 8192 // not used by this implementation

// TODO: Legacy, not needed anymore. Remove in next major version.
Buffer._augment = function (arr) {
  arr.__proto__ = Buffer.prototype
  return arr
}

function from (that, value, encodingOrOffset, length) {
  if (typeof value === 'number') {
    throw new TypeError('"value" argument must not be a number')
  }

  if (typeof ArrayBuffer !== 'undefined' && value instanceof ArrayBuffer) {
    return fromArrayBuffer(that, value, encodingOrOffset, length)
  }

  if (typeof value === 'string') {
    return fromString(that, value, encodingOrOffset)
  }

  return fromObject(that, value)
}

/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/
Buffer.from = function (value, encodingOrOffset, length) {
  return from(null, value, encodingOrOffset, length)
}

if (Buffer.TYPED_ARRAY_SUPPORT) {
  Buffer.prototype.__proto__ = Uint8Array.prototype
  Buffer.__proto__ = Uint8Array
  if (typeof Symbol !== 'undefined' && Symbol.species &&
      Buffer[Symbol.species] === Buffer) {
    // Fix subarray() in ES2016. See: https://github.com/feross/buffer/pull/97
    Object.defineProperty(Buffer, Symbol.species, {
      value: null,
      configurable: true
    })
  }
}

function assertSize (size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be a number')
  } else if (size < 0) {
    throw new RangeError('"size" argument must not be negative')
  }
}

function alloc (that, size, fill, encoding) {
  assertSize(size)
  if (size <= 0) {
    return createBuffer(that, size)
  }
  if (fill !== undefined) {
    // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpretted as a start offset.
    return typeof encoding === 'string'
      ? createBuffer(that, size).fill(fill, encoding)
      : createBuffer(that, size).fill(fill)
  }
  return createBuffer(that, size)
}

/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/
Buffer.alloc = function (size, fill, encoding) {
  return alloc(null, size, fill, encoding)
}

function allocUnsafe (that, size) {
  assertSize(size)
  that = createBuffer(that, size < 0 ? 0 : checked(size) | 0)
  if (!Buffer.TYPED_ARRAY_SUPPORT) {
    for (var i = 0; i < size; ++i) {
      that[i] = 0
    }
  }
  return that
}

/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */
Buffer.allocUnsafe = function (size) {
  return allocUnsafe(null, size)
}
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */
Buffer.allocUnsafeSlow = function (size) {
  return allocUnsafe(null, size)
}

function fromString (that, string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8'
  }

  if (!Buffer.isEncoding(encoding)) {
    throw new TypeError('"encoding" must be a valid string encoding')
  }

  var length = byteLength(string, encoding) | 0
  that = createBuffer(that, length)

  var actual = that.write(string, encoding)

  if (actual !== length) {
    // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    that = that.slice(0, actual)
  }

  return that
}

function fromArrayLike (that, array) {
  var length = array.length < 0 ? 0 : checked(array.length) | 0
  that = createBuffer(that, length)
  for (var i = 0; i < length; i += 1) {
    that[i] = array[i] & 255
  }
  return that
}

function fromArrayBuffer (that, array, byteOffset, length) {
  array.byteLength // this throws if `array` is not a valid ArrayBuffer

  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('\'offset\' is out of bounds')
  }

  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('\'length\' is out of bounds')
  }

  if (byteOffset === undefined && length === undefined) {
    array = new Uint8Array(array)
  } else if (length === undefined) {
    array = new Uint8Array(array, byteOffset)
  } else {
    array = new Uint8Array(array, byteOffset, length)
  }

  if (Buffer.TYPED_ARRAY_SUPPORT) {
    // Return an augmented `Uint8Array` instance, for best performance
    that = array
    that.__proto__ = Buffer.prototype
  } else {
    // Fallback: Return an object instance of the Buffer class
    that = fromArrayLike(that, array)
  }
  return that
}

function fromObject (that, obj) {
  if (Buffer.isBuffer(obj)) {
    var len = checked(obj.length) | 0
    that = createBuffer(that, len)

    if (that.length === 0) {
      return that
    }

    obj.copy(that, 0, 0, len)
    return that
  }

  if (obj) {
    if ((typeof ArrayBuffer !== 'undefined' &&
        obj.buffer instanceof ArrayBuffer) || 'length' in obj) {
      if (typeof obj.length !== 'number' || isnan(obj.length)) {
        return createBuffer(that, 0)
      }
      return fromArrayLike(that, obj)
    }

    if (obj.type === 'Buffer' && isArray(obj.data)) {
      return fromArrayLike(that, obj.data)
    }
  }

  throw new TypeError('First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.')
}

function checked (length) {
  // Note: cannot use `length < kMaxLength()` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= kMaxLength()) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + kMaxLength().toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (length) {
  if (+length != length) { // eslint-disable-line eqeqeq
    length = 0
  }
  return Buffer.alloc(+length)
}

Buffer.isBuffer = function isBuffer (b) {
  return !!(b != null && b._isBuffer)
}

Buffer.compare = function compare (a, b) {
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError('Arguments must be Buffers')
  }

  if (a === b) return 0

  var x = a.length
  var y = b.length

  for (var i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i]
      y = b[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers')
  }

  if (list.length === 0) {
    return Buffer.alloc(0)
  }

  var i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; ++i) {
      length += list[i].length
    }
  }

  var buffer = Buffer.allocUnsafe(length)
  var pos = 0
  for (i = 0; i < list.length; ++i) {
    var buf = list[i]
    if (!Buffer.isBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    }
    buf.copy(buffer, pos)
    pos += buf.length
  }
  return buffer
}

function byteLength (string, encoding) {
  if (Buffer.isBuffer(string)) {
    return string.length
  }
  if (typeof ArrayBuffer !== 'undefined' && typeof ArrayBuffer.isView === 'function' &&
      (ArrayBuffer.isView(string) || string instanceof ArrayBuffer)) {
    return string.byteLength
  }
  if (typeof string !== 'string') {
    string = '' + string
  }

  var len = string.length
  if (len === 0) return 0

  // Use a for loop to avoid recursion
  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len
      case 'utf8':
      case 'utf-8':
      case undefined:
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) return utf8ToBytes(string).length // assume utf8
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

function slowToString (encoding, start, end) {
  var loweredCase = false

  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
  // property of a typed array.

  // This behaves neither like String nor Uint8Array in that we set start/end
  // to their upper/lower bounds if the value passed is out of range.
  // undefined is handled specially as per ECMA-262 6th Edition,
  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
  if (start === undefined || start < 0) {
    start = 0
  }
  // Return early if start > this.length. Done here to prevent potential uint32
  // coercion fail below.
  if (start > this.length) {
    return ''
  }

  if (end === undefined || end > this.length) {
    end = this.length
  }

  if (end <= 0) {
    return ''
  }

  // Force coersion to uint32. This will also coerce falsey/NaN values to 0.
  end >>>= 0
  start >>>= 0

  if (end <= start) {
    return ''
  }

  if (!encoding) encoding = 'utf8'

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

// The property is used by `Buffer.isBuffer` and `is-buffer` (in Safari 5-7) to detect
// Buffer instances.
Buffer.prototype._isBuffer = true

function swap (b, n, m) {
  var i = b[n]
  b[n] = b[m]
  b[m] = i
}

Buffer.prototype.swap16 = function swap16 () {
  var len = this.length
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits')
  }
  for (var i = 0; i < len; i += 2) {
    swap(this, i, i + 1)
  }
  return this
}

Buffer.prototype.swap32 = function swap32 () {
  var len = this.length
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits')
  }
  for (var i = 0; i < len; i += 4) {
    swap(this, i, i + 3)
    swap(this, i + 1, i + 2)
  }
  return this
}

Buffer.prototype.swap64 = function swap64 () {
  var len = this.length
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits')
  }
  for (var i = 0; i < len; i += 8) {
    swap(this, i, i + 7)
    swap(this, i + 1, i + 6)
    swap(this, i + 2, i + 5)
    swap(this, i + 3, i + 4)
  }
  return this
}

Buffer.prototype.toString = function toString () {
  var length = this.length | 0
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  var str = ''
  var max = exports.INSPECT_MAX_BYTES
  if (this.length > 0) {
    str = this.toString('hex', 0, max).match(/.{2}/g).join(' ')
    if (this.length > max) str += ' ... '
  }
  return '<Buffer ' + str + '>'
}

Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
  if (!Buffer.isBuffer(target)) {
    throw new TypeError('Argument must be a Buffer')
  }

  if (start === undefined) {
    start = 0
  }
  if (end === undefined) {
    end = target ? target.length : 0
  }
  if (thisStart === undefined) {
    thisStart = 0
  }
  if (thisEnd === undefined) {
    thisEnd = this.length
  }

  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index')
  }

  if (thisStart >= thisEnd && start >= end) {
    return 0
  }
  if (thisStart >= thisEnd) {
    return -1
  }
  if (start >= end) {
    return 1
  }

  start >>>= 0
  end >>>= 0
  thisStart >>>= 0
  thisEnd >>>= 0

  if (this === target) return 0

  var x = thisEnd - thisStart
  var y = end - start
  var len = Math.min(x, y)

  var thisCopy = this.slice(thisStart, thisEnd)
  var targetCopy = target.slice(start, end)

  for (var i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i]
      y = targetCopy[i]
      break
    }
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
  // Empty buffer means no match
  if (buffer.length === 0) return -1

  // Normalize byteOffset
  if (typeof byteOffset === 'string') {
    encoding = byteOffset
    byteOffset = 0
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000
  }
  byteOffset = +byteOffset  // Coerce to Number.
  if (isNaN(byteOffset)) {
    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : (buffer.length - 1)
  }

  // Normalize byteOffset: negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset
  if (byteOffset >= buffer.length) {
    if (dir) return -1
    else byteOffset = buffer.length - 1
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0
    else return -1
  }

  // Normalize val
  if (typeof val === 'string') {
    val = Buffer.from(val, encoding)
  }

  // Finally, search either indexOf (if dir is true) or lastIndexOf
  if (Buffer.isBuffer(val)) {
    // Special case: looking for empty string/buffer always fails
    if (val.length === 0) {
      return -1
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
  } else if (typeof val === 'number') {
    val = val & 0xFF // Search for a byte value [0-255]
    if (Buffer.TYPED_ARRAY_SUPPORT &&
        typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
      }
    }
    return arrayIndexOf(buffer, [ val ], byteOffset, encoding, dir)
  }

  throw new TypeError('val must be string, number or Buffer')
}

function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
  var indexSize = 1
  var arrLength = arr.length
  var valLength = val.length

  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase()
    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
        encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1
      }
      indexSize = 2
      arrLength /= 2
      valLength /= 2
      byteOffset /= 2
    }
  }

  function read (buf, i) {
    if (indexSize === 1) {
      return buf[i]
    } else {
      return buf.readUInt16BE(i * indexSize)
    }
  }

  var i
  if (dir) {
    var foundIndex = -1
    for (i = byteOffset; i < arrLength; i++) {
      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
      } else {
        if (foundIndex !== -1) i -= i - foundIndex
        foundIndex = -1
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
    for (i = byteOffset; i >= 0; i--) {
      var found = true
      for (var j = 0; j < valLength; j++) {
        if (read(arr, i + j) !== read(val, j)) {
          found = false
          break
        }
      }
      if (found) return i
    }
  }

  return -1
}

Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
}

Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  var remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  // must be an even number of digits
  var strLen = string.length
  if (strLen % 2 !== 0) throw new TypeError('Invalid hex string')

  if (length > strLen / 2) {
    length = strLen / 2
  }
  for (var i = 0; i < length; ++i) {
    var parsed = parseInt(string.substr(i * 2, 2), 16)
    if (isNaN(parsed)) return i
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function latin1Write (buf, string, offset, length) {
  return asciiWrite(buf, string, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset | 0
    if (isFinite(length)) {
      length = length | 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  // legacy write(string, encoding, offset, length) - remove in v0.13
  } else {
    throw new Error(
      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
    )
  }

  var remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
        return asciiWrite(this, string, offset, length)

      case 'latin1':
      case 'binary':
        return latin1Write(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  var res = []

  var i = start
  while (i < end) {
    var firstByte = buf[i]
    var codePoint = null
    var bytesPerSequence = (firstByte > 0xEF) ? 4
      : (firstByte > 0xDF) ? 3
      : (firstByte > 0xBF) ? 2
      : 1

    if (i + bytesPerSequence <= end) {
      var secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
var MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  var len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  var res = ''
  var i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function latin1Slice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  var len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  var out = ''
  for (var i = start; i < end; ++i) {
    out += toHex(buf[i])
  }
  return out
}

function utf16leSlice (buf, start, end) {
  var bytes = buf.slice(start, end)
  var res = ''
  for (var i = 0; i < bytes.length; i += 2) {
    res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256)
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  var len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  var newBuf
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    newBuf = this.subarray(start, end)
    newBuf.__proto__ = Buffer.prototype
  } else {
    var sliceLen = end - start
    newBuf = new Buffer(sliceLen, undefined)
    for (var i = 0; i < sliceLen; ++i) {
      newBuf[i] = this[i + start]
    }
  }

  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  var val = this[offset + --byteLength]
  var mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var i = byteLength
  var mul = 1
  var val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
}

Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  var mul = 1
  var i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1
    checkInt(this, value, offset, byteLength, maxBytes, 0)
  }

  var i = byteLength - 1
  var mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
  this[offset] = (value & 0xff)
  return offset + 1
}

function objectWriteUInt16 (buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffff + value + 1
  for (var i = 0, j = Math.min(buf.length - offset, 2); i < j; ++i) {
    buf[offset + i] = (value & (0xff << (8 * (littleEndian ? i : 1 - i)))) >>>
      (littleEndian ? i : 1 - i) * 8
  }
}

Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
  } else {
    objectWriteUInt16(this, value, offset, true)
  }
  return offset + 2
}

Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 8)
    this[offset + 1] = (value & 0xff)
  } else {
    objectWriteUInt16(this, value, offset, false)
  }
  return offset + 2
}

function objectWriteUInt32 (buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffffffff + value + 1
  for (var i = 0, j = Math.min(buf.length - offset, 4); i < j; ++i) {
    buf[offset + i] = (value >>> (littleEndian ? i : 3 - i) * 8) & 0xff
  }
}

Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset + 3] = (value >>> 24)
    this[offset + 2] = (value >>> 16)
    this[offset + 1] = (value >>> 8)
    this[offset] = (value & 0xff)
  } else {
    objectWriteUInt32(this, value, offset, true)
  }
  return offset + 4
}

Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = (value & 0xff)
  } else {
    objectWriteUInt32(this, value, offset, false)
  }
  return offset + 4
}

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = 0
  var mul = 1
  var sub = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = byteLength - 1
  var mul = 1
  var sub = 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1
    }
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
  if (value < 0) value = 0xff + value + 1
  this[offset] = (value & 0xff)
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
  } else {
    objectWriteUInt16(this, value, offset, true)
  }
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 8)
    this[offset + 1] = (value & 0xff)
  } else {
    objectWriteUInt16(this, value, offset, false)
  }
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
    this[offset + 2] = (value >>> 16)
    this[offset + 3] = (value >>> 24)
  } else {
    objectWriteUInt32(this, value, offset, true)
  }
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = (value & 0xff)
  } else {
    objectWriteUInt32(this, value, offset, false)
  }
  return offset + 4
}

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range')
  if (offset < 0) throw new RangeError('Index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  var len = end - start
  var i

  if (this === target && start < targetStart && targetStart < end) {
    // descending copy from end
    for (i = len - 1; i >= 0; --i) {
      target[i + targetStart] = this[i + start]
    }
  } else if (len < 1000 || !Buffer.TYPED_ARRAY_SUPPORT) {
    // ascending copy from start
    for (i = 0; i < len; ++i) {
      target[i + targetStart] = this[i + start]
    }
  } else {
    Uint8Array.prototype.set.call(
      target,
      this.subarray(start, start + len),
      targetStart
    )
  }

  return len
}

// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill (val, start, end, encoding) {
  // Handle string cases:
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start
      start = 0
      end = this.length
    } else if (typeof end === 'string') {
      encoding = end
      end = this.length
    }
    if (val.length === 1) {
      var code = val.charCodeAt(0)
      if (code < 256) {
        val = code
      }
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string')
    }
    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
  } else if (typeof val === 'number') {
    val = val & 255
  }

  // Invalid ranges are not set to a default, so can range check early.
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index')
  }

  if (end <= start) {
    return this
  }

  start = start >>> 0
  end = end === undefined ? this.length : end >>> 0

  if (!val) val = 0

  var i
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val
    }
  } else {
    var bytes = Buffer.isBuffer(val)
      ? val
      : utf8ToBytes(new Buffer(val, encoding).toString())
    var len = bytes.length
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len]
    }
  }

  return this
}

// HELPER FUNCTIONS
// ================

var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = stringtrim(str).replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function stringtrim (str) {
  if (str.trim) return str.trim()
  return str.replace(/^\s+|\s+$/g, '')
}

function toHex (n) {
  if (n < 16) return '0' + n.toString(16)
  return n.toString(16)
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  var codePoint
  var length = string.length
  var leadSurrogate = null
  var bytes = []

  for (var i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  var byteArray = []
  for (var i = 0; i < str.length; ++i) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  var c, hi, lo
  var byteArray = []
  for (var i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  for (var i = 0; i < length; ++i) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

function isnan (val) {
  return val !== val // eslint-disable-line no-self-compare
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"base64-js":2,"ieee754":7,"isarray":8}],5:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

function EventEmitter() {
  this._events = this._events || {};
  this._maxListeners = this._maxListeners || undefined;
}
module.exports = EventEmitter;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
EventEmitter.defaultMaxListeners = 10;

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function(n) {
  if (!isNumber(n) || n < 0 || isNaN(n))
    throw TypeError('n must be a positive number');
  this._maxListeners = n;
  return this;
};

EventEmitter.prototype.emit = function(type) {
  var er, handler, len, args, i, listeners;

  if (!this._events)
    this._events = {};

  // If there is no 'error' event listener then throw.
  if (type === 'error') {
    if (!this._events.error ||
        (isObject(this._events.error) && !this._events.error.length)) {
      er = arguments[1];
      if (er instanceof Error) {
        throw er; // Unhandled 'error' event
      } else {
        // At least give some kind of context to the user
        var err = new Error('Uncaught, unspecified "error" event. (' + er + ')');
        err.context = er;
        throw err;
      }
    }
  }

  handler = this._events[type];

  if (isUndefined(handler))
    return false;

  if (isFunction(handler)) {
    switch (arguments.length) {
      // fast cases
      case 1:
        handler.call(this);
        break;
      case 2:
        handler.call(this, arguments[1]);
        break;
      case 3:
        handler.call(this, arguments[1], arguments[2]);
        break;
      // slower
      default:
        args = Array.prototype.slice.call(arguments, 1);
        handler.apply(this, args);
    }
  } else if (isObject(handler)) {
    args = Array.prototype.slice.call(arguments, 1);
    listeners = handler.slice();
    len = listeners.length;
    for (i = 0; i < len; i++)
      listeners[i].apply(this, args);
  }

  return true;
};

EventEmitter.prototype.addListener = function(type, listener) {
  var m;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events)
    this._events = {};

  // To avoid recursion in the case that type === "newListener"! Before
  // adding it to the listeners, first emit "newListener".
  if (this._events.newListener)
    this.emit('newListener', type,
              isFunction(listener.listener) ?
              listener.listener : listener);

  if (!this._events[type])
    // Optimize the case of one listener. Don't need the extra array object.
    this._events[type] = listener;
  else if (isObject(this._events[type]))
    // If we've already got an array, just append.
    this._events[type].push(listener);
  else
    // Adding the second element, need to change to array.
    this._events[type] = [this._events[type], listener];

  // Check for listener leak
  if (isObject(this._events[type]) && !this._events[type].warned) {
    if (!isUndefined(this._maxListeners)) {
      m = this._maxListeners;
    } else {
      m = EventEmitter.defaultMaxListeners;
    }

    if (m && m > 0 && this._events[type].length > m) {
      this._events[type].warned = true;
      console.error('(node) warning: possible EventEmitter memory ' +
                    'leak detected. %d listeners added. ' +
                    'Use emitter.setMaxListeners() to increase limit.',
                    this._events[type].length);
      if (typeof console.trace === 'function') {
        // not supported in IE 10
        console.trace();
      }
    }
  }

  return this;
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.once = function(type, listener) {
  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  var fired = false;

  function g() {
    this.removeListener(type, g);

    if (!fired) {
      fired = true;
      listener.apply(this, arguments);
    }
  }

  g.listener = listener;
  this.on(type, g);

  return this;
};

// emits a 'removeListener' event iff the listener was removed
EventEmitter.prototype.removeListener = function(type, listener) {
  var list, position, length, i;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events || !this._events[type])
    return this;

  list = this._events[type];
  length = list.length;
  position = -1;

  if (list === listener ||
      (isFunction(list.listener) && list.listener === listener)) {
    delete this._events[type];
    if (this._events.removeListener)
      this.emit('removeListener', type, listener);

  } else if (isObject(list)) {
    for (i = length; i-- > 0;) {
      if (list[i] === listener ||
          (list[i].listener && list[i].listener === listener)) {
        position = i;
        break;
      }
    }

    if (position < 0)
      return this;

    if (list.length === 1) {
      list.length = 0;
      delete this._events[type];
    } else {
      list.splice(position, 1);
    }

    if (this._events.removeListener)
      this.emit('removeListener', type, listener);
  }

  return this;
};

EventEmitter.prototype.removeAllListeners = function(type) {
  var key, listeners;

  if (!this._events)
    return this;

  // not listening for removeListener, no need to emit
  if (!this._events.removeListener) {
    if (arguments.length === 0)
      this._events = {};
    else if (this._events[type])
      delete this._events[type];
    return this;
  }

  // emit removeListener for all listeners on all events
  if (arguments.length === 0) {
    for (key in this._events) {
      if (key === 'removeListener') continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners('removeListener');
    this._events = {};
    return this;
  }

  listeners = this._events[type];

  if (isFunction(listeners)) {
    this.removeListener(type, listeners);
  } else if (listeners) {
    // LIFO order
    while (listeners.length)
      this.removeListener(type, listeners[listeners.length - 1]);
  }
  delete this._events[type];

  return this;
};

EventEmitter.prototype.listeners = function(type) {
  var ret;
  if (!this._events || !this._events[type])
    ret = [];
  else if (isFunction(this._events[type]))
    ret = [this._events[type]];
  else
    ret = this._events[type].slice();
  return ret;
};

EventEmitter.prototype.listenerCount = function(type) {
  if (this._events) {
    var evlistener = this._events[type];

    if (isFunction(evlistener))
      return 1;
    else if (evlistener)
      return evlistener.length;
  }
  return 0;
};

EventEmitter.listenerCount = function(emitter, type) {
  return emitter.listenerCount(type);
};

function isFunction(arg) {
  return typeof arg === 'function';
}

function isNumber(arg) {
  return typeof arg === 'number';
}

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}

function isUndefined(arg) {
  return arg === void 0;
}

},{}],6:[function(require,module,exports){
(function (process,Buffer){
//
// FileReader
//
// http://www.w3.org/TR/FileAPI/#dfn-filereader
// https://developer.mozilla.org/en/DOM/FileReader
(function () {
  "use strict";

  var fs = require("fs")
    , EventEmitter = require("events").EventEmitter
    ;

  function doop(fn, args, context) {
    if ('function' === typeof fn) {
      fn.apply(context, args);
    }
  }

  function toDataUrl(data, type) {
    // var data = self.result;
    var dataUrl = 'data:';

    if (type) {
      dataUrl += type + ';';
    }

    if (/text/i.test(type)) {
      dataUrl += 'charset=utf-8,';
      dataUrl += data.toString('utf8');
    } else {
      dataUrl += 'base64,';
      dataUrl += data.toString('base64');
    }

    return dataUrl;
  }

  function mapDataToFormat(file, data, format, encoding) {
    // var data = self.result;

    switch(format) {
      case 'buffer':
        return data;
        break;
      case 'binary':
        return data.toString('binary');
        break;
      case 'dataUrl':
        return toDataUrl(data, file.type);
        break;
      case 'text':
        return data.toString(encoding || 'utf8');
        break;
    }
  }

  function FileReader() {
    var self = this,
      emitter = new EventEmitter,
      file;

    self.addEventListener = function (on, callback) {
      emitter.on(on, callback);
    };
    self.removeEventListener = function (callback) {
      emitter.removeListener(callback);
    }
    self.dispatchEvent = function (on) {
      emitter.emit(on);
    }

    self.EMPTY = 0;
    self.LOADING = 1;
    self.DONE = 2;

    self.error = undefined;         // Read only
    self.readyState = self.EMPTY;   // Read only
    self.result = undefined;        // Road only

    // non-standard
    self.on = function () {
      emitter.on.apply(emitter, arguments);
    }
    self.nodeChunkedEncoding = false;
    self.setNodeChunkedEncoding = function (val) {
      self.nodeChunkedEncoding = val;
    };
    // end non-standard



    // Whatever the file object is, turn it into a Node.JS File.Stream
    function createFileStream() {
      var stream = new EventEmitter(),
        chunked = self.nodeChunkedEncoding;

      // attempt to make the length computable
      if (!file.size && chunked && file.path) {
        fs.stat(file.path, function (err, stat) {
          file.size = stat.size;
          file.lastModifiedDate = stat.mtime;
        });
      }


      // The stream exists, do nothing more
      if (file.stream) {
        return;
      }


      // Create a read stream from a buffer
      if (file.buffer) {
        process.nextTick(function () {
          stream.emit('data', file.buffer);
          stream.emit('end');
        });
        file.stream = stream;
        return;
      }


      // Create a read stream from a file
      if (file.path) {
        // TODO url
        if (!chunked) {
          fs.readFile(file.path, function (err, data) {
            if (err) {
              stream.emit('error', err);
            }
            if (data) {
              stream.emit('data', data);
              stream.emit('end');
            }
          });

          file.stream = stream;
          return;
        }

        // TODO don't duplicate this code here,
        // expose a method in File instead
        file.stream = fs.createReadStream(file.path);
      }
    }



    // before any other listeners are added
    emitter.on('abort', function () {
      self.readyState = self.DONE;
    });



    // Map `error`, `progress`, `load`, and `loadend`
    function mapStreamToEmitter(format, encoding) {
      var stream = file.stream,
        buffers = [],
        chunked = self.nodeChunkedEncoding;

      buffers.dataLength = 0;

      stream.on('error', function (err) {
        if (self.DONE === self.readyState) {
          return;
        }

        self.readyState = self.DONE;
        self.error = err;
        emitter.emit('error', err);
      });

      stream.on('data', function (data) {
        if (self.DONE === self.readyState) {
          return;
        }

        buffers.dataLength += data.length;
        buffers.push(data);

        emitter.emit('progress', {
          // fs.stat will probably complete before this
          // but possibly it will not, hence the check
          lengthComputable: (!isNaN(file.size)) ? true : false,
          loaded: buffers.dataLength,
          total: file.size
        });

        emitter.emit('data', data);
      });

      stream.on('end', function () {
        if (self.DONE === self.readyState) {
          return;
        }

        var data;

        if (buffers.length > 1 ) {
          data = Buffer.concat(buffers);
        } else {
          data = buffers[0];
        }

        self.readyState = self.DONE;
        self.result = mapDataToFormat(file, data, format, encoding);
        emitter.emit('load', {
          target: {
            // non-standard
            nodeBufferResult: data,
            result: self.result
          }
        });

        emitter.emit('loadend');
      });
    }


    // Abort is overwritten by readAsXyz
    self.abort = function () {
      if (self.readState == self.DONE) {
        return;
      }
      self.readyState = self.DONE;
      emitter.emit('abort');
    };



    // 
    function mapUserEvents() {
      emitter.on('start', function () {
        doop(self.onloadstart, arguments);
      });
      emitter.on('progress', function () {
        doop(self.onprogress, arguments);
      });
      emitter.on('error', function (err) {
        // TODO translate to FileError
        if (self.onerror) {
          self.onerror(err);
        } else {
          if (!emitter.listeners.error || !emitter.listeners.error.length) {
            throw err;
          }
        }
      });
      emitter.on('load', function () {
        doop(self.onload, arguments);
      });
      emitter.on('end', function () {
        doop(self.onloadend, arguments);
      });
      emitter.on('abort', function () {
        doop(self.onabort, arguments);
      });
    }



    function readFile(_file, format, encoding) {
      file = _file;
      if (!file || !file.name || !(file.path || file.stream || file.buffer)) {
        throw new Error("cannot read as File: " + JSON.stringify(file));
      }
      if (0 !== self.readyState) {
        console.log("already loading, request to change format ignored");
        return;
      }

      // 'process.nextTick' does not ensure order, (i.e. an fs.stat queued later may return faster)
      // but `onloadstart` must come before the first `data` event and must be asynchronous.
      // Hence we waste a single tick waiting
      process.nextTick(function () {
        self.readyState = self.LOADING;
        emitter.emit('loadstart');
        createFileStream();
        mapStreamToEmitter(format, encoding);
        mapUserEvents();
      });
    }

    self.readAsArrayBuffer = function (file) {
      readFile(file, 'buffer');
    };
    self.readAsBinaryString = function (file) {
      readFile(file, 'binary');
    };
    self.readAsDataURL = function (file) {
      readFile(file, 'dataUrl');
    };
    self.readAsText = function (file, encoding) {
      readFile(file, 'text', encoding);
    };
  }

  module.exports = FileReader;
}());

}).call(this,require('_process'),require("buffer").Buffer)

},{"_process":9,"buffer":4,"events":5,"fs":3}],7:[function(require,module,exports){
exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}

},{}],8:[function(require,module,exports){
var toString = {}.toString;

module.exports = Array.isArray || function (arr) {
  return toString.call(arr) == '[object Array]';
};

},{}],9:[function(require,module,exports){
// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],10:[function(require,module,exports){
var config = require('../../config.json');
var Clump = require('./objects/clump');
var Lump = require('./objects/lump');

var io = require('./io');

var library = require('./library');
var loaded = {};

var types = {
  Quality: require('./objects/quality'),
  Event: require('./objects/event'),
  Interaction: require('./objects/interaction'),
  QualityEffect: require('./objects/quality-effect'),
  QualityRequirement: require('./objects/quality-requirement'),
  Area: require('./objects/area'),
  SpawnedEntity: require('./objects/spawned-entity'),
  CombatAttack: require('./objects/combat-attack'),
  Exchange: require('./objects/exchange'),
  Shop: require('./objects/shop'),
  Availability: require('./objects/availability'),
  Tile: require('./objects/tile'),
  TileVariant: require('./objects/tile-variant'),
  Port: require('./objects/port'),
  Setting: require('./objects/setting')
};

// Prepopulate library with Clumps of each type we know about
Object.keys(types).forEach(function(typeName) {
	var Type = types[typeName];
	if(!library[typeName]) {
		library[typeName] = new Clump([], Type);
		loaded[typeName] = new Clump([], Type);
	}
});

function get(Type, id, parent) {
	var typename = Type.name;	// Event, Quality, Interaction, etc

	var existingThingWithThisId = library[typename].id(id);
	if(existingThingWithThisId) {
		//console.log("Attached existing " + existingThingWithThisId + " to " + this.toString())
		var newParent = true;
		existingThingWithThisId.parents.forEach(function(p) {
			if(p.Id === parent.Id && p.constructor.name === parent.constructor.name) {
				newParent = false;
			}
		});
		if(newParent){
			existingThingWithThisId.parents.push(parent);
		}

		if(!existingThingWithThisId.wired) {
			existingThingWithThisId.wireUp(this);	// Pass in the api so object can add itself to the master-library
		}
		return existingThingWithThisId;
	}
	else {
		return null;
	}
}

function getOrCreate(Type, possNewThing, parent) {	// If an object already exists with this ID, use that.  Otherwise create a new object from the supplied details hash
	var typename = Type.name;	// Event, Quality, Interaction, etc
	if(possNewThing) {
  	var existingThingWithThisId = this.get(Type, possNewThing.Id, parent);
  	if(existingThingWithThisId) {
  		return existingThingWithThisId;
  	}
  	else {
			var newThing = new Type(possNewThing, parent);
			newThing.wireUp(this);
			//console.log("Recursively created " + newThing + " for " + this.toString());
			return newThing;
		}
	}
	else {
		return null;
	}
}

function wireUpObjects() {
	var api = this;
  Object.keys(types).forEach(function(type) {
    library[type].forEach(function(lump) {
      if(lump.wireUp) {
        lump.wireUp(api);
      }
    });
  });
}

var whatIs = function(id) {
  var possibilities = [];
  Object.keys(library).forEach(function(key) {
    if(library[key] instanceof Clump && library[key].id(id)) {
      possibilities.push(key);
    }
  });
  return possibilities;
};

function describeAdvancedExpression(expr) {
	var self = this;
	if(expr) {
		expr = expr.replace(/\[d:(\d+)\]/gi, "RANDOM[1-$1]");	// [d:x] = random number from 1-x(?)
		expr = expr.replace(/\[q:(\d+)\]/gi, function(match, backref, pos, whole_str) {
			var quality = self.library.Quality.id(backref);
			return "["+(quality ? quality.Name : 'INVALID')+"]";
		});

		return expr;
	}
	return null;
}

function readFromFile(Type, file, callback) {
	io.readFile(file, function (e) {
    var contents = e.target.result;
    
    var obj = JSON.parse(contents);
    loaded[Type.prototype.constructor.name] = new Clump(obj, Type);

    callback(contents, Type, loaded[Type.prototype.constructor.name]);
  });
}


module.exports = {
	'Clump': Clump,
	'Lump': Lump,
	'config': config,
	'types': types,
	'library': library,
	'loaded': loaded,
	'get': get,
	'whatIs': whatIs,
	'wireUpObjects': wireUpObjects,
	'getOrCreate': getOrCreate,
	'describeAdvancedExpression': describeAdvancedExpression,
	'readFromFile': readFromFile
};
},{"../../config.json":1,"./io":11,"./library":12,"./objects/area":13,"./objects/availability":14,"./objects/clump":15,"./objects/combat-attack":16,"./objects/event":17,"./objects/exchange":18,"./objects/interaction":19,"./objects/lump":20,"./objects/port":21,"./objects/quality":24,"./objects/quality-effect":22,"./objects/quality-requirement":23,"./objects/setting":25,"./objects/shop":26,"./objects/spawned-entity":27,"./objects/tile":29,"./objects/tile-variant":28}],11:[function(require,module,exports){

if(typeof FileReader === 'undefined') { // Running in node rather than a browser
  FileReader = require('filereader');
}

var fileObjectMap = {
    'events.json' : 'Event',
    'qualities.json' : 'Quality',
    'areas.json' : 'Area',
    'SpawnedEntities.json' : 'SpawnedEntity',
    'CombatAttacks.json' : 'CombatAttack',
    'exchanges.json' : 'Exchange',
    'Tiles.json': 'Tile'
  };

function readFile(file, callback) {
  var reader = new FileReader();
  reader.onload = callback;
  reader.readAsText(file);
}

var files_to_load = 0;
function resetFilesToLoad() {
	files_to_load = 0;
}
function incrementFilesToLoad() {
	files_to_load++;
}
function decrementFilesToLoad() {
	files_to_load--;
}
function countFilesToLoad() {
	return files_to_load;
}


module.exports = {
  readFile: readFile,
  resetFilesToLoad: resetFilesToLoad,
	incrementFilesToLoad: incrementFilesToLoad,
	decrementFilesToLoad: decrementFilesToLoad,
	countFilesToLoad: countFilesToLoad,
  fileObjectMap: fileObjectMap
};
},{"filereader":6}],12:[function(require,module,exports){
module.exports = {};
},{}],13:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Area(raw) {
	this.straightCopy = ["Name", "Description", "ImageName", "MoveMessage"];
	Lump.call(this, raw);
}
Object.keys(Lump.prototype).forEach(function(member) { Area.prototype[member] = Lump.prototype[member]; });

Area.prototype.wireUp = function(theApi) {
	api = theApi;
	Lump.prototype.wireUp.call(this);
};

Area.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Area.prototype.toDom = function(size) {

	size = size || "normal";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.ImageName !== null && this.Image !== "") {
		element.innerHTML = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.ImageName+".png' />";
	}

	element.innerHTML += "\n<h3 class='title'>"+this.Name+"</h3>\n<p class='description'>"+this.Description+"</p>";

	element.title = this.toString();

	return element;
};

module.exports = Area;
},{"./lump":20}],14:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Availability(raw, parent) {
	this.straightCopy = [
		'Cost',
		'SellPrice'
	];
	Lump.apply(this, arguments);

	this.quality = null;
	this.purchaseQuality = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Availability.prototype[member] = Lump.prototype[member]; });

Availability.prototype.wireUp = function(theApi) {

	api = theApi;

	this.quality = api.getOrCreate(api.types.Quality, this.attribs.Quality, this);
	this.purchaseQuality = api.getOrCreate(api.types.Quality, this.attribs.PurchaseQuality, this);

	Lump.prototype.wireUp.call(this, api);
};

Availability.prototype.isAdditive = function() {
	return this.Cost > 0;
};

Availability.prototype.isSubtractive = function() {
	return this.SellPrice > 0;
};

Availability.prototype.toString = function() {
	return this.constructor.name + " " + this.quality + " (buy: " + this.Cost + "x" + this.purchaseQuality.Name + " / sell: " + this.SellPrice + "x" + this.purchaseQuality.Name + ")";
};

Availability.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;
	
	var purchase_quality_element;

	if(!this.quality) {
		purchase_quality_element = document.createElement("span");
		purchase_quality_element.innerHTML = "[INVALID]";
	}
	else {
		purchase_quality_element = this.quality.toDom("small", false, "span");
	}

	var currency_quality_element = this.purchaseQuality.toDom("small", false, "span");
	currency_quality_element.className = "quantity item small";
	var currency_quality_markup = currency_quality_element.outerHTML;

	var currency_buy_amount_element = document.createElement("span");
	currency_buy_amount_element.className = "item quantity";
	currency_buy_amount_element.innerHTML = "Buy: " + (this.Cost ? this.Cost+"x" : "&#10007;");
	currency_buy_amount_element.title = this.toString();

	var currency_sell_amount_element = document.createElement("span");
	currency_sell_amount_element.className = "item quantity";
	currency_sell_amount_element.innerHTML = "Sell: " + (this.SellPrice ? this.SellPrice+"x" : "&#10007;");
	currency_sell_amount_element.title = this.toString();


	element.appendChild(purchase_quality_element);
	element.appendChild(currency_buy_amount_element);
	if(this.Cost) {
		element.appendChild($(currency_quality_markup)[0]);
	}
	element.appendChild(currency_sell_amount_element);
	if(this.SellPrice) {
		element.appendChild($(currency_quality_markup)[0]);
	}

	return element;
};

module.exports = Availability;
},{"./lump":20}],15:[function(require,module,exports){

function Clump(raw, Type, parent) {
	this.type = Type;
	this.items = {};
	var self = this;
	raw.forEach(function(item, index, collection) {
		if(!(item instanceof Type)) {
			item = new Type(item, parent);
		}
		else if(parent) {
			var newParent = true;
			item.parents.forEach(function(p) {
				if(p.Id === parent.Id && p.constructor.name === parent.constructor.name) {
					newParent = false;
				}
			});
			if(newParent){
				item.parents.push(parent);
			}
		}
		if(self.items[item.Id]) {
			console.warn(Type.name+" "+item.Id+" already exists in this clump.  Duplicated IDs for different objects in the game-json?")
		}
		self.items[item.Id] = item;
	});
}

Clump.prototype.empty = function() {
	return !!this.size();
};

Clump.prototype.size = function() {
	return Object.keys(this.items).length;
};

Clump.prototype.get = function(index) {
	for(var id in this.items) {
		if(index === 0) {
			return this.items[id];
		}
		index--;
	}
};

Clump.prototype.id = function(id) {
	return this.items[id];
};

Clump.prototype.each = function() {
	var args = Array.prototype.slice.call(arguments);
	return this.map(function(item) {

		if(args[0] instanceof Array) {	// Passed in array of fields, so return values concatenated with optional separator
			var separator = (typeof args[1] === "undefined") ? "-" : args[1];
			return args[0].map(function(f) { return item[f]; }).join(separator);
		}
		else if(args.length > 1) {	// Passed in separate fields, so return array of values
			return args.map(function(f) { return item[f]; });
		}
		else {
			return item[args[0]];
		}
	});
};

Clump.prototype.forEach = function(callback) {
	for(var id in this.items) {
		var item = this.items[id];
		callback(item, id, this.items);
	}
};

Clump.prototype.map = function(callback) {
	var self = this;
	var arrayOfItems = Object.keys(this.items).map(function(key) {
		return self.items[key];
	});
	return arrayOfItems.map.call(arrayOfItems, callback);
};

Clump.prototype.sortBy = function(field, reverse) {
	var self = this;
	var objs = Object.keys(this.items).map(function(key) {
		return self.items[key];
	}).sort(function(a, b) {
		if(a[field] < b[field]) {
			return -1;
		}
		if(a[field] === b[field]) {
			return 0;
		}
		if(a[field] > b[field]) {
			return 1;
		}
	});

	return reverse ? objs.reverse() : objs;
};

Clump.prototype.same = function() {
	var self = this;

	var clone = function(obj) {
    var target = {};
    for (var i in obj) {
    	if (obj.hasOwnProperty(i)) {
    		if(typeof obj[i] === "object") {
    			target[i] = clone(obj[i]);
    		}
    		else {
      		target[i] = obj[i];
      	}
      }
    }
    return target;
  };

	var template = clone(this.get(0).attribs);

	for(var id in this.items) {
		var otherObj = this.items[id].attribs;
		for(var key in template) {
			if(template[key] !== otherObj[key]) {
				delete(template[key]);
			}
		}
	}

	return template;
};

Clump.prototype.distinct = function(field) {
	var sampleValues = {};
	this.forEach(function(item) {
		var value = item[field];
		sampleValues[value] = value;	// Cheap de-duping with a hash
	});
	return Object.keys(sampleValues).map(function(key) { return sampleValues[key]; });
};

Clump.prototype.distinctRaw = function(field) {
	var sampleValues = {};
	this.forEach(function(item) {
		var value = item.attribs[field];
		sampleValues[value] = value;	// Cheap de-duping with a hash
	});
	return Object.keys(sampleValues).map(function(key) { return sampleValues[key]; });
};

Clump.prototype.query = function(field, value) {
	var matches = [];
	var test;

	// Work out what sort of comparison to do:

	if(typeof value === "function") {	// If value is a function, pass it the candidate and return the result
		test = function(candidate) {
			return !!value(candidate);
		};
	}
	else if(typeof value === "object") {
		if(value instanceof RegExp) {
			test = function(candidate) {
				return value.test(candidate);
			};
		}
		else if(value instanceof Array) {	// If value is an array, test for the presence of the candidate value in the array
			test = function(candidate) {
				return value.indexOf(candidate) !== -1;
			};
		}
		else {
			test = function(candidate) {
				return candidate === value;	// Handle null, undefined or object-reference comparison
			};
		}
	}
	else {	// Else if it's a simple type, try a strict equality comparison
		test = function(candidate) {
			return candidate === value;
		};
	}
	
	// Now iterate over the items, filtering using the test function we defined
	this.forEach(function(item) {
		if(
			(field !== null && test(item[field])) ||
			(field === null && test(item))
		) {
			matches.push(item);
		}
	});
	return new Clump(matches, this.type);	// And wrap the resulting array of objects in a new Clump object for sexy method chaining like x.query().forEach() or x.query().query()
};

Clump.prototype.queryRaw = function(field, value) {
	var matches = [];
	var test;

	// Work out what sort of comparison to do:

	if(typeof value === "function") {	// If value is a function, pass it the candidate and return the result
		test = function(candidate) {
			return !!value(candidate);
		};
	}
	else if(typeof value === "object") {
		if(value instanceof RegExp) {
			test = function(candidate) {
				return value.test(candidate);
			};
		}
		else if(value instanceof Array) {	// If value is an array, test for the presence of the candidate value in the array
			test = function(candidate) {
				return value.indexOf(candidate) !== -1;
			};
		}
		else {	// If value is a hash... what do we do?
			// Check the candidate for each field in the hash in turn, and include the candidate if any/all of them have the same value as the corresponding value-hash field?
			throw "No idea what to do with an object as the value";
		}
	}
	else {	// Else if it's a simple type, try a strict equality comparison
		test = function(candidate) {
			return candidate === value;
		};
	}
	
	// Now iterate over them all, filtering using the test function we defined
	this.forEach(function(item) {
		if(
			(field !== null && test(item.attribs[field])) ||
			(field === null && test(item.attribs))
		) {
			matches.push(item);
		}
	});
	return new Clump(matches, this.type);	// And wrap the resulting array of objects in a new Clump object for sexy method chaining like x.query().forEach() or x.query().query()
};

Clump.prototype.toString = function() {
	return this.type.name + " Clump (" + this.size() + " items)";
};

Clump.prototype.toDom = function(size, includeChildren, tag, firstChild) {

	size = size || "normal";
	tag = tag || "ul";

	var element = document.createElement(tag);
	element.className = this.constructor.name.toLowerCase()+"-list "+size;
	if(firstChild) {
		element.appendChild(firstChild);
	}
	this.sortBy("Name").forEach(function(i) {
		element.appendChild(i.toDom(size, includeChildren));
	});
	return element;
};

Clump.prototype.describe = function() {
	var self = this;
	return Object.keys(this.items).map(function(i) { return self.items[i].toString(); }).join(" and ");
};

module.exports = Clump;
},{}],16:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function CombatAttack(raw, parent) {
	this.straightCopy = [
		'Name',
		'Image',
		'RammingAttack',
		'OnlyWhenExposed',
		'Range',
		'Orientation',
		'Arc',
		'BaseHullDamage',
		'BaseLifeDamage',
		'ExposedQualityDamage',	// Value to add to the exposedQuality: positive increases quality level (eg Terror), negative decreases it (eg Crew)
		'StaggerAmount',
		'BaseWarmUp',
		'Animation',
		'AnimationNumber'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.qualityRequired = null;
	this.qualityCost = null;
	this.exposedQuality = null;
}

Object.keys(Lump.prototype).forEach(function(member) { CombatAttack.prototype[member] = Lump.prototype[member]; });

CombatAttack.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualityRequired = api.get(api.types.Quality, this.attribs.QualityRequiredId, this);
	this.qualityCost = api.get(api.types.Quality, this.attribs.QualityCostId, this);
	this.exposedQuality = api.get(api.types.Quality, this.attribs.ExposedQualityId, this);

	Lump.prototype.wireUp.call(this, api);
};

CombatAttack.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

CombatAttack.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var self = this;
	
	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"</h3>";

	if(this.qualityRequired || this.qualityCost) {
		html += "<div class='sidebar'>";

		if(this.qualityRequired) {
			html += "<h4>Required</h4>";
			html += (new Clump([this.qualityRequired], api.types.Quality)).toDom("small", false, "ul").outerHTML;
		}
		if(this.qualityCost) {
			html += "<h4>Cost</h4>";
			html += (new Clump([this.qualityCost], api.types.Quality)).toDom("small", false, "ul").outerHTML;
		}
		html += "</div>";
	}

	html += "<dl class='clump-list small'>";
	['Range', 'Arc', 'BaseHullDamage', 'BaseLifeDamage', 'StaggerAmount', 'BaseWarmUp'].forEach(function(key) {
		html += "<dt class='item'>"+key+"</dt><dd class='quantity'>"+self[key]+"</dd>";
	});
	html += "</dl>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = CombatAttack;
},{"./clump":15,"./lump":20}],17:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Event(raw, parent) {
	this.straightCopy = [
	'Name',
	'Description',
	'Teaser',
	'Image',
	'Category'
	];
	Lump.apply(this, arguments);

	this.tag = null;

	this.ExoticEffects = this.getExoticEffect(this.attribs.ExoticEffects);

	this.qualitiesRequired = null;
	this.qualitiesAffected = null;
	this.interactions = null;
	this.linkToEvent = null;

	this.limitedToArea = null;

	this.setting = null;
	
	//Deck
	//Stickiness
	//Transient
	//Urgency
}
Object.keys(Lump.prototype).forEach(function(member) { Event.prototype[member] = Lump.prototype[member]; });

Event.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualitiesRequired = new Clump(this.attribs.QualitiesRequired || [], api.types.QualityRequirement, this);
	this.qualitiesAffected = new Clump(this.attribs.QualitiesAffected || [], api.types.QualityEffect, this);
	this.interactions = new Clump(this.attribs.ChildBranches|| [], api.types.Interaction, this);

	this.linkToEvent = api.getOrCreate(api.types.Event, this.attribs.LinkToEvent, this);

	this.limitedToArea = api.getOrCreate(api.types.Area, this.attribs.LimitedToArea, this);

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);
	
	Lump.prototype.wireUp.call(this, api);
};

Event.prototype.toString = function(long) {
	return this.constructor.name + " " + (long ? " [" + this.Category + "] " : "") + this.Name + " (#" + this.Id + ")";
};

Event.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"\n"+(this.tag ? "<span class='tag "+this.tag+"'>"+this.tag+"</span>" : "")+"</h3>";

	if(size != "small" && (this.qualitiesRequired || this.qualitiesAffected)) {
		html += "<div class='sidebar'>";
		if(this.qualitiesRequired && this.qualitiesRequired.size()) {
			html += "<h4>Requirements</h4>\n";
			html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
		}
		if(this.qualitiesAffected && this.qualitiesAffected.size()) {
			html += "<h4>Effects</h4>\n";
			html += this.qualitiesAffected.toDom("small", false, "ul").outerHTML;
		}
		html += "</div>";
	}
	
	html += "<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString(true);

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var interactions = self.interactions;
				var linkToEvent = self.linkToEvent;
				if(linkToEvent) {
					var wrapperClump = new Clump([linkToEvent], api.types.Event);
					var linkToEvent_element = wrapperClump.toDom("normal", true);

					linkToEvent_element.classList.add("child-list");
					element.appendChild(linkToEvent_element);
				}
				else if(interactions && interactions.size() > 0) {
					var interactions_element = interactions.toDom("normal", true);

					interactions_element.classList.add("child-list");
					element.appendChild(interactions_element);
				}
			}
		});
	}

	return element;
};

module.exports = Event;
},{"./clump":15,"./lump":20}],18:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Exchange(raw, parent) {
	this.straightCopy = [
		'Id',
		'Name',
		'Description',
		'Image',
		'SettingIds'
	];
	Lump.apply(this, arguments);

	this.shops = null;
	this.settings = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Exchange.prototype[member] = Lump.prototype[member]; });

Exchange.prototype.wireUp = function(theApi) {

	api = theApi;

	var self = this;

	this.shops = new Clump(this.attribs.Shops || [], api.types.Shop, this);
	
	this.settings = api.library.Setting.query("Id", function(id) {
		return self.SettingIds.indexOf(id) !== -1;
	});
	this.settings.forEach(function (s) {
		self.parents.push(s);
	});
	
	this.ports = api.library.Port.query("SettingId", function(id) {
		return self.SettingIds.indexOf(id) !== -1;
	});
	this.ports.forEach(function (p) {
		self.parents.push(p);
	});

	Lump.prototype.wireUp.call(this);
};

Exchange.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Exchange.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.shops) {

					var child_elements = self.shops.toDom("normal", true);

					child_elements.classList.add("child-list");
					element.appendChild(child_elements);
				}
			}
		});
	}

	return element;
};

module.exports = Exchange;
},{"./clump":15,"./lump":20}],19:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Interaction(raw, parent) {
	this.straightCopy = [
	'Name',
	'Description',
	'ButtonText',
	'Image',

	'Ordering'
	];
	Lump.apply(this, arguments);

	this.qualitiesRequired = null;
	this.successEvent = null;
	this.defaultEvent = null;

}
Object.keys(Lump.prototype).forEach(function(member) { Interaction.prototype[member] = Lump.prototype[member]; });

Interaction.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualitiesRequired = new Clump(this.attribs.QualitiesRequired || [], api.types.QualityRequirement, this);
	this.successEvent = api.getOrCreate(api.types.Event, this.attribs.SuccessEvent, this);
	if(this.successEvent) {
		this.successEvent.tag = "success";
	}
	this.defaultEvent = api.getOrCreate(api.types.Event, this.attribs.DefaultEvent, this);
	var qualitiesRequired =  this.qualitiesRequired;
	if(this.defaultEvent && this.successEvent && qualitiesRequired && qualitiesRequired.size()) {
		this.defaultEvent.tag = "failure";
	}

	Lump.prototype.wireUp.call(this, api);
};

Interaction.prototype.toString = function() {
	return this.constructor.name + " [" + this.Ordering + "] " + this.Name + " (#" + this.Id + ")";
};

Interaction.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"</h3>";

	if(size != "small" && this.qualitiesRequired) {
		html += "<div class='sidebar'>";
		html += "<h4>Requirements</h4>";
		html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
		html += "</div>";
	}

	html += "<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom("normal", true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = Interaction;
},{"./clump":15,"./lump":20}],20:[function(require,module,exports){
var library = require('../library');
var Clump = require('./clump');

var api;

function Lump(raw, parent) {
	if(parent) {
		this.parents = parent instanceof Array ? parent : [parent];
	}
	else {
		this.parents = [];
	}

	if(!this.straightCopy) {
		this.straightCopy = [];
	}
	this.straightCopy.unshift('Id');

	this.attribs = raw;

	var self = this;
	this.straightCopy.forEach(function(attrib) {
		self[attrib] = raw[attrib];
		if(typeof self[attrib] === "undefined") {
			self[attrib] = null;
		}
	});
	delete(this.straightCopy);

	this.wired = false;

	if(!library[this.constructor.name]) {
		library[this.constructor.name] = new Clump([], this);
	}

	if(library[this.constructor.name].items[this.Id]) {	// Something with this ID already exists!

		var existingObject = library[this.constructor.name].items[this.Id];

		if(!isFunctionallySame(this.attribs, existingObject.attribs)) {	// Was it a functionally-identical redefinition of this object?
			console.warn("Duplicate ID", this.constructor.name+" "+this.Id+" already exists in the library - replacing", existingObject, "with redefinition", this);
		}
	}
	library[this.constructor.name].items[this.Id] = this;
}

var isFunctionallySame = function(obj1, obj2) {

	if(obj1 === obj2) {
		return true;
	}

	if(obj1 instanceof Object) {
		if(!(obj2 instanceof Object) || obj1.constructor !== obj2.constructor) {
			return false;
		}

		var allKeys = Object.keys(obj1).concat(Object.keys(obj2)).filter(function (value, index, self) { 
    	return self.indexOf(value) === index;
		});

		return allKeys.map(function(key) {
			return isFunctionallySame(obj1[key], obj2[key]);
		}).reduce(function(previousValue, currentValue) {
			return previousValue && currentValue;
		}, true);
	}

	return false;

};

Lump.prototype = {
	wireUp: function(theApi) {
		api = theApi;
		this.wired = true;
	},

	getStates: function(encoded) {
		if(typeof encoded === "string" && encoded !== "") {
			var map = {};
			encoded.split("~").forEach(function(state) {
				var pair = state.split("|");
				map[pair[0]] = pair[1];
			});
			return map;
		}
		else {
			return null;
		}
	},

	getExoticEffect: function(encoded) {
		if(typeof encoded === "string") {
			var effect={}, fields=["operation", "first", "second"];
			encoded.split(",").forEach(function(val, index) {
				effect[fields[index]] = val;
			});
			return effect;
		}
		else {
			return null;
		}
	},

	evalAdvancedExpression: function(expr) {
		expr = expr.replace(/\[d:(\d+)\]/gi, "Math.floor((Math.random()*$1)+1)");	// Replace [d:x] with JS to calculate random number on a Dx die
		/*jshint -W061 */
		return eval(expr);
		/*jshint +W061 */
	},

	isA: function(type) {
		return this instanceof type;
	},

	isOneOf: function(types) {
		var self = this;
		return types.map(function(type) {
			return self.isA(type);
		}).reduce(function(previousValue, currentValue, index, array){
			return previousValue || currentValue;
		}, false);
	},

	toString: function() {
		return this.constructor.name + " (#" + this.Id + ")";
	},

	isFunctionallySame: isFunctionallySame	// Convenience utility function
};

module.exports = Lump;
},{"../library":12,"./clump":15}],21:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Port(raw, parent) {
	this.straightCopy = [
		'Name',
		'Rotation',
		'Position',
		'DiscoveryValue',
		'IsStartingPort'
	];


	raw.Id = parent.Name+"/"+raw.Name;
	Lump.apply(this, arguments);

	this.SettingId = raw.Setting.Id;
	this.setting = null;

	this.area = null;

	this.exchanges = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Port.prototype[member] = Lump.prototype[member]; });

Port.prototype.wireUp = function(theApi) {
	
	api = theApi;
	var self = this;

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);
	
	this.area = api.getOrCreate(api.types.Area, this.attribs.Area, this);

	this.exchanges = api.library.Exchange.query("SettingIds", function(ids) { return ids.indexOf(self.SettingId) !== -1; });

	Lump.prototype.wireUp.call(this, api);
};

Port.prototype.toString = function(long) {
	return this.constructor.name + " " + this.Name + " (#" + this.Name + ")";
};

Port.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Name+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Port;
},{"./lump":20}],22:[function(require,module,exports){
var Lump = require('./lump');

var api;

function QualityEffect(raw, parent) {
	this.straightCopy = ["Level", "SetToExactly"];
	Lump.apply(this, arguments);

	// May involve Quality object references, so can't resolve until after all objects are wired up
	this.setToExactlyAdvanced = null;
	this.changeByAdvanced = null;	

	this.associatedQuality = null;
	
}
Object.keys(Lump.prototype).forEach(function(member) { QualityEffect.prototype[member] = Lump.prototype[member]; });

QualityEffect.prototype.wireUp = function(theApi) {

	api = theApi;

	this.associatedQuality = api.get(api.types.Quality, this.attribs.AssociatedQualityId, this);
	this.setToExactlyAdvanced = api.describeAdvancedExpression(this.attribs.SetToExactlyAdvanced);
	this.changeByAdvanced = api.describeAdvancedExpression(this.attribs.ChangeByAdvanced);

	Lump.prototype.wireUp.call(this, api);
};

QualityEffect.prototype.getQuantity = function() {
	var condition = "";
	
	if(this.setToExactlyAdvanced !== null) {
		condition = "+(" + this.setToExactlyAdvanced + ")";
	}
	else if(this.SetToExactly !== null) {
		condition = "= " + this.SetToExactly;
	}
	else if(this.changeByAdvanced !== null) {
		condition = "+(" + this.changeByAdvanced + ")";
	}
	else if(this.Level !== null) {
		if(this.Level < 0) {
			condition = this.Level;
		}
		else if(this.Level > 0) {
			condition = "+" + this.Level;
		}
	}
	
	return condition;
};

QualityEffect.prototype.isAdditive = function() {
	return this.setToExactlyAdvanced || this.SetToExactly || this.changeByAdvanced || (this.Level > 0);
};

QualityEffect.prototype.isSubtractive = function() {
	return !this.setToExactlyAdvanced && !this.SetToExactly && !this.changeByAdvanced && (this.Level <= 0);
};

QualityEffect.prototype.toString = function() {
	var quality = this.associatedQuality;
	return this.constructor.name + " ("+this.Id+") on " + quality + this.getQuantity();
};

QualityEffect.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	var quality_element = this.associatedQuality;

	if(!quality_element) {
		quality_element = document.createElement("span");
		quality_element.innerHTML = "[INVALID]";
	}
	else {
		quality_element = this.associatedQuality.toDom(size, false, "span");
	}

	var quantity_element = document.createElement("span");
	quantity_element.className = "item quantity";
	quantity_element.innerHTML = this.getQuantity();
	quantity_element.title = this.toString();

	element.appendChild(quality_element);
	element.appendChild(quantity_element);

	return element;
};

module.exports = QualityEffect;
},{"./lump":20}],23:[function(require,module,exports){
var Lump = require('./lump');

var api;

function QualityRequirement(raw, parent) {
	this.straightCopy = ['MinLevel', 'MaxLevel'];
	Lump.apply(this, arguments);

	this.difficultyAdvanced = null;
	this.minAdvanced = null;
	this.maxAdvanced = null;

	this.associatedQuality = null;
	this.chanceQuality = null;
}
Object.keys(Lump.prototype).forEach(function(member) { QualityRequirement.prototype[member] = Lump.prototype[member]; });

QualityRequirement.prototype.wireUp = function(theApi) {

	api = theApi;

	this.difficultyAdvanced = api.describeAdvancedExpression(this.attribs.DifficultyAdvanced);
	this.minAdvanced = api.describeAdvancedExpression(this.attribs.MinAdvanced);
	this.maxAdvanced = api.describeAdvancedExpression(this.attribs.MaxAdvanced);

	this.associatedQuality = api.get(api.types.Quality, this.attribs.AssociatedQualityId, this);

	this.chanceQuality = this.getChanceCap();

	Lump.prototype.wireUp.call(this, api);
};

QualityRequirement.prototype.getChanceCap = function() {
	var quality = null;
	if(!this.attribs.DifficultyLevel) {
		return null;
	}
	quality = this.associatedQuality;
	if(!quality) {
		return null;
	}
	
	return Math.round(this.attribs.DifficultyLevel * ((100 + quality.DifficultyScaler + 7)/100));
};

QualityRequirement.prototype.getQuantity = function() {
	var condition = "";

  if(this.difficultyAdvanced !== null) {
  	condition = this.difficultyAdvanced;
  }
  else if(this.minAdvanced !== null) {
  	condition = this.minAdvanced;
  }
  else if(this.maxAdvanced !== null) {
  	condition = this.maxAdvanced;
  }
	else if(this.chanceQuality !== null) {
		condition = this.chanceQuality + " for 100%";
	}
	else if(this.MaxLevel !== null && this.MinLevel !== null) {
		if(this.MaxLevel === this.MinLevel) {
			condition = "= " + this.MinLevel;
		}
		else {
			condition = this.MinLevel + "-" + this.MaxLevel;
		}
	}
	else {
		if(this.MinLevel !== null) {
			condition = "&ge; " + this.MinLevel;
		}
		if(this.MaxLevel !== null) {
			condition = "&le; " + this.MaxLevel;
		}
	}
	return condition;
};

QualityRequirement.prototype.toString = function() {
	var quality = this.associatedQuality;
	return this.constructor.name + " ("+this.Id+") on " + quality + " " + this.getQuantity();
};

QualityRequirement.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	var quality_element = this.associatedQuality;

	if(!quality_element) {
		quality_element = document.createElement("span");
		quality_element.innerHTML = "[INVALID]";
	}
	else {
		quality_element = this.associatedQuality.toDom(size, false, "span");
	}

	var quantity_element = document.createElement("span");
	quantity_element.className = "item quantity";
	quantity_element.innerHTML = this.getQuantity();
	quantity_element.title = this.toString();

	element.appendChild(quality_element);
	element.appendChild(quantity_element);

	return element;
};

module.exports = QualityRequirement;
},{"./lump":20}],24:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Quality(raw, parent) {
	this.straightCopy = [
		'Name',
		'Description',
		'Image',

		'Category',
		'Nature',
		'Tag',

		"IsSlot",

		'AllowedOn',
		"AvailableAt",

		'Cap',
		'DifficultyScaler',
		'Enhancements'
	];
	Lump.apply(this, arguments);

	this.States = this.getStates(raw.ChangeDescriptionText);
	this.LevelDescriptionText = this.getStates(raw.LevelDescriptionText);
	this.LevelImageText = this.getStates(raw.LevelImageText);

	this.useEvent = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Quality.prototype[member] = Lump.prototype[member]; });

Quality.prototype.wireUp = function(theApi) {

	api = theApi;

	this.useEvent = api.getOrCreate(api.types.Event, this.attribs.UseEvent, this);
	if(this.useEvent) {
		this.useEvent.tag = "use";
	}

	Lump.prototype.wireUp.call(this, api);
};

Quality.prototype.toString = function(long) {
	return this.constructor.name + " " + (long ? " [" + this.Nature + " > " + this.Category + " > " + this.Tag + "] " : "") + this.Name + " (#" + this.Id + ")";
};

Quality.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.useEvent) {

					var wrapperClump = new Clump([self.useEvent], api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = Quality;
},{"./clump":15,"./lump":20}],25:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Setting(raw, parent) {
	this.straightCopy = [
		'Id'
	];
	Lump.apply(this, arguments);

	this.shops = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Setting.prototype[member] = Lump.prototype[member]; });

Setting.prototype.wireUp = function(theApi) {

	api = theApi;

	Lump.prototype.wireUp.call(this);
};

Setting.prototype.toString = function() {
	return this.constructor.name + " #" + this.Id;
};

Setting.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Id+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Setting;
},{"./lump":20}],26:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Shop(raw, parent) {
	this.straightCopy = [
		'Id',
		'Name',
		'Description',
		'Image',
		'Ordering'
	];
	Lump.apply(this, arguments);

	this.availabilities = null;
	this.unlockCost = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Shop.prototype[member] = Lump.prototype[member]; });

Shop.prototype.wireUp = function(theApi) {

	api = theApi;

	this.availabilities = new Clump(this.attribs.Availabilities || [], api.types.Availability, this);

	Lump.prototype.wireUp.call(this);
};

Shop.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Shop.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.availabilities) {

					var child_elements = self.availabilities.toDom("normal", true);

					child_elements.classList.add("child-list");
					element.appendChild(child_elements);
				}
			}
		});
	}

	return element;
};

module.exports = Shop;
},{"./clump":15,"./lump":20}],27:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function SpawnedEntity(raw, parent) {
	this.straightCopy = [
		'Name',
		'HumanName',

		'Neutral',
		'PrefabName',
		'DormantBehaviour',
		'AwareBehaviour',

		'Hull',
		'Crew',
		'Life',
		'MovementSpeed',
		'RotationSpeed',
		'BeastieCharacteristicsName',
		'CombatItems',
		'LootPrefabName',
		'GleamValue'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.pacifyEvent = null;
	this.killQualityEvent = null;
	this.combatAttackNames = [];

	this.image = null;
}
Object.keys(Lump.prototype).forEach(function(member) { SpawnedEntity.prototype[member] = Lump.prototype[member]; });

SpawnedEntity.prototype.wireUp = function(theApi) {

	api = theApi;

	var self = this;
	
	this.combatAttackNames = (this.attribs.CombatAttackNames || []).map(function(name) {
		return api.get(api.types.CombatAttack, name, self);
	}).filter(function(attack) {
		return typeof attack === "object";
	});

	this.pacifyEvent = api.get(api.types.Event, this.attribs.PacifyEventId, this);
	if(this.pacifyEvent) {
		this.pacifyEvent.tag = "pacified";
	}

	this.killQualityEvent = api.get(api.types.Event, this.attribs.KillQualityEventId, this);
	if(this.killQualityEvent) {
		this.killQualityEvent.tag = "killed";
	}

	this.image = ((this.killQualityEvent && this.killQualityEvent.Image) || (this.pacifyEvent && this.pacifyEvent.Image));

	Lump.prototype.wireUp.call(this, api);
};

SpawnedEntity.prototype.toString = function() {
	return this.constructor.name + " " + this.HumanName + " (#" + this.Id + ")";
};

SpawnedEntity.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var self = this;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.HumanName+"</h3>";

	if(size !== "small") {
		if(this.qualitiesRequired) {
			html += "<div class='sidebar'>";
			html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
			html += "</div>";
		}

		html += "<dl class='clump-list small'>";

		['Hull', 'Crew', 'Life', 'MovementSpeed', 'RotationSpeed'].forEach(function(key) {
			html += "<dt class='item'>"+key+"</dt><dd class='quantity'>"+self[key]+"</dd>";
		});
		html += "</dl>";
	}

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = SpawnedEntity;
},{"./clump":15,"./lump":20}],28:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');
var Port = require('./port');
var Area = require('./area');

var api;

function TileVariant(raw, parent) {
	this.straightCopy = [
		'Name',
		'HumanName',
		'Description',

		'MaxTilePopulation',
		'MinTilePopulation',
		
		'SeaColour',
		'MusicTrackName',
		'ChanceOfWeather',
		'FogRevealThreshold'
	];

/*
LabelData: Array[6]
PhenomenaData: Array[1]
SpawnPoints: Array[2]
TerrainData: Array[14]
Weather: Array[1]
*/

	raw.Id = parent.Name+"/"+raw.Name;
	Lump.apply(this, arguments);

	this.SettingId = raw.Setting.Id;
	this.setting = null;

	this.ports = new Clump(this.attribs.PortData || [], Port, this);

	this.areas = null;
}
Object.keys(Lump.prototype).forEach(function(member) { TileVariant.prototype[member] = Lump.prototype[member]; });

TileVariant.prototype.wireUp = function(theApi) {

	api = theApi;

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);

	this.ports.forEach(function(p) { p.wireUp(api); });

	// Also create a list of all the areas of each of the ports in this object for convenience
	this.areas = new Clump(this.ports.map(function(p) { return p.area; }), api.types.Area, this);

	Lump.prototype.wireUp.call(this);
};

TileVariant.prototype.toString = function(long) {
	return this.constructor.name + " " + this.HumanName + " (#" + this.Name + ")";
};

TileVariant.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.HumanName+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = TileVariant;
},{"./area":13,"./clump":15,"./lump":20,"./port":21}],29:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');
var TileVariant = require('./tile-variant');
var Port = require('./port');
var Area = require('./area');

var api;

function Tile(raw, parent) {
	this.straightCopy = [
		'Name'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.tileVariants = new Clump(this.attribs.Tiles || [], TileVariant, this);
}
Object.keys(Lump.prototype).forEach(function(member) { Tile.prototype[member] = Lump.prototype[member]; });

Tile.prototype.wireUp = function(theApi) {

	api = theApi;

	this.tileVariants.forEach(function(tv) { tv.wireUp(api); });

	// Also create a list of all the ports and areas of each of the tilevariants in this object for convenience
	var all_ports = {};
	var all_areas = {};
	this.tileVariants.forEach(function(tv) {
		tv.ports.forEach(function(p) {
			all_ports[p.Id] = p;
			all_areas[p.area.Id] = p.area;
		});
	});
	this.ports = new Clump(Object.keys(all_ports).map(function(p) { return all_ports[p]; }), api.types.Port, this);
	this.areas = new Clump(Object.keys(all_areas).map(function(a) { return all_areas[a]; }), api.types.Area, this);

	Lump.prototype.wireUp.call(this);
};

Tile.prototype.toString = function(long) {
	return this.constructor.name + " " + this.Name + " (#" + this.Name + ")";
};

Tile.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Name+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Tile;
},{"./area":13,"./clump":15,"./lump":20,"./port":21,"./tile-variant":28}],30:[function(require,module,exports){
var api = require('./api');
var dragndrop = require('./ui/dragndrop');
var query = require('./ui/query');


$("#tabs .buttons li").on("click", function(e) {

  var type = $(this).attr("data-type");

  $("#tabs .panes .pane").hide(); // Hide all panes
  $("#tabs .buttons li").removeClass("active"); // Deactivate all buttons

  $("#tabs .panes ."+type.toLowerCase()).show();
  $("#tabs .buttons [data-type="+type+"]").addClass("active");
});

// Setup the dnd listeners.
var dropZone = document.getElementById('drop-zone');

dropZone.addEventListener('dragenter', dragndrop.handlers.dragOver, false);
dropZone.addEventListener('dragleave', dragndrop.handlers.dragEnd, false);
dropZone.addEventListener('dragover', dragndrop.handlers.dragOver, false);

dropZone.addEventListener('drop', dragndrop.handlers.dragDrop, false);

document.getElementById('paths-to-node').addEventListener('click', query.pathsToNodeUI, false);

// For convenience
window.api = api;
window.api.query = query;
},{"./api":10,"./ui/dragndrop":31,"./ui/query":32}],31:[function(require,module,exports){
var api = require('../api');
var Clump = require('../objects/clump');
var io = require('../io');

var render = require('./render');

function handleDragOver(evt) {
  evt.stopPropagation();
  evt.preventDefault();

  $("#drop-zone").addClass("drop-target");
}

function handleDragEnd(evt) {
  evt.stopPropagation();
  evt.preventDefault();

  $("#drop-zone").removeClass("drop-target");
}

function handleDragDrop(evt) {

  $("#drop-zone").removeClass("drop-target");

  evt.stopPropagation();
  evt.preventDefault();

  var files = evt.dataTransfer.files; // FileList object.

  // Files is a FileList of File objects. List some properties.
  var output = [];
  io.resetFilesToLoad();
  for (var i = 0; i < files.length; i++) {
    var f = files[i];
    var filename = escape(f.name);
    var typeName = io.fileObjectMap[filename];
    var Type = api.types[typeName];
    if(Type) {
      io.incrementFilesToLoad();
      api.readFromFile(Type, f, function() {
        io.decrementFilesToLoad();

        if(io.countFilesToLoad() === 0) {
          api.wireUpObjects();
          render.lists();
        }
      });
      output.push('<li><strong>', escape(f.name), '</strong> (', f.type || 'n/a', ') - ',
                f.size, ' bytes, last modified: ',
                f.lastModifiedDate ? f.lastModifiedDate.toLocaleDateString() : 'n/a',
                '</li>');
    }
    else {
      output.push('<li>ERROR: No handler for file <strong>' , escape(f.name), '</strong></li>');
    }
  }
  document.getElementById('list').innerHTML = '<ul>' + output.join('') + '</ul>';
}

module.exports = {
	handlers: {
		dragOver: handleDragOver,
		dragEnd: handleDragEnd,
		dragDrop: handleDragDrop
	}
};
},{"../api":10,"../io":11,"../objects/clump":15,"./render":33}],32:[function(require,module,exports){
var api = require('../api');
var Clump = require('../objects/clump');

function RouteNode(node) {
  this.node = node;
  this.children = [];
}

function pathsToNodeUI() {

  var type = document.getElementById('type');
  type = type.options[type.selectedIndex].value;

  var operation = document.getElementById('operation');
  operation = operation.options[operation.selectedIndex].value;

  var id = prompt("Id of "+type);

  if(!id) {  // Cancelled dialogue
    return;
  }

  var item = api.library[type].id(id);

  if(!item) {
    alert("Could not find "+type+" "+id);
    return;
  }

  var root = document.getElementById("query-tree");
  root.innerHTML = "";

  var title = $('.pane.query .pane-title').text("Query: "+item.toString());

  var routes = pathsToNode(item, {});

  if(routes && routes.children.length) {

    routes = filterPathsToNode(routes, operation);

    var top_children = document.createElement("ul");
    top_children.className += "clump-list small";

    routes.children.forEach(function(child_route) {
      var tree = renderPathsToNode(child_route, []);
      top_children.appendChild(tree);
    });

    root.appendChild(top_children);
  }
  else {
    alert("This "+type+" is a root node with no parents that satisfy the conditions");
  }
  
}

function pathsToNode(node, seen, parent) {

  if(seen[node.Id]) {   // Don't recurse into nodes we've already seen
    return false;
  }

  var ancestry = JSON.parse(JSON.stringify(seen));
  ancestry[node.Id] = true;

  var this_node = new RouteNode(/*node.linkToEvent ? node.linkToEvent :*/ node); // If this node is just a link to another one, skip over the useless link

  if(node instanceof api.types.SpawnedEntity) {
    return this_node;   // Leaf node in tree
  }
  else if(node instanceof api.types.Event && node.tag === "use") {
    return this_node;   // Leaf node in tree
  }
  else if(node instanceof api.types.Event && parent instanceof api.types.Event && (parent.tag === "killed" || parent.tag === "pacified")) { // If this is an event that's reachable by killing a monster, don't recurse any other causes (as they're usually misleading/circular)
    return false;
  }
  else if(node instanceof api.types.Setting) {
    return false;
  }
  else if (node instanceof api.types.Port) {
    return new RouteNode(node.area);
  }
  else if(node.limitedToArea && node.limitedToArea.Id !== 101956) {
    var area_name = node.limitedToArea.Name.toLowerCase();
    var event_name = (node.Name && node.Name.toLowerCase()) || "";
    if(area_name.indexOf(event_name) !== -1 || event_name.indexOf(area_name) !== -1) {  // If Area has similar name to Event, ignore the event and just substitute the area
      return new RouteNode(node.limitedToArea);
    }
    else {
      this_node.children.push(new RouteNode(node.limitedToArea));   // Else include both the Area and the Event
      return this_node;
    }
    
  }
  else {
    for(var i=0; i<node.parents.length; i++) {
      var the_parent = node.parents[i];
      var subtree = pathsToNode(the_parent, ancestry, node);
      if(subtree) {
        this_node.children.push(subtree);
      }
    }
    if(!this_node.children.length) {
      return false;
    }
  }

  return this_node;
}

function filterPathsToNode(routes, operation) {
  // Filter routes by operation
  if(routes && routes.children && operation !== "any") {
    routes.children = routes.children.filter(function(route_node) {

      lump = route_node.node;

      if(operation === "additive") {
        return lump.isOneOf([api.types.QualityEffect, api.types.Availability]) && lump.isAdditive();
      }
      else if(operation === "subtractive") {
        return lump.isOneOf([api.types.QualityEffect, api.types.Availability]) && lump.isSubtractive();
      }
    });
  }

  return routes;
}

function renderPathsToNode(routeNode, ancestry) {
  
  if(!(routeNode instanceof RouteNode)) {
    return null;
  }

  var element = routeNode.node.toDom("small", false);
  
  var child_list = document.createElement("ul");
  child_list.className += "clump-list small child-list";

  var new_ancestry = ancestry.slice();
  new_ancestry.push(routeNode.node);
  routeNode.children.forEach(function(child_route, index, children) {
    var child_content = renderPathsToNode(child_route, new_ancestry);
    child_list.appendChild(child_content);
  });

  if(routeNode.children.length) {
    element.appendChild(child_list);
  }
  else {
    var description = document.createElement("li");
    description.innerHTML = '<span class="route-description">HINT: ' + describeRoute(new_ancestry) + '</span>';

    var reqsTitle = document.createElement('h5');
    reqsTitle.innerHTML = "Requirements";
    description.appendChild(reqsTitle);

    var total_requirements = getRouteRequirements(new_ancestry);
    
    description.appendChild(total_requirements.toDom("small", false));
    element.appendChild(description);
  }

  return element;
}

function lower(text) {
  return text.slice(0,1).toLowerCase()+text.slice(1);
}

function describeRoute(ancestry) {
  var a = ancestry.slice().reverse();

  var guide = "";
  if(a[0] instanceof api.types.Area) {
    if(a[1] instanceof api.types.Event) {
      guide = "Seek "+a[1].Name+" in "+a[0].Name;
      if(a[2] instanceof api.types.Interaction) {
        guide += " and ";
        if("\"'".indexOf(a[2].Name[0]) !== -1) {
          guide += "exclaim ";
        }
        guide += lower(a[2].Name);
      }
      guide += ".";
    }
    else {
      guide = "Travel to "+a[0].Name;

      if(a[1] instanceof api.types.Interaction) {
        guide += " and "+lower(a[1].Name);
      }
      else if(a[1] instanceof api.types.Exchange && a[2] instanceof api.types.Shop) {
        guide += " and look for the "+a[2].Name+" Emporium in "+a[1].Name;
      }

      guide += ".";
    }
  }
  else if(a[0] instanceof api.types.SpawnedEntity) {
    guide = "Find and best a "+a[0].HumanName;
    if(a[2] instanceof api.types.Interaction) {
      guide += ", then " + lower(a[2].Name);
    }
    guide += ".";
  }
  else if(a[0] instanceof api.types.Event && a[0].tag === "use" && !(a[1] instanceof api.types.QualityRequirement)) {
    if(a[0].Name.match(/^\s*Speak/i)) {
      guide = a[0].Name;
    }
    else if(a[0].Name.match(/^\s*A/i)) {
      guide = "Acquire "+lower(a[0].Name);
    }
    else {
      guide = "Find a "+lower(a[0].Name);
    }
    guide += " and " + lower(a[1].Name) + ".";
  }

  return guide;
}

function detailRoute(ancestry) {
  var a = ancestry.slice().reverse();

  var guide = "";
  if(a[0] instanceof api.types.Area) {
    if(a[1] instanceof api.types.Event) {
      guide = "You must travel to "+a[0].Name+" and look for "+a[1].Name+".";
      if(a[2] instanceof api.types.Interaction) {
        guide += "  When you find it you should ";
        if("\"'".indexOf(a[2].Name[0]) !== -1) {
          guide += "say ";
        }
        guide += lower(a[2].Name);
      }
      guide += ".";
    }
    else {
      guide = "Make for "+a[0].Name;

      if(a[1] instanceof api.types.Interaction) {
        guide += " and "+lower(a[1].Name);
      }
      else if(a[1] instanceof api.types.Exchange && a[2] instanceof api.types.Shop) {
        guide += ".  Upon arrival go to "+a[1].Name+", and look for the shop "+a[2].Names;
      }

      guide += ".";
    }
  }
  else if(a[0] instanceof api.types.SpawnedEntity) {
    guide = "You must hunt the mythical zee-peril known as the "+a[0].HumanName+", engage it in battle and defeat it.";
    if(a[2] instanceof api.types.Interaction) {
      guide += "  Once you have conquered it you must " + lower(a[2].Name) + " to help secure your prize.";
    }
  }
  else if(a[0] instanceof api.types.Event && a[0].tag === "use" && !(a[1] instanceof api.types.QualityRequirement)) {
    if(a[0].Name.match(/^\s*Speak/i)) {
      guide = "First you must "+lower(a[0].Name);
    }
    else if(a[0].Name.match(/^\s*A/i)) {
      guide = "Source "+lower(a[0].Name);
    }
    else {
      guide = "Try to locate a "+lower(a[0].Name);
    }
    guide += ", and then " + lower(a[1].Name) + ".";
  }

  return guide;
}

function getRouteRequirements(ancestry) {

  var reqs = {};

  // Ancestry is ordered from last->first, so iterate backwards from final effect -> initial cause
  ancestry.forEach(function(step) {
    /* Simplification: if an event modifies a quality then assume that later requirements
    on the same quality are probably satisfied by that modification (eg, when qualities
    are incremented/decremented to control story-quest progress). */
    if(step.qualitiesAffected) {
      step.qualitiesAffected.forEach(function(effect) {
        delete(reqs[effect.associatedQuality.Id]);
      });
    }
    // Now add any requirements for the current stage (earlier requirements overwrite later ones on the same quality)
    if(step.qualitiesRequired) {
      step.qualitiesRequired.forEach(function(req) {
        if(req.associatedQuality) { // Check this is a valid QualityRequirement, and not one of the half-finished debug elements referring to anon-existant Quality
          reqs[req.associatedQuality.Id] = req;
        }
      });
    }
  });

  var result = Object.keys(reqs).map(function(key) { return reqs[key]; });

  return new Clump(result, api.types.QualityRequirement);
}

module.exports = {
  RouteNode: RouteNode,
  pathsToNodeUI: pathsToNodeUI,
  pathsToNode: pathsToNode,
  filterPathsToNode: filterPathsToNode,
  renderPathsToNode: renderPathsToNode,
  describeRoute: describeRoute,
  detailRoute: detailRoute,
  getRouteRequirements: getRouteRequirements
};
},{"../api":10,"../objects/clump":15}],33:[function(require,module,exports){
var api = require('../api');

function renderLists() {
  Object.keys(api.loaded).forEach(function(type) {
    renderList(api.loaded[type]); // Only display directly loaded (root-level) Lumps, to prevent the list becoming unwieldy
  });
}

function renderList(clump) {
	var root = document.getElementById(clump.type.name.toLowerCase()+"-list");
  if(root) {
	 root.appendChild(clump.toDom());
  }
}

module.exports = {
	list: renderList,
	lists: renderLists
};
},{"../api":10}]},{},[10,11,12,30])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJjb25maWcuanNvbiIsIm5vZGVfbW9kdWxlcy9iYXNlNjQtanMvaW5kZXguanMiLCJub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9saWIvX2VtcHR5LmpzIiwibm9kZV9tb2R1bGVzL2J1ZmZlci9pbmRleC5qcyIsIm5vZGVfbW9kdWxlcy9ldmVudHMvZXZlbnRzLmpzIiwibm9kZV9tb2R1bGVzL2ZpbGVyZWFkZXIvRmlsZVJlYWRlci5qcyIsIm5vZGVfbW9kdWxlcy9pZWVlNzU0L2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL2lzYXJyYXkvaW5kZXguanMiLCJub2RlX21vZHVsZXMvcHJvY2Vzcy9icm93c2VyLmpzIiwic3JjL3NjcmlwdHMvYXBpLmpzIiwic3JjL3NjcmlwdHMvaW8uanMiLCJzcmMvc2NyaXB0cy9saWJyYXJ5LmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9hcmVhLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9hdmFpbGFiaWxpdHkuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL2NsdW1wLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9jb21iYXQtYXR0YWNrLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9ldmVudC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvZXhjaGFuZ2UuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL2ludGVyYWN0aW9uLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9sdW1wLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9wb3J0LmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9xdWFsaXR5LWVmZmVjdC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvcXVhbGl0eS1yZXF1aXJlbWVudC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvcXVhbGl0eS5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvc2V0dGluZy5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvc2hvcC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvc3Bhd25lZC1lbnRpdHkuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3RpbGUtdmFyaWFudC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvdGlsZS5qcyIsInNyYy9zY3JpcHRzL3VpLmpzIiwic3JjL3NjcmlwdHMvdWkvZHJhZ25kcm9wLmpzIiwic3JjL3NjcmlwdHMvdWkvcXVlcnkuanMiLCJzcmMvc2NyaXB0cy91aS9yZW5kZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN4QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbEhBOzs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FDN3ZEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQzlTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQzVTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3SUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzQ0E7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25GQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMUhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNUZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzVHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzVFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeklBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0VBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9EQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeFRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIm1vZHVsZS5leHBvcnRzPXtcblx0XCJ0aXRsZVwiOiBcIlN1bmxlc3MgU2VhXCIsXG5cdFwicGF0aHNcIjoge1xuXHRcdFwidGVtcGxhdGVzXCI6IFwic3JjL3RlbXBsYXRlc1wiLFxuXHRcdFwibW9kR2FtZUpzb25cIjogXCJidWlsZC9tb2R0b29scy9nYW1lLWRhdGEvanNvblwiLFxuXHRcdFwiYnVpbGRkaXJcIjoge1xuXHRcdFx0XCJtb2RcIjogXCJidWlsZC9jbG9ja3dvcmFjbGUvZW50aXRpZXNcIixcblx0XHRcdFwidWlcIjogXCJidWlsZC9tb2R0b29sc1wiXG5cdFx0fVxuXHR9LFxuXHRcImxvY2F0aW9uc1wiOiB7XG5cdFx0XCJpbWFnZXNQYXRoXCI6IFwiZ2FtZS1kYXRhL2ljb25zXCJcblx0fSxcblx0XCJiYXNlR2FtZUlkc1wiOiB7XG5cdFx0XCJxdWFsaXR5XCI6IDUwMDAwMCxcblx0XHRcInByZWxpbUV2ZW50XCI6IDUwMDAxMCxcblx0XHRcImJ1eU9yYWNsZVwiOiA1MDAwMDIwLFxuXHRcdFwic2VsbE9yYWNsZVwiOiA1MDAwMzAsXG5cdFx0XCJldmVudFwiOiA1MDAwMzUsXG5cdFx0XCJhY3F1aXJlXCI6IDYwMDAwMCxcblx0XHRcImxlYXJuXCI6IDcwMDAwMCxcblx0XHRcInN1ZmZlclwiOiA4MDAwMDAsXG5cdFx0XCJiZWNvbWVcIjogOTAwMDAwXG5cdH1cbn0iLCIndXNlIHN0cmljdCdcblxuZXhwb3J0cy5ieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aFxuZXhwb3J0cy50b0J5dGVBcnJheSA9IHRvQnl0ZUFycmF5XG5leHBvcnRzLmZyb21CeXRlQXJyYXkgPSBmcm9tQnl0ZUFycmF5XG5cbnZhciBsb29rdXAgPSBbXVxudmFyIHJldkxvb2t1cCA9IFtdXG52YXIgQXJyID0gdHlwZW9mIFVpbnQ4QXJyYXkgIT09ICd1bmRlZmluZWQnID8gVWludDhBcnJheSA6IEFycmF5XG5cbnZhciBjb2RlID0gJ0FCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5Ky8nXG5mb3IgKHZhciBpID0gMCwgbGVuID0gY29kZS5sZW5ndGg7IGkgPCBsZW47ICsraSkge1xuICBsb29rdXBbaV0gPSBjb2RlW2ldXG4gIHJldkxvb2t1cFtjb2RlLmNoYXJDb2RlQXQoaSldID0gaVxufVxuXG5yZXZMb29rdXBbJy0nLmNoYXJDb2RlQXQoMCldID0gNjJcbnJldkxvb2t1cFsnXycuY2hhckNvZGVBdCgwKV0gPSA2M1xuXG5mdW5jdGlvbiBwbGFjZUhvbGRlcnNDb3VudCAoYjY0KSB7XG4gIHZhciBsZW4gPSBiNjQubGVuZ3RoXG4gIGlmIChsZW4gJSA0ID4gMCkge1xuICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBzdHJpbmcuIExlbmd0aCBtdXN0IGJlIGEgbXVsdGlwbGUgb2YgNCcpXG4gIH1cblxuICAvLyB0aGUgbnVtYmVyIG9mIGVxdWFsIHNpZ25zIChwbGFjZSBob2xkZXJzKVxuICAvLyBpZiB0aGVyZSBhcmUgdHdvIHBsYWNlaG9sZGVycywgdGhhbiB0aGUgdHdvIGNoYXJhY3RlcnMgYmVmb3JlIGl0XG4gIC8vIHJlcHJlc2VudCBvbmUgYnl0ZVxuICAvLyBpZiB0aGVyZSBpcyBvbmx5IG9uZSwgdGhlbiB0aGUgdGhyZWUgY2hhcmFjdGVycyBiZWZvcmUgaXQgcmVwcmVzZW50IDIgYnl0ZXNcbiAgLy8gdGhpcyBpcyBqdXN0IGEgY2hlYXAgaGFjayB0byBub3QgZG8gaW5kZXhPZiB0d2ljZVxuICByZXR1cm4gYjY0W2xlbiAtIDJdID09PSAnPScgPyAyIDogYjY0W2xlbiAtIDFdID09PSAnPScgPyAxIDogMFxufVxuXG5mdW5jdGlvbiBieXRlTGVuZ3RoIChiNjQpIHtcbiAgLy8gYmFzZTY0IGlzIDQvMyArIHVwIHRvIHR3byBjaGFyYWN0ZXJzIG9mIHRoZSBvcmlnaW5hbCBkYXRhXG4gIHJldHVybiBiNjQubGVuZ3RoICogMyAvIDQgLSBwbGFjZUhvbGRlcnNDb3VudChiNjQpXG59XG5cbmZ1bmN0aW9uIHRvQnl0ZUFycmF5IChiNjQpIHtcbiAgdmFyIGksIGosIGwsIHRtcCwgcGxhY2VIb2xkZXJzLCBhcnJcbiAgdmFyIGxlbiA9IGI2NC5sZW5ndGhcbiAgcGxhY2VIb2xkZXJzID0gcGxhY2VIb2xkZXJzQ291bnQoYjY0KVxuXG4gIGFyciA9IG5ldyBBcnIobGVuICogMyAvIDQgLSBwbGFjZUhvbGRlcnMpXG5cbiAgLy8gaWYgdGhlcmUgYXJlIHBsYWNlaG9sZGVycywgb25seSBnZXQgdXAgdG8gdGhlIGxhc3QgY29tcGxldGUgNCBjaGFyc1xuICBsID0gcGxhY2VIb2xkZXJzID4gMCA/IGxlbiAtIDQgOiBsZW5cblxuICB2YXIgTCA9IDBcblxuICBmb3IgKGkgPSAwLCBqID0gMDsgaSA8IGw7IGkgKz0gNCwgaiArPSAzKSB7XG4gICAgdG1wID0gKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpKV0gPDwgMTgpIHwgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpICsgMSldIDw8IDEyKSB8IChyZXZMb29rdXBbYjY0LmNoYXJDb2RlQXQoaSArIDIpXSA8PCA2KSB8IHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpICsgMyldXG4gICAgYXJyW0wrK10gPSAodG1wID4+IDE2KSAmIDB4RkZcbiAgICBhcnJbTCsrXSA9ICh0bXAgPj4gOCkgJiAweEZGXG4gICAgYXJyW0wrK10gPSB0bXAgJiAweEZGXG4gIH1cblxuICBpZiAocGxhY2VIb2xkZXJzID09PSAyKSB7XG4gICAgdG1wID0gKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpKV0gPDwgMikgfCAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAxKV0gPj4gNClcbiAgICBhcnJbTCsrXSA9IHRtcCAmIDB4RkZcbiAgfSBlbHNlIGlmIChwbGFjZUhvbGRlcnMgPT09IDEpIHtcbiAgICB0bXAgPSAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkpXSA8PCAxMCkgfCAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAxKV0gPDwgNCkgfCAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAyKV0gPj4gMilcbiAgICBhcnJbTCsrXSA9ICh0bXAgPj4gOCkgJiAweEZGXG4gICAgYXJyW0wrK10gPSB0bXAgJiAweEZGXG4gIH1cblxuICByZXR1cm4gYXJyXG59XG5cbmZ1bmN0aW9uIHRyaXBsZXRUb0Jhc2U2NCAobnVtKSB7XG4gIHJldHVybiBsb29rdXBbbnVtID4+IDE4ICYgMHgzRl0gKyBsb29rdXBbbnVtID4+IDEyICYgMHgzRl0gKyBsb29rdXBbbnVtID4+IDYgJiAweDNGXSArIGxvb2t1cFtudW0gJiAweDNGXVxufVxuXG5mdW5jdGlvbiBlbmNvZGVDaHVuayAodWludDgsIHN0YXJ0LCBlbmQpIHtcbiAgdmFyIHRtcFxuICB2YXIgb3V0cHV0ID0gW11cbiAgZm9yICh2YXIgaSA9IHN0YXJ0OyBpIDwgZW5kOyBpICs9IDMpIHtcbiAgICB0bXAgPSAodWludDhbaV0gPDwgMTYpICsgKHVpbnQ4W2kgKyAxXSA8PCA4KSArICh1aW50OFtpICsgMl0pXG4gICAgb3V0cHV0LnB1c2godHJpcGxldFRvQmFzZTY0KHRtcCkpXG4gIH1cbiAgcmV0dXJuIG91dHB1dC5qb2luKCcnKVxufVxuXG5mdW5jdGlvbiBmcm9tQnl0ZUFycmF5ICh1aW50OCkge1xuICB2YXIgdG1wXG4gIHZhciBsZW4gPSB1aW50OC5sZW5ndGhcbiAgdmFyIGV4dHJhQnl0ZXMgPSBsZW4gJSAzIC8vIGlmIHdlIGhhdmUgMSBieXRlIGxlZnQsIHBhZCAyIGJ5dGVzXG4gIHZhciBvdXRwdXQgPSAnJ1xuICB2YXIgcGFydHMgPSBbXVxuICB2YXIgbWF4Q2h1bmtMZW5ndGggPSAxNjM4MyAvLyBtdXN0IGJlIG11bHRpcGxlIG9mIDNcblxuICAvLyBnbyB0aHJvdWdoIHRoZSBhcnJheSBldmVyeSB0aHJlZSBieXRlcywgd2UnbGwgZGVhbCB3aXRoIHRyYWlsaW5nIHN0dWZmIGxhdGVyXG4gIGZvciAodmFyIGkgPSAwLCBsZW4yID0gbGVuIC0gZXh0cmFCeXRlczsgaSA8IGxlbjI7IGkgKz0gbWF4Q2h1bmtMZW5ndGgpIHtcbiAgICBwYXJ0cy5wdXNoKGVuY29kZUNodW5rKHVpbnQ4LCBpLCAoaSArIG1heENodW5rTGVuZ3RoKSA+IGxlbjIgPyBsZW4yIDogKGkgKyBtYXhDaHVua0xlbmd0aCkpKVxuICB9XG5cbiAgLy8gcGFkIHRoZSBlbmQgd2l0aCB6ZXJvcywgYnV0IG1ha2Ugc3VyZSB0byBub3QgZm9yZ2V0IHRoZSBleHRyYSBieXRlc1xuICBpZiAoZXh0cmFCeXRlcyA9PT0gMSkge1xuICAgIHRtcCA9IHVpbnQ4W2xlbiAtIDFdXG4gICAgb3V0cHV0ICs9IGxvb2t1cFt0bXAgPj4gMl1cbiAgICBvdXRwdXQgKz0gbG9va3VwWyh0bXAgPDwgNCkgJiAweDNGXVxuICAgIG91dHB1dCArPSAnPT0nXG4gIH0gZWxzZSBpZiAoZXh0cmFCeXRlcyA9PT0gMikge1xuICAgIHRtcCA9ICh1aW50OFtsZW4gLSAyXSA8PCA4KSArICh1aW50OFtsZW4gLSAxXSlcbiAgICBvdXRwdXQgKz0gbG9va3VwW3RtcCA+PiAxMF1cbiAgICBvdXRwdXQgKz0gbG9va3VwWyh0bXAgPj4gNCkgJiAweDNGXVxuICAgIG91dHB1dCArPSBsb29rdXBbKHRtcCA8PCAyKSAmIDB4M0ZdXG4gICAgb3V0cHV0ICs9ICc9J1xuICB9XG5cbiAgcGFydHMucHVzaChvdXRwdXQpXG5cbiAgcmV0dXJuIHBhcnRzLmpvaW4oJycpXG59XG4iLCIiLCIvKiFcbiAqIFRoZSBidWZmZXIgbW9kdWxlIGZyb20gbm9kZS5qcywgZm9yIHRoZSBicm93c2VyLlxuICpcbiAqIEBhdXRob3IgICBGZXJvc3MgQWJvdWtoYWRpamVoIDxmZXJvc3NAZmVyb3NzLm9yZz4gPGh0dHA6Ly9mZXJvc3Mub3JnPlxuICogQGxpY2Vuc2UgIE1JVFxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBuby1wcm90byAqL1xuXG4ndXNlIHN0cmljdCdcblxudmFyIGJhc2U2NCA9IHJlcXVpcmUoJ2Jhc2U2NC1qcycpXG52YXIgaWVlZTc1NCA9IHJlcXVpcmUoJ2llZWU3NTQnKVxudmFyIGlzQXJyYXkgPSByZXF1aXJlKCdpc2FycmF5JylcblxuZXhwb3J0cy5CdWZmZXIgPSBCdWZmZXJcbmV4cG9ydHMuU2xvd0J1ZmZlciA9IFNsb3dCdWZmZXJcbmV4cG9ydHMuSU5TUEVDVF9NQVhfQllURVMgPSA1MFxuXG4vKipcbiAqIElmIGBCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVGA6XG4gKiAgID09PSB0cnVlICAgIFVzZSBVaW50OEFycmF5IGltcGxlbWVudGF0aW9uIChmYXN0ZXN0KVxuICogICA9PT0gZmFsc2UgICBVc2UgT2JqZWN0IGltcGxlbWVudGF0aW9uIChtb3N0IGNvbXBhdGlibGUsIGV2ZW4gSUU2KVxuICpcbiAqIEJyb3dzZXJzIHRoYXQgc3VwcG9ydCB0eXBlZCBhcnJheXMgYXJlIElFIDEwKywgRmlyZWZveCA0KywgQ2hyb21lIDcrLCBTYWZhcmkgNS4xKyxcbiAqIE9wZXJhIDExLjYrLCBpT1MgNC4yKy5cbiAqXG4gKiBEdWUgdG8gdmFyaW91cyBicm93c2VyIGJ1Z3MsIHNvbWV0aW1lcyB0aGUgT2JqZWN0IGltcGxlbWVudGF0aW9uIHdpbGwgYmUgdXNlZCBldmVuXG4gKiB3aGVuIHRoZSBicm93c2VyIHN1cHBvcnRzIHR5cGVkIGFycmF5cy5cbiAqXG4gKiBOb3RlOlxuICpcbiAqICAgLSBGaXJlZm94IDQtMjkgbGFja3Mgc3VwcG9ydCBmb3IgYWRkaW5nIG5ldyBwcm9wZXJ0aWVzIHRvIGBVaW50OEFycmF5YCBpbnN0YW5jZXMsXG4gKiAgICAgU2VlOiBodHRwczovL2J1Z3ppbGxhLm1vemlsbGEub3JnL3Nob3dfYnVnLmNnaT9pZD02OTU0MzguXG4gKlxuICogICAtIENocm9tZSA5LTEwIGlzIG1pc3NpbmcgdGhlIGBUeXBlZEFycmF5LnByb3RvdHlwZS5zdWJhcnJheWAgZnVuY3Rpb24uXG4gKlxuICogICAtIElFMTAgaGFzIGEgYnJva2VuIGBUeXBlZEFycmF5LnByb3RvdHlwZS5zdWJhcnJheWAgZnVuY3Rpb24gd2hpY2ggcmV0dXJucyBhcnJheXMgb2ZcbiAqICAgICBpbmNvcnJlY3QgbGVuZ3RoIGluIHNvbWUgc2l0dWF0aW9ucy5cblxuICogV2UgZGV0ZWN0IHRoZXNlIGJ1Z2d5IGJyb3dzZXJzIGFuZCBzZXQgYEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUYCB0byBgZmFsc2VgIHNvIHRoZXlcbiAqIGdldCB0aGUgT2JqZWN0IGltcGxlbWVudGF0aW9uLCB3aGljaCBpcyBzbG93ZXIgYnV0IGJlaGF2ZXMgY29ycmVjdGx5LlxuICovXG5CdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCA9IGdsb2JhbC5UWVBFRF9BUlJBWV9TVVBQT1JUICE9PSB1bmRlZmluZWRcbiAgPyBnbG9iYWwuVFlQRURfQVJSQVlfU1VQUE9SVFxuICA6IHR5cGVkQXJyYXlTdXBwb3J0KClcblxuLypcbiAqIEV4cG9ydCBrTWF4TGVuZ3RoIGFmdGVyIHR5cGVkIGFycmF5IHN1cHBvcnQgaXMgZGV0ZXJtaW5lZC5cbiAqL1xuZXhwb3J0cy5rTWF4TGVuZ3RoID0ga01heExlbmd0aCgpXG5cbmZ1bmN0aW9uIHR5cGVkQXJyYXlTdXBwb3J0ICgpIHtcbiAgdHJ5IHtcbiAgICB2YXIgYXJyID0gbmV3IFVpbnQ4QXJyYXkoMSlcbiAgICBhcnIuX19wcm90b19fID0ge19fcHJvdG9fXzogVWludDhBcnJheS5wcm90b3R5cGUsIGZvbzogZnVuY3Rpb24gKCkgeyByZXR1cm4gNDIgfX1cbiAgICByZXR1cm4gYXJyLmZvbygpID09PSA0MiAmJiAvLyB0eXBlZCBhcnJheSBpbnN0YW5jZXMgY2FuIGJlIGF1Z21lbnRlZFxuICAgICAgICB0eXBlb2YgYXJyLnN1YmFycmF5ID09PSAnZnVuY3Rpb24nICYmIC8vIGNocm9tZSA5LTEwIGxhY2sgYHN1YmFycmF5YFxuICAgICAgICBhcnIuc3ViYXJyYXkoMSwgMSkuYnl0ZUxlbmd0aCA9PT0gMCAvLyBpZTEwIGhhcyBicm9rZW4gYHN1YmFycmF5YFxuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cbn1cblxuZnVuY3Rpb24ga01heExlbmd0aCAoKSB7XG4gIHJldHVybiBCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVFxuICAgID8gMHg3ZmZmZmZmZlxuICAgIDogMHgzZmZmZmZmZlxufVxuXG5mdW5jdGlvbiBjcmVhdGVCdWZmZXIgKHRoYXQsIGxlbmd0aCkge1xuICBpZiAoa01heExlbmd0aCgpIDwgbGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0ludmFsaWQgdHlwZWQgYXJyYXkgbGVuZ3RoJylcbiAgfVxuICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICAvLyBSZXR1cm4gYW4gYXVnbWVudGVkIGBVaW50OEFycmF5YCBpbnN0YW5jZSwgZm9yIGJlc3QgcGVyZm9ybWFuY2VcbiAgICB0aGF0ID0gbmV3IFVpbnQ4QXJyYXkobGVuZ3RoKVxuICAgIHRoYXQuX19wcm90b19fID0gQnVmZmVyLnByb3RvdHlwZVxuICB9IGVsc2Uge1xuICAgIC8vIEZhbGxiYWNrOiBSZXR1cm4gYW4gb2JqZWN0IGluc3RhbmNlIG9mIHRoZSBCdWZmZXIgY2xhc3NcbiAgICBpZiAodGhhdCA9PT0gbnVsbCkge1xuICAgICAgdGhhdCA9IG5ldyBCdWZmZXIobGVuZ3RoKVxuICAgIH1cbiAgICB0aGF0Lmxlbmd0aCA9IGxlbmd0aFxuICB9XG5cbiAgcmV0dXJuIHRoYXRcbn1cblxuLyoqXG4gKiBUaGUgQnVmZmVyIGNvbnN0cnVjdG9yIHJldHVybnMgaW5zdGFuY2VzIG9mIGBVaW50OEFycmF5YCB0aGF0IGhhdmUgdGhlaXJcbiAqIHByb3RvdHlwZSBjaGFuZ2VkIHRvIGBCdWZmZXIucHJvdG90eXBlYC4gRnVydGhlcm1vcmUsIGBCdWZmZXJgIGlzIGEgc3ViY2xhc3Mgb2ZcbiAqIGBVaW50OEFycmF5YCwgc28gdGhlIHJldHVybmVkIGluc3RhbmNlcyB3aWxsIGhhdmUgYWxsIHRoZSBub2RlIGBCdWZmZXJgIG1ldGhvZHNcbiAqIGFuZCB0aGUgYFVpbnQ4QXJyYXlgIG1ldGhvZHMuIFNxdWFyZSBicmFja2V0IG5vdGF0aW9uIHdvcmtzIGFzIGV4cGVjdGVkIC0tIGl0XG4gKiByZXR1cm5zIGEgc2luZ2xlIG9jdGV0LlxuICpcbiAqIFRoZSBgVWludDhBcnJheWAgcHJvdG90eXBlIHJlbWFpbnMgdW5tb2RpZmllZC5cbiAqL1xuXG5mdW5jdGlvbiBCdWZmZXIgKGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKSB7XG4gIGlmICghQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQgJiYgISh0aGlzIGluc3RhbmNlb2YgQnVmZmVyKSkge1xuICAgIHJldHVybiBuZXcgQnVmZmVyKGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKVxuICB9XG5cbiAgLy8gQ29tbW9uIGNhc2UuXG4gIGlmICh0eXBlb2YgYXJnID09PSAnbnVtYmVyJykge1xuICAgIGlmICh0eXBlb2YgZW5jb2RpbmdPck9mZnNldCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ0lmIGVuY29kaW5nIGlzIHNwZWNpZmllZCB0aGVuIHRoZSBmaXJzdCBhcmd1bWVudCBtdXN0IGJlIGEgc3RyaW5nJ1xuICAgICAgKVxuICAgIH1cbiAgICByZXR1cm4gYWxsb2NVbnNhZmUodGhpcywgYXJnKVxuICB9XG4gIHJldHVybiBmcm9tKHRoaXMsIGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKVxufVxuXG5CdWZmZXIucG9vbFNpemUgPSA4MTkyIC8vIG5vdCB1c2VkIGJ5IHRoaXMgaW1wbGVtZW50YXRpb25cblxuLy8gVE9ETzogTGVnYWN5LCBub3QgbmVlZGVkIGFueW1vcmUuIFJlbW92ZSBpbiBuZXh0IG1ham9yIHZlcnNpb24uXG5CdWZmZXIuX2F1Z21lbnQgPSBmdW5jdGlvbiAoYXJyKSB7XG4gIGFyci5fX3Byb3RvX18gPSBCdWZmZXIucHJvdG90eXBlXG4gIHJldHVybiBhcnJcbn1cblxuZnVuY3Rpb24gZnJvbSAodGhhdCwgdmFsdWUsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1widmFsdWVcIiBhcmd1bWVudCBtdXN0IG5vdCBiZSBhIG51bWJlcicpXG4gIH1cblxuICBpZiAodHlwZW9mIEFycmF5QnVmZmVyICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSB7XG4gICAgcmV0dXJuIGZyb21BcnJheUJ1ZmZlcih0aGF0LCB2YWx1ZSwgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKVxuICB9XG5cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gZnJvbVN0cmluZyh0aGF0LCB2YWx1ZSwgZW5jb2RpbmdPck9mZnNldClcbiAgfVxuXG4gIHJldHVybiBmcm9tT2JqZWN0KHRoYXQsIHZhbHVlKVxufVxuXG4vKipcbiAqIEZ1bmN0aW9uYWxseSBlcXVpdmFsZW50IHRvIEJ1ZmZlcihhcmcsIGVuY29kaW5nKSBidXQgdGhyb3dzIGEgVHlwZUVycm9yXG4gKiBpZiB2YWx1ZSBpcyBhIG51bWJlci5cbiAqIEJ1ZmZlci5mcm9tKHN0clssIGVuY29kaW5nXSlcbiAqIEJ1ZmZlci5mcm9tKGFycmF5KVxuICogQnVmZmVyLmZyb20oYnVmZmVyKVxuICogQnVmZmVyLmZyb20oYXJyYXlCdWZmZXJbLCBieXRlT2Zmc2V0WywgbGVuZ3RoXV0pXG4gKiovXG5CdWZmZXIuZnJvbSA9IGZ1bmN0aW9uICh2YWx1ZSwgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKSB7XG4gIHJldHVybiBmcm9tKG51bGwsIHZhbHVlLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpXG59XG5cbmlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICBCdWZmZXIucHJvdG90eXBlLl9fcHJvdG9fXyA9IFVpbnQ4QXJyYXkucHJvdG90eXBlXG4gIEJ1ZmZlci5fX3Byb3RvX18gPSBVaW50OEFycmF5XG4gIGlmICh0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wuc3BlY2llcyAmJlxuICAgICAgQnVmZmVyW1N5bWJvbC5zcGVjaWVzXSA9PT0gQnVmZmVyKSB7XG4gICAgLy8gRml4IHN1YmFycmF5KCkgaW4gRVMyMDE2LiBTZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9mZXJvc3MvYnVmZmVyL3B1bGwvOTdcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQnVmZmVyLCBTeW1ib2wuc3BlY2llcywge1xuICAgICAgdmFsdWU6IG51bGwsXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KVxuICB9XG59XG5cbmZ1bmN0aW9uIGFzc2VydFNpemUgKHNpemUpIHtcbiAgaWYgKHR5cGVvZiBzaXplICE9PSAnbnVtYmVyJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wic2l6ZVwiIGFyZ3VtZW50IG11c3QgYmUgYSBudW1iZXInKVxuICB9IGVsc2UgaWYgKHNpemUgPCAwKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1wic2l6ZVwiIGFyZ3VtZW50IG11c3Qgbm90IGJlIG5lZ2F0aXZlJylcbiAgfVxufVxuXG5mdW5jdGlvbiBhbGxvYyAodGhhdCwgc2l6ZSwgZmlsbCwgZW5jb2RpbmcpIHtcbiAgYXNzZXJ0U2l6ZShzaXplKVxuICBpZiAoc2l6ZSA8PSAwKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUJ1ZmZlcih0aGF0LCBzaXplKVxuICB9XG4gIGlmIChmaWxsICE9PSB1bmRlZmluZWQpIHtcbiAgICAvLyBPbmx5IHBheSBhdHRlbnRpb24gdG8gZW5jb2RpbmcgaWYgaXQncyBhIHN0cmluZy4gVGhpc1xuICAgIC8vIHByZXZlbnRzIGFjY2lkZW50YWxseSBzZW5kaW5nIGluIGEgbnVtYmVyIHRoYXQgd291bGRcbiAgICAvLyBiZSBpbnRlcnByZXR0ZWQgYXMgYSBzdGFydCBvZmZzZXQuXG4gICAgcmV0dXJuIHR5cGVvZiBlbmNvZGluZyA9PT0gJ3N0cmluZydcbiAgICAgID8gY3JlYXRlQnVmZmVyKHRoYXQsIHNpemUpLmZpbGwoZmlsbCwgZW5jb2RpbmcpXG4gICAgICA6IGNyZWF0ZUJ1ZmZlcih0aGF0LCBzaXplKS5maWxsKGZpbGwpXG4gIH1cbiAgcmV0dXJuIGNyZWF0ZUJ1ZmZlcih0aGF0LCBzaXplKVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgZmlsbGVkIEJ1ZmZlciBpbnN0YW5jZS5cbiAqIGFsbG9jKHNpemVbLCBmaWxsWywgZW5jb2RpbmddXSlcbiAqKi9cbkJ1ZmZlci5hbGxvYyA9IGZ1bmN0aW9uIChzaXplLCBmaWxsLCBlbmNvZGluZykge1xuICByZXR1cm4gYWxsb2MobnVsbCwgc2l6ZSwgZmlsbCwgZW5jb2RpbmcpXG59XG5cbmZ1bmN0aW9uIGFsbG9jVW5zYWZlICh0aGF0LCBzaXplKSB7XG4gIGFzc2VydFNpemUoc2l6ZSlcbiAgdGhhdCA9IGNyZWF0ZUJ1ZmZlcih0aGF0LCBzaXplIDwgMCA/IDAgOiBjaGVja2VkKHNpemUpIHwgMClcbiAgaWYgKCFCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2l6ZTsgKytpKSB7XG4gICAgICB0aGF0W2ldID0gMFxuICAgIH1cbiAgfVxuICByZXR1cm4gdGhhdFxufVxuXG4vKipcbiAqIEVxdWl2YWxlbnQgdG8gQnVmZmVyKG51bSksIGJ5IGRlZmF1bHQgY3JlYXRlcyBhIG5vbi16ZXJvLWZpbGxlZCBCdWZmZXIgaW5zdGFuY2UuXG4gKiAqL1xuQnVmZmVyLmFsbG9jVW5zYWZlID0gZnVuY3Rpb24gKHNpemUpIHtcbiAgcmV0dXJuIGFsbG9jVW5zYWZlKG51bGwsIHNpemUpXG59XG4vKipcbiAqIEVxdWl2YWxlbnQgdG8gU2xvd0J1ZmZlcihudW0pLCBieSBkZWZhdWx0IGNyZWF0ZXMgYSBub24temVyby1maWxsZWQgQnVmZmVyIGluc3RhbmNlLlxuICovXG5CdWZmZXIuYWxsb2NVbnNhZmVTbG93ID0gZnVuY3Rpb24gKHNpemUpIHtcbiAgcmV0dXJuIGFsbG9jVW5zYWZlKG51bGwsIHNpemUpXG59XG5cbmZ1bmN0aW9uIGZyb21TdHJpbmcgKHRoYXQsIHN0cmluZywgZW5jb2RpbmcpIHtcbiAgaWYgKHR5cGVvZiBlbmNvZGluZyAhPT0gJ3N0cmluZycgfHwgZW5jb2RpbmcgPT09ICcnKSB7XG4gICAgZW5jb2RpbmcgPSAndXRmOCdcbiAgfVxuXG4gIGlmICghQnVmZmVyLmlzRW5jb2RpbmcoZW5jb2RpbmcpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignXCJlbmNvZGluZ1wiIG11c3QgYmUgYSB2YWxpZCBzdHJpbmcgZW5jb2RpbmcnKVxuICB9XG5cbiAgdmFyIGxlbmd0aCA9IGJ5dGVMZW5ndGgoc3RyaW5nLCBlbmNvZGluZykgfCAwXG4gIHRoYXQgPSBjcmVhdGVCdWZmZXIodGhhdCwgbGVuZ3RoKVxuXG4gIHZhciBhY3R1YWwgPSB0aGF0LndyaXRlKHN0cmluZywgZW5jb2RpbmcpXG5cbiAgaWYgKGFjdHVhbCAhPT0gbGVuZ3RoKSB7XG4gICAgLy8gV3JpdGluZyBhIGhleCBzdHJpbmcsIGZvciBleGFtcGxlLCB0aGF0IGNvbnRhaW5zIGludmFsaWQgY2hhcmFjdGVycyB3aWxsXG4gICAgLy8gY2F1c2UgZXZlcnl0aGluZyBhZnRlciB0aGUgZmlyc3QgaW52YWxpZCBjaGFyYWN0ZXIgdG8gYmUgaWdub3JlZC4gKGUuZy5cbiAgICAvLyAnYWJ4eGNkJyB3aWxsIGJlIHRyZWF0ZWQgYXMgJ2FiJylcbiAgICB0aGF0ID0gdGhhdC5zbGljZSgwLCBhY3R1YWwpXG4gIH1cblxuICByZXR1cm4gdGhhdFxufVxuXG5mdW5jdGlvbiBmcm9tQXJyYXlMaWtlICh0aGF0LCBhcnJheSkge1xuICB2YXIgbGVuZ3RoID0gYXJyYXkubGVuZ3RoIDwgMCA/IDAgOiBjaGVja2VkKGFycmF5Lmxlbmd0aCkgfCAwXG4gIHRoYXQgPSBjcmVhdGVCdWZmZXIodGhhdCwgbGVuZ3RoKVxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSArPSAxKSB7XG4gICAgdGhhdFtpXSA9IGFycmF5W2ldICYgMjU1XG4gIH1cbiAgcmV0dXJuIHRoYXRcbn1cblxuZnVuY3Rpb24gZnJvbUFycmF5QnVmZmVyICh0aGF0LCBhcnJheSwgYnl0ZU9mZnNldCwgbGVuZ3RoKSB7XG4gIGFycmF5LmJ5dGVMZW5ndGggLy8gdGhpcyB0aHJvd3MgaWYgYGFycmF5YCBpcyBub3QgYSB2YWxpZCBBcnJheUJ1ZmZlclxuXG4gIGlmIChieXRlT2Zmc2V0IDwgMCB8fCBhcnJheS5ieXRlTGVuZ3RoIDwgYnl0ZU9mZnNldCkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdcXCdvZmZzZXRcXCcgaXMgb3V0IG9mIGJvdW5kcycpXG4gIH1cblxuICBpZiAoYXJyYXkuYnl0ZUxlbmd0aCA8IGJ5dGVPZmZzZXQgKyAobGVuZ3RoIHx8IDApKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1xcJ2xlbmd0aFxcJyBpcyBvdXQgb2YgYm91bmRzJylcbiAgfVxuXG4gIGlmIChieXRlT2Zmc2V0ID09PSB1bmRlZmluZWQgJiYgbGVuZ3RoID09PSB1bmRlZmluZWQpIHtcbiAgICBhcnJheSA9IG5ldyBVaW50OEFycmF5KGFycmF5KVxuICB9IGVsc2UgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgYXJyYXkgPSBuZXcgVWludDhBcnJheShhcnJheSwgYnl0ZU9mZnNldClcbiAgfSBlbHNlIHtcbiAgICBhcnJheSA9IG5ldyBVaW50OEFycmF5KGFycmF5LCBieXRlT2Zmc2V0LCBsZW5ndGgpXG4gIH1cblxuICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICAvLyBSZXR1cm4gYW4gYXVnbWVudGVkIGBVaW50OEFycmF5YCBpbnN0YW5jZSwgZm9yIGJlc3QgcGVyZm9ybWFuY2VcbiAgICB0aGF0ID0gYXJyYXlcbiAgICB0aGF0Ll9fcHJvdG9fXyA9IEJ1ZmZlci5wcm90b3R5cGVcbiAgfSBlbHNlIHtcbiAgICAvLyBGYWxsYmFjazogUmV0dXJuIGFuIG9iamVjdCBpbnN0YW5jZSBvZiB0aGUgQnVmZmVyIGNsYXNzXG4gICAgdGhhdCA9IGZyb21BcnJheUxpa2UodGhhdCwgYXJyYXkpXG4gIH1cbiAgcmV0dXJuIHRoYXRcbn1cblxuZnVuY3Rpb24gZnJvbU9iamVjdCAodGhhdCwgb2JqKSB7XG4gIGlmIChCdWZmZXIuaXNCdWZmZXIob2JqKSkge1xuICAgIHZhciBsZW4gPSBjaGVja2VkKG9iai5sZW5ndGgpIHwgMFxuICAgIHRoYXQgPSBjcmVhdGVCdWZmZXIodGhhdCwgbGVuKVxuXG4gICAgaWYgKHRoYXQubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gdGhhdFxuICAgIH1cblxuICAgIG9iai5jb3B5KHRoYXQsIDAsIDAsIGxlbilcbiAgICByZXR1cm4gdGhhdFxuICB9XG5cbiAgaWYgKG9iaikge1xuICAgIGlmICgodHlwZW9mIEFycmF5QnVmZmVyICE9PSAndW5kZWZpbmVkJyAmJlxuICAgICAgICBvYmouYnVmZmVyIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHx8ICdsZW5ndGgnIGluIG9iaikge1xuICAgICAgaWYgKHR5cGVvZiBvYmoubGVuZ3RoICE9PSAnbnVtYmVyJyB8fCBpc25hbihvYmoubGVuZ3RoKSkge1xuICAgICAgICByZXR1cm4gY3JlYXRlQnVmZmVyKHRoYXQsIDApXG4gICAgICB9XG4gICAgICByZXR1cm4gZnJvbUFycmF5TGlrZSh0aGF0LCBvYmopXG4gICAgfVxuXG4gICAgaWYgKG9iai50eXBlID09PSAnQnVmZmVyJyAmJiBpc0FycmF5KG9iai5kYXRhKSkge1xuICAgICAgcmV0dXJuIGZyb21BcnJheUxpa2UodGhhdCwgb2JqLmRhdGEpXG4gICAgfVxuICB9XG5cbiAgdGhyb3cgbmV3IFR5cGVFcnJvcignRmlyc3QgYXJndW1lbnQgbXVzdCBiZSBhIHN0cmluZywgQnVmZmVyLCBBcnJheUJ1ZmZlciwgQXJyYXksIG9yIGFycmF5LWxpa2Ugb2JqZWN0LicpXG59XG5cbmZ1bmN0aW9uIGNoZWNrZWQgKGxlbmd0aCkge1xuICAvLyBOb3RlOiBjYW5ub3QgdXNlIGBsZW5ndGggPCBrTWF4TGVuZ3RoKClgIGhlcmUgYmVjYXVzZSB0aGF0IGZhaWxzIHdoZW5cbiAgLy8gbGVuZ3RoIGlzIE5hTiAod2hpY2ggaXMgb3RoZXJ3aXNlIGNvZXJjZWQgdG8gemVyby4pXG4gIGlmIChsZW5ndGggPj0ga01heExlbmd0aCgpKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0F0dGVtcHQgdG8gYWxsb2NhdGUgQnVmZmVyIGxhcmdlciB0aGFuIG1heGltdW0gJyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgJ3NpemU6IDB4JyArIGtNYXhMZW5ndGgoKS50b1N0cmluZygxNikgKyAnIGJ5dGVzJylcbiAgfVxuICByZXR1cm4gbGVuZ3RoIHwgMFxufVxuXG5mdW5jdGlvbiBTbG93QnVmZmVyIChsZW5ndGgpIHtcbiAgaWYgKCtsZW5ndGggIT0gbGVuZ3RoKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgZXFlcWVxXG4gICAgbGVuZ3RoID0gMFxuICB9XG4gIHJldHVybiBCdWZmZXIuYWxsb2MoK2xlbmd0aClcbn1cblxuQnVmZmVyLmlzQnVmZmVyID0gZnVuY3Rpb24gaXNCdWZmZXIgKGIpIHtcbiAgcmV0dXJuICEhKGIgIT0gbnVsbCAmJiBiLl9pc0J1ZmZlcilcbn1cblxuQnVmZmVyLmNvbXBhcmUgPSBmdW5jdGlvbiBjb21wYXJlIChhLCBiKSB7XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGEpIHx8ICFCdWZmZXIuaXNCdWZmZXIoYikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudHMgbXVzdCBiZSBCdWZmZXJzJylcbiAgfVxuXG4gIGlmIChhID09PSBiKSByZXR1cm4gMFxuXG4gIHZhciB4ID0gYS5sZW5ndGhcbiAgdmFyIHkgPSBiLmxlbmd0aFxuXG4gIGZvciAodmFyIGkgPSAwLCBsZW4gPSBNYXRoLm1pbih4LCB5KTsgaSA8IGxlbjsgKytpKSB7XG4gICAgaWYgKGFbaV0gIT09IGJbaV0pIHtcbiAgICAgIHggPSBhW2ldXG4gICAgICB5ID0gYltpXVxuICAgICAgYnJlYWtcbiAgICB9XG4gIH1cblxuICBpZiAoeCA8IHkpIHJldHVybiAtMVxuICBpZiAoeSA8IHgpIHJldHVybiAxXG4gIHJldHVybiAwXG59XG5cbkJ1ZmZlci5pc0VuY29kaW5nID0gZnVuY3Rpb24gaXNFbmNvZGluZyAoZW5jb2RpbmcpIHtcbiAgc3dpdGNoIChTdHJpbmcoZW5jb2RpbmcpLnRvTG93ZXJDYXNlKCkpIHtcbiAgICBjYXNlICdoZXgnOlxuICAgIGNhc2UgJ3V0ZjgnOlxuICAgIGNhc2UgJ3V0Zi04JzpcbiAgICBjYXNlICdhc2NpaSc6XG4gICAgY2FzZSAnbGF0aW4xJzpcbiAgICBjYXNlICdiaW5hcnknOlxuICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgY2FzZSAndWNzMic6XG4gICAgY2FzZSAndWNzLTInOlxuICAgIGNhc2UgJ3V0ZjE2bGUnOlxuICAgIGNhc2UgJ3V0Zi0xNmxlJzpcbiAgICAgIHJldHVybiB0cnVlXG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBmYWxzZVxuICB9XG59XG5cbkJ1ZmZlci5jb25jYXQgPSBmdW5jdGlvbiBjb25jYXQgKGxpc3QsIGxlbmd0aCkge1xuICBpZiAoIWlzQXJyYXkobGlzdCkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdcImxpc3RcIiBhcmd1bWVudCBtdXN0IGJlIGFuIEFycmF5IG9mIEJ1ZmZlcnMnKVxuICB9XG5cbiAgaWYgKGxpc3QubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIEJ1ZmZlci5hbGxvYygwKVxuICB9XG5cbiAgdmFyIGlcbiAgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgbGVuZ3RoID0gMFxuICAgIGZvciAoaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgKytpKSB7XG4gICAgICBsZW5ndGggKz0gbGlzdFtpXS5sZW5ndGhcbiAgICB9XG4gIH1cblxuICB2YXIgYnVmZmVyID0gQnVmZmVyLmFsbG9jVW5zYWZlKGxlbmd0aClcbiAgdmFyIHBvcyA9IDBcbiAgZm9yIChpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyArK2kpIHtcbiAgICB2YXIgYnVmID0gbGlzdFtpXVxuICAgIGlmICghQnVmZmVyLmlzQnVmZmVyKGJ1ZikpIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wibGlzdFwiIGFyZ3VtZW50IG11c3QgYmUgYW4gQXJyYXkgb2YgQnVmZmVycycpXG4gICAgfVxuICAgIGJ1Zi5jb3B5KGJ1ZmZlciwgcG9zKVxuICAgIHBvcyArPSBidWYubGVuZ3RoXG4gIH1cbiAgcmV0dXJuIGJ1ZmZlclxufVxuXG5mdW5jdGlvbiBieXRlTGVuZ3RoIChzdHJpbmcsIGVuY29kaW5nKSB7XG4gIGlmIChCdWZmZXIuaXNCdWZmZXIoc3RyaW5nKSkge1xuICAgIHJldHVybiBzdHJpbmcubGVuZ3RoXG4gIH1cbiAgaWYgKHR5cGVvZiBBcnJheUJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIEFycmF5QnVmZmVyLmlzVmlldyA9PT0gJ2Z1bmN0aW9uJyAmJlxuICAgICAgKEFycmF5QnVmZmVyLmlzVmlldyhzdHJpbmcpIHx8IHN0cmluZyBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSkge1xuICAgIHJldHVybiBzdHJpbmcuYnl0ZUxlbmd0aFxuICB9XG4gIGlmICh0eXBlb2Ygc3RyaW5nICE9PSAnc3RyaW5nJykge1xuICAgIHN0cmluZyA9ICcnICsgc3RyaW5nXG4gIH1cblxuICB2YXIgbGVuID0gc3RyaW5nLmxlbmd0aFxuICBpZiAobGVuID09PSAwKSByZXR1cm4gMFxuXG4gIC8vIFVzZSBhIGZvciBsb29wIHRvIGF2b2lkIHJlY3Vyc2lvblxuICB2YXIgbG93ZXJlZENhc2UgPSBmYWxzZVxuICBmb3IgKDs7KSB7XG4gICAgc3dpdGNoIChlbmNvZGluZykge1xuICAgICAgY2FzZSAnYXNjaWknOlxuICAgICAgY2FzZSAnbGF0aW4xJzpcbiAgICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICAgIHJldHVybiBsZW5cbiAgICAgIGNhc2UgJ3V0ZjgnOlxuICAgICAgY2FzZSAndXRmLTgnOlxuICAgICAgY2FzZSB1bmRlZmluZWQ6XG4gICAgICAgIHJldHVybiB1dGY4VG9CeXRlcyhzdHJpbmcpLmxlbmd0aFxuICAgICAgY2FzZSAndWNzMic6XG4gICAgICBjYXNlICd1Y3MtMic6XG4gICAgICBjYXNlICd1dGYxNmxlJzpcbiAgICAgIGNhc2UgJ3V0Zi0xNmxlJzpcbiAgICAgICAgcmV0dXJuIGxlbiAqIDJcbiAgICAgIGNhc2UgJ2hleCc6XG4gICAgICAgIHJldHVybiBsZW4gPj4+IDFcbiAgICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgICAgIHJldHVybiBiYXNlNjRUb0J5dGVzKHN0cmluZykubGVuZ3RoXG4gICAgICBkZWZhdWx0OlxuICAgICAgICBpZiAobG93ZXJlZENhc2UpIHJldHVybiB1dGY4VG9CeXRlcyhzdHJpbmcpLmxlbmd0aCAvLyBhc3N1bWUgdXRmOFxuICAgICAgICBlbmNvZGluZyA9ICgnJyArIGVuY29kaW5nKS50b0xvd2VyQ2FzZSgpXG4gICAgICAgIGxvd2VyZWRDYXNlID0gdHJ1ZVxuICAgIH1cbiAgfVxufVxuQnVmZmVyLmJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoXG5cbmZ1bmN0aW9uIHNsb3dUb1N0cmluZyAoZW5jb2RpbmcsIHN0YXJ0LCBlbmQpIHtcbiAgdmFyIGxvd2VyZWRDYXNlID0gZmFsc2VcblxuICAvLyBObyBuZWVkIHRvIHZlcmlmeSB0aGF0IFwidGhpcy5sZW5ndGggPD0gTUFYX1VJTlQzMlwiIHNpbmNlIGl0J3MgYSByZWFkLW9ubHlcbiAgLy8gcHJvcGVydHkgb2YgYSB0eXBlZCBhcnJheS5cblxuICAvLyBUaGlzIGJlaGF2ZXMgbmVpdGhlciBsaWtlIFN0cmluZyBub3IgVWludDhBcnJheSBpbiB0aGF0IHdlIHNldCBzdGFydC9lbmRcbiAgLy8gdG8gdGhlaXIgdXBwZXIvbG93ZXIgYm91bmRzIGlmIHRoZSB2YWx1ZSBwYXNzZWQgaXMgb3V0IG9mIHJhbmdlLlxuICAvLyB1bmRlZmluZWQgaXMgaGFuZGxlZCBzcGVjaWFsbHkgYXMgcGVyIEVDTUEtMjYyIDZ0aCBFZGl0aW9uLFxuICAvLyBTZWN0aW9uIDEzLjMuMy43IFJ1bnRpbWUgU2VtYW50aWNzOiBLZXllZEJpbmRpbmdJbml0aWFsaXphdGlvbi5cbiAgaWYgKHN0YXJ0ID09PSB1bmRlZmluZWQgfHwgc3RhcnQgPCAwKSB7XG4gICAgc3RhcnQgPSAwXG4gIH1cbiAgLy8gUmV0dXJuIGVhcmx5IGlmIHN0YXJ0ID4gdGhpcy5sZW5ndGguIERvbmUgaGVyZSB0byBwcmV2ZW50IHBvdGVudGlhbCB1aW50MzJcbiAgLy8gY29lcmNpb24gZmFpbCBiZWxvdy5cbiAgaWYgKHN0YXJ0ID4gdGhpcy5sZW5ndGgpIHtcbiAgICByZXR1cm4gJydcbiAgfVxuXG4gIGlmIChlbmQgPT09IHVuZGVmaW5lZCB8fCBlbmQgPiB0aGlzLmxlbmd0aCkge1xuICAgIGVuZCA9IHRoaXMubGVuZ3RoXG4gIH1cblxuICBpZiAoZW5kIDw9IDApIHtcbiAgICByZXR1cm4gJydcbiAgfVxuXG4gIC8vIEZvcmNlIGNvZXJzaW9uIHRvIHVpbnQzMi4gVGhpcyB3aWxsIGFsc28gY29lcmNlIGZhbHNleS9OYU4gdmFsdWVzIHRvIDAuXG4gIGVuZCA+Pj49IDBcbiAgc3RhcnQgPj4+PSAwXG5cbiAgaWYgKGVuZCA8PSBzdGFydCkge1xuICAgIHJldHVybiAnJ1xuICB9XG5cbiAgaWYgKCFlbmNvZGluZykgZW5jb2RpbmcgPSAndXRmOCdcblxuICB3aGlsZSAodHJ1ZSkge1xuICAgIHN3aXRjaCAoZW5jb2RpbmcpIHtcbiAgICAgIGNhc2UgJ2hleCc6XG4gICAgICAgIHJldHVybiBoZXhTbGljZSh0aGlzLCBzdGFydCwgZW5kKVxuXG4gICAgICBjYXNlICd1dGY4JzpcbiAgICAgIGNhc2UgJ3V0Zi04JzpcbiAgICAgICAgcmV0dXJuIHV0ZjhTbGljZSh0aGlzLCBzdGFydCwgZW5kKVxuXG4gICAgICBjYXNlICdhc2NpaSc6XG4gICAgICAgIHJldHVybiBhc2NpaVNsaWNlKHRoaXMsIHN0YXJ0LCBlbmQpXG5cbiAgICAgIGNhc2UgJ2xhdGluMSc6XG4gICAgICBjYXNlICdiaW5hcnknOlxuICAgICAgICByZXR1cm4gbGF0aW4xU2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgY2FzZSAnYmFzZTY0JzpcbiAgICAgICAgcmV0dXJuIGJhc2U2NFNsaWNlKHRoaXMsIHN0YXJ0LCBlbmQpXG5cbiAgICAgIGNhc2UgJ3VjczInOlxuICAgICAgY2FzZSAndWNzLTInOlxuICAgICAgY2FzZSAndXRmMTZsZSc6XG4gICAgICBjYXNlICd1dGYtMTZsZSc6XG4gICAgICAgIHJldHVybiB1dGYxNmxlU2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaWYgKGxvd2VyZWRDYXNlKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jb2RpbmcpXG4gICAgICAgIGVuY29kaW5nID0gKGVuY29kaW5nICsgJycpLnRvTG93ZXJDYXNlKClcbiAgICAgICAgbG93ZXJlZENhc2UgPSB0cnVlXG4gICAgfVxuICB9XG59XG5cbi8vIFRoZSBwcm9wZXJ0eSBpcyB1c2VkIGJ5IGBCdWZmZXIuaXNCdWZmZXJgIGFuZCBgaXMtYnVmZmVyYCAoaW4gU2FmYXJpIDUtNykgdG8gZGV0ZWN0XG4vLyBCdWZmZXIgaW5zdGFuY2VzLlxuQnVmZmVyLnByb3RvdHlwZS5faXNCdWZmZXIgPSB0cnVlXG5cbmZ1bmN0aW9uIHN3YXAgKGIsIG4sIG0pIHtcbiAgdmFyIGkgPSBiW25dXG4gIGJbbl0gPSBiW21dXG4gIGJbbV0gPSBpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuc3dhcDE2ID0gZnVuY3Rpb24gc3dhcDE2ICgpIHtcbiAgdmFyIGxlbiA9IHRoaXMubGVuZ3RoXG4gIGlmIChsZW4gJSAyICE9PSAwKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0J1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiAxNi1iaXRzJylcbiAgfVxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSArPSAyKSB7XG4gICAgc3dhcCh0aGlzLCBpLCBpICsgMSlcbiAgfVxuICByZXR1cm4gdGhpc1xufVxuXG5CdWZmZXIucHJvdG90eXBlLnN3YXAzMiA9IGZ1bmN0aW9uIHN3YXAzMiAoKSB7XG4gIHZhciBsZW4gPSB0aGlzLmxlbmd0aFxuICBpZiAobGVuICUgNCAhPT0gMCkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdCdWZmZXIgc2l6ZSBtdXN0IGJlIGEgbXVsdGlwbGUgb2YgMzItYml0cycpXG4gIH1cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkgKz0gNCkge1xuICAgIHN3YXAodGhpcywgaSwgaSArIDMpXG4gICAgc3dhcCh0aGlzLCBpICsgMSwgaSArIDIpXG4gIH1cbiAgcmV0dXJuIHRoaXNcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5zd2FwNjQgPSBmdW5jdGlvbiBzd2FwNjQgKCkge1xuICB2YXIgbGVuID0gdGhpcy5sZW5ndGhcbiAgaWYgKGxlbiAlIDggIT09IDApIHtcbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignQnVmZmVyIHNpemUgbXVzdCBiZSBhIG11bHRpcGxlIG9mIDY0LWJpdHMnKVxuICB9XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpICs9IDgpIHtcbiAgICBzd2FwKHRoaXMsIGksIGkgKyA3KVxuICAgIHN3YXAodGhpcywgaSArIDEsIGkgKyA2KVxuICAgIHN3YXAodGhpcywgaSArIDIsIGkgKyA1KVxuICAgIHN3YXAodGhpcywgaSArIDMsIGkgKyA0KVxuICB9XG4gIHJldHVybiB0aGlzXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbiB0b1N0cmluZyAoKSB7XG4gIHZhciBsZW5ndGggPSB0aGlzLmxlbmd0aCB8IDBcbiAgaWYgKGxlbmd0aCA9PT0gMCkgcmV0dXJuICcnXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAwKSByZXR1cm4gdXRmOFNsaWNlKHRoaXMsIDAsIGxlbmd0aClcbiAgcmV0dXJuIHNsb3dUb1N0cmluZy5hcHBseSh0aGlzLCBhcmd1bWVudHMpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuZXF1YWxzID0gZnVuY3Rpb24gZXF1YWxzIChiKSB7XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IGJlIGEgQnVmZmVyJylcbiAgaWYgKHRoaXMgPT09IGIpIHJldHVybiB0cnVlXG4gIHJldHVybiBCdWZmZXIuY29tcGFyZSh0aGlzLCBiKSA9PT0gMFxufVxuXG5CdWZmZXIucHJvdG90eXBlLmluc3BlY3QgPSBmdW5jdGlvbiBpbnNwZWN0ICgpIHtcbiAgdmFyIHN0ciA9ICcnXG4gIHZhciBtYXggPSBleHBvcnRzLklOU1BFQ1RfTUFYX0JZVEVTXG4gIGlmICh0aGlzLmxlbmd0aCA+IDApIHtcbiAgICBzdHIgPSB0aGlzLnRvU3RyaW5nKCdoZXgnLCAwLCBtYXgpLm1hdGNoKC8uezJ9L2cpLmpvaW4oJyAnKVxuICAgIGlmICh0aGlzLmxlbmd0aCA+IG1heCkgc3RyICs9ICcgLi4uICdcbiAgfVxuICByZXR1cm4gJzxCdWZmZXIgJyArIHN0ciArICc+J1xufVxuXG5CdWZmZXIucHJvdG90eXBlLmNvbXBhcmUgPSBmdW5jdGlvbiBjb21wYXJlICh0YXJnZXQsIHN0YXJ0LCBlbmQsIHRoaXNTdGFydCwgdGhpc0VuZCkge1xuICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcih0YXJnZXQpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJndW1lbnQgbXVzdCBiZSBhIEJ1ZmZlcicpXG4gIH1cblxuICBpZiAoc3RhcnQgPT09IHVuZGVmaW5lZCkge1xuICAgIHN0YXJ0ID0gMFxuICB9XG4gIGlmIChlbmQgPT09IHVuZGVmaW5lZCkge1xuICAgIGVuZCA9IHRhcmdldCA/IHRhcmdldC5sZW5ndGggOiAwXG4gIH1cbiAgaWYgKHRoaXNTdGFydCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhpc1N0YXJ0ID0gMFxuICB9XG4gIGlmICh0aGlzRW5kID09PSB1bmRlZmluZWQpIHtcbiAgICB0aGlzRW5kID0gdGhpcy5sZW5ndGhcbiAgfVxuXG4gIGlmIChzdGFydCA8IDAgfHwgZW5kID4gdGFyZ2V0Lmxlbmd0aCB8fCB0aGlzU3RhcnQgPCAwIHx8IHRoaXNFbmQgPiB0aGlzLmxlbmd0aCkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdvdXQgb2YgcmFuZ2UgaW5kZXgnKVxuICB9XG5cbiAgaWYgKHRoaXNTdGFydCA+PSB0aGlzRW5kICYmIHN0YXJ0ID49IGVuZCkge1xuICAgIHJldHVybiAwXG4gIH1cbiAgaWYgKHRoaXNTdGFydCA+PSB0aGlzRW5kKSB7XG4gICAgcmV0dXJuIC0xXG4gIH1cbiAgaWYgKHN0YXJ0ID49IGVuZCkge1xuICAgIHJldHVybiAxXG4gIH1cblxuICBzdGFydCA+Pj49IDBcbiAgZW5kID4+Pj0gMFxuICB0aGlzU3RhcnQgPj4+PSAwXG4gIHRoaXNFbmQgPj4+PSAwXG5cbiAgaWYgKHRoaXMgPT09IHRhcmdldCkgcmV0dXJuIDBcblxuICB2YXIgeCA9IHRoaXNFbmQgLSB0aGlzU3RhcnRcbiAgdmFyIHkgPSBlbmQgLSBzdGFydFxuICB2YXIgbGVuID0gTWF0aC5taW4oeCwgeSlcblxuICB2YXIgdGhpc0NvcHkgPSB0aGlzLnNsaWNlKHRoaXNTdGFydCwgdGhpc0VuZClcbiAgdmFyIHRhcmdldENvcHkgPSB0YXJnZXQuc2xpY2Uoc3RhcnQsIGVuZClcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgKytpKSB7XG4gICAgaWYgKHRoaXNDb3B5W2ldICE9PSB0YXJnZXRDb3B5W2ldKSB7XG4gICAgICB4ID0gdGhpc0NvcHlbaV1cbiAgICAgIHkgPSB0YXJnZXRDb3B5W2ldXG4gICAgICBicmVha1xuICAgIH1cbiAgfVxuXG4gIGlmICh4IDwgeSkgcmV0dXJuIC0xXG4gIGlmICh5IDwgeCkgcmV0dXJuIDFcbiAgcmV0dXJuIDBcbn1cblxuLy8gRmluZHMgZWl0aGVyIHRoZSBmaXJzdCBpbmRleCBvZiBgdmFsYCBpbiBgYnVmZmVyYCBhdCBvZmZzZXQgPj0gYGJ5dGVPZmZzZXRgLFxuLy8gT1IgdGhlIGxhc3QgaW5kZXggb2YgYHZhbGAgaW4gYGJ1ZmZlcmAgYXQgb2Zmc2V0IDw9IGBieXRlT2Zmc2V0YC5cbi8vXG4vLyBBcmd1bWVudHM6XG4vLyAtIGJ1ZmZlciAtIGEgQnVmZmVyIHRvIHNlYXJjaFxuLy8gLSB2YWwgLSBhIHN0cmluZywgQnVmZmVyLCBvciBudW1iZXJcbi8vIC0gYnl0ZU9mZnNldCAtIGFuIGluZGV4IGludG8gYGJ1ZmZlcmA7IHdpbGwgYmUgY2xhbXBlZCB0byBhbiBpbnQzMlxuLy8gLSBlbmNvZGluZyAtIGFuIG9wdGlvbmFsIGVuY29kaW5nLCByZWxldmFudCBpcyB2YWwgaXMgYSBzdHJpbmdcbi8vIC0gZGlyIC0gdHJ1ZSBmb3IgaW5kZXhPZiwgZmFsc2UgZm9yIGxhc3RJbmRleE9mXG5mdW5jdGlvbiBiaWRpcmVjdGlvbmFsSW5kZXhPZiAoYnVmZmVyLCB2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nLCBkaXIpIHtcbiAgLy8gRW1wdHkgYnVmZmVyIG1lYW5zIG5vIG1hdGNoXG4gIGlmIChidWZmZXIubGVuZ3RoID09PSAwKSByZXR1cm4gLTFcblxuICAvLyBOb3JtYWxpemUgYnl0ZU9mZnNldFxuICBpZiAodHlwZW9mIGJ5dGVPZmZzZXQgPT09ICdzdHJpbmcnKSB7XG4gICAgZW5jb2RpbmcgPSBieXRlT2Zmc2V0XG4gICAgYnl0ZU9mZnNldCA9IDBcbiAgfSBlbHNlIGlmIChieXRlT2Zmc2V0ID4gMHg3ZmZmZmZmZikge1xuICAgIGJ5dGVPZmZzZXQgPSAweDdmZmZmZmZmXG4gIH0gZWxzZSBpZiAoYnl0ZU9mZnNldCA8IC0weDgwMDAwMDAwKSB7XG4gICAgYnl0ZU9mZnNldCA9IC0weDgwMDAwMDAwXG4gIH1cbiAgYnl0ZU9mZnNldCA9ICtieXRlT2Zmc2V0ICAvLyBDb2VyY2UgdG8gTnVtYmVyLlxuICBpZiAoaXNOYU4oYnl0ZU9mZnNldCkpIHtcbiAgICAvLyBieXRlT2Zmc2V0OiBpdCBpdCdzIHVuZGVmaW5lZCwgbnVsbCwgTmFOLCBcImZvb1wiLCBldGMsIHNlYXJjaCB3aG9sZSBidWZmZXJcbiAgICBieXRlT2Zmc2V0ID0gZGlyID8gMCA6IChidWZmZXIubGVuZ3RoIC0gMSlcbiAgfVxuXG4gIC8vIE5vcm1hbGl6ZSBieXRlT2Zmc2V0OiBuZWdhdGl2ZSBvZmZzZXRzIHN0YXJ0IGZyb20gdGhlIGVuZCBvZiB0aGUgYnVmZmVyXG4gIGlmIChieXRlT2Zmc2V0IDwgMCkgYnl0ZU9mZnNldCA9IGJ1ZmZlci5sZW5ndGggKyBieXRlT2Zmc2V0XG4gIGlmIChieXRlT2Zmc2V0ID49IGJ1ZmZlci5sZW5ndGgpIHtcbiAgICBpZiAoZGlyKSByZXR1cm4gLTFcbiAgICBlbHNlIGJ5dGVPZmZzZXQgPSBidWZmZXIubGVuZ3RoIC0gMVxuICB9IGVsc2UgaWYgKGJ5dGVPZmZzZXQgPCAwKSB7XG4gICAgaWYgKGRpcikgYnl0ZU9mZnNldCA9IDBcbiAgICBlbHNlIHJldHVybiAtMVxuICB9XG5cbiAgLy8gTm9ybWFsaXplIHZhbFxuICBpZiAodHlwZW9mIHZhbCA9PT0gJ3N0cmluZycpIHtcbiAgICB2YWwgPSBCdWZmZXIuZnJvbSh2YWwsIGVuY29kaW5nKVxuICB9XG5cbiAgLy8gRmluYWxseSwgc2VhcmNoIGVpdGhlciBpbmRleE9mIChpZiBkaXIgaXMgdHJ1ZSkgb3IgbGFzdEluZGV4T2ZcbiAgaWYgKEJ1ZmZlci5pc0J1ZmZlcih2YWwpKSB7XG4gICAgLy8gU3BlY2lhbCBjYXNlOiBsb29raW5nIGZvciBlbXB0eSBzdHJpbmcvYnVmZmVyIGFsd2F5cyBmYWlsc1xuICAgIGlmICh2YWwubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gLTFcbiAgICB9XG4gICAgcmV0dXJuIGFycmF5SW5kZXhPZihidWZmZXIsIHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcsIGRpcilcbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsID09PSAnbnVtYmVyJykge1xuICAgIHZhbCA9IHZhbCAmIDB4RkYgLy8gU2VhcmNoIGZvciBhIGJ5dGUgdmFsdWUgWzAtMjU1XVxuICAgIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCAmJlxuICAgICAgICB0eXBlb2YgVWludDhBcnJheS5wcm90b3R5cGUuaW5kZXhPZiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgaWYgKGRpcikge1xuICAgICAgICByZXR1cm4gVWludDhBcnJheS5wcm90b3R5cGUuaW5kZXhPZi5jYWxsKGJ1ZmZlciwgdmFsLCBieXRlT2Zmc2V0KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFVpbnQ4QXJyYXkucHJvdG90eXBlLmxhc3RJbmRleE9mLmNhbGwoYnVmZmVyLCB2YWwsIGJ5dGVPZmZzZXQpXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBhcnJheUluZGV4T2YoYnVmZmVyLCBbIHZhbCBdLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZGlyKVxuICB9XG5cbiAgdGhyb3cgbmV3IFR5cGVFcnJvcigndmFsIG11c3QgYmUgc3RyaW5nLCBudW1iZXIgb3IgQnVmZmVyJylcbn1cblxuZnVuY3Rpb24gYXJyYXlJbmRleE9mIChhcnIsIHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcsIGRpcikge1xuICB2YXIgaW5kZXhTaXplID0gMVxuICB2YXIgYXJyTGVuZ3RoID0gYXJyLmxlbmd0aFxuICB2YXIgdmFsTGVuZ3RoID0gdmFsLmxlbmd0aFxuXG4gIGlmIChlbmNvZGluZyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgZW5jb2RpbmcgPSBTdHJpbmcoZW5jb2RpbmcpLnRvTG93ZXJDYXNlKClcbiAgICBpZiAoZW5jb2RpbmcgPT09ICd1Y3MyJyB8fCBlbmNvZGluZyA9PT0gJ3Vjcy0yJyB8fFxuICAgICAgICBlbmNvZGluZyA9PT0gJ3V0ZjE2bGUnIHx8IGVuY29kaW5nID09PSAndXRmLTE2bGUnKSB7XG4gICAgICBpZiAoYXJyLmxlbmd0aCA8IDIgfHwgdmFsLmxlbmd0aCA8IDIpIHtcbiAgICAgICAgcmV0dXJuIC0xXG4gICAgICB9XG4gICAgICBpbmRleFNpemUgPSAyXG4gICAgICBhcnJMZW5ndGggLz0gMlxuICAgICAgdmFsTGVuZ3RoIC89IDJcbiAgICAgIGJ5dGVPZmZzZXQgLz0gMlxuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHJlYWQgKGJ1ZiwgaSkge1xuICAgIGlmIChpbmRleFNpemUgPT09IDEpIHtcbiAgICAgIHJldHVybiBidWZbaV1cbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGJ1Zi5yZWFkVUludDE2QkUoaSAqIGluZGV4U2l6ZSlcbiAgICB9XG4gIH1cblxuICB2YXIgaVxuICBpZiAoZGlyKSB7XG4gICAgdmFyIGZvdW5kSW5kZXggPSAtMVxuICAgIGZvciAoaSA9IGJ5dGVPZmZzZXQ7IGkgPCBhcnJMZW5ndGg7IGkrKykge1xuICAgICAgaWYgKHJlYWQoYXJyLCBpKSA9PT0gcmVhZCh2YWwsIGZvdW5kSW5kZXggPT09IC0xID8gMCA6IGkgLSBmb3VuZEluZGV4KSkge1xuICAgICAgICBpZiAoZm91bmRJbmRleCA9PT0gLTEpIGZvdW5kSW5kZXggPSBpXG4gICAgICAgIGlmIChpIC0gZm91bmRJbmRleCArIDEgPT09IHZhbExlbmd0aCkgcmV0dXJuIGZvdW5kSW5kZXggKiBpbmRleFNpemVcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChmb3VuZEluZGV4ICE9PSAtMSkgaSAtPSBpIC0gZm91bmRJbmRleFxuICAgICAgICBmb3VuZEluZGV4ID0gLTFcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKGJ5dGVPZmZzZXQgKyB2YWxMZW5ndGggPiBhcnJMZW5ndGgpIGJ5dGVPZmZzZXQgPSBhcnJMZW5ndGggLSB2YWxMZW5ndGhcbiAgICBmb3IgKGkgPSBieXRlT2Zmc2V0OyBpID49IDA7IGktLSkge1xuICAgICAgdmFyIGZvdW5kID0gdHJ1ZVxuICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCB2YWxMZW5ndGg7IGorKykge1xuICAgICAgICBpZiAocmVhZChhcnIsIGkgKyBqKSAhPT0gcmVhZCh2YWwsIGopKSB7XG4gICAgICAgICAgZm91bmQgPSBmYWxzZVxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChmb3VuZCkgcmV0dXJuIGlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gLTFcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5pbmNsdWRlcyA9IGZ1bmN0aW9uIGluY2x1ZGVzICh2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nKSB7XG4gIHJldHVybiB0aGlzLmluZGV4T2YodmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZykgIT09IC0xXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuaW5kZXhPZiA9IGZ1bmN0aW9uIGluZGV4T2YgKHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcpIHtcbiAgcmV0dXJuIGJpZGlyZWN0aW9uYWxJbmRleE9mKHRoaXMsIHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcsIHRydWUpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUubGFzdEluZGV4T2YgPSBmdW5jdGlvbiBsYXN0SW5kZXhPZiAodmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZykge1xuICByZXR1cm4gYmlkaXJlY3Rpb25hbEluZGV4T2YodGhpcywgdmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZmFsc2UpXG59XG5cbmZ1bmN0aW9uIGhleFdyaXRlIChidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgb2Zmc2V0ID0gTnVtYmVyKG9mZnNldCkgfHwgMFxuICB2YXIgcmVtYWluaW5nID0gYnVmLmxlbmd0aCAtIG9mZnNldFxuICBpZiAoIWxlbmd0aCkge1xuICAgIGxlbmd0aCA9IHJlbWFpbmluZ1xuICB9IGVsc2Uge1xuICAgIGxlbmd0aCA9IE51bWJlcihsZW5ndGgpXG4gICAgaWYgKGxlbmd0aCA+IHJlbWFpbmluZykge1xuICAgICAgbGVuZ3RoID0gcmVtYWluaW5nXG4gICAgfVxuICB9XG5cbiAgLy8gbXVzdCBiZSBhbiBldmVuIG51bWJlciBvZiBkaWdpdHNcbiAgdmFyIHN0ckxlbiA9IHN0cmluZy5sZW5ndGhcbiAgaWYgKHN0ckxlbiAlIDIgIT09IDApIHRocm93IG5ldyBUeXBlRXJyb3IoJ0ludmFsaWQgaGV4IHN0cmluZycpXG5cbiAgaWYgKGxlbmd0aCA+IHN0ckxlbiAvIDIpIHtcbiAgICBsZW5ndGggPSBzdHJMZW4gLyAyXG4gIH1cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7ICsraSkge1xuICAgIHZhciBwYXJzZWQgPSBwYXJzZUludChzdHJpbmcuc3Vic3RyKGkgKiAyLCAyKSwgMTYpXG4gICAgaWYgKGlzTmFOKHBhcnNlZCkpIHJldHVybiBpXG4gICAgYnVmW29mZnNldCArIGldID0gcGFyc2VkXG4gIH1cbiAgcmV0dXJuIGlcbn1cblxuZnVuY3Rpb24gdXRmOFdyaXRlIChidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgcmV0dXJuIGJsaXRCdWZmZXIodXRmOFRvQnl0ZXMoc3RyaW5nLCBidWYubGVuZ3RoIC0gb2Zmc2V0KSwgYnVmLCBvZmZzZXQsIGxlbmd0aClcbn1cblxuZnVuY3Rpb24gYXNjaWlXcml0ZSAoYnVmLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKSB7XG4gIHJldHVybiBibGl0QnVmZmVyKGFzY2lpVG9CeXRlcyhzdHJpbmcpLCBidWYsIG9mZnNldCwgbGVuZ3RoKVxufVxuXG5mdW5jdGlvbiBsYXRpbjFXcml0ZSAoYnVmLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKSB7XG4gIHJldHVybiBhc2NpaVdyaXRlKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aClcbn1cblxuZnVuY3Rpb24gYmFzZTY0V3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkge1xuICByZXR1cm4gYmxpdEJ1ZmZlcihiYXNlNjRUb0J5dGVzKHN0cmluZyksIGJ1Ziwgb2Zmc2V0LCBsZW5ndGgpXG59XG5cbmZ1bmN0aW9uIHVjczJXcml0ZSAoYnVmLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKSB7XG4gIHJldHVybiBibGl0QnVmZmVyKHV0ZjE2bGVUb0J5dGVzKHN0cmluZywgYnVmLmxlbmd0aCAtIG9mZnNldCksIGJ1Ziwgb2Zmc2V0LCBsZW5ndGgpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGUgPSBmdW5jdGlvbiB3cml0ZSAoc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCwgZW5jb2RpbmcpIHtcbiAgLy8gQnVmZmVyI3dyaXRlKHN0cmluZylcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgZW5jb2RpbmcgPSAndXRmOCdcbiAgICBsZW5ndGggPSB0aGlzLmxlbmd0aFxuICAgIG9mZnNldCA9IDBcbiAgLy8gQnVmZmVyI3dyaXRlKHN0cmluZywgZW5jb2RpbmcpXG4gIH0gZWxzZSBpZiAobGVuZ3RoID09PSB1bmRlZmluZWQgJiYgdHlwZW9mIG9mZnNldCA9PT0gJ3N0cmluZycpIHtcbiAgICBlbmNvZGluZyA9IG9mZnNldFxuICAgIGxlbmd0aCA9IHRoaXMubGVuZ3RoXG4gICAgb2Zmc2V0ID0gMFxuICAvLyBCdWZmZXIjd3JpdGUoc3RyaW5nLCBvZmZzZXRbLCBsZW5ndGhdWywgZW5jb2RpbmddKVxuICB9IGVsc2UgaWYgKGlzRmluaXRlKG9mZnNldCkpIHtcbiAgICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gICAgaWYgKGlzRmluaXRlKGxlbmd0aCkpIHtcbiAgICAgIGxlbmd0aCA9IGxlbmd0aCB8IDBcbiAgICAgIGlmIChlbmNvZGluZyA9PT0gdW5kZWZpbmVkKSBlbmNvZGluZyA9ICd1dGY4J1xuICAgIH0gZWxzZSB7XG4gICAgICBlbmNvZGluZyA9IGxlbmd0aFxuICAgICAgbGVuZ3RoID0gdW5kZWZpbmVkXG4gICAgfVxuICAvLyBsZWdhY3kgd3JpdGUoc3RyaW5nLCBlbmNvZGluZywgb2Zmc2V0LCBsZW5ndGgpIC0gcmVtb3ZlIGluIHYwLjEzXG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ0J1ZmZlci53cml0ZShzdHJpbmcsIGVuY29kaW5nLCBvZmZzZXRbLCBsZW5ndGhdKSBpcyBubyBsb25nZXIgc3VwcG9ydGVkJ1xuICAgIClcbiAgfVxuXG4gIHZhciByZW1haW5pbmcgPSB0aGlzLmxlbmd0aCAtIG9mZnNldFxuICBpZiAobGVuZ3RoID09PSB1bmRlZmluZWQgfHwgbGVuZ3RoID4gcmVtYWluaW5nKSBsZW5ndGggPSByZW1haW5pbmdcblxuICBpZiAoKHN0cmluZy5sZW5ndGggPiAwICYmIChsZW5ndGggPCAwIHx8IG9mZnNldCA8IDApKSB8fCBvZmZzZXQgPiB0aGlzLmxlbmd0aCkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdBdHRlbXB0IHRvIHdyaXRlIG91dHNpZGUgYnVmZmVyIGJvdW5kcycpXG4gIH1cblxuICBpZiAoIWVuY29kaW5nKSBlbmNvZGluZyA9ICd1dGY4J1xuXG4gIHZhciBsb3dlcmVkQ2FzZSA9IGZhbHNlXG4gIGZvciAoOzspIHtcbiAgICBzd2l0Y2ggKGVuY29kaW5nKSB7XG4gICAgICBjYXNlICdoZXgnOlxuICAgICAgICByZXR1cm4gaGV4V3JpdGUodGhpcywgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aClcblxuICAgICAgY2FzZSAndXRmOCc6XG4gICAgICBjYXNlICd1dGYtOCc6XG4gICAgICAgIHJldHVybiB1dGY4V3JpdGUodGhpcywgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aClcblxuICAgICAgY2FzZSAnYXNjaWknOlxuICAgICAgICByZXR1cm4gYXNjaWlXcml0ZSh0aGlzLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKVxuXG4gICAgICBjYXNlICdsYXRpbjEnOlxuICAgICAgY2FzZSAnYmluYXJ5JzpcbiAgICAgICAgcmV0dXJuIGxhdGluMVdyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG5cbiAgICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgICAgIC8vIFdhcm5pbmc6IG1heExlbmd0aCBub3QgdGFrZW4gaW50byBhY2NvdW50IGluIGJhc2U2NFdyaXRlXG4gICAgICAgIHJldHVybiBiYXNlNjRXcml0ZSh0aGlzLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKVxuXG4gICAgICBjYXNlICd1Y3MyJzpcbiAgICAgIGNhc2UgJ3Vjcy0yJzpcbiAgICAgIGNhc2UgJ3V0ZjE2bGUnOlxuICAgICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgICByZXR1cm4gdWNzMldyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG5cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGlmIChsb3dlcmVkQ2FzZSkgdGhyb3cgbmV3IFR5cGVFcnJvcignVW5rbm93biBlbmNvZGluZzogJyArIGVuY29kaW5nKVxuICAgICAgICBlbmNvZGluZyA9ICgnJyArIGVuY29kaW5nKS50b0xvd2VyQ2FzZSgpXG4gICAgICAgIGxvd2VyZWRDYXNlID0gdHJ1ZVxuICAgIH1cbiAgfVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTiAoKSB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogJ0J1ZmZlcicsXG4gICAgZGF0YTogQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodGhpcy5fYXJyIHx8IHRoaXMsIDApXG4gIH1cbn1cblxuZnVuY3Rpb24gYmFzZTY0U2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICBpZiAoc3RhcnQgPT09IDAgJiYgZW5kID09PSBidWYubGVuZ3RoKSB7XG4gICAgcmV0dXJuIGJhc2U2NC5mcm9tQnl0ZUFycmF5KGJ1ZilcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gYmFzZTY0LmZyb21CeXRlQXJyYXkoYnVmLnNsaWNlKHN0YXJ0LCBlbmQpKVxuICB9XG59XG5cbmZ1bmN0aW9uIHV0ZjhTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7XG4gIGVuZCA9IE1hdGgubWluKGJ1Zi5sZW5ndGgsIGVuZClcbiAgdmFyIHJlcyA9IFtdXG5cbiAgdmFyIGkgPSBzdGFydFxuICB3aGlsZSAoaSA8IGVuZCkge1xuICAgIHZhciBmaXJzdEJ5dGUgPSBidWZbaV1cbiAgICB2YXIgY29kZVBvaW50ID0gbnVsbFxuICAgIHZhciBieXRlc1BlclNlcXVlbmNlID0gKGZpcnN0Qnl0ZSA+IDB4RUYpID8gNFxuICAgICAgOiAoZmlyc3RCeXRlID4gMHhERikgPyAzXG4gICAgICA6IChmaXJzdEJ5dGUgPiAweEJGKSA/IDJcbiAgICAgIDogMVxuXG4gICAgaWYgKGkgKyBieXRlc1BlclNlcXVlbmNlIDw9IGVuZCkge1xuICAgICAgdmFyIHNlY29uZEJ5dGUsIHRoaXJkQnl0ZSwgZm91cnRoQnl0ZSwgdGVtcENvZGVQb2ludFxuXG4gICAgICBzd2l0Y2ggKGJ5dGVzUGVyU2VxdWVuY2UpIHtcbiAgICAgICAgY2FzZSAxOlxuICAgICAgICAgIGlmIChmaXJzdEJ5dGUgPCAweDgwKSB7XG4gICAgICAgICAgICBjb2RlUG9pbnQgPSBmaXJzdEJ5dGVcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAyOlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgaWYgKChzZWNvbmRCeXRlICYgMHhDMCkgPT09IDB4ODApIHtcbiAgICAgICAgICAgIHRlbXBDb2RlUG9pbnQgPSAoZmlyc3RCeXRlICYgMHgxRikgPDwgMHg2IHwgKHNlY29uZEJ5dGUgJiAweDNGKVxuICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweDdGKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAzOlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgdGhpcmRCeXRlID0gYnVmW2kgKyAyXVxuICAgICAgICAgIGlmICgoc2Vjb25kQnl0ZSAmIDB4QzApID09PSAweDgwICYmICh0aGlyZEJ5dGUgJiAweEMwKSA9PT0gMHg4MCkge1xuICAgICAgICAgICAgdGVtcENvZGVQb2ludCA9IChmaXJzdEJ5dGUgJiAweEYpIDw8IDB4QyB8IChzZWNvbmRCeXRlICYgMHgzRikgPDwgMHg2IHwgKHRoaXJkQnl0ZSAmIDB4M0YpXG4gICAgICAgICAgICBpZiAodGVtcENvZGVQb2ludCA+IDB4N0ZGICYmICh0ZW1wQ29kZVBvaW50IDwgMHhEODAwIHx8IHRlbXBDb2RlUG9pbnQgPiAweERGRkYpKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSA0OlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgdGhpcmRCeXRlID0gYnVmW2kgKyAyXVxuICAgICAgICAgIGZvdXJ0aEJ5dGUgPSBidWZbaSArIDNdXG4gICAgICAgICAgaWYgKChzZWNvbmRCeXRlICYgMHhDMCkgPT09IDB4ODAgJiYgKHRoaXJkQnl0ZSAmIDB4QzApID09PSAweDgwICYmIChmb3VydGhCeXRlICYgMHhDMCkgPT09IDB4ODApIHtcbiAgICAgICAgICAgIHRlbXBDb2RlUG9pbnQgPSAoZmlyc3RCeXRlICYgMHhGKSA8PCAweDEyIHwgKHNlY29uZEJ5dGUgJiAweDNGKSA8PCAweEMgfCAodGhpcmRCeXRlICYgMHgzRikgPDwgMHg2IHwgKGZvdXJ0aEJ5dGUgJiAweDNGKVxuICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweEZGRkYgJiYgdGVtcENvZGVQb2ludCA8IDB4MTEwMDAwKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGNvZGVQb2ludCA9PT0gbnVsbCkge1xuICAgICAgLy8gd2UgZGlkIG5vdCBnZW5lcmF0ZSBhIHZhbGlkIGNvZGVQb2ludCBzbyBpbnNlcnQgYVxuICAgICAgLy8gcmVwbGFjZW1lbnQgY2hhciAoVStGRkZEKSBhbmQgYWR2YW5jZSBvbmx5IDEgYnl0ZVxuICAgICAgY29kZVBvaW50ID0gMHhGRkZEXG4gICAgICBieXRlc1BlclNlcXVlbmNlID0gMVxuICAgIH0gZWxzZSBpZiAoY29kZVBvaW50ID4gMHhGRkZGKSB7XG4gICAgICAvLyBlbmNvZGUgdG8gdXRmMTYgKHN1cnJvZ2F0ZSBwYWlyIGRhbmNlKVxuICAgICAgY29kZVBvaW50IC09IDB4MTAwMDBcbiAgICAgIHJlcy5wdXNoKGNvZGVQb2ludCA+Pj4gMTAgJiAweDNGRiB8IDB4RDgwMClcbiAgICAgIGNvZGVQb2ludCA9IDB4REMwMCB8IGNvZGVQb2ludCAmIDB4M0ZGXG4gICAgfVxuXG4gICAgcmVzLnB1c2goY29kZVBvaW50KVxuICAgIGkgKz0gYnl0ZXNQZXJTZXF1ZW5jZVxuICB9XG5cbiAgcmV0dXJuIGRlY29kZUNvZGVQb2ludHNBcnJheShyZXMpXG59XG5cbi8vIEJhc2VkIG9uIGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzIyNzQ3MjcyLzY4MDc0MiwgdGhlIGJyb3dzZXIgd2l0aFxuLy8gdGhlIGxvd2VzdCBsaW1pdCBpcyBDaHJvbWUsIHdpdGggMHgxMDAwMCBhcmdzLlxuLy8gV2UgZ28gMSBtYWduaXR1ZGUgbGVzcywgZm9yIHNhZmV0eVxudmFyIE1BWF9BUkdVTUVOVFNfTEVOR1RIID0gMHgxMDAwXG5cbmZ1bmN0aW9uIGRlY29kZUNvZGVQb2ludHNBcnJheSAoY29kZVBvaW50cykge1xuICB2YXIgbGVuID0gY29kZVBvaW50cy5sZW5ndGhcbiAgaWYgKGxlbiA8PSBNQVhfQVJHVU1FTlRTX0xFTkdUSCkge1xuICAgIHJldHVybiBTdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KFN0cmluZywgY29kZVBvaW50cykgLy8gYXZvaWQgZXh0cmEgc2xpY2UoKVxuICB9XG5cbiAgLy8gRGVjb2RlIGluIGNodW5rcyB0byBhdm9pZCBcImNhbGwgc3RhY2sgc2l6ZSBleGNlZWRlZFwiLlxuICB2YXIgcmVzID0gJydcbiAgdmFyIGkgPSAwXG4gIHdoaWxlIChpIDwgbGVuKSB7XG4gICAgcmVzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkoXG4gICAgICBTdHJpbmcsXG4gICAgICBjb2RlUG9pbnRzLnNsaWNlKGksIGkgKz0gTUFYX0FSR1VNRU5UU19MRU5HVEgpXG4gICAgKVxuICB9XG4gIHJldHVybiByZXNcbn1cblxuZnVuY3Rpb24gYXNjaWlTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7XG4gIHZhciByZXQgPSAnJ1xuICBlbmQgPSBNYXRoLm1pbihidWYubGVuZ3RoLCBlbmQpXG5cbiAgZm9yICh2YXIgaSA9IHN0YXJ0OyBpIDwgZW5kOyArK2kpIHtcbiAgICByZXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShidWZbaV0gJiAweDdGKVxuICB9XG4gIHJldHVybiByZXRcbn1cblxuZnVuY3Rpb24gbGF0aW4xU2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICB2YXIgcmV0ID0gJydcbiAgZW5kID0gTWF0aC5taW4oYnVmLmxlbmd0aCwgZW5kKVxuXG4gIGZvciAodmFyIGkgPSBzdGFydDsgaSA8IGVuZDsgKytpKSB7XG4gICAgcmV0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYnVmW2ldKVxuICB9XG4gIHJldHVybiByZXRcbn1cblxuZnVuY3Rpb24gaGV4U2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICB2YXIgbGVuID0gYnVmLmxlbmd0aFxuXG4gIGlmICghc3RhcnQgfHwgc3RhcnQgPCAwKSBzdGFydCA9IDBcbiAgaWYgKCFlbmQgfHwgZW5kIDwgMCB8fCBlbmQgPiBsZW4pIGVuZCA9IGxlblxuXG4gIHZhciBvdXQgPSAnJ1xuICBmb3IgKHZhciBpID0gc3RhcnQ7IGkgPCBlbmQ7ICsraSkge1xuICAgIG91dCArPSB0b0hleChidWZbaV0pXG4gIH1cbiAgcmV0dXJuIG91dFxufVxuXG5mdW5jdGlvbiB1dGYxNmxlU2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICB2YXIgYnl0ZXMgPSBidWYuc2xpY2Uoc3RhcnQsIGVuZClcbiAgdmFyIHJlcyA9ICcnXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpICs9IDIpIHtcbiAgICByZXMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShieXRlc1tpXSArIGJ5dGVzW2kgKyAxXSAqIDI1NilcbiAgfVxuICByZXR1cm4gcmVzXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuc2xpY2UgPSBmdW5jdGlvbiBzbGljZSAoc3RhcnQsIGVuZCkge1xuICB2YXIgbGVuID0gdGhpcy5sZW5ndGhcbiAgc3RhcnQgPSB+fnN0YXJ0XG4gIGVuZCA9IGVuZCA9PT0gdW5kZWZpbmVkID8gbGVuIDogfn5lbmRcblxuICBpZiAoc3RhcnQgPCAwKSB7XG4gICAgc3RhcnQgKz0gbGVuXG4gICAgaWYgKHN0YXJ0IDwgMCkgc3RhcnQgPSAwXG4gIH0gZWxzZSBpZiAoc3RhcnQgPiBsZW4pIHtcbiAgICBzdGFydCA9IGxlblxuICB9XG5cbiAgaWYgKGVuZCA8IDApIHtcbiAgICBlbmQgKz0gbGVuXG4gICAgaWYgKGVuZCA8IDApIGVuZCA9IDBcbiAgfSBlbHNlIGlmIChlbmQgPiBsZW4pIHtcbiAgICBlbmQgPSBsZW5cbiAgfVxuXG4gIGlmIChlbmQgPCBzdGFydCkgZW5kID0gc3RhcnRcblxuICB2YXIgbmV3QnVmXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIG5ld0J1ZiA9IHRoaXMuc3ViYXJyYXkoc3RhcnQsIGVuZClcbiAgICBuZXdCdWYuX19wcm90b19fID0gQnVmZmVyLnByb3RvdHlwZVxuICB9IGVsc2Uge1xuICAgIHZhciBzbGljZUxlbiA9IGVuZCAtIHN0YXJ0XG4gICAgbmV3QnVmID0gbmV3IEJ1ZmZlcihzbGljZUxlbiwgdW5kZWZpbmVkKVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2xpY2VMZW47ICsraSkge1xuICAgICAgbmV3QnVmW2ldID0gdGhpc1tpICsgc3RhcnRdXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG5ld0J1ZlxufVxuXG4vKlxuICogTmVlZCB0byBtYWtlIHN1cmUgdGhhdCBidWZmZXIgaXNuJ3QgdHJ5aW5nIHRvIHdyaXRlIG91dCBvZiBib3VuZHMuXG4gKi9cbmZ1bmN0aW9uIGNoZWNrT2Zmc2V0IChvZmZzZXQsIGV4dCwgbGVuZ3RoKSB7XG4gIGlmICgob2Zmc2V0ICUgMSkgIT09IDAgfHwgb2Zmc2V0IDwgMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ29mZnNldCBpcyBub3QgdWludCcpXG4gIGlmIChvZmZzZXQgKyBleHQgPiBsZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdUcnlpbmcgdG8gYWNjZXNzIGJleW9uZCBidWZmZXIgbGVuZ3RoJylcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludExFID0gZnVuY3Rpb24gcmVhZFVJbnRMRSAob2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoIHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIGJ5dGVMZW5ndGgsIHRoaXMubGVuZ3RoKVxuXG4gIHZhciB2YWwgPSB0aGlzW29mZnNldF1cbiAgdmFyIG11bCA9IDFcbiAgdmFyIGkgPSAwXG4gIHdoaWxlICgrK2kgPCBieXRlTGVuZ3RoICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgdmFsICs9IHRoaXNbb2Zmc2V0ICsgaV0gKiBtdWxcbiAgfVxuXG4gIHJldHVybiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludEJFID0gZnVuY3Rpb24gcmVhZFVJbnRCRSAob2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoIHwgMFxuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcbiAgfVxuXG4gIHZhciB2YWwgPSB0aGlzW29mZnNldCArIC0tYnl0ZUxlbmd0aF1cbiAgdmFyIG11bCA9IDFcbiAgd2hpbGUgKGJ5dGVMZW5ndGggPiAwICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgdmFsICs9IHRoaXNbb2Zmc2V0ICsgLS1ieXRlTGVuZ3RoXSAqIG11bFxuICB9XG5cbiAgcmV0dXJuIHZhbFxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50OCA9IGZ1bmN0aW9uIHJlYWRVSW50OCAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDEsIHRoaXMubGVuZ3RoKVxuICByZXR1cm4gdGhpc1tvZmZzZXRdXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnQxNkxFID0gZnVuY3Rpb24gcmVhZFVJbnQxNkxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMiwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiB0aGlzW29mZnNldF0gfCAodGhpc1tvZmZzZXQgKyAxXSA8PCA4KVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50MTZCRSA9IGZ1bmN0aW9uIHJlYWRVSW50MTZCRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKVxuICByZXR1cm4gKHRoaXNbb2Zmc2V0XSA8PCA4KSB8IHRoaXNbb2Zmc2V0ICsgMV1cbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludDMyTEUgPSBmdW5jdGlvbiByZWFkVUludDMyTEUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA0LCB0aGlzLmxlbmd0aClcblxuICByZXR1cm4gKCh0aGlzW29mZnNldF0pIHxcbiAgICAgICh0aGlzW29mZnNldCArIDFdIDw8IDgpIHxcbiAgICAgICh0aGlzW29mZnNldCArIDJdIDw8IDE2KSkgK1xuICAgICAgKHRoaXNbb2Zmc2V0ICsgM10gKiAweDEwMDAwMDApXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnQzMkJFID0gZnVuY3Rpb24gcmVhZFVJbnQzMkJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG5cbiAgcmV0dXJuICh0aGlzW29mZnNldF0gKiAweDEwMDAwMDApICtcbiAgICAoKHRoaXNbb2Zmc2V0ICsgMV0gPDwgMTYpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAyXSA8PCA4KSB8XG4gICAgdGhpc1tvZmZzZXQgKyAzXSlcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50TEUgPSBmdW5jdGlvbiByZWFkSW50TEUgKG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcblxuICB2YXIgdmFsID0gdGhpc1tvZmZzZXRdXG4gIHZhciBtdWwgPSAxXG4gIHZhciBpID0gMFxuICB3aGlsZSAoKytpIDwgYnl0ZUxlbmd0aCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHZhbCArPSB0aGlzW29mZnNldCArIGldICogbXVsXG4gIH1cbiAgbXVsICo9IDB4ODBcblxuICBpZiAodmFsID49IG11bCkgdmFsIC09IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoKVxuXG4gIHJldHVybiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50QkUgPSBmdW5jdGlvbiByZWFkSW50QkUgKG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcblxuICB2YXIgaSA9IGJ5dGVMZW5ndGhcbiAgdmFyIG11bCA9IDFcbiAgdmFyIHZhbCA9IHRoaXNbb2Zmc2V0ICsgLS1pXVxuICB3aGlsZSAoaSA+IDAgJiYgKG11bCAqPSAweDEwMCkpIHtcbiAgICB2YWwgKz0gdGhpc1tvZmZzZXQgKyAtLWldICogbXVsXG4gIH1cbiAgbXVsICo9IDB4ODBcblxuICBpZiAodmFsID49IG11bCkgdmFsIC09IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoKVxuXG4gIHJldHVybiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50OCA9IGZ1bmN0aW9uIHJlYWRJbnQ4IChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMSwgdGhpcy5sZW5ndGgpXG4gIGlmICghKHRoaXNbb2Zmc2V0XSAmIDB4ODApKSByZXR1cm4gKHRoaXNbb2Zmc2V0XSlcbiAgcmV0dXJuICgoMHhmZiAtIHRoaXNbb2Zmc2V0XSArIDEpICogLTEpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZEludDE2TEUgPSBmdW5jdGlvbiByZWFkSW50MTZMRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKVxuICB2YXIgdmFsID0gdGhpc1tvZmZzZXRdIHwgKHRoaXNbb2Zmc2V0ICsgMV0gPDwgOClcbiAgcmV0dXJuICh2YWwgJiAweDgwMDApID8gdmFsIHwgMHhGRkZGMDAwMCA6IHZhbFxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRJbnQxNkJFID0gZnVuY3Rpb24gcmVhZEludDE2QkUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCAyLCB0aGlzLmxlbmd0aClcbiAgdmFyIHZhbCA9IHRoaXNbb2Zmc2V0ICsgMV0gfCAodGhpc1tvZmZzZXRdIDw8IDgpXG4gIHJldHVybiAodmFsICYgMHg4MDAwKSA/IHZhbCB8IDB4RkZGRjAwMDAgOiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50MzJMRSA9IGZ1bmN0aW9uIHJlYWRJbnQzMkxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG5cbiAgcmV0dXJuICh0aGlzW29mZnNldF0pIHxcbiAgICAodGhpc1tvZmZzZXQgKyAxXSA8PCA4KSB8XG4gICAgKHRoaXNbb2Zmc2V0ICsgMl0gPDwgMTYpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAzXSA8PCAyNClcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50MzJCRSA9IGZ1bmN0aW9uIHJlYWRJbnQzMkJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG5cbiAgcmV0dXJuICh0aGlzW29mZnNldF0gPDwgMjQpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAxXSA8PCAxNikgfFxuICAgICh0aGlzW29mZnNldCArIDJdIDw8IDgpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAzXSlcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkRmxvYXRMRSA9IGZ1bmN0aW9uIHJlYWRGbG9hdExFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCB0cnVlLCAyMywgNClcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkRmxvYXRCRSA9IGZ1bmN0aW9uIHJlYWRGbG9hdEJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCBmYWxzZSwgMjMsIDQpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZERvdWJsZUxFID0gZnVuY3Rpb24gcmVhZERvdWJsZUxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgOCwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCB0cnVlLCA1MiwgOClcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkRG91YmxlQkUgPSBmdW5jdGlvbiByZWFkRG91YmxlQkUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA4LCB0aGlzLmxlbmd0aClcbiAgcmV0dXJuIGllZWU3NTQucmVhZCh0aGlzLCBvZmZzZXQsIGZhbHNlLCA1MiwgOClcbn1cblxuZnVuY3Rpb24gY2hlY2tJbnQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgZXh0LCBtYXgsIG1pbikge1xuICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihidWYpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdcImJ1ZmZlclwiIGFyZ3VtZW50IG11c3QgYmUgYSBCdWZmZXIgaW5zdGFuY2UnKVxuICBpZiAodmFsdWUgPiBtYXggfHwgdmFsdWUgPCBtaW4pIHRocm93IG5ldyBSYW5nZUVycm9yKCdcInZhbHVlXCIgYXJndW1lbnQgaXMgb3V0IG9mIGJvdW5kcycpXG4gIGlmIChvZmZzZXQgKyBleHQgPiBidWYubGVuZ3RoKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignSW5kZXggb3V0IG9mIHJhbmdlJylcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnRMRSA9IGZ1bmN0aW9uIHdyaXRlVUludExFICh2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoIHwgMFxuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgdmFyIG1heEJ5dGVzID0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpIC0gMVxuICAgIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG1heEJ5dGVzLCAwKVxuICB9XG5cbiAgdmFyIG11bCA9IDFcbiAgdmFyIGkgPSAwXG4gIHRoaXNbb2Zmc2V0XSA9IHZhbHVlICYgMHhGRlxuICB3aGlsZSAoKytpIDwgYnl0ZUxlbmd0aCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHRoaXNbb2Zmc2V0ICsgaV0gPSAodmFsdWUgLyBtdWwpICYgMHhGRlxuICB9XG5cbiAgcmV0dXJuIG9mZnNldCArIGJ5dGVMZW5ndGhcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnRCRSA9IGZ1bmN0aW9uIHdyaXRlVUludEJFICh2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoIHwgMFxuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgdmFyIG1heEJ5dGVzID0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpIC0gMVxuICAgIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG1heEJ5dGVzLCAwKVxuICB9XG5cbiAgdmFyIGkgPSBieXRlTGVuZ3RoIC0gMVxuICB2YXIgbXVsID0gMVxuICB0aGlzW29mZnNldCArIGldID0gdmFsdWUgJiAweEZGXG4gIHdoaWxlICgtLWkgPj0gMCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHRoaXNbb2Zmc2V0ICsgaV0gPSAodmFsdWUgLyBtdWwpICYgMHhGRlxuICB9XG5cbiAgcmV0dXJuIG9mZnNldCArIGJ5dGVMZW5ndGhcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQ4ID0gZnVuY3Rpb24gd3JpdGVVSW50OCAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAxLCAweGZmLCAwKVxuICBpZiAoIUJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB2YWx1ZSA9IE1hdGguZmxvb3IodmFsdWUpXG4gIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSAmIDB4ZmYpXG4gIHJldHVybiBvZmZzZXQgKyAxXG59XG5cbmZ1bmN0aW9uIG9iamVjdFdyaXRlVUludDE2IChidWYsIHZhbHVlLCBvZmZzZXQsIGxpdHRsZUVuZGlhbikge1xuICBpZiAodmFsdWUgPCAwKSB2YWx1ZSA9IDB4ZmZmZiArIHZhbHVlICsgMVxuICBmb3IgKHZhciBpID0gMCwgaiA9IE1hdGgubWluKGJ1Zi5sZW5ndGggLSBvZmZzZXQsIDIpOyBpIDwgajsgKytpKSB7XG4gICAgYnVmW29mZnNldCArIGldID0gKHZhbHVlICYgKDB4ZmYgPDwgKDggKiAobGl0dGxlRW5kaWFuID8gaSA6IDEgLSBpKSkpKSA+Pj5cbiAgICAgIChsaXR0bGVFbmRpYW4gPyBpIDogMSAtIGkpICogOFxuICB9XG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50MTZMRSA9IGZ1bmN0aW9uIHdyaXRlVUludDE2TEUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgMiwgMHhmZmZmLCAwKVxuICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKVxuICAgIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDgpXG4gIH0gZWxzZSB7XG4gICAgb2JqZWN0V3JpdGVVSW50MTYodGhpcywgdmFsdWUsIG9mZnNldCwgdHJ1ZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgMlxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlVUludDE2QkUgPSBmdW5jdGlvbiB3cml0ZVVJbnQxNkJFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4ZmZmZiwgMClcbiAgaWYgKEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gICAgdGhpc1tvZmZzZXRdID0gKHZhbHVlID4+PiA4KVxuICAgIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgJiAweGZmKVxuICB9IGVsc2Uge1xuICAgIG9iamVjdFdyaXRlVUludDE2KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGZhbHNlKVxuICB9XG4gIHJldHVybiBvZmZzZXQgKyAyXG59XG5cbmZ1bmN0aW9uIG9iamVjdFdyaXRlVUludDMyIChidWYsIHZhbHVlLCBvZmZzZXQsIGxpdHRsZUVuZGlhbikge1xuICBpZiAodmFsdWUgPCAwKSB2YWx1ZSA9IDB4ZmZmZmZmZmYgKyB2YWx1ZSArIDFcbiAgZm9yICh2YXIgaSA9IDAsIGogPSBNYXRoLm1pbihidWYubGVuZ3RoIC0gb2Zmc2V0LCA0KTsgaSA8IGo7ICsraSkge1xuICAgIGJ1ZltvZmZzZXQgKyBpXSA9ICh2YWx1ZSA+Pj4gKGxpdHRsZUVuZGlhbiA/IGkgOiAzIC0gaSkgKiA4KSAmIDB4ZmZcbiAgfVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlVUludDMyTEUgPSBmdW5jdGlvbiB3cml0ZVVJbnQzMkxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDQsIDB4ZmZmZmZmZmYsIDApXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIHRoaXNbb2Zmc2V0ICsgM10gPSAodmFsdWUgPj4+IDI0KVxuICAgIHRoaXNbb2Zmc2V0ICsgMl0gPSAodmFsdWUgPj4+IDE2KVxuICAgIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDgpXG4gICAgdGhpc1tvZmZzZXRdID0gKHZhbHVlICYgMHhmZilcbiAgfSBlbHNlIHtcbiAgICBvYmplY3RXcml0ZVVJbnQzMih0aGlzLCB2YWx1ZSwgb2Zmc2V0LCB0cnVlKVxuICB9XG4gIHJldHVybiBvZmZzZXQgKyA0XG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50MzJCRSA9IGZ1bmN0aW9uIHdyaXRlVUludDMyQkUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgNCwgMHhmZmZmZmZmZiwgMClcbiAgaWYgKEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gICAgdGhpc1tvZmZzZXRdID0gKHZhbHVlID4+PiAyNClcbiAgICB0aGlzW29mZnNldCArIDFdID0gKHZhbHVlID4+PiAxNilcbiAgICB0aGlzW29mZnNldCArIDJdID0gKHZhbHVlID4+PiA4KVxuICAgIHRoaXNbb2Zmc2V0ICsgM10gPSAodmFsdWUgJiAweGZmKVxuICB9IGVsc2Uge1xuICAgIG9iamVjdFdyaXRlVUludDMyKHRoaXMsIHZhbHVlLCBvZmZzZXQsIGZhbHNlKVxuICB9XG4gIHJldHVybiBvZmZzZXQgKyA0XG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnRMRSA9IGZ1bmN0aW9uIHdyaXRlSW50TEUgKHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCB8IDBcbiAgaWYgKCFub0Fzc2VydCkge1xuICAgIHZhciBsaW1pdCA9IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoIC0gMSlcblxuICAgIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIGxpbWl0IC0gMSwgLWxpbWl0KVxuICB9XG5cbiAgdmFyIGkgPSAwXG4gIHZhciBtdWwgPSAxXG4gIHZhciBzdWIgPSAwXG4gIHRoaXNbb2Zmc2V0XSA9IHZhbHVlICYgMHhGRlxuICB3aGlsZSAoKytpIDwgYnl0ZUxlbmd0aCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIGlmICh2YWx1ZSA8IDAgJiYgc3ViID09PSAwICYmIHRoaXNbb2Zmc2V0ICsgaSAtIDFdICE9PSAwKSB7XG4gICAgICBzdWIgPSAxXG4gICAgfVxuICAgIHRoaXNbb2Zmc2V0ICsgaV0gPSAoKHZhbHVlIC8gbXVsKSA+PiAwKSAtIHN1YiAmIDB4RkZcbiAgfVxuXG4gIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnRCRSA9IGZ1bmN0aW9uIHdyaXRlSW50QkUgKHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCB8IDBcbiAgaWYgKCFub0Fzc2VydCkge1xuICAgIHZhciBsaW1pdCA9IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoIC0gMSlcblxuICAgIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIGxpbWl0IC0gMSwgLWxpbWl0KVxuICB9XG5cbiAgdmFyIGkgPSBieXRlTGVuZ3RoIC0gMVxuICB2YXIgbXVsID0gMVxuICB2YXIgc3ViID0gMFxuICB0aGlzW29mZnNldCArIGldID0gdmFsdWUgJiAweEZGXG4gIHdoaWxlICgtLWkgPj0gMCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIGlmICh2YWx1ZSA8IDAgJiYgc3ViID09PSAwICYmIHRoaXNbb2Zmc2V0ICsgaSArIDFdICE9PSAwKSB7XG4gICAgICBzdWIgPSAxXG4gICAgfVxuICAgIHRoaXNbb2Zmc2V0ICsgaV0gPSAoKHZhbHVlIC8gbXVsKSA+PiAwKSAtIHN1YiAmIDB4RkZcbiAgfVxuXG4gIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQ4ID0gZnVuY3Rpb24gd3JpdGVJbnQ4ICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDEsIDB4N2YsIC0weDgwKVxuICBpZiAoIUJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB2YWx1ZSA9IE1hdGguZmxvb3IodmFsdWUpXG4gIGlmICh2YWx1ZSA8IDApIHZhbHVlID0gMHhmZiArIHZhbHVlICsgMVxuICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKVxuICByZXR1cm4gb2Zmc2V0ICsgMVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlSW50MTZMRSA9IGZ1bmN0aW9uIHdyaXRlSW50MTZMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAyLCAweDdmZmYsIC0weDgwMDApXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSAmIDB4ZmYpXG4gICAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gOClcbiAgfSBlbHNlIHtcbiAgICBvYmplY3RXcml0ZVVJbnQxNih0aGlzLCB2YWx1ZSwgb2Zmc2V0LCB0cnVlKVxuICB9XG4gIHJldHVybiBvZmZzZXQgKyAyXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQxNkJFID0gZnVuY3Rpb24gd3JpdGVJbnQxNkJFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4N2ZmZiwgLTB4ODAwMClcbiAgaWYgKEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gICAgdGhpc1tvZmZzZXRdID0gKHZhbHVlID4+PiA4KVxuICAgIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgJiAweGZmKVxuICB9IGVsc2Uge1xuICAgIG9iamVjdFdyaXRlVUludDE2KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGZhbHNlKVxuICB9XG4gIHJldHVybiBvZmZzZXQgKyAyXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQzMkxFID0gZnVuY3Rpb24gd3JpdGVJbnQzMkxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDQsIDB4N2ZmZmZmZmYsIC0weDgwMDAwMDAwKVxuICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKVxuICAgIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDgpXG4gICAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gMTYpXG4gICAgdGhpc1tvZmZzZXQgKyAzXSA9ICh2YWx1ZSA+Pj4gMjQpXG4gIH0gZWxzZSB7XG4gICAgb2JqZWN0V3JpdGVVSW50MzIodGhpcywgdmFsdWUsIG9mZnNldCwgdHJ1ZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlSW50MzJCRSA9IGZ1bmN0aW9uIHdyaXRlSW50MzJCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCA0LCAweDdmZmZmZmZmLCAtMHg4MDAwMDAwMClcbiAgaWYgKHZhbHVlIDwgMCkgdmFsdWUgPSAweGZmZmZmZmZmICsgdmFsdWUgKyAxXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSA+Pj4gMjQpXG4gICAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gMTYpXG4gICAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gOClcbiAgICB0aGlzW29mZnNldCArIDNdID0gKHZhbHVlICYgMHhmZilcbiAgfSBlbHNlIHtcbiAgICBvYmplY3RXcml0ZVVJbnQzMih0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5mdW5jdGlvbiBjaGVja0lFRUU3NTQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgZXh0LCBtYXgsIG1pbikge1xuICBpZiAob2Zmc2V0ICsgZXh0ID4gYnVmLmxlbmd0aCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0luZGV4IG91dCBvZiByYW5nZScpXG4gIGlmIChvZmZzZXQgPCAwKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignSW5kZXggb3V0IG9mIHJhbmdlJylcbn1cblxuZnVuY3Rpb24gd3JpdGVGbG9hdCAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4sIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIHtcbiAgICBjaGVja0lFRUU3NTQoYnVmLCB2YWx1ZSwgb2Zmc2V0LCA0LCAzLjQwMjgyMzQ2NjM4NTI4ODZlKzM4LCAtMy40MDI4MjM0NjYzODUyODg2ZSszOClcbiAgfVxuICBpZWVlNzU0LndyaXRlKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbGl0dGxlRW5kaWFuLCAyMywgNClcbiAgcmV0dXJuIG9mZnNldCArIDRcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZUZsb2F0TEUgPSBmdW5jdGlvbiB3cml0ZUZsb2F0TEUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHJldHVybiB3cml0ZUZsb2F0KHRoaXMsIHZhbHVlLCBvZmZzZXQsIHRydWUsIG5vQXNzZXJ0KVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlRmxvYXRCRSA9IGZ1bmN0aW9uIHdyaXRlRmxvYXRCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgcmV0dXJuIHdyaXRlRmxvYXQodGhpcywgdmFsdWUsIG9mZnNldCwgZmFsc2UsIG5vQXNzZXJ0KVxufVxuXG5mdW5jdGlvbiB3cml0ZURvdWJsZSAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4sIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIHtcbiAgICBjaGVja0lFRUU3NTQoYnVmLCB2YWx1ZSwgb2Zmc2V0LCA4LCAxLjc5NzY5MzEzNDg2MjMxNTdFKzMwOCwgLTEuNzk3NjkzMTM0ODYyMzE1N0UrMzA4KVxuICB9XG4gIGllZWU3NTQud3JpdGUoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4sIDUyLCA4KVxuICByZXR1cm4gb2Zmc2V0ICsgOFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlRG91YmxlTEUgPSBmdW5jdGlvbiB3cml0ZURvdWJsZUxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICByZXR1cm4gd3JpdGVEb3VibGUodGhpcywgdmFsdWUsIG9mZnNldCwgdHJ1ZSwgbm9Bc3NlcnQpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVEb3VibGVCRSA9IGZ1bmN0aW9uIHdyaXRlRG91YmxlQkUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHJldHVybiB3cml0ZURvdWJsZSh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSwgbm9Bc3NlcnQpXG59XG5cbi8vIGNvcHkodGFyZ2V0QnVmZmVyLCB0YXJnZXRTdGFydD0wLCBzb3VyY2VTdGFydD0wLCBzb3VyY2VFbmQ9YnVmZmVyLmxlbmd0aClcbkJ1ZmZlci5wcm90b3R5cGUuY29weSA9IGZ1bmN0aW9uIGNvcHkgKHRhcmdldCwgdGFyZ2V0U3RhcnQsIHN0YXJ0LCBlbmQpIHtcbiAgaWYgKCFzdGFydCkgc3RhcnQgPSAwXG4gIGlmICghZW5kICYmIGVuZCAhPT0gMCkgZW5kID0gdGhpcy5sZW5ndGhcbiAgaWYgKHRhcmdldFN0YXJ0ID49IHRhcmdldC5sZW5ndGgpIHRhcmdldFN0YXJ0ID0gdGFyZ2V0Lmxlbmd0aFxuICBpZiAoIXRhcmdldFN0YXJ0KSB0YXJnZXRTdGFydCA9IDBcbiAgaWYgKGVuZCA+IDAgJiYgZW5kIDwgc3RhcnQpIGVuZCA9IHN0YXJ0XG5cbiAgLy8gQ29weSAwIGJ5dGVzOyB3ZSdyZSBkb25lXG4gIGlmIChlbmQgPT09IHN0YXJ0KSByZXR1cm4gMFxuICBpZiAodGFyZ2V0Lmxlbmd0aCA9PT0gMCB8fCB0aGlzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDBcblxuICAvLyBGYXRhbCBlcnJvciBjb25kaXRpb25zXG4gIGlmICh0YXJnZXRTdGFydCA8IDApIHtcbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcigndGFyZ2V0U3RhcnQgb3V0IG9mIGJvdW5kcycpXG4gIH1cbiAgaWYgKHN0YXJ0IDwgMCB8fCBzdGFydCA+PSB0aGlzLmxlbmd0aCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ3NvdXJjZVN0YXJ0IG91dCBvZiBib3VuZHMnKVxuICBpZiAoZW5kIDwgMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ3NvdXJjZUVuZCBvdXQgb2YgYm91bmRzJylcblxuICAvLyBBcmUgd2Ugb29iP1xuICBpZiAoZW5kID4gdGhpcy5sZW5ndGgpIGVuZCA9IHRoaXMubGVuZ3RoXG4gIGlmICh0YXJnZXQubGVuZ3RoIC0gdGFyZ2V0U3RhcnQgPCBlbmQgLSBzdGFydCkge1xuICAgIGVuZCA9IHRhcmdldC5sZW5ndGggLSB0YXJnZXRTdGFydCArIHN0YXJ0XG4gIH1cblxuICB2YXIgbGVuID0gZW5kIC0gc3RhcnRcbiAgdmFyIGlcblxuICBpZiAodGhpcyA9PT0gdGFyZ2V0ICYmIHN0YXJ0IDwgdGFyZ2V0U3RhcnQgJiYgdGFyZ2V0U3RhcnQgPCBlbmQpIHtcbiAgICAvLyBkZXNjZW5kaW5nIGNvcHkgZnJvbSBlbmRcbiAgICBmb3IgKGkgPSBsZW4gLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgdGFyZ2V0W2kgKyB0YXJnZXRTdGFydF0gPSB0aGlzW2kgKyBzdGFydF1cbiAgICB9XG4gIH0gZWxzZSBpZiAobGVuIDwgMTAwMCB8fCAhQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICAvLyBhc2NlbmRpbmcgY29weSBmcm9tIHN0YXJ0XG4gICAgZm9yIChpID0gMDsgaSA8IGxlbjsgKytpKSB7XG4gICAgICB0YXJnZXRbaSArIHRhcmdldFN0YXJ0XSA9IHRoaXNbaSArIHN0YXJ0XVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBVaW50OEFycmF5LnByb3RvdHlwZS5zZXQuY2FsbChcbiAgICAgIHRhcmdldCxcbiAgICAgIHRoaXMuc3ViYXJyYXkoc3RhcnQsIHN0YXJ0ICsgbGVuKSxcbiAgICAgIHRhcmdldFN0YXJ0XG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIGxlblxufVxuXG4vLyBVc2FnZTpcbi8vICAgIGJ1ZmZlci5maWxsKG51bWJlclssIG9mZnNldFssIGVuZF1dKVxuLy8gICAgYnVmZmVyLmZpbGwoYnVmZmVyWywgb2Zmc2V0WywgZW5kXV0pXG4vLyAgICBidWZmZXIuZmlsbChzdHJpbmdbLCBvZmZzZXRbLCBlbmRdXVssIGVuY29kaW5nXSlcbkJ1ZmZlci5wcm90b3R5cGUuZmlsbCA9IGZ1bmN0aW9uIGZpbGwgKHZhbCwgc3RhcnQsIGVuZCwgZW5jb2RpbmcpIHtcbiAgLy8gSGFuZGxlIHN0cmluZyBjYXNlczpcbiAgaWYgKHR5cGVvZiB2YWwgPT09ICdzdHJpbmcnKSB7XG4gICAgaWYgKHR5cGVvZiBzdGFydCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGVuY29kaW5nID0gc3RhcnRcbiAgICAgIHN0YXJ0ID0gMFxuICAgICAgZW5kID0gdGhpcy5sZW5ndGhcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBlbmQgPT09ICdzdHJpbmcnKSB7XG4gICAgICBlbmNvZGluZyA9IGVuZFxuICAgICAgZW5kID0gdGhpcy5sZW5ndGhcbiAgICB9XG4gICAgaWYgKHZhbC5sZW5ndGggPT09IDEpIHtcbiAgICAgIHZhciBjb2RlID0gdmFsLmNoYXJDb2RlQXQoMClcbiAgICAgIGlmIChjb2RlIDwgMjU2KSB7XG4gICAgICAgIHZhbCA9IGNvZGVcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGVuY29kaW5nICE9PSB1bmRlZmluZWQgJiYgdHlwZW9mIGVuY29kaW5nICE9PSAnc3RyaW5nJykge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignZW5jb2RpbmcgbXVzdCBiZSBhIHN0cmluZycpXG4gICAgfVxuICAgIGlmICh0eXBlb2YgZW5jb2RpbmcgPT09ICdzdHJpbmcnICYmICFCdWZmZXIuaXNFbmNvZGluZyhlbmNvZGluZykpIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1Vua25vd24gZW5jb2Rpbmc6ICcgKyBlbmNvZGluZylcbiAgICB9XG4gIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gJ251bWJlcicpIHtcbiAgICB2YWwgPSB2YWwgJiAyNTVcbiAgfVxuXG4gIC8vIEludmFsaWQgcmFuZ2VzIGFyZSBub3Qgc2V0IHRvIGEgZGVmYXVsdCwgc28gY2FuIHJhbmdlIGNoZWNrIGVhcmx5LlxuICBpZiAoc3RhcnQgPCAwIHx8IHRoaXMubGVuZ3RoIDwgc3RhcnQgfHwgdGhpcy5sZW5ndGggPCBlbmQpIHtcbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignT3V0IG9mIHJhbmdlIGluZGV4JylcbiAgfVxuXG4gIGlmIChlbmQgPD0gc3RhcnQpIHtcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgc3RhcnQgPSBzdGFydCA+Pj4gMFxuICBlbmQgPSBlbmQgPT09IHVuZGVmaW5lZCA/IHRoaXMubGVuZ3RoIDogZW5kID4+PiAwXG5cbiAgaWYgKCF2YWwpIHZhbCA9IDBcblxuICB2YXIgaVxuICBpZiAodHlwZW9mIHZhbCA9PT0gJ251bWJlcicpIHtcbiAgICBmb3IgKGkgPSBzdGFydDsgaSA8IGVuZDsgKytpKSB7XG4gICAgICB0aGlzW2ldID0gdmFsXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHZhciBieXRlcyA9IEJ1ZmZlci5pc0J1ZmZlcih2YWwpXG4gICAgICA/IHZhbFxuICAgICAgOiB1dGY4VG9CeXRlcyhuZXcgQnVmZmVyKHZhbCwgZW5jb2RpbmcpLnRvU3RyaW5nKCkpXG4gICAgdmFyIGxlbiA9IGJ5dGVzLmxlbmd0aFxuICAgIGZvciAoaSA9IDA7IGkgPCBlbmQgLSBzdGFydDsgKytpKSB7XG4gICAgICB0aGlzW2kgKyBzdGFydF0gPSBieXRlc1tpICUgbGVuXVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0aGlzXG59XG5cbi8vIEhFTFBFUiBGVU5DVElPTlNcbi8vID09PT09PT09PT09PT09PT1cblxudmFyIElOVkFMSURfQkFTRTY0X1JFID0gL1teK1xcLzAtOUEtWmEtei1fXS9nXG5cbmZ1bmN0aW9uIGJhc2U2NGNsZWFuIChzdHIpIHtcbiAgLy8gTm9kZSBzdHJpcHMgb3V0IGludmFsaWQgY2hhcmFjdGVycyBsaWtlIFxcbiBhbmQgXFx0IGZyb20gdGhlIHN0cmluZywgYmFzZTY0LWpzIGRvZXMgbm90XG4gIHN0ciA9IHN0cmluZ3RyaW0oc3RyKS5yZXBsYWNlKElOVkFMSURfQkFTRTY0X1JFLCAnJylcbiAgLy8gTm9kZSBjb252ZXJ0cyBzdHJpbmdzIHdpdGggbGVuZ3RoIDwgMiB0byAnJ1xuICBpZiAoc3RyLmxlbmd0aCA8IDIpIHJldHVybiAnJ1xuICAvLyBOb2RlIGFsbG93cyBmb3Igbm9uLXBhZGRlZCBiYXNlNjQgc3RyaW5ncyAobWlzc2luZyB0cmFpbGluZyA9PT0pLCBiYXNlNjQtanMgZG9lcyBub3RcbiAgd2hpbGUgKHN0ci5sZW5ndGggJSA0ICE9PSAwKSB7XG4gICAgc3RyID0gc3RyICsgJz0nXG4gIH1cbiAgcmV0dXJuIHN0clxufVxuXG5mdW5jdGlvbiBzdHJpbmd0cmltIChzdHIpIHtcbiAgaWYgKHN0ci50cmltKSByZXR1cm4gc3RyLnRyaW0oKVxuICByZXR1cm4gc3RyLnJlcGxhY2UoL15cXHMrfFxccyskL2csICcnKVxufVxuXG5mdW5jdGlvbiB0b0hleCAobikge1xuICBpZiAobiA8IDE2KSByZXR1cm4gJzAnICsgbi50b1N0cmluZygxNilcbiAgcmV0dXJuIG4udG9TdHJpbmcoMTYpXG59XG5cbmZ1bmN0aW9uIHV0ZjhUb0J5dGVzIChzdHJpbmcsIHVuaXRzKSB7XG4gIHVuaXRzID0gdW5pdHMgfHwgSW5maW5pdHlcbiAgdmFyIGNvZGVQb2ludFxuICB2YXIgbGVuZ3RoID0gc3RyaW5nLmxlbmd0aFxuICB2YXIgbGVhZFN1cnJvZ2F0ZSA9IG51bGxcbiAgdmFyIGJ5dGVzID0gW11cblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgKytpKSB7XG4gICAgY29kZVBvaW50ID0gc3RyaW5nLmNoYXJDb2RlQXQoaSlcblxuICAgIC8vIGlzIHN1cnJvZ2F0ZSBjb21wb25lbnRcbiAgICBpZiAoY29kZVBvaW50ID4gMHhEN0ZGICYmIGNvZGVQb2ludCA8IDB4RTAwMCkge1xuICAgICAgLy8gbGFzdCBjaGFyIHdhcyBhIGxlYWRcbiAgICAgIGlmICghbGVhZFN1cnJvZ2F0ZSkge1xuICAgICAgICAvLyBubyBsZWFkIHlldFxuICAgICAgICBpZiAoY29kZVBvaW50ID4gMHhEQkZGKSB7XG4gICAgICAgICAgLy8gdW5leHBlY3RlZCB0cmFpbFxuICAgICAgICAgIGlmICgodW5pdHMgLT0gMykgPiAtMSkgYnl0ZXMucHVzaCgweEVGLCAweEJGLCAweEJEKVxuICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgIH0gZWxzZSBpZiAoaSArIDEgPT09IGxlbmd0aCkge1xuICAgICAgICAgIC8vIHVucGFpcmVkIGxlYWRcbiAgICAgICAgICBpZiAoKHVuaXRzIC09IDMpID4gLTEpIGJ5dGVzLnB1c2goMHhFRiwgMHhCRiwgMHhCRClcbiAgICAgICAgICBjb250aW51ZVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gdmFsaWQgbGVhZFxuICAgICAgICBsZWFkU3Vycm9nYXRlID0gY29kZVBvaW50XG5cbiAgICAgICAgY29udGludWVcbiAgICAgIH1cblxuICAgICAgLy8gMiBsZWFkcyBpbiBhIHJvd1xuICAgICAgaWYgKGNvZGVQb2ludCA8IDB4REMwMCkge1xuICAgICAgICBpZiAoKHVuaXRzIC09IDMpID4gLTEpIGJ5dGVzLnB1c2goMHhFRiwgMHhCRiwgMHhCRClcbiAgICAgICAgbGVhZFN1cnJvZ2F0ZSA9IGNvZGVQb2ludFxuICAgICAgICBjb250aW51ZVxuICAgICAgfVxuXG4gICAgICAvLyB2YWxpZCBzdXJyb2dhdGUgcGFpclxuICAgICAgY29kZVBvaW50ID0gKGxlYWRTdXJyb2dhdGUgLSAweEQ4MDAgPDwgMTAgfCBjb2RlUG9pbnQgLSAweERDMDApICsgMHgxMDAwMFxuICAgIH0gZWxzZSBpZiAobGVhZFN1cnJvZ2F0ZSkge1xuICAgICAgLy8gdmFsaWQgYm1wIGNoYXIsIGJ1dCBsYXN0IGNoYXIgd2FzIGEgbGVhZFxuICAgICAgaWYgKCh1bml0cyAtPSAzKSA+IC0xKSBieXRlcy5wdXNoKDB4RUYsIDB4QkYsIDB4QkQpXG4gICAgfVxuXG4gICAgbGVhZFN1cnJvZ2F0ZSA9IG51bGxcblxuICAgIC8vIGVuY29kZSB1dGY4XG4gICAgaWYgKGNvZGVQb2ludCA8IDB4ODApIHtcbiAgICAgIGlmICgodW5pdHMgLT0gMSkgPCAwKSBicmVha1xuICAgICAgYnl0ZXMucHVzaChjb2RlUG9pbnQpXG4gICAgfSBlbHNlIGlmIChjb2RlUG9pbnQgPCAweDgwMCkge1xuICAgICAgaWYgKCh1bml0cyAtPSAyKSA8IDApIGJyZWFrXG4gICAgICBieXRlcy5wdXNoKFxuICAgICAgICBjb2RlUG9pbnQgPj4gMHg2IHwgMHhDMCxcbiAgICAgICAgY29kZVBvaW50ICYgMHgzRiB8IDB4ODBcbiAgICAgIClcbiAgICB9IGVsc2UgaWYgKGNvZGVQb2ludCA8IDB4MTAwMDApIHtcbiAgICAgIGlmICgodW5pdHMgLT0gMykgPCAwKSBicmVha1xuICAgICAgYnl0ZXMucHVzaChcbiAgICAgICAgY29kZVBvaW50ID4+IDB4QyB8IDB4RTAsXG4gICAgICAgIGNvZGVQb2ludCA+PiAweDYgJiAweDNGIHwgMHg4MCxcbiAgICAgICAgY29kZVBvaW50ICYgMHgzRiB8IDB4ODBcbiAgICAgIClcbiAgICB9IGVsc2UgaWYgKGNvZGVQb2ludCA8IDB4MTEwMDAwKSB7XG4gICAgICBpZiAoKHVuaXRzIC09IDQpIDwgMCkgYnJlYWtcbiAgICAgIGJ5dGVzLnB1c2goXG4gICAgICAgIGNvZGVQb2ludCA+PiAweDEyIHwgMHhGMCxcbiAgICAgICAgY29kZVBvaW50ID4+IDB4QyAmIDB4M0YgfCAweDgwLFxuICAgICAgICBjb2RlUG9pbnQgPj4gMHg2ICYgMHgzRiB8IDB4ODAsXG4gICAgICAgIGNvZGVQb2ludCAmIDB4M0YgfCAweDgwXG4gICAgICApXG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBjb2RlIHBvaW50JylcbiAgICB9XG4gIH1cblxuICByZXR1cm4gYnl0ZXNcbn1cblxuZnVuY3Rpb24gYXNjaWlUb0J5dGVzIChzdHIpIHtcbiAgdmFyIGJ5dGVBcnJheSA9IFtdXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgKytpKSB7XG4gICAgLy8gTm9kZSdzIGNvZGUgc2VlbXMgdG8gYmUgZG9pbmcgdGhpcyBhbmQgbm90ICYgMHg3Ri4uXG4gICAgYnl0ZUFycmF5LnB1c2goc3RyLmNoYXJDb2RlQXQoaSkgJiAweEZGKVxuICB9XG4gIHJldHVybiBieXRlQXJyYXlcbn1cblxuZnVuY3Rpb24gdXRmMTZsZVRvQnl0ZXMgKHN0ciwgdW5pdHMpIHtcbiAgdmFyIGMsIGhpLCBsb1xuICB2YXIgYnl0ZUFycmF5ID0gW11cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyArK2kpIHtcbiAgICBpZiAoKHVuaXRzIC09IDIpIDwgMCkgYnJlYWtcblxuICAgIGMgPSBzdHIuY2hhckNvZGVBdChpKVxuICAgIGhpID0gYyA+PiA4XG4gICAgbG8gPSBjICUgMjU2XG4gICAgYnl0ZUFycmF5LnB1c2gobG8pXG4gICAgYnl0ZUFycmF5LnB1c2goaGkpXG4gIH1cblxuICByZXR1cm4gYnl0ZUFycmF5XG59XG5cbmZ1bmN0aW9uIGJhc2U2NFRvQnl0ZXMgKHN0cikge1xuICByZXR1cm4gYmFzZTY0LnRvQnl0ZUFycmF5KGJhc2U2NGNsZWFuKHN0cikpXG59XG5cbmZ1bmN0aW9uIGJsaXRCdWZmZXIgKHNyYywgZHN0LCBvZmZzZXQsIGxlbmd0aCkge1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgKytpKSB7XG4gICAgaWYgKChpICsgb2Zmc2V0ID49IGRzdC5sZW5ndGgpIHx8IChpID49IHNyYy5sZW5ndGgpKSBicmVha1xuICAgIGRzdFtpICsgb2Zmc2V0XSA9IHNyY1tpXVxuICB9XG4gIHJldHVybiBpXG59XG5cbmZ1bmN0aW9uIGlzbmFuICh2YWwpIHtcbiAgcmV0dXJuIHZhbCAhPT0gdmFsIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tc2VsZi1jb21wYXJlXG59XG4iLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cblxuZnVuY3Rpb24gRXZlbnRFbWl0dGVyKCkge1xuICB0aGlzLl9ldmVudHMgPSB0aGlzLl9ldmVudHMgfHwge307XG4gIHRoaXMuX21heExpc3RlbmVycyA9IHRoaXMuX21heExpc3RlbmVycyB8fCB1bmRlZmluZWQ7XG59XG5tb2R1bGUuZXhwb3J0cyA9IEV2ZW50RW1pdHRlcjtcblxuLy8gQmFja3dhcmRzLWNvbXBhdCB3aXRoIG5vZGUgMC4xMC54XG5FdmVudEVtaXR0ZXIuRXZlbnRFbWl0dGVyID0gRXZlbnRFbWl0dGVyO1xuXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLl9ldmVudHMgPSB1bmRlZmluZWQ7XG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLl9tYXhMaXN0ZW5lcnMgPSB1bmRlZmluZWQ7XG5cbi8vIEJ5IGRlZmF1bHQgRXZlbnRFbWl0dGVycyB3aWxsIHByaW50IGEgd2FybmluZyBpZiBtb3JlIHRoYW4gMTAgbGlzdGVuZXJzIGFyZVxuLy8gYWRkZWQgdG8gaXQuIFRoaXMgaXMgYSB1c2VmdWwgZGVmYXVsdCB3aGljaCBoZWxwcyBmaW5kaW5nIG1lbW9yeSBsZWFrcy5cbkV2ZW50RW1pdHRlci5kZWZhdWx0TWF4TGlzdGVuZXJzID0gMTA7XG5cbi8vIE9idmlvdXNseSBub3QgYWxsIEVtaXR0ZXJzIHNob3VsZCBiZSBsaW1pdGVkIHRvIDEwLiBUaGlzIGZ1bmN0aW9uIGFsbG93c1xuLy8gdGhhdCB0byBiZSBpbmNyZWFzZWQuIFNldCB0byB6ZXJvIGZvciB1bmxpbWl0ZWQuXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLnNldE1heExpc3RlbmVycyA9IGZ1bmN0aW9uKG4pIHtcbiAgaWYgKCFpc051bWJlcihuKSB8fCBuIDwgMCB8fCBpc05hTihuKSlcbiAgICB0aHJvdyBUeXBlRXJyb3IoJ24gbXVzdCBiZSBhIHBvc2l0aXZlIG51bWJlcicpO1xuICB0aGlzLl9tYXhMaXN0ZW5lcnMgPSBuO1xuICByZXR1cm4gdGhpcztcbn07XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUuZW1pdCA9IGZ1bmN0aW9uKHR5cGUpIHtcbiAgdmFyIGVyLCBoYW5kbGVyLCBsZW4sIGFyZ3MsIGksIGxpc3RlbmVycztcblxuICBpZiAoIXRoaXMuX2V2ZW50cylcbiAgICB0aGlzLl9ldmVudHMgPSB7fTtcblxuICAvLyBJZiB0aGVyZSBpcyBubyAnZXJyb3InIGV2ZW50IGxpc3RlbmVyIHRoZW4gdGhyb3cuXG4gIGlmICh0eXBlID09PSAnZXJyb3InKSB7XG4gICAgaWYgKCF0aGlzLl9ldmVudHMuZXJyb3IgfHxcbiAgICAgICAgKGlzT2JqZWN0KHRoaXMuX2V2ZW50cy5lcnJvcikgJiYgIXRoaXMuX2V2ZW50cy5lcnJvci5sZW5ndGgpKSB7XG4gICAgICBlciA9IGFyZ3VtZW50c1sxXTtcbiAgICAgIGlmIChlciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIHRocm93IGVyOyAvLyBVbmhhbmRsZWQgJ2Vycm9yJyBldmVudFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gQXQgbGVhc3QgZ2l2ZSBzb21lIGtpbmQgb2YgY29udGV4dCB0byB0aGUgdXNlclxuICAgICAgICB2YXIgZXJyID0gbmV3IEVycm9yKCdVbmNhdWdodCwgdW5zcGVjaWZpZWQgXCJlcnJvclwiIGV2ZW50LiAoJyArIGVyICsgJyknKTtcbiAgICAgICAgZXJyLmNvbnRleHQgPSBlcjtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGhhbmRsZXIgPSB0aGlzLl9ldmVudHNbdHlwZV07XG5cbiAgaWYgKGlzVW5kZWZpbmVkKGhhbmRsZXIpKVxuICAgIHJldHVybiBmYWxzZTtcblxuICBpZiAoaXNGdW5jdGlvbihoYW5kbGVyKSkge1xuICAgIHN3aXRjaCAoYXJndW1lbnRzLmxlbmd0aCkge1xuICAgICAgLy8gZmFzdCBjYXNlc1xuICAgICAgY2FzZSAxOlxuICAgICAgICBoYW5kbGVyLmNhbGwodGhpcyk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAyOlxuICAgICAgICBoYW5kbGVyLmNhbGwodGhpcywgYXJndW1lbnRzWzFdKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDM6XG4gICAgICAgIGhhbmRsZXIuY2FsbCh0aGlzLCBhcmd1bWVudHNbMV0sIGFyZ3VtZW50c1syXSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgLy8gc2xvd2VyXG4gICAgICBkZWZhdWx0OlxuICAgICAgICBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzLCAxKTtcbiAgICAgICAgaGFuZGxlci5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNPYmplY3QoaGFuZGxlcikpIHtcbiAgICBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzLCAxKTtcbiAgICBsaXN0ZW5lcnMgPSBoYW5kbGVyLnNsaWNlKCk7XG4gICAgbGVuID0gbGlzdGVuZXJzLmxlbmd0aDtcbiAgICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspXG4gICAgICBsaXN0ZW5lcnNbaV0uYXBwbHkodGhpcywgYXJncyk7XG4gIH1cblxuICByZXR1cm4gdHJ1ZTtcbn07XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUuYWRkTGlzdGVuZXIgPSBmdW5jdGlvbih0eXBlLCBsaXN0ZW5lcikge1xuICB2YXIgbTtcblxuICBpZiAoIWlzRnVuY3Rpb24obGlzdGVuZXIpKVxuICAgIHRocm93IFR5cGVFcnJvcignbGlzdGVuZXIgbXVzdCBiZSBhIGZ1bmN0aW9uJyk7XG5cbiAgaWYgKCF0aGlzLl9ldmVudHMpXG4gICAgdGhpcy5fZXZlbnRzID0ge307XG5cbiAgLy8gVG8gYXZvaWQgcmVjdXJzaW9uIGluIHRoZSBjYXNlIHRoYXQgdHlwZSA9PT0gXCJuZXdMaXN0ZW5lclwiISBCZWZvcmVcbiAgLy8gYWRkaW5nIGl0IHRvIHRoZSBsaXN0ZW5lcnMsIGZpcnN0IGVtaXQgXCJuZXdMaXN0ZW5lclwiLlxuICBpZiAodGhpcy5fZXZlbnRzLm5ld0xpc3RlbmVyKVxuICAgIHRoaXMuZW1pdCgnbmV3TGlzdGVuZXInLCB0eXBlLFxuICAgICAgICAgICAgICBpc0Z1bmN0aW9uKGxpc3RlbmVyLmxpc3RlbmVyKSA/XG4gICAgICAgICAgICAgIGxpc3RlbmVyLmxpc3RlbmVyIDogbGlzdGVuZXIpO1xuXG4gIGlmICghdGhpcy5fZXZlbnRzW3R5cGVdKVxuICAgIC8vIE9wdGltaXplIHRoZSBjYXNlIG9mIG9uZSBsaXN0ZW5lci4gRG9uJ3QgbmVlZCB0aGUgZXh0cmEgYXJyYXkgb2JqZWN0LlxuICAgIHRoaXMuX2V2ZW50c1t0eXBlXSA9IGxpc3RlbmVyO1xuICBlbHNlIGlmIChpc09iamVjdCh0aGlzLl9ldmVudHNbdHlwZV0pKVxuICAgIC8vIElmIHdlJ3ZlIGFscmVhZHkgZ290IGFuIGFycmF5LCBqdXN0IGFwcGVuZC5cbiAgICB0aGlzLl9ldmVudHNbdHlwZV0ucHVzaChsaXN0ZW5lcik7XG4gIGVsc2VcbiAgICAvLyBBZGRpbmcgdGhlIHNlY29uZCBlbGVtZW50LCBuZWVkIHRvIGNoYW5nZSB0byBhcnJheS5cbiAgICB0aGlzLl9ldmVudHNbdHlwZV0gPSBbdGhpcy5fZXZlbnRzW3R5cGVdLCBsaXN0ZW5lcl07XG5cbiAgLy8gQ2hlY2sgZm9yIGxpc3RlbmVyIGxlYWtcbiAgaWYgKGlzT2JqZWN0KHRoaXMuX2V2ZW50c1t0eXBlXSkgJiYgIXRoaXMuX2V2ZW50c1t0eXBlXS53YXJuZWQpIHtcbiAgICBpZiAoIWlzVW5kZWZpbmVkKHRoaXMuX21heExpc3RlbmVycykpIHtcbiAgICAgIG0gPSB0aGlzLl9tYXhMaXN0ZW5lcnM7XG4gICAgfSBlbHNlIHtcbiAgICAgIG0gPSBFdmVudEVtaXR0ZXIuZGVmYXVsdE1heExpc3RlbmVycztcbiAgICB9XG5cbiAgICBpZiAobSAmJiBtID4gMCAmJiB0aGlzLl9ldmVudHNbdHlwZV0ubGVuZ3RoID4gbSkge1xuICAgICAgdGhpcy5fZXZlbnRzW3R5cGVdLndhcm5lZCA9IHRydWU7XG4gICAgICBjb25zb2xlLmVycm9yKCcobm9kZSkgd2FybmluZzogcG9zc2libGUgRXZlbnRFbWl0dGVyIG1lbW9yeSAnICtcbiAgICAgICAgICAgICAgICAgICAgJ2xlYWsgZGV0ZWN0ZWQuICVkIGxpc3RlbmVycyBhZGRlZC4gJyArXG4gICAgICAgICAgICAgICAgICAgICdVc2UgZW1pdHRlci5zZXRNYXhMaXN0ZW5lcnMoKSB0byBpbmNyZWFzZSBsaW1pdC4nLFxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ldmVudHNbdHlwZV0ubGVuZ3RoKTtcbiAgICAgIGlmICh0eXBlb2YgY29uc29sZS50cmFjZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAvLyBub3Qgc3VwcG9ydGVkIGluIElFIDEwXG4gICAgICAgIGNvbnNvbGUudHJhY2UoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gdGhpcztcbn07XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUub24gPSBFdmVudEVtaXR0ZXIucHJvdG90eXBlLmFkZExpc3RlbmVyO1xuXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLm9uY2UgPSBmdW5jdGlvbih0eXBlLCBsaXN0ZW5lcikge1xuICBpZiAoIWlzRnVuY3Rpb24obGlzdGVuZXIpKVxuICAgIHRocm93IFR5cGVFcnJvcignbGlzdGVuZXIgbXVzdCBiZSBhIGZ1bmN0aW9uJyk7XG5cbiAgdmFyIGZpcmVkID0gZmFsc2U7XG5cbiAgZnVuY3Rpb24gZygpIHtcbiAgICB0aGlzLnJlbW92ZUxpc3RlbmVyKHR5cGUsIGcpO1xuXG4gICAgaWYgKCFmaXJlZCkge1xuICAgICAgZmlyZWQgPSB0cnVlO1xuICAgICAgbGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9XG4gIH1cblxuICBnLmxpc3RlbmVyID0gbGlzdGVuZXI7XG4gIHRoaXMub24odHlwZSwgZyk7XG5cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG4vLyBlbWl0cyBhICdyZW1vdmVMaXN0ZW5lcicgZXZlbnQgaWZmIHRoZSBsaXN0ZW5lciB3YXMgcmVtb3ZlZFxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5yZW1vdmVMaXN0ZW5lciA9IGZ1bmN0aW9uKHR5cGUsIGxpc3RlbmVyKSB7XG4gIHZhciBsaXN0LCBwb3NpdGlvbiwgbGVuZ3RoLCBpO1xuXG4gIGlmICghaXNGdW5jdGlvbihsaXN0ZW5lcikpXG4gICAgdGhyb3cgVHlwZUVycm9yKCdsaXN0ZW5lciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcblxuICBpZiAoIXRoaXMuX2V2ZW50cyB8fCAhdGhpcy5fZXZlbnRzW3R5cGVdKVxuICAgIHJldHVybiB0aGlzO1xuXG4gIGxpc3QgPSB0aGlzLl9ldmVudHNbdHlwZV07XG4gIGxlbmd0aCA9IGxpc3QubGVuZ3RoO1xuICBwb3NpdGlvbiA9IC0xO1xuXG4gIGlmIChsaXN0ID09PSBsaXN0ZW5lciB8fFxuICAgICAgKGlzRnVuY3Rpb24obGlzdC5saXN0ZW5lcikgJiYgbGlzdC5saXN0ZW5lciA9PT0gbGlzdGVuZXIpKSB7XG4gICAgZGVsZXRlIHRoaXMuX2V2ZW50c1t0eXBlXTtcbiAgICBpZiAodGhpcy5fZXZlbnRzLnJlbW92ZUxpc3RlbmVyKVxuICAgICAgdGhpcy5lbWl0KCdyZW1vdmVMaXN0ZW5lcicsIHR5cGUsIGxpc3RlbmVyKTtcblxuICB9IGVsc2UgaWYgKGlzT2JqZWN0KGxpc3QpKSB7XG4gICAgZm9yIChpID0gbGVuZ3RoOyBpLS0gPiAwOykge1xuICAgICAgaWYgKGxpc3RbaV0gPT09IGxpc3RlbmVyIHx8XG4gICAgICAgICAgKGxpc3RbaV0ubGlzdGVuZXIgJiYgbGlzdFtpXS5saXN0ZW5lciA9PT0gbGlzdGVuZXIpKSB7XG4gICAgICAgIHBvc2l0aW9uID0gaTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHBvc2l0aW9uIDwgMClcbiAgICAgIHJldHVybiB0aGlzO1xuXG4gICAgaWYgKGxpc3QubGVuZ3RoID09PSAxKSB7XG4gICAgICBsaXN0Lmxlbmd0aCA9IDA7XG4gICAgICBkZWxldGUgdGhpcy5fZXZlbnRzW3R5cGVdO1xuICAgIH0gZWxzZSB7XG4gICAgICBsaXN0LnNwbGljZShwb3NpdGlvbiwgMSk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2V2ZW50cy5yZW1vdmVMaXN0ZW5lcilcbiAgICAgIHRoaXMuZW1pdCgncmVtb3ZlTGlzdGVuZXInLCB0eXBlLCBsaXN0ZW5lcik7XG4gIH1cblxuICByZXR1cm4gdGhpcztcbn07XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUucmVtb3ZlQWxsTGlzdGVuZXJzID0gZnVuY3Rpb24odHlwZSkge1xuICB2YXIga2V5LCBsaXN0ZW5lcnM7XG5cbiAgaWYgKCF0aGlzLl9ldmVudHMpXG4gICAgcmV0dXJuIHRoaXM7XG5cbiAgLy8gbm90IGxpc3RlbmluZyBmb3IgcmVtb3ZlTGlzdGVuZXIsIG5vIG5lZWQgdG8gZW1pdFxuICBpZiAoIXRoaXMuX2V2ZW50cy5yZW1vdmVMaXN0ZW5lcikge1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAwKVxuICAgICAgdGhpcy5fZXZlbnRzID0ge307XG4gICAgZWxzZSBpZiAodGhpcy5fZXZlbnRzW3R5cGVdKVxuICAgICAgZGVsZXRlIHRoaXMuX2V2ZW50c1t0eXBlXTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8vIGVtaXQgcmVtb3ZlTGlzdGVuZXIgZm9yIGFsbCBsaXN0ZW5lcnMgb24gYWxsIGV2ZW50c1xuICBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGZvciAoa2V5IGluIHRoaXMuX2V2ZW50cykge1xuICAgICAgaWYgKGtleSA9PT0gJ3JlbW92ZUxpc3RlbmVyJykgY29udGludWU7XG4gICAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycyhrZXkpO1xuICAgIH1cbiAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycygncmVtb3ZlTGlzdGVuZXInKTtcbiAgICB0aGlzLl9ldmVudHMgPSB7fTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIGxpc3RlbmVycyA9IHRoaXMuX2V2ZW50c1t0eXBlXTtcblxuICBpZiAoaXNGdW5jdGlvbihsaXN0ZW5lcnMpKSB7XG4gICAgdGhpcy5yZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcnMpO1xuICB9IGVsc2UgaWYgKGxpc3RlbmVycykge1xuICAgIC8vIExJRk8gb3JkZXJcbiAgICB3aGlsZSAobGlzdGVuZXJzLmxlbmd0aClcbiAgICAgIHRoaXMucmVtb3ZlTGlzdGVuZXIodHlwZSwgbGlzdGVuZXJzW2xpc3RlbmVycy5sZW5ndGggLSAxXSk7XG4gIH1cbiAgZGVsZXRlIHRoaXMuX2V2ZW50c1t0eXBlXTtcblxuICByZXR1cm4gdGhpcztcbn07XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUubGlzdGVuZXJzID0gZnVuY3Rpb24odHlwZSkge1xuICB2YXIgcmV0O1xuICBpZiAoIXRoaXMuX2V2ZW50cyB8fCAhdGhpcy5fZXZlbnRzW3R5cGVdKVxuICAgIHJldCA9IFtdO1xuICBlbHNlIGlmIChpc0Z1bmN0aW9uKHRoaXMuX2V2ZW50c1t0eXBlXSkpXG4gICAgcmV0ID0gW3RoaXMuX2V2ZW50c1t0eXBlXV07XG4gIGVsc2VcbiAgICByZXQgPSB0aGlzLl9ldmVudHNbdHlwZV0uc2xpY2UoKTtcbiAgcmV0dXJuIHJldDtcbn07XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUubGlzdGVuZXJDb3VudCA9IGZ1bmN0aW9uKHR5cGUpIHtcbiAgaWYgKHRoaXMuX2V2ZW50cykge1xuICAgIHZhciBldmxpc3RlbmVyID0gdGhpcy5fZXZlbnRzW3R5cGVdO1xuXG4gICAgaWYgKGlzRnVuY3Rpb24oZXZsaXN0ZW5lcikpXG4gICAgICByZXR1cm4gMTtcbiAgICBlbHNlIGlmIChldmxpc3RlbmVyKVxuICAgICAgcmV0dXJuIGV2bGlzdGVuZXIubGVuZ3RoO1xuICB9XG4gIHJldHVybiAwO1xufTtcblxuRXZlbnRFbWl0dGVyLmxpc3RlbmVyQ291bnQgPSBmdW5jdGlvbihlbWl0dGVyLCB0eXBlKSB7XG4gIHJldHVybiBlbWl0dGVyLmxpc3RlbmVyQ291bnQodHlwZSk7XG59O1xuXG5mdW5jdGlvbiBpc0Z1bmN0aW9uKGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ2Z1bmN0aW9uJztcbn1cblxuZnVuY3Rpb24gaXNOdW1iZXIoYXJnKSB7XG4gIHJldHVybiB0eXBlb2YgYXJnID09PSAnbnVtYmVyJztcbn1cblxuZnVuY3Rpb24gaXNPYmplY3QoYXJnKSB7XG4gIHJldHVybiB0eXBlb2YgYXJnID09PSAnb2JqZWN0JyAmJiBhcmcgIT09IG51bGw7XG59XG5cbmZ1bmN0aW9uIGlzVW5kZWZpbmVkKGFyZykge1xuICByZXR1cm4gYXJnID09PSB2b2lkIDA7XG59XG4iLCIvL1xuLy8gRmlsZVJlYWRlclxuLy9cbi8vIGh0dHA6Ly93d3cudzMub3JnL1RSL0ZpbGVBUEkvI2Rmbi1maWxlcmVhZGVyXG4vLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi9ET00vRmlsZVJlYWRlclxuKGZ1bmN0aW9uICgpIHtcbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgdmFyIGZzID0gcmVxdWlyZShcImZzXCIpXG4gICAgLCBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlclxuICAgIDtcblxuICBmdW5jdGlvbiBkb29wKGZuLCBhcmdzLCBjb250ZXh0KSB7XG4gICAgaWYgKCdmdW5jdGlvbicgPT09IHR5cGVvZiBmbikge1xuICAgICAgZm4uYXBwbHkoY29udGV4dCwgYXJncyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gdG9EYXRhVXJsKGRhdGEsIHR5cGUpIHtcbiAgICAvLyB2YXIgZGF0YSA9IHNlbGYucmVzdWx0O1xuICAgIHZhciBkYXRhVXJsID0gJ2RhdGE6JztcblxuICAgIGlmICh0eXBlKSB7XG4gICAgICBkYXRhVXJsICs9IHR5cGUgKyAnOyc7XG4gICAgfVxuXG4gICAgaWYgKC90ZXh0L2kudGVzdCh0eXBlKSkge1xuICAgICAgZGF0YVVybCArPSAnY2hhcnNldD11dGYtOCwnO1xuICAgICAgZGF0YVVybCArPSBkYXRhLnRvU3RyaW5nKCd1dGY4Jyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRhdGFVcmwgKz0gJ2Jhc2U2NCwnO1xuICAgICAgZGF0YVVybCArPSBkYXRhLnRvU3RyaW5nKCdiYXNlNjQnKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZGF0YVVybDtcbiAgfVxuXG4gIGZ1bmN0aW9uIG1hcERhdGFUb0Zvcm1hdChmaWxlLCBkYXRhLCBmb3JtYXQsIGVuY29kaW5nKSB7XG4gICAgLy8gdmFyIGRhdGEgPSBzZWxmLnJlc3VsdDtcblxuICAgIHN3aXRjaChmb3JtYXQpIHtcbiAgICAgIGNhc2UgJ2J1ZmZlcic6XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICAgIHJldHVybiBkYXRhLnRvU3RyaW5nKCdiaW5hcnknKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdkYXRhVXJsJzpcbiAgICAgICAgcmV0dXJuIHRvRGF0YVVybChkYXRhLCBmaWxlLnR5cGUpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ3RleHQnOlxuICAgICAgICByZXR1cm4gZGF0YS50b1N0cmluZyhlbmNvZGluZyB8fCAndXRmOCcpO1xuICAgICAgICBicmVhaztcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBGaWxlUmVhZGVyKCkge1xuICAgIHZhciBzZWxmID0gdGhpcyxcbiAgICAgIGVtaXR0ZXIgPSBuZXcgRXZlbnRFbWl0dGVyLFxuICAgICAgZmlsZTtcblxuICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lciA9IGZ1bmN0aW9uIChvbiwgY2FsbGJhY2spIHtcbiAgICAgIGVtaXR0ZXIub24ob24sIGNhbGxiYWNrKTtcbiAgICB9O1xuICAgIHNlbGYucmVtb3ZlRXZlbnRMaXN0ZW5lciA9IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICAgICAgZW1pdHRlci5yZW1vdmVMaXN0ZW5lcihjYWxsYmFjayk7XG4gICAgfVxuICAgIHNlbGYuZGlzcGF0Y2hFdmVudCA9IGZ1bmN0aW9uIChvbikge1xuICAgICAgZW1pdHRlci5lbWl0KG9uKTtcbiAgICB9XG5cbiAgICBzZWxmLkVNUFRZID0gMDtcbiAgICBzZWxmLkxPQURJTkcgPSAxO1xuICAgIHNlbGYuRE9ORSA9IDI7XG5cbiAgICBzZWxmLmVycm9yID0gdW5kZWZpbmVkOyAgICAgICAgIC8vIFJlYWQgb25seVxuICAgIHNlbGYucmVhZHlTdGF0ZSA9IHNlbGYuRU1QVFk7ICAgLy8gUmVhZCBvbmx5XG4gICAgc2VsZi5yZXN1bHQgPSB1bmRlZmluZWQ7ICAgICAgICAvLyBSb2FkIG9ubHlcblxuICAgIC8vIG5vbi1zdGFuZGFyZFxuICAgIHNlbGYub24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICBlbWl0dGVyLm9uLmFwcGx5KGVtaXR0ZXIsIGFyZ3VtZW50cyk7XG4gICAgfVxuICAgIHNlbGYubm9kZUNodW5rZWRFbmNvZGluZyA9IGZhbHNlO1xuICAgIHNlbGYuc2V0Tm9kZUNodW5rZWRFbmNvZGluZyA9IGZ1bmN0aW9uICh2YWwpIHtcbiAgICAgIHNlbGYubm9kZUNodW5rZWRFbmNvZGluZyA9IHZhbDtcbiAgICB9O1xuICAgIC8vIGVuZCBub24tc3RhbmRhcmRcblxuXG5cbiAgICAvLyBXaGF0ZXZlciB0aGUgZmlsZSBvYmplY3QgaXMsIHR1cm4gaXQgaW50byBhIE5vZGUuSlMgRmlsZS5TdHJlYW1cbiAgICBmdW5jdGlvbiBjcmVhdGVGaWxlU3RyZWFtKCkge1xuICAgICAgdmFyIHN0cmVhbSA9IG5ldyBFdmVudEVtaXR0ZXIoKSxcbiAgICAgICAgY2h1bmtlZCA9IHNlbGYubm9kZUNodW5rZWRFbmNvZGluZztcblxuICAgICAgLy8gYXR0ZW1wdCB0byBtYWtlIHRoZSBsZW5ndGggY29tcHV0YWJsZVxuICAgICAgaWYgKCFmaWxlLnNpemUgJiYgY2h1bmtlZCAmJiBmaWxlLnBhdGgpIHtcbiAgICAgICAgZnMuc3RhdChmaWxlLnBhdGgsIGZ1bmN0aW9uIChlcnIsIHN0YXQpIHtcbiAgICAgICAgICBmaWxlLnNpemUgPSBzdGF0LnNpemU7XG4gICAgICAgICAgZmlsZS5sYXN0TW9kaWZpZWREYXRlID0gc3RhdC5tdGltZTtcbiAgICAgICAgfSk7XG4gICAgICB9XG5cblxuICAgICAgLy8gVGhlIHN0cmVhbSBleGlzdHMsIGRvIG5vdGhpbmcgbW9yZVxuICAgICAgaWYgKGZpbGUuc3RyZWFtKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuXG4gICAgICAvLyBDcmVhdGUgYSByZWFkIHN0cmVhbSBmcm9tIGEgYnVmZmVyXG4gICAgICBpZiAoZmlsZS5idWZmZXIpIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgc3RyZWFtLmVtaXQoJ2RhdGEnLCBmaWxlLmJ1ZmZlcik7XG4gICAgICAgICAgc3RyZWFtLmVtaXQoJ2VuZCcpO1xuICAgICAgICB9KTtcbiAgICAgICAgZmlsZS5zdHJlYW0gPSBzdHJlYW07XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuXG4gICAgICAvLyBDcmVhdGUgYSByZWFkIHN0cmVhbSBmcm9tIGEgZmlsZVxuICAgICAgaWYgKGZpbGUucGF0aCkge1xuICAgICAgICAvLyBUT0RPIHVybFxuICAgICAgICBpZiAoIWNodW5rZWQpIHtcbiAgICAgICAgICBmcy5yZWFkRmlsZShmaWxlLnBhdGgsIGZ1bmN0aW9uIChlcnIsIGRhdGEpIHtcbiAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgc3RyZWFtLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgICAgIHN0cmVhbS5lbWl0KCdkYXRhJywgZGF0YSk7XG4gICAgICAgICAgICAgIHN0cmVhbS5lbWl0KCdlbmQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGZpbGUuc3RyZWFtID0gc3RyZWFtO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRPRE8gZG9uJ3QgZHVwbGljYXRlIHRoaXMgY29kZSBoZXJlLFxuICAgICAgICAvLyBleHBvc2UgYSBtZXRob2QgaW4gRmlsZSBpbnN0ZWFkXG4gICAgICAgIGZpbGUuc3RyZWFtID0gZnMuY3JlYXRlUmVhZFN0cmVhbShmaWxlLnBhdGgpO1xuICAgICAgfVxuICAgIH1cblxuXG5cbiAgICAvLyBiZWZvcmUgYW55IG90aGVyIGxpc3RlbmVycyBhcmUgYWRkZWRcbiAgICBlbWl0dGVyLm9uKCdhYm9ydCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYucmVhZHlTdGF0ZSA9IHNlbGYuRE9ORTtcbiAgICB9KTtcblxuXG5cbiAgICAvLyBNYXAgYGVycm9yYCwgYHByb2dyZXNzYCwgYGxvYWRgLCBhbmQgYGxvYWRlbmRgXG4gICAgZnVuY3Rpb24gbWFwU3RyZWFtVG9FbWl0dGVyKGZvcm1hdCwgZW5jb2RpbmcpIHtcbiAgICAgIHZhciBzdHJlYW0gPSBmaWxlLnN0cmVhbSxcbiAgICAgICAgYnVmZmVycyA9IFtdLFxuICAgICAgICBjaHVua2VkID0gc2VsZi5ub2RlQ2h1bmtlZEVuY29kaW5nO1xuXG4gICAgICBidWZmZXJzLmRhdGFMZW5ndGggPSAwO1xuXG4gICAgICBzdHJlYW0ub24oJ2Vycm9yJywgZnVuY3Rpb24gKGVycikge1xuICAgICAgICBpZiAoc2VsZi5ET05FID09PSBzZWxmLnJlYWR5U3RhdGUpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZWxmLnJlYWR5U3RhdGUgPSBzZWxmLkRPTkU7XG4gICAgICAgIHNlbGYuZXJyb3IgPSBlcnI7XG4gICAgICAgIGVtaXR0ZXIuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgfSk7XG5cbiAgICAgIHN0cmVhbS5vbignZGF0YScsIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgIGlmIChzZWxmLkRPTkUgPT09IHNlbGYucmVhZHlTdGF0ZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGJ1ZmZlcnMuZGF0YUxlbmd0aCArPSBkYXRhLmxlbmd0aDtcbiAgICAgICAgYnVmZmVycy5wdXNoKGRhdGEpO1xuXG4gICAgICAgIGVtaXR0ZXIuZW1pdCgncHJvZ3Jlc3MnLCB7XG4gICAgICAgICAgLy8gZnMuc3RhdCB3aWxsIHByb2JhYmx5IGNvbXBsZXRlIGJlZm9yZSB0aGlzXG4gICAgICAgICAgLy8gYnV0IHBvc3NpYmx5IGl0IHdpbGwgbm90LCBoZW5jZSB0aGUgY2hlY2tcbiAgICAgICAgICBsZW5ndGhDb21wdXRhYmxlOiAoIWlzTmFOKGZpbGUuc2l6ZSkpID8gdHJ1ZSA6IGZhbHNlLFxuICAgICAgICAgIGxvYWRlZDogYnVmZmVycy5kYXRhTGVuZ3RoLFxuICAgICAgICAgIHRvdGFsOiBmaWxlLnNpemVcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZW1pdHRlci5lbWl0KCdkYXRhJywgZGF0YSk7XG4gICAgICB9KTtcblxuICAgICAgc3RyZWFtLm9uKCdlbmQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmIChzZWxmLkRPTkUgPT09IHNlbGYucmVhZHlTdGF0ZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBkYXRhO1xuXG4gICAgICAgIGlmIChidWZmZXJzLmxlbmd0aCA+IDEgKSB7XG4gICAgICAgICAgZGF0YSA9IEJ1ZmZlci5jb25jYXQoYnVmZmVycyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGF0YSA9IGJ1ZmZlcnNbMF07XG4gICAgICAgIH1cblxuICAgICAgICBzZWxmLnJlYWR5U3RhdGUgPSBzZWxmLkRPTkU7XG4gICAgICAgIHNlbGYucmVzdWx0ID0gbWFwRGF0YVRvRm9ybWF0KGZpbGUsIGRhdGEsIGZvcm1hdCwgZW5jb2RpbmcpO1xuICAgICAgICBlbWl0dGVyLmVtaXQoJ2xvYWQnLCB7XG4gICAgICAgICAgdGFyZ2V0OiB7XG4gICAgICAgICAgICAvLyBub24tc3RhbmRhcmRcbiAgICAgICAgICAgIG5vZGVCdWZmZXJSZXN1bHQ6IGRhdGEsXG4gICAgICAgICAgICByZXN1bHQ6IHNlbGYucmVzdWx0XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICBlbWl0dGVyLmVtaXQoJ2xvYWRlbmQnKTtcbiAgICAgIH0pO1xuICAgIH1cblxuXG4gICAgLy8gQWJvcnQgaXMgb3ZlcndyaXR0ZW4gYnkgcmVhZEFzWHl6XG4gICAgc2VsZi5hYm9ydCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLnJlYWRTdGF0ZSA9PSBzZWxmLkRPTkUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2VsZi5yZWFkeVN0YXRlID0gc2VsZi5ET05FO1xuICAgICAgZW1pdHRlci5lbWl0KCdhYm9ydCcpO1xuICAgIH07XG5cblxuXG4gICAgLy8gXG4gICAgZnVuY3Rpb24gbWFwVXNlckV2ZW50cygpIHtcbiAgICAgIGVtaXR0ZXIub24oJ3N0YXJ0JywgZnVuY3Rpb24gKCkge1xuICAgICAgICBkb29wKHNlbGYub25sb2Fkc3RhcnQsIGFyZ3VtZW50cyk7XG4gICAgICB9KTtcbiAgICAgIGVtaXR0ZXIub24oJ3Byb2dyZXNzJywgZnVuY3Rpb24gKCkge1xuICAgICAgICBkb29wKHNlbGYub25wcm9ncmVzcywgYXJndW1lbnRzKTtcbiAgICAgIH0pO1xuICAgICAgZW1pdHRlci5vbignZXJyb3InLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIC8vIFRPRE8gdHJhbnNsYXRlIHRvIEZpbGVFcnJvclxuICAgICAgICBpZiAoc2VsZi5vbmVycm9yKSB7XG4gICAgICAgICAgc2VsZi5vbmVycm9yKGVycik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKCFlbWl0dGVyLmxpc3RlbmVycy5lcnJvciB8fCAhZW1pdHRlci5saXN0ZW5lcnMuZXJyb3IubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGVtaXR0ZXIub24oJ2xvYWQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGRvb3Aoc2VsZi5vbmxvYWQsIGFyZ3VtZW50cyk7XG4gICAgICB9KTtcbiAgICAgIGVtaXR0ZXIub24oJ2VuZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZG9vcChzZWxmLm9ubG9hZGVuZCwgYXJndW1lbnRzKTtcbiAgICAgIH0pO1xuICAgICAgZW1pdHRlci5vbignYWJvcnQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGRvb3Aoc2VsZi5vbmFib3J0LCBhcmd1bWVudHMpO1xuICAgICAgfSk7XG4gICAgfVxuXG5cblxuICAgIGZ1bmN0aW9uIHJlYWRGaWxlKF9maWxlLCBmb3JtYXQsIGVuY29kaW5nKSB7XG4gICAgICBmaWxlID0gX2ZpbGU7XG4gICAgICBpZiAoIWZpbGUgfHwgIWZpbGUubmFtZSB8fCAhKGZpbGUucGF0aCB8fCBmaWxlLnN0cmVhbSB8fCBmaWxlLmJ1ZmZlcikpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiY2Fubm90IHJlYWQgYXMgRmlsZTogXCIgKyBKU09OLnN0cmluZ2lmeShmaWxlKSk7XG4gICAgICB9XG4gICAgICBpZiAoMCAhPT0gc2VsZi5yZWFkeVN0YXRlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiYWxyZWFkeSBsb2FkaW5nLCByZXF1ZXN0IHRvIGNoYW5nZSBmb3JtYXQgaWdub3JlZFwiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyAncHJvY2Vzcy5uZXh0VGljaycgZG9lcyBub3QgZW5zdXJlIG9yZGVyLCAoaS5lLiBhbiBmcy5zdGF0IHF1ZXVlZCBsYXRlciBtYXkgcmV0dXJuIGZhc3RlcilcbiAgICAgIC8vIGJ1dCBgb25sb2Fkc3RhcnRgIG11c3QgY29tZSBiZWZvcmUgdGhlIGZpcnN0IGBkYXRhYCBldmVudCBhbmQgbXVzdCBiZSBhc3luY2hyb25vdXMuXG4gICAgICAvLyBIZW5jZSB3ZSB3YXN0ZSBhIHNpbmdsZSB0aWNrIHdhaXRpbmdcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICBzZWxmLnJlYWR5U3RhdGUgPSBzZWxmLkxPQURJTkc7XG4gICAgICAgIGVtaXR0ZXIuZW1pdCgnbG9hZHN0YXJ0Jyk7XG4gICAgICAgIGNyZWF0ZUZpbGVTdHJlYW0oKTtcbiAgICAgICAgbWFwU3RyZWFtVG9FbWl0dGVyKGZvcm1hdCwgZW5jb2RpbmcpO1xuICAgICAgICBtYXBVc2VyRXZlbnRzKCk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBzZWxmLnJlYWRBc0FycmF5QnVmZmVyID0gZnVuY3Rpb24gKGZpbGUpIHtcbiAgICAgIHJlYWRGaWxlKGZpbGUsICdidWZmZXInKTtcbiAgICB9O1xuICAgIHNlbGYucmVhZEFzQmluYXJ5U3RyaW5nID0gZnVuY3Rpb24gKGZpbGUpIHtcbiAgICAgIHJlYWRGaWxlKGZpbGUsICdiaW5hcnknKTtcbiAgICB9O1xuICAgIHNlbGYucmVhZEFzRGF0YVVSTCA9IGZ1bmN0aW9uIChmaWxlKSB7XG4gICAgICByZWFkRmlsZShmaWxlLCAnZGF0YVVybCcpO1xuICAgIH07XG4gICAgc2VsZi5yZWFkQXNUZXh0ID0gZnVuY3Rpb24gKGZpbGUsIGVuY29kaW5nKSB7XG4gICAgICByZWFkRmlsZShmaWxlLCAndGV4dCcsIGVuY29kaW5nKTtcbiAgICB9O1xuICB9XG5cbiAgbW9kdWxlLmV4cG9ydHMgPSBGaWxlUmVhZGVyO1xufSgpKTtcbiIsImV4cG9ydHMucmVhZCA9IGZ1bmN0aW9uIChidWZmZXIsIG9mZnNldCwgaXNMRSwgbUxlbiwgbkJ5dGVzKSB7XG4gIHZhciBlLCBtXG4gIHZhciBlTGVuID0gbkJ5dGVzICogOCAtIG1MZW4gLSAxXG4gIHZhciBlTWF4ID0gKDEgPDwgZUxlbikgLSAxXG4gIHZhciBlQmlhcyA9IGVNYXggPj4gMVxuICB2YXIgbkJpdHMgPSAtN1xuICB2YXIgaSA9IGlzTEUgPyAobkJ5dGVzIC0gMSkgOiAwXG4gIHZhciBkID0gaXNMRSA/IC0xIDogMVxuICB2YXIgcyA9IGJ1ZmZlcltvZmZzZXQgKyBpXVxuXG4gIGkgKz0gZFxuXG4gIGUgPSBzICYgKCgxIDw8ICgtbkJpdHMpKSAtIDEpXG4gIHMgPj49ICgtbkJpdHMpXG4gIG5CaXRzICs9IGVMZW5cbiAgZm9yICg7IG5CaXRzID4gMDsgZSA9IGUgKiAyNTYgKyBidWZmZXJbb2Zmc2V0ICsgaV0sIGkgKz0gZCwgbkJpdHMgLT0gOCkge31cblxuICBtID0gZSAmICgoMSA8PCAoLW5CaXRzKSkgLSAxKVxuICBlID4+PSAoLW5CaXRzKVxuICBuQml0cyArPSBtTGVuXG4gIGZvciAoOyBuQml0cyA+IDA7IG0gPSBtICogMjU2ICsgYnVmZmVyW29mZnNldCArIGldLCBpICs9IGQsIG5CaXRzIC09IDgpIHt9XG5cbiAgaWYgKGUgPT09IDApIHtcbiAgICBlID0gMSAtIGVCaWFzXG4gIH0gZWxzZSBpZiAoZSA9PT0gZU1heCkge1xuICAgIHJldHVybiBtID8gTmFOIDogKChzID8gLTEgOiAxKSAqIEluZmluaXR5KVxuICB9IGVsc2Uge1xuICAgIG0gPSBtICsgTWF0aC5wb3coMiwgbUxlbilcbiAgICBlID0gZSAtIGVCaWFzXG4gIH1cbiAgcmV0dXJuIChzID8gLTEgOiAxKSAqIG0gKiBNYXRoLnBvdygyLCBlIC0gbUxlbilcbn1cblxuZXhwb3J0cy53cml0ZSA9IGZ1bmN0aW9uIChidWZmZXIsIHZhbHVlLCBvZmZzZXQsIGlzTEUsIG1MZW4sIG5CeXRlcykge1xuICB2YXIgZSwgbSwgY1xuICB2YXIgZUxlbiA9IG5CeXRlcyAqIDggLSBtTGVuIC0gMVxuICB2YXIgZU1heCA9ICgxIDw8IGVMZW4pIC0gMVxuICB2YXIgZUJpYXMgPSBlTWF4ID4+IDFcbiAgdmFyIHJ0ID0gKG1MZW4gPT09IDIzID8gTWF0aC5wb3coMiwgLTI0KSAtIE1hdGgucG93KDIsIC03NykgOiAwKVxuICB2YXIgaSA9IGlzTEUgPyAwIDogKG5CeXRlcyAtIDEpXG4gIHZhciBkID0gaXNMRSA/IDEgOiAtMVxuICB2YXIgcyA9IHZhbHVlIDwgMCB8fCAodmFsdWUgPT09IDAgJiYgMSAvIHZhbHVlIDwgMCkgPyAxIDogMFxuXG4gIHZhbHVlID0gTWF0aC5hYnModmFsdWUpXG5cbiAgaWYgKGlzTmFOKHZhbHVlKSB8fCB2YWx1ZSA9PT0gSW5maW5pdHkpIHtcbiAgICBtID0gaXNOYU4odmFsdWUpID8gMSA6IDBcbiAgICBlID0gZU1heFxuICB9IGVsc2Uge1xuICAgIGUgPSBNYXRoLmZsb29yKE1hdGgubG9nKHZhbHVlKSAvIE1hdGguTE4yKVxuICAgIGlmICh2YWx1ZSAqIChjID0gTWF0aC5wb3coMiwgLWUpKSA8IDEpIHtcbiAgICAgIGUtLVxuICAgICAgYyAqPSAyXG4gICAgfVxuICAgIGlmIChlICsgZUJpYXMgPj0gMSkge1xuICAgICAgdmFsdWUgKz0gcnQgLyBjXG4gICAgfSBlbHNlIHtcbiAgICAgIHZhbHVlICs9IHJ0ICogTWF0aC5wb3coMiwgMSAtIGVCaWFzKVxuICAgIH1cbiAgICBpZiAodmFsdWUgKiBjID49IDIpIHtcbiAgICAgIGUrK1xuICAgICAgYyAvPSAyXG4gICAgfVxuXG4gICAgaWYgKGUgKyBlQmlhcyA+PSBlTWF4KSB7XG4gICAgICBtID0gMFxuICAgICAgZSA9IGVNYXhcbiAgICB9IGVsc2UgaWYgKGUgKyBlQmlhcyA+PSAxKSB7XG4gICAgICBtID0gKHZhbHVlICogYyAtIDEpICogTWF0aC5wb3coMiwgbUxlbilcbiAgICAgIGUgPSBlICsgZUJpYXNcbiAgICB9IGVsc2Uge1xuICAgICAgbSA9IHZhbHVlICogTWF0aC5wb3coMiwgZUJpYXMgLSAxKSAqIE1hdGgucG93KDIsIG1MZW4pXG4gICAgICBlID0gMFxuICAgIH1cbiAgfVxuXG4gIGZvciAoOyBtTGVuID49IDg7IGJ1ZmZlcltvZmZzZXQgKyBpXSA9IG0gJiAweGZmLCBpICs9IGQsIG0gLz0gMjU2LCBtTGVuIC09IDgpIHt9XG5cbiAgZSA9IChlIDw8IG1MZW4pIHwgbVxuICBlTGVuICs9IG1MZW5cbiAgZm9yICg7IGVMZW4gPiAwOyBidWZmZXJbb2Zmc2V0ICsgaV0gPSBlICYgMHhmZiwgaSArPSBkLCBlIC89IDI1NiwgZUxlbiAtPSA4KSB7fVxuXG4gIGJ1ZmZlcltvZmZzZXQgKyBpIC0gZF0gfD0gcyAqIDEyOFxufVxuIiwidmFyIHRvU3RyaW5nID0ge30udG9TdHJpbmc7XG5cbm1vZHVsZS5leHBvcnRzID0gQXJyYXkuaXNBcnJheSB8fCBmdW5jdGlvbiAoYXJyKSB7XG4gIHJldHVybiB0b1N0cmluZy5jYWxsKGFycikgPT0gJ1tvYmplY3QgQXJyYXldJztcbn07XG4iLCIvLyBzaGltIGZvciB1c2luZyBwcm9jZXNzIGluIGJyb3dzZXJcbnZhciBwcm9jZXNzID0gbW9kdWxlLmV4cG9ydHMgPSB7fTtcblxuLy8gY2FjaGVkIGZyb20gd2hhdGV2ZXIgZ2xvYmFsIGlzIHByZXNlbnQgc28gdGhhdCB0ZXN0IHJ1bm5lcnMgdGhhdCBzdHViIGl0XG4vLyBkb24ndCBicmVhayB0aGluZ3MuICBCdXQgd2UgbmVlZCB0byB3cmFwIGl0IGluIGEgdHJ5IGNhdGNoIGluIGNhc2UgaXQgaXNcbi8vIHdyYXBwZWQgaW4gc3RyaWN0IG1vZGUgY29kZSB3aGljaCBkb2Vzbid0IGRlZmluZSBhbnkgZ2xvYmFscy4gIEl0J3MgaW5zaWRlIGFcbi8vIGZ1bmN0aW9uIGJlY2F1c2UgdHJ5L2NhdGNoZXMgZGVvcHRpbWl6ZSBpbiBjZXJ0YWluIGVuZ2luZXMuXG5cbnZhciBjYWNoZWRTZXRUaW1lb3V0O1xudmFyIGNhY2hlZENsZWFyVGltZW91dDtcblxuZnVuY3Rpb24gZGVmYXVsdFNldFRpbW91dCgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3NldFRpbWVvdXQgaGFzIG5vdCBiZWVuIGRlZmluZWQnKTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRDbGVhclRpbWVvdXQgKCkge1xuICAgIHRocm93IG5ldyBFcnJvcignY2xlYXJUaW1lb3V0IGhhcyBub3QgYmVlbiBkZWZpbmVkJyk7XG59XG4oZnVuY3Rpb24gKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGlmICh0eXBlb2Ygc2V0VGltZW91dCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgY2FjaGVkU2V0VGltZW91dCA9IHNldFRpbWVvdXQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYWNoZWRTZXRUaW1lb3V0ID0gZGVmYXVsdFNldFRpbW91dDtcbiAgICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY2FjaGVkU2V0VGltZW91dCA9IGRlZmF1bHRTZXRUaW1vdXQ7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIGlmICh0eXBlb2YgY2xlYXJUaW1lb3V0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjYWNoZWRDbGVhclRpbWVvdXQgPSBjbGVhclRpbWVvdXQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYWNoZWRDbGVhclRpbWVvdXQgPSBkZWZhdWx0Q2xlYXJUaW1lb3V0O1xuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjYWNoZWRDbGVhclRpbWVvdXQgPSBkZWZhdWx0Q2xlYXJUaW1lb3V0O1xuICAgIH1cbn0gKCkpXG5mdW5jdGlvbiBydW5UaW1lb3V0KGZ1bikge1xuICAgIGlmIChjYWNoZWRTZXRUaW1lb3V0ID09PSBzZXRUaW1lb3V0KSB7XG4gICAgICAgIC8vbm9ybWFsIGVudmlyb21lbnRzIGluIHNhbmUgc2l0dWF0aW9uc1xuICAgICAgICByZXR1cm4gc2V0VGltZW91dChmdW4sIDApO1xuICAgIH1cbiAgICAvLyBpZiBzZXRUaW1lb3V0IHdhc24ndCBhdmFpbGFibGUgYnV0IHdhcyBsYXR0ZXIgZGVmaW5lZFxuICAgIGlmICgoY2FjaGVkU2V0VGltZW91dCA9PT0gZGVmYXVsdFNldFRpbW91dCB8fCAhY2FjaGVkU2V0VGltZW91dCkgJiYgc2V0VGltZW91dCkge1xuICAgICAgICBjYWNoZWRTZXRUaW1lb3V0ID0gc2V0VGltZW91dDtcbiAgICAgICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuLCAwKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gd2hlbiB3aGVuIHNvbWVib2R5IGhhcyBzY3Jld2VkIHdpdGggc2V0VGltZW91dCBidXQgbm8gSS5FLiBtYWRkbmVzc1xuICAgICAgICByZXR1cm4gY2FjaGVkU2V0VGltZW91dChmdW4sIDApO1xuICAgIH0gY2F0Y2goZSl7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBXaGVuIHdlIGFyZSBpbiBJLkUuIGJ1dCB0aGUgc2NyaXB0IGhhcyBiZWVuIGV2YWxlZCBzbyBJLkUuIGRvZXNuJ3QgdHJ1c3QgdGhlIGdsb2JhbCBvYmplY3Qgd2hlbiBjYWxsZWQgbm9ybWFsbHlcbiAgICAgICAgICAgIHJldHVybiBjYWNoZWRTZXRUaW1lb3V0LmNhbGwobnVsbCwgZnVuLCAwKTtcbiAgICAgICAgfSBjYXRjaChlKXtcbiAgICAgICAgICAgIC8vIHNhbWUgYXMgYWJvdmUgYnV0IHdoZW4gaXQncyBhIHZlcnNpb24gb2YgSS5FLiB0aGF0IG11c3QgaGF2ZSB0aGUgZ2xvYmFsIG9iamVjdCBmb3IgJ3RoaXMnLCBob3BmdWxseSBvdXIgY29udGV4dCBjb3JyZWN0IG90aGVyd2lzZSBpdCB3aWxsIHRocm93IGEgZ2xvYmFsIGVycm9yXG4gICAgICAgICAgICByZXR1cm4gY2FjaGVkU2V0VGltZW91dC5jYWxsKHRoaXMsIGZ1biwgMCk7XG4gICAgICAgIH1cbiAgICB9XG5cblxufVxuZnVuY3Rpb24gcnVuQ2xlYXJUaW1lb3V0KG1hcmtlcikge1xuICAgIGlmIChjYWNoZWRDbGVhclRpbWVvdXQgPT09IGNsZWFyVGltZW91dCkge1xuICAgICAgICAvL25vcm1hbCBlbnZpcm9tZW50cyBpbiBzYW5lIHNpdHVhdGlvbnNcbiAgICAgICAgcmV0dXJuIGNsZWFyVGltZW91dChtYXJrZXIpO1xuICAgIH1cbiAgICAvLyBpZiBjbGVhclRpbWVvdXQgd2Fzbid0IGF2YWlsYWJsZSBidXQgd2FzIGxhdHRlciBkZWZpbmVkXG4gICAgaWYgKChjYWNoZWRDbGVhclRpbWVvdXQgPT09IGRlZmF1bHRDbGVhclRpbWVvdXQgfHwgIWNhY2hlZENsZWFyVGltZW91dCkgJiYgY2xlYXJUaW1lb3V0KSB7XG4gICAgICAgIGNhY2hlZENsZWFyVGltZW91dCA9IGNsZWFyVGltZW91dDtcbiAgICAgICAgcmV0dXJuIGNsZWFyVGltZW91dChtYXJrZXIpO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICAvLyB3aGVuIHdoZW4gc29tZWJvZHkgaGFzIHNjcmV3ZWQgd2l0aCBzZXRUaW1lb3V0IGJ1dCBubyBJLkUuIG1hZGRuZXNzXG4gICAgICAgIHJldHVybiBjYWNoZWRDbGVhclRpbWVvdXQobWFya2VyKTtcbiAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIFdoZW4gd2UgYXJlIGluIEkuRS4gYnV0IHRoZSBzY3JpcHQgaGFzIGJlZW4gZXZhbGVkIHNvIEkuRS4gZG9lc24ndCAgdHJ1c3QgdGhlIGdsb2JhbCBvYmplY3Qgd2hlbiBjYWxsZWQgbm9ybWFsbHlcbiAgICAgICAgICAgIHJldHVybiBjYWNoZWRDbGVhclRpbWVvdXQuY2FsbChudWxsLCBtYXJrZXIpO1xuICAgICAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgICAgIC8vIHNhbWUgYXMgYWJvdmUgYnV0IHdoZW4gaXQncyBhIHZlcnNpb24gb2YgSS5FLiB0aGF0IG11c3QgaGF2ZSB0aGUgZ2xvYmFsIG9iamVjdCBmb3IgJ3RoaXMnLCBob3BmdWxseSBvdXIgY29udGV4dCBjb3JyZWN0IG90aGVyd2lzZSBpdCB3aWxsIHRocm93IGEgZ2xvYmFsIGVycm9yLlxuICAgICAgICAgICAgLy8gU29tZSB2ZXJzaW9ucyBvZiBJLkUuIGhhdmUgZGlmZmVyZW50IHJ1bGVzIGZvciBjbGVhclRpbWVvdXQgdnMgc2V0VGltZW91dFxuICAgICAgICAgICAgcmV0dXJuIGNhY2hlZENsZWFyVGltZW91dC5jYWxsKHRoaXMsIG1hcmtlcik7XG4gICAgICAgIH1cbiAgICB9XG5cblxuXG59XG52YXIgcXVldWUgPSBbXTtcbnZhciBkcmFpbmluZyA9IGZhbHNlO1xudmFyIGN1cnJlbnRRdWV1ZTtcbnZhciBxdWV1ZUluZGV4ID0gLTE7XG5cbmZ1bmN0aW9uIGNsZWFuVXBOZXh0VGljaygpIHtcbiAgICBpZiAoIWRyYWluaW5nIHx8ICFjdXJyZW50UXVldWUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBkcmFpbmluZyA9IGZhbHNlO1xuICAgIGlmIChjdXJyZW50UXVldWUubGVuZ3RoKSB7XG4gICAgICAgIHF1ZXVlID0gY3VycmVudFF1ZXVlLmNvbmNhdChxdWV1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcXVldWVJbmRleCA9IC0xO1xuICAgIH1cbiAgICBpZiAocXVldWUubGVuZ3RoKSB7XG4gICAgICAgIGRyYWluUXVldWUoKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGRyYWluUXVldWUoKSB7XG4gICAgaWYgKGRyYWluaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIHRpbWVvdXQgPSBydW5UaW1lb3V0KGNsZWFuVXBOZXh0VGljayk7XG4gICAgZHJhaW5pbmcgPSB0cnVlO1xuXG4gICAgdmFyIGxlbiA9IHF1ZXVlLmxlbmd0aDtcbiAgICB3aGlsZShsZW4pIHtcbiAgICAgICAgY3VycmVudFF1ZXVlID0gcXVldWU7XG4gICAgICAgIHF1ZXVlID0gW107XG4gICAgICAgIHdoaWxlICgrK3F1ZXVlSW5kZXggPCBsZW4pIHtcbiAgICAgICAgICAgIGlmIChjdXJyZW50UXVldWUpIHtcbiAgICAgICAgICAgICAgICBjdXJyZW50UXVldWVbcXVldWVJbmRleF0ucnVuKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcXVldWVJbmRleCA9IC0xO1xuICAgICAgICBsZW4gPSBxdWV1ZS5sZW5ndGg7XG4gICAgfVxuICAgIGN1cnJlbnRRdWV1ZSA9IG51bGw7XG4gICAgZHJhaW5pbmcgPSBmYWxzZTtcbiAgICBydW5DbGVhclRpbWVvdXQodGltZW91dCk7XG59XG5cbnByb2Nlc3MubmV4dFRpY2sgPSBmdW5jdGlvbiAoZnVuKSB7XG4gICAgdmFyIGFyZ3MgPSBuZXcgQXJyYXkoYXJndW1lbnRzLmxlbmd0aCAtIDEpO1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgYXJnc1tpIC0gMV0gPSBhcmd1bWVudHNbaV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcXVldWUucHVzaChuZXcgSXRlbShmdW4sIGFyZ3MpKTtcbiAgICBpZiAocXVldWUubGVuZ3RoID09PSAxICYmICFkcmFpbmluZykge1xuICAgICAgICBydW5UaW1lb3V0KGRyYWluUXVldWUpO1xuICAgIH1cbn07XG5cbi8vIHY4IGxpa2VzIHByZWRpY3RpYmxlIG9iamVjdHNcbmZ1bmN0aW9uIEl0ZW0oZnVuLCBhcnJheSkge1xuICAgIHRoaXMuZnVuID0gZnVuO1xuICAgIHRoaXMuYXJyYXkgPSBhcnJheTtcbn1cbkl0ZW0ucHJvdG90eXBlLnJ1biA9IGZ1bmN0aW9uICgpIHtcbiAgICB0aGlzLmZ1bi5hcHBseShudWxsLCB0aGlzLmFycmF5KTtcbn07XG5wcm9jZXNzLnRpdGxlID0gJ2Jyb3dzZXInO1xucHJvY2Vzcy5icm93c2VyID0gdHJ1ZTtcbnByb2Nlc3MuZW52ID0ge307XG5wcm9jZXNzLmFyZ3YgPSBbXTtcbnByb2Nlc3MudmVyc2lvbiA9ICcnOyAvLyBlbXB0eSBzdHJpbmcgdG8gYXZvaWQgcmVnZXhwIGlzc3Vlc1xucHJvY2Vzcy52ZXJzaW9ucyA9IHt9O1xuXG5mdW5jdGlvbiBub29wKCkge31cblxucHJvY2Vzcy5vbiA9IG5vb3A7XG5wcm9jZXNzLmFkZExpc3RlbmVyID0gbm9vcDtcbnByb2Nlc3Mub25jZSA9IG5vb3A7XG5wcm9jZXNzLm9mZiA9IG5vb3A7XG5wcm9jZXNzLnJlbW92ZUxpc3RlbmVyID0gbm9vcDtcbnByb2Nlc3MucmVtb3ZlQWxsTGlzdGVuZXJzID0gbm9vcDtcbnByb2Nlc3MuZW1pdCA9IG5vb3A7XG5cbnByb2Nlc3MuYmluZGluZyA9IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdwcm9jZXNzLmJpbmRpbmcgaXMgbm90IHN1cHBvcnRlZCcpO1xufTtcblxucHJvY2Vzcy5jd2QgPSBmdW5jdGlvbiAoKSB7IHJldHVybiAnLycgfTtcbnByb2Nlc3MuY2hkaXIgPSBmdW5jdGlvbiAoZGlyKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdwcm9jZXNzLmNoZGlyIGlzIG5vdCBzdXBwb3J0ZWQnKTtcbn07XG5wcm9jZXNzLnVtYXNrID0gZnVuY3Rpb24oKSB7IHJldHVybiAwOyB9O1xuIiwidmFyIGNvbmZpZyA9IHJlcXVpcmUoJy4uLy4uL2NvbmZpZy5qc29uJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL29iamVjdHMvY2x1bXAnKTtcbnZhciBMdW1wID0gcmVxdWlyZSgnLi9vYmplY3RzL2x1bXAnKTtcblxudmFyIGlvID0gcmVxdWlyZSgnLi9pbycpO1xuXG52YXIgbGlicmFyeSA9IHJlcXVpcmUoJy4vbGlicmFyeScpO1xudmFyIGxvYWRlZCA9IHt9O1xuXG52YXIgdHlwZXMgPSB7XG4gIFF1YWxpdHk6IHJlcXVpcmUoJy4vb2JqZWN0cy9xdWFsaXR5JyksXG4gIEV2ZW50OiByZXF1aXJlKCcuL29iamVjdHMvZXZlbnQnKSxcbiAgSW50ZXJhY3Rpb246IHJlcXVpcmUoJy4vb2JqZWN0cy9pbnRlcmFjdGlvbicpLFxuICBRdWFsaXR5RWZmZWN0OiByZXF1aXJlKCcuL29iamVjdHMvcXVhbGl0eS1lZmZlY3QnKSxcbiAgUXVhbGl0eVJlcXVpcmVtZW50OiByZXF1aXJlKCcuL29iamVjdHMvcXVhbGl0eS1yZXF1aXJlbWVudCcpLFxuICBBcmVhOiByZXF1aXJlKCcuL29iamVjdHMvYXJlYScpLFxuICBTcGF3bmVkRW50aXR5OiByZXF1aXJlKCcuL29iamVjdHMvc3Bhd25lZC1lbnRpdHknKSxcbiAgQ29tYmF0QXR0YWNrOiByZXF1aXJlKCcuL29iamVjdHMvY29tYmF0LWF0dGFjaycpLFxuICBFeGNoYW5nZTogcmVxdWlyZSgnLi9vYmplY3RzL2V4Y2hhbmdlJyksXG4gIFNob3A6IHJlcXVpcmUoJy4vb2JqZWN0cy9zaG9wJyksXG4gIEF2YWlsYWJpbGl0eTogcmVxdWlyZSgnLi9vYmplY3RzL2F2YWlsYWJpbGl0eScpLFxuICBUaWxlOiByZXF1aXJlKCcuL29iamVjdHMvdGlsZScpLFxuICBUaWxlVmFyaWFudDogcmVxdWlyZSgnLi9vYmplY3RzL3RpbGUtdmFyaWFudCcpLFxuICBQb3J0OiByZXF1aXJlKCcuL29iamVjdHMvcG9ydCcpLFxuICBTZXR0aW5nOiByZXF1aXJlKCcuL29iamVjdHMvc2V0dGluZycpXG59O1xuXG4vLyBQcmVwb3B1bGF0ZSBsaWJyYXJ5IHdpdGggQ2x1bXBzIG9mIGVhY2ggdHlwZSB3ZSBrbm93IGFib3V0XG5PYmplY3Qua2V5cyh0eXBlcykuZm9yRWFjaChmdW5jdGlvbih0eXBlTmFtZSkge1xuXHR2YXIgVHlwZSA9IHR5cGVzW3R5cGVOYW1lXTtcblx0aWYoIWxpYnJhcnlbdHlwZU5hbWVdKSB7XG5cdFx0bGlicmFyeVt0eXBlTmFtZV0gPSBuZXcgQ2x1bXAoW10sIFR5cGUpO1xuXHRcdGxvYWRlZFt0eXBlTmFtZV0gPSBuZXcgQ2x1bXAoW10sIFR5cGUpO1xuXHR9XG59KTtcblxuZnVuY3Rpb24gZ2V0KFR5cGUsIGlkLCBwYXJlbnQpIHtcblx0dmFyIHR5cGVuYW1lID0gVHlwZS5uYW1lO1x0Ly8gRXZlbnQsIFF1YWxpdHksIEludGVyYWN0aW9uLCBldGNcblxuXHR2YXIgZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQgPSBsaWJyYXJ5W3R5cGVuYW1lXS5pZChpZCk7XG5cdGlmKGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkKSB7XG5cdFx0Ly9jb25zb2xlLmxvZyhcIkF0dGFjaGVkIGV4aXN0aW5nIFwiICsgZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQgKyBcIiB0byBcIiArIHRoaXMudG9TdHJpbmcoKSlcblx0XHR2YXIgbmV3UGFyZW50ID0gdHJ1ZTtcblx0XHRleGlzdGluZ1RoaW5nV2l0aFRoaXNJZC5wYXJlbnRzLmZvckVhY2goZnVuY3Rpb24ocCkge1xuXHRcdFx0aWYocC5JZCA9PT0gcGFyZW50LklkICYmIHAuY29uc3RydWN0b3IubmFtZSA9PT0gcGFyZW50LmNvbnN0cnVjdG9yLm5hbWUpIHtcblx0XHRcdFx0bmV3UGFyZW50ID0gZmFsc2U7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0aWYobmV3UGFyZW50KXtcblx0XHRcdGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkLnBhcmVudHMucHVzaChwYXJlbnQpO1xuXHRcdH1cblxuXHRcdGlmKCFleGlzdGluZ1RoaW5nV2l0aFRoaXNJZC53aXJlZCkge1xuXHRcdFx0ZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQud2lyZVVwKHRoaXMpO1x0Ly8gUGFzcyBpbiB0aGUgYXBpIHNvIG9iamVjdCBjYW4gYWRkIGl0c2VsZiB0byB0aGUgbWFzdGVyLWxpYnJhcnlcblx0XHR9XG5cdFx0cmV0dXJuIGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkO1xuXHR9XG5cdGVsc2Uge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG59XG5cbmZ1bmN0aW9uIGdldE9yQ3JlYXRlKFR5cGUsIHBvc3NOZXdUaGluZywgcGFyZW50KSB7XHQvLyBJZiBhbiBvYmplY3QgYWxyZWFkeSBleGlzdHMgd2l0aCB0aGlzIElELCB1c2UgdGhhdC4gIE90aGVyd2lzZSBjcmVhdGUgYSBuZXcgb2JqZWN0IGZyb20gdGhlIHN1cHBsaWVkIGRldGFpbHMgaGFzaFxuXHR2YXIgdHlwZW5hbWUgPSBUeXBlLm5hbWU7XHQvLyBFdmVudCwgUXVhbGl0eSwgSW50ZXJhY3Rpb24sIGV0Y1xuXHRpZihwb3NzTmV3VGhpbmcpIHtcbiAgXHR2YXIgZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQgPSB0aGlzLmdldChUeXBlLCBwb3NzTmV3VGhpbmcuSWQsIHBhcmVudCk7XG4gIFx0aWYoZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQpIHtcbiAgXHRcdHJldHVybiBleGlzdGluZ1RoaW5nV2l0aFRoaXNJZDtcbiAgXHR9XG4gIFx0ZWxzZSB7XG5cdFx0XHR2YXIgbmV3VGhpbmcgPSBuZXcgVHlwZShwb3NzTmV3VGhpbmcsIHBhcmVudCk7XG5cdFx0XHRuZXdUaGluZy53aXJlVXAodGhpcyk7XG5cdFx0XHQvL2NvbnNvbGUubG9nKFwiUmVjdXJzaXZlbHkgY3JlYXRlZCBcIiArIG5ld1RoaW5nICsgXCIgZm9yIFwiICsgdGhpcy50b1N0cmluZygpKTtcblx0XHRcdHJldHVybiBuZXdUaGluZztcblx0XHR9XG5cdH1cblx0ZWxzZSB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cbn1cblxuZnVuY3Rpb24gd2lyZVVwT2JqZWN0cygpIHtcblx0dmFyIGFwaSA9IHRoaXM7XG4gIE9iamVjdC5rZXlzKHR5cGVzKS5mb3JFYWNoKGZ1bmN0aW9uKHR5cGUpIHtcbiAgICBsaWJyYXJ5W3R5cGVdLmZvckVhY2goZnVuY3Rpb24obHVtcCkge1xuICAgICAgaWYobHVtcC53aXJlVXApIHtcbiAgICAgICAgbHVtcC53aXJlVXAoYXBpKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG5cbnZhciB3aGF0SXMgPSBmdW5jdGlvbihpZCkge1xuICB2YXIgcG9zc2liaWxpdGllcyA9IFtdO1xuICBPYmplY3Qua2V5cyhsaWJyYXJ5KS5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xuICAgIGlmKGxpYnJhcnlba2V5XSBpbnN0YW5jZW9mIENsdW1wICYmIGxpYnJhcnlba2V5XS5pZChpZCkpIHtcbiAgICAgIHBvc3NpYmlsaXRpZXMucHVzaChrZXkpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBwb3NzaWJpbGl0aWVzO1xufTtcblxuZnVuY3Rpb24gZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24oZXhwcikge1xuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdGlmKGV4cHIpIHtcblx0XHRleHByID0gZXhwci5yZXBsYWNlKC9cXFtkOihcXGQrKVxcXS9naSwgXCJSQU5ET01bMS0kMV1cIik7XHQvLyBbZDp4XSA9IHJhbmRvbSBudW1iZXIgZnJvbSAxLXgoPylcblx0XHRleHByID0gZXhwci5yZXBsYWNlKC9cXFtxOihcXGQrKVxcXS9naSwgZnVuY3Rpb24obWF0Y2gsIGJhY2tyZWYsIHBvcywgd2hvbGVfc3RyKSB7XG5cdFx0XHR2YXIgcXVhbGl0eSA9IHNlbGYubGlicmFyeS5RdWFsaXR5LmlkKGJhY2tyZWYpO1xuXHRcdFx0cmV0dXJuIFwiW1wiKyhxdWFsaXR5ID8gcXVhbGl0eS5OYW1lIDogJ0lOVkFMSUQnKStcIl1cIjtcblx0XHR9KTtcblxuXHRcdHJldHVybiBleHByO1xuXHR9XG5cdHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiByZWFkRnJvbUZpbGUoVHlwZSwgZmlsZSwgY2FsbGJhY2spIHtcblx0aW8ucmVhZEZpbGUoZmlsZSwgZnVuY3Rpb24gKGUpIHtcbiAgICB2YXIgY29udGVudHMgPSBlLnRhcmdldC5yZXN1bHQ7XG4gICAgXG4gICAgdmFyIG9iaiA9IEpTT04ucGFyc2UoY29udGVudHMpO1xuICAgIGxvYWRlZFtUeXBlLnByb3RvdHlwZS5jb25zdHJ1Y3Rvci5uYW1lXSA9IG5ldyBDbHVtcChvYmosIFR5cGUpO1xuXG4gICAgY2FsbGJhY2soY29udGVudHMsIFR5cGUsIGxvYWRlZFtUeXBlLnByb3RvdHlwZS5jb25zdHJ1Y3Rvci5uYW1lXSk7XG4gIH0pO1xufVxuXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXHQnQ2x1bXAnOiBDbHVtcCxcblx0J0x1bXAnOiBMdW1wLFxuXHQnY29uZmlnJzogY29uZmlnLFxuXHQndHlwZXMnOiB0eXBlcyxcblx0J2xpYnJhcnknOiBsaWJyYXJ5LFxuXHQnbG9hZGVkJzogbG9hZGVkLFxuXHQnZ2V0JzogZ2V0LFxuXHQnd2hhdElzJzogd2hhdElzLFxuXHQnd2lyZVVwT2JqZWN0cyc6IHdpcmVVcE9iamVjdHMsXG5cdCdnZXRPckNyZWF0ZSc6IGdldE9yQ3JlYXRlLFxuXHQnZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24nOiBkZXNjcmliZUFkdmFuY2VkRXhwcmVzc2lvbixcblx0J3JlYWRGcm9tRmlsZSc6IHJlYWRGcm9tRmlsZVxufTsiLCJcbmlmKHR5cGVvZiBGaWxlUmVhZGVyID09PSAndW5kZWZpbmVkJykgeyAvLyBSdW5uaW5nIGluIG5vZGUgcmF0aGVyIHRoYW4gYSBicm93c2VyXG4gIEZpbGVSZWFkZXIgPSByZXF1aXJlKCdmaWxlcmVhZGVyJyk7XG59XG5cbnZhciBmaWxlT2JqZWN0TWFwID0ge1xuICAgICdldmVudHMuanNvbicgOiAnRXZlbnQnLFxuICAgICdxdWFsaXRpZXMuanNvbicgOiAnUXVhbGl0eScsXG4gICAgJ2FyZWFzLmpzb24nIDogJ0FyZWEnLFxuICAgICdTcGF3bmVkRW50aXRpZXMuanNvbicgOiAnU3Bhd25lZEVudGl0eScsXG4gICAgJ0NvbWJhdEF0dGFja3MuanNvbicgOiAnQ29tYmF0QXR0YWNrJyxcbiAgICAnZXhjaGFuZ2VzLmpzb24nIDogJ0V4Y2hhbmdlJyxcbiAgICAnVGlsZXMuanNvbic6ICdUaWxlJ1xuICB9O1xuXG5mdW5jdGlvbiByZWFkRmlsZShmaWxlLCBjYWxsYmFjaykge1xuICB2YXIgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgcmVhZGVyLm9ubG9hZCA9IGNhbGxiYWNrO1xuICByZWFkZXIucmVhZEFzVGV4dChmaWxlKTtcbn1cblxudmFyIGZpbGVzX3RvX2xvYWQgPSAwO1xuZnVuY3Rpb24gcmVzZXRGaWxlc1RvTG9hZCgpIHtcblx0ZmlsZXNfdG9fbG9hZCA9IDA7XG59XG5mdW5jdGlvbiBpbmNyZW1lbnRGaWxlc1RvTG9hZCgpIHtcblx0ZmlsZXNfdG9fbG9hZCsrO1xufVxuZnVuY3Rpb24gZGVjcmVtZW50RmlsZXNUb0xvYWQoKSB7XG5cdGZpbGVzX3RvX2xvYWQtLTtcbn1cbmZ1bmN0aW9uIGNvdW50RmlsZXNUb0xvYWQoKSB7XG5cdHJldHVybiBmaWxlc190b19sb2FkO1xufVxuXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICByZWFkRmlsZTogcmVhZEZpbGUsXG4gIHJlc2V0RmlsZXNUb0xvYWQ6IHJlc2V0RmlsZXNUb0xvYWQsXG5cdGluY3JlbWVudEZpbGVzVG9Mb2FkOiBpbmNyZW1lbnRGaWxlc1RvTG9hZCxcblx0ZGVjcmVtZW50RmlsZXNUb0xvYWQ6IGRlY3JlbWVudEZpbGVzVG9Mb2FkLFxuXHRjb3VudEZpbGVzVG9Mb2FkOiBjb3VudEZpbGVzVG9Mb2FkLFxuICBmaWxlT2JqZWN0TWFwOiBmaWxlT2JqZWN0TWFwXG59OyIsIm1vZHVsZS5leHBvcnRzID0ge307IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gQXJlYShyYXcpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXCJOYW1lXCIsIFwiRGVzY3JpcHRpb25cIiwgXCJJbWFnZU5hbWVcIiwgXCJNb3ZlTWVzc2FnZVwiXTtcblx0THVtcC5jYWxsKHRoaXMsIHJhdyk7XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgQXJlYS5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5BcmVhLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblx0YXBpID0gdGhlQXBpO1xuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzKTtcbn07XG5cbkFyZWEucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiBcIiArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5BcmVhLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUpIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdGlmKHRoaXMuSW1hZ2VOYW1lICE9PSBudWxsICYmIHRoaXMuSW1hZ2UgIT09IFwiXCIpIHtcblx0XHRlbGVtZW50LmlubmVySFRNTCA9IFwiPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2VOYW1lK1wiLnBuZycgLz5cIjtcblx0fVxuXG5cdGVsZW1lbnQuaW5uZXJIVE1MICs9IFwiXFxuPGgzIGNsYXNzPSd0aXRsZSc+XCIrdGhpcy5OYW1lK1wiPC9oMz5cXG48cCBjbGFzcz0nZGVzY3JpcHRpb24nPlwiK3RoaXMuRGVzY3JpcHRpb24rXCI8L3A+XCI7XG5cblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gQXJlYTsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBBdmFpbGFiaWxpdHkocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXG5cdFx0J0Nvc3QnLFxuXHRcdCdTZWxsUHJpY2UnXG5cdF07XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLnF1YWxpdHkgPSBudWxsO1xuXHR0aGlzLnB1cmNoYXNlUXVhbGl0eSA9IG51bGw7XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgQXZhaWxhYmlsaXR5LnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XG5cbkF2YWlsYWJpbGl0eS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHRoaXMucXVhbGl0eSA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuUXVhbGl0eSwgdGhpcy5hdHRyaWJzLlF1YWxpdHksIHRoaXMpO1xuXHR0aGlzLnB1cmNoYXNlUXVhbGl0eSA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuUXVhbGl0eSwgdGhpcy5hdHRyaWJzLlB1cmNoYXNlUXVhbGl0eSwgdGhpcyk7XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcbn07XG5cbkF2YWlsYWJpbGl0eS5wcm90b3R5cGUuaXNBZGRpdGl2ZSA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5Db3N0ID4gMDtcbn07XG5cbkF2YWlsYWJpbGl0eS5wcm90b3R5cGUuaXNTdWJ0cmFjdGl2ZSA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5TZWxsUHJpY2UgPiAwO1xufTtcblxuQXZhaWxhYmlsaXR5LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLnF1YWxpdHkgKyBcIiAoYnV5OiBcIiArIHRoaXMuQ29zdCArIFwieFwiICsgdGhpcy5wdXJjaGFzZVF1YWxpdHkuTmFtZSArIFwiIC8gc2VsbDogXCIgKyB0aGlzLlNlbGxQcmljZSArIFwieFwiICsgdGhpcy5wdXJjaGFzZVF1YWxpdHkuTmFtZSArIFwiKVwiO1xufTtcblxuQXZhaWxhYmlsaXR5LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUpIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcInNtYWxsXCI7XG5cblx0dmFyIGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblx0XG5cdHZhciBwdXJjaGFzZV9xdWFsaXR5X2VsZW1lbnQ7XG5cblx0aWYoIXRoaXMucXVhbGl0eSkge1xuXHRcdHB1cmNoYXNlX3F1YWxpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRcdHB1cmNoYXNlX3F1YWxpdHlfZWxlbWVudC5pbm5lckhUTUwgPSBcIltJTlZBTElEXVwiO1xuXHR9XG5cdGVsc2Uge1xuXHRcdHB1cmNoYXNlX3F1YWxpdHlfZWxlbWVudCA9IHRoaXMucXVhbGl0eS50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInNwYW5cIik7XG5cdH1cblxuXHR2YXIgY3VycmVuY3lfcXVhbGl0eV9lbGVtZW50ID0gdGhpcy5wdXJjaGFzZVF1YWxpdHkudG9Eb20oXCJzbWFsbFwiLCBmYWxzZSwgXCJzcGFuXCIpO1xuXHRjdXJyZW5jeV9xdWFsaXR5X2VsZW1lbnQuY2xhc3NOYW1lID0gXCJxdWFudGl0eSBpdGVtIHNtYWxsXCI7XG5cdHZhciBjdXJyZW5jeV9xdWFsaXR5X21hcmt1cCA9IGN1cnJlbmN5X3F1YWxpdHlfZWxlbWVudC5vdXRlckhUTUw7XG5cblx0dmFyIGN1cnJlbmN5X2J1eV9hbW91bnRfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRjdXJyZW5jeV9idXlfYW1vdW50X2VsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIHF1YW50aXR5XCI7XG5cdGN1cnJlbmN5X2J1eV9hbW91bnRfZWxlbWVudC5pbm5lckhUTUwgPSBcIkJ1eTogXCIgKyAodGhpcy5Db3N0ID8gdGhpcy5Db3N0K1wieFwiIDogXCImIzEwMDA3O1wiKTtcblx0Y3VycmVuY3lfYnV5X2Ftb3VudF9lbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xuXG5cdHZhciBjdXJyZW5jeV9zZWxsX2Ftb3VudF9lbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG5cdGN1cnJlbmN5X3NlbGxfYW1vdW50X2VsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIHF1YW50aXR5XCI7XG5cdGN1cnJlbmN5X3NlbGxfYW1vdW50X2VsZW1lbnQuaW5uZXJIVE1MID0gXCJTZWxsOiBcIiArICh0aGlzLlNlbGxQcmljZSA/IHRoaXMuU2VsbFByaWNlK1wieFwiIDogXCImIzEwMDA3O1wiKTtcblx0Y3VycmVuY3lfc2VsbF9hbW91bnRfZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQocHVyY2hhc2VfcXVhbGl0eV9lbGVtZW50KTtcblx0ZWxlbWVudC5hcHBlbmRDaGlsZChjdXJyZW5jeV9idXlfYW1vdW50X2VsZW1lbnQpO1xuXHRpZih0aGlzLkNvc3QpIHtcblx0XHRlbGVtZW50LmFwcGVuZENoaWxkKCQoY3VycmVuY3lfcXVhbGl0eV9tYXJrdXApWzBdKTtcblx0fVxuXHRlbGVtZW50LmFwcGVuZENoaWxkKGN1cnJlbmN5X3NlbGxfYW1vdW50X2VsZW1lbnQpO1xuXHRpZih0aGlzLlNlbGxQcmljZSkge1xuXHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoJChjdXJyZW5jeV9xdWFsaXR5X21hcmt1cClbMF0pO1xuXHR9XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEF2YWlsYWJpbGl0eTsiLCJcbmZ1bmN0aW9uIENsdW1wKHJhdywgVHlwZSwgcGFyZW50KSB7XG5cdHRoaXMudHlwZSA9IFR5cGU7XG5cdHRoaXMuaXRlbXMgPSB7fTtcblx0dmFyIHNlbGYgPSB0aGlzO1xuXHRyYXcuZm9yRWFjaChmdW5jdGlvbihpdGVtLCBpbmRleCwgY29sbGVjdGlvbikge1xuXHRcdGlmKCEoaXRlbSBpbnN0YW5jZW9mIFR5cGUpKSB7XG5cdFx0XHRpdGVtID0gbmV3IFR5cGUoaXRlbSwgcGFyZW50KTtcblx0XHR9XG5cdFx0ZWxzZSBpZihwYXJlbnQpIHtcblx0XHRcdHZhciBuZXdQYXJlbnQgPSB0cnVlO1xuXHRcdFx0aXRlbS5wYXJlbnRzLmZvckVhY2goZnVuY3Rpb24ocCkge1xuXHRcdFx0XHRpZihwLklkID09PSBwYXJlbnQuSWQgJiYgcC5jb25zdHJ1Y3Rvci5uYW1lID09PSBwYXJlbnQuY29uc3RydWN0b3IubmFtZSkge1xuXHRcdFx0XHRcdG5ld1BhcmVudCA9IGZhbHNlO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHRcdGlmKG5ld1BhcmVudCl7XG5cdFx0XHRcdGl0ZW0ucGFyZW50cy5wdXNoKHBhcmVudCk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmKHNlbGYuaXRlbXNbaXRlbS5JZF0pIHtcblx0XHRcdGNvbnNvbGUud2FybihUeXBlLm5hbWUrXCIgXCIraXRlbS5JZCtcIiBhbHJlYWR5IGV4aXN0cyBpbiB0aGlzIGNsdW1wLiAgRHVwbGljYXRlZCBJRHMgZm9yIGRpZmZlcmVudCBvYmplY3RzIGluIHRoZSBnYW1lLWpzb24/XCIpXG5cdFx0fVxuXHRcdHNlbGYuaXRlbXNbaXRlbS5JZF0gPSBpdGVtO1xuXHR9KTtcbn1cblxuQ2x1bXAucHJvdG90eXBlLmVtcHR5ID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiAhIXRoaXMuc2l6ZSgpO1xufTtcblxuQ2x1bXAucHJvdG90eXBlLnNpemUgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuaXRlbXMpLmxlbmd0aDtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbihpbmRleCkge1xuXHRmb3IodmFyIGlkIGluIHRoaXMuaXRlbXMpIHtcblx0XHRpZihpbmRleCA9PT0gMCkge1xuXHRcdFx0cmV0dXJuIHRoaXMuaXRlbXNbaWRdO1xuXHRcdH1cblx0XHRpbmRleC0tO1xuXHR9XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuaWQgPSBmdW5jdGlvbihpZCkge1xuXHRyZXR1cm4gdGhpcy5pdGVtc1tpZF07XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuZWFjaCA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgYXJncyA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cyk7XG5cdHJldHVybiB0aGlzLm1hcChmdW5jdGlvbihpdGVtKSB7XG5cblx0XHRpZihhcmdzWzBdIGluc3RhbmNlb2YgQXJyYXkpIHtcdC8vIFBhc3NlZCBpbiBhcnJheSBvZiBmaWVsZHMsIHNvIHJldHVybiB2YWx1ZXMgY29uY2F0ZW5hdGVkIHdpdGggb3B0aW9uYWwgc2VwYXJhdG9yXG5cdFx0XHR2YXIgc2VwYXJhdG9yID0gKHR5cGVvZiBhcmdzWzFdID09PSBcInVuZGVmaW5lZFwiKSA/IFwiLVwiIDogYXJnc1sxXTtcblx0XHRcdHJldHVybiBhcmdzWzBdLm1hcChmdW5jdGlvbihmKSB7IHJldHVybiBpdGVtW2ZdOyB9KS5qb2luKHNlcGFyYXRvcik7XG5cdFx0fVxuXHRcdGVsc2UgaWYoYXJncy5sZW5ndGggPiAxKSB7XHQvLyBQYXNzZWQgaW4gc2VwYXJhdGUgZmllbGRzLCBzbyByZXR1cm4gYXJyYXkgb2YgdmFsdWVzXG5cdFx0XHRyZXR1cm4gYXJncy5tYXAoZnVuY3Rpb24oZikgeyByZXR1cm4gaXRlbVtmXTsgfSk7XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0cmV0dXJuIGl0ZW1bYXJnc1swXV07XG5cdFx0fVxuXHR9KTtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS5mb3JFYWNoID0gZnVuY3Rpb24oY2FsbGJhY2spIHtcblx0Zm9yKHZhciBpZCBpbiB0aGlzLml0ZW1zKSB7XG5cdFx0dmFyIGl0ZW0gPSB0aGlzLml0ZW1zW2lkXTtcblx0XHRjYWxsYmFjayhpdGVtLCBpZCwgdGhpcy5pdGVtcyk7XG5cdH1cbn07XG5cbkNsdW1wLnByb3RvdHlwZS5tYXAgPSBmdW5jdGlvbihjYWxsYmFjaykge1xuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdHZhciBhcnJheU9mSXRlbXMgPSBPYmplY3Qua2V5cyh0aGlzLml0ZW1zKS5tYXAoZnVuY3Rpb24oa2V5KSB7XG5cdFx0cmV0dXJuIHNlbGYuaXRlbXNba2V5XTtcblx0fSk7XG5cdHJldHVybiBhcnJheU9mSXRlbXMubWFwLmNhbGwoYXJyYXlPZkl0ZW1zLCBjYWxsYmFjayk7XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuc29ydEJ5ID0gZnVuY3Rpb24oZmllbGQsIHJldmVyc2UpIHtcblx0dmFyIHNlbGYgPSB0aGlzO1xuXHR2YXIgb2JqcyA9IE9iamVjdC5rZXlzKHRoaXMuaXRlbXMpLm1hcChmdW5jdGlvbihrZXkpIHtcblx0XHRyZXR1cm4gc2VsZi5pdGVtc1trZXldO1xuXHR9KS5zb3J0KGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRpZihhW2ZpZWxkXSA8IGJbZmllbGRdKSB7XG5cdFx0XHRyZXR1cm4gLTE7XG5cdFx0fVxuXHRcdGlmKGFbZmllbGRdID09PSBiW2ZpZWxkXSkge1xuXHRcdFx0cmV0dXJuIDA7XG5cdFx0fVxuXHRcdGlmKGFbZmllbGRdID4gYltmaWVsZF0pIHtcblx0XHRcdHJldHVybiAxO1xuXHRcdH1cblx0fSk7XG5cblx0cmV0dXJuIHJldmVyc2UgPyBvYmpzLnJldmVyc2UoKSA6IG9ianM7XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuc2FtZSA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgc2VsZiA9IHRoaXM7XG5cblx0dmFyIGNsb25lID0gZnVuY3Rpb24ob2JqKSB7XG4gICAgdmFyIHRhcmdldCA9IHt9O1xuICAgIGZvciAodmFyIGkgaW4gb2JqKSB7XG4gICAgXHRpZiAob2JqLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgXHRcdGlmKHR5cGVvZiBvYmpbaV0gPT09IFwib2JqZWN0XCIpIHtcbiAgICBcdFx0XHR0YXJnZXRbaV0gPSBjbG9uZShvYmpbaV0pO1xuICAgIFx0XHR9XG4gICAgXHRcdGVsc2Uge1xuICAgICAgXHRcdHRhcmdldFtpXSA9IG9ialtpXTtcbiAgICAgIFx0fVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9O1xuXG5cdHZhciB0ZW1wbGF0ZSA9IGNsb25lKHRoaXMuZ2V0KDApLmF0dHJpYnMpO1xuXG5cdGZvcih2YXIgaWQgaW4gdGhpcy5pdGVtcykge1xuXHRcdHZhciBvdGhlck9iaiA9IHRoaXMuaXRlbXNbaWRdLmF0dHJpYnM7XG5cdFx0Zm9yKHZhciBrZXkgaW4gdGVtcGxhdGUpIHtcblx0XHRcdGlmKHRlbXBsYXRlW2tleV0gIT09IG90aGVyT2JqW2tleV0pIHtcblx0XHRcdFx0ZGVsZXRlKHRlbXBsYXRlW2tleV0pO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHJldHVybiB0ZW1wbGF0ZTtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS5kaXN0aW5jdCA9IGZ1bmN0aW9uKGZpZWxkKSB7XG5cdHZhciBzYW1wbGVWYWx1ZXMgPSB7fTtcblx0dGhpcy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0pIHtcblx0XHR2YXIgdmFsdWUgPSBpdGVtW2ZpZWxkXTtcblx0XHRzYW1wbGVWYWx1ZXNbdmFsdWVdID0gdmFsdWU7XHQvLyBDaGVhcCBkZS1kdXBpbmcgd2l0aCBhIGhhc2hcblx0fSk7XG5cdHJldHVybiBPYmplY3Qua2V5cyhzYW1wbGVWYWx1ZXMpLm1hcChmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHNhbXBsZVZhbHVlc1trZXldOyB9KTtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS5kaXN0aW5jdFJhdyA9IGZ1bmN0aW9uKGZpZWxkKSB7XG5cdHZhciBzYW1wbGVWYWx1ZXMgPSB7fTtcblx0dGhpcy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0pIHtcblx0XHR2YXIgdmFsdWUgPSBpdGVtLmF0dHJpYnNbZmllbGRdO1xuXHRcdHNhbXBsZVZhbHVlc1t2YWx1ZV0gPSB2YWx1ZTtcdC8vIENoZWFwIGRlLWR1cGluZyB3aXRoIGEgaGFzaFxuXHR9KTtcblx0cmV0dXJuIE9iamVjdC5rZXlzKHNhbXBsZVZhbHVlcykubWFwKGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gc2FtcGxlVmFsdWVzW2tleV07IH0pO1xufTtcblxuQ2x1bXAucHJvdG90eXBlLnF1ZXJ5ID0gZnVuY3Rpb24oZmllbGQsIHZhbHVlKSB7XG5cdHZhciBtYXRjaGVzID0gW107XG5cdHZhciB0ZXN0O1xuXG5cdC8vIFdvcmsgb3V0IHdoYXQgc29ydCBvZiBjb21wYXJpc29uIHRvIGRvOlxuXG5cdGlmKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XHQvLyBJZiB2YWx1ZSBpcyBhIGZ1bmN0aW9uLCBwYXNzIGl0IHRoZSBjYW5kaWRhdGUgYW5kIHJldHVybiB0aGUgcmVzdWx0XG5cdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xuXHRcdFx0cmV0dXJuICEhdmFsdWUoY2FuZGlkYXRlKTtcblx0XHR9O1xuXHR9XG5cdGVsc2UgaWYodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiKSB7XG5cdFx0aWYodmFsdWUgaW5zdGFuY2VvZiBSZWdFeHApIHtcblx0XHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcblx0XHRcdFx0cmV0dXJuIHZhbHVlLnRlc3QoY2FuZGlkYXRlKTtcblx0XHRcdH07XG5cdFx0fVxuXHRcdGVsc2UgaWYodmFsdWUgaW5zdGFuY2VvZiBBcnJheSkge1x0Ly8gSWYgdmFsdWUgaXMgYW4gYXJyYXksIHRlc3QgZm9yIHRoZSBwcmVzZW5jZSBvZiB0aGUgY2FuZGlkYXRlIHZhbHVlIGluIHRoZSBhcnJheVxuXHRcdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xuXHRcdFx0XHRyZXR1cm4gdmFsdWUuaW5kZXhPZihjYW5kaWRhdGUpICE9PSAtMTtcblx0XHRcdH07XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xuXHRcdFx0XHRyZXR1cm4gY2FuZGlkYXRlID09PSB2YWx1ZTtcdC8vIEhhbmRsZSBudWxsLCB1bmRlZmluZWQgb3Igb2JqZWN0LXJlZmVyZW5jZSBjb21wYXJpc29uXG5cdFx0XHR9O1xuXHRcdH1cblx0fVxuXHRlbHNlIHtcdC8vIEVsc2UgaWYgaXQncyBhIHNpbXBsZSB0eXBlLCB0cnkgYSBzdHJpY3QgZXF1YWxpdHkgY29tcGFyaXNvblxuXHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcblx0XHRcdHJldHVybiBjYW5kaWRhdGUgPT09IHZhbHVlO1xuXHRcdH07XG5cdH1cblx0XG5cdC8vIE5vdyBpdGVyYXRlIG92ZXIgdGhlIGl0ZW1zLCBmaWx0ZXJpbmcgdXNpbmcgdGhlIHRlc3QgZnVuY3Rpb24gd2UgZGVmaW5lZFxuXHR0aGlzLmZvckVhY2goZnVuY3Rpb24oaXRlbSkge1xuXHRcdGlmKFxuXHRcdFx0KGZpZWxkICE9PSBudWxsICYmIHRlc3QoaXRlbVtmaWVsZF0pKSB8fFxuXHRcdFx0KGZpZWxkID09PSBudWxsICYmIHRlc3QoaXRlbSkpXG5cdFx0KSB7XG5cdFx0XHRtYXRjaGVzLnB1c2goaXRlbSk7XG5cdFx0fVxuXHR9KTtcblx0cmV0dXJuIG5ldyBDbHVtcChtYXRjaGVzLCB0aGlzLnR5cGUpO1x0Ly8gQW5kIHdyYXAgdGhlIHJlc3VsdGluZyBhcnJheSBvZiBvYmplY3RzIGluIGEgbmV3IENsdW1wIG9iamVjdCBmb3Igc2V4eSBtZXRob2QgY2hhaW5pbmcgbGlrZSB4LnF1ZXJ5KCkuZm9yRWFjaCgpIG9yIHgucXVlcnkoKS5xdWVyeSgpXG59O1xuXG5DbHVtcC5wcm90b3R5cGUucXVlcnlSYXcgPSBmdW5jdGlvbihmaWVsZCwgdmFsdWUpIHtcblx0dmFyIG1hdGNoZXMgPSBbXTtcblx0dmFyIHRlc3Q7XG5cblx0Ly8gV29yayBvdXQgd2hhdCBzb3J0IG9mIGNvbXBhcmlzb24gdG8gZG86XG5cblx0aWYodHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIpIHtcdC8vIElmIHZhbHVlIGlzIGEgZnVuY3Rpb24sIHBhc3MgaXQgdGhlIGNhbmRpZGF0ZSBhbmQgcmV0dXJuIHRoZSByZXN1bHRcblx0XHR0ZXN0ID0gZnVuY3Rpb24oY2FuZGlkYXRlKSB7XG5cdFx0XHRyZXR1cm4gISF2YWx1ZShjYW5kaWRhdGUpO1xuXHRcdH07XG5cdH1cblx0ZWxzZSBpZih0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIpIHtcblx0XHRpZih2YWx1ZSBpbnN0YW5jZW9mIFJlZ0V4cCkge1xuXHRcdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xuXHRcdFx0XHRyZXR1cm4gdmFsdWUudGVzdChjYW5kaWRhdGUpO1xuXHRcdFx0fTtcblx0XHR9XG5cdFx0ZWxzZSBpZih2YWx1ZSBpbnN0YW5jZW9mIEFycmF5KSB7XHQvLyBJZiB2YWx1ZSBpcyBhbiBhcnJheSwgdGVzdCBmb3IgdGhlIHByZXNlbmNlIG9mIHRoZSBjYW5kaWRhdGUgdmFsdWUgaW4gdGhlIGFycmF5XG5cdFx0XHR0ZXN0ID0gZnVuY3Rpb24oY2FuZGlkYXRlKSB7XG5cdFx0XHRcdHJldHVybiB2YWx1ZS5pbmRleE9mKGNhbmRpZGF0ZSkgIT09IC0xO1xuXHRcdFx0fTtcblx0XHR9XG5cdFx0ZWxzZSB7XHQvLyBJZiB2YWx1ZSBpcyBhIGhhc2guLi4gd2hhdCBkbyB3ZSBkbz9cblx0XHRcdC8vIENoZWNrIHRoZSBjYW5kaWRhdGUgZm9yIGVhY2ggZmllbGQgaW4gdGhlIGhhc2ggaW4gdHVybiwgYW5kIGluY2x1ZGUgdGhlIGNhbmRpZGF0ZSBpZiBhbnkvYWxsIG9mIHRoZW0gaGF2ZSB0aGUgc2FtZSB2YWx1ZSBhcyB0aGUgY29ycmVzcG9uZGluZyB2YWx1ZS1oYXNoIGZpZWxkP1xuXHRcdFx0dGhyb3cgXCJObyBpZGVhIHdoYXQgdG8gZG8gd2l0aCBhbiBvYmplY3QgYXMgdGhlIHZhbHVlXCI7XG5cdFx0fVxuXHR9XG5cdGVsc2Uge1x0Ly8gRWxzZSBpZiBpdCdzIGEgc2ltcGxlIHR5cGUsIHRyeSBhIHN0cmljdCBlcXVhbGl0eSBjb21wYXJpc29uXG5cdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xuXHRcdFx0cmV0dXJuIGNhbmRpZGF0ZSA9PT0gdmFsdWU7XG5cdFx0fTtcblx0fVxuXHRcblx0Ly8gTm93IGl0ZXJhdGUgb3ZlciB0aGVtIGFsbCwgZmlsdGVyaW5nIHVzaW5nIHRoZSB0ZXN0IGZ1bmN0aW9uIHdlIGRlZmluZWRcblx0dGhpcy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0pIHtcblx0XHRpZihcblx0XHRcdChmaWVsZCAhPT0gbnVsbCAmJiB0ZXN0KGl0ZW0uYXR0cmlic1tmaWVsZF0pKSB8fFxuXHRcdFx0KGZpZWxkID09PSBudWxsICYmIHRlc3QoaXRlbS5hdHRyaWJzKSlcblx0XHQpIHtcblx0XHRcdG1hdGNoZXMucHVzaChpdGVtKTtcblx0XHR9XG5cdH0pO1xuXHRyZXR1cm4gbmV3IENsdW1wKG1hdGNoZXMsIHRoaXMudHlwZSk7XHQvLyBBbmQgd3JhcCB0aGUgcmVzdWx0aW5nIGFycmF5IG9mIG9iamVjdHMgaW4gYSBuZXcgQ2x1bXAgb2JqZWN0IGZvciBzZXh5IG1ldGhvZCBjaGFpbmluZyBsaWtlIHgucXVlcnkoKS5mb3JFYWNoKCkgb3IgeC5xdWVyeSgpLnF1ZXJ5KClcbn07XG5cbkNsdW1wLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy50eXBlLm5hbWUgKyBcIiBDbHVtcCAoXCIgKyB0aGlzLnNpemUoKSArIFwiIGl0ZW1zKVwiO1xufTtcblxuQ2x1bXAucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSwgaW5jbHVkZUNoaWxkcmVuLCB0YWcsIGZpcnN0Q2hpbGQpIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXHR0YWcgPSB0YWcgfHwgXCJ1bFwiO1xuXG5cdHZhciBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IHRoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWxpc3QgXCIrc2l6ZTtcblx0aWYoZmlyc3RDaGlsZCkge1xuXHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoZmlyc3RDaGlsZCk7XG5cdH1cblx0dGhpcy5zb3J0QnkoXCJOYW1lXCIpLmZvckVhY2goZnVuY3Rpb24oaSkge1xuXHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoaS50b0RvbShzaXplLCBpbmNsdWRlQ2hpbGRyZW4pKTtcblx0fSk7XG5cdHJldHVybiBlbGVtZW50O1xufTtcblxuQ2x1bXAucHJvdG90eXBlLmRlc2NyaWJlID0gZnVuY3Rpb24oKSB7XG5cdHZhciBzZWxmID0gdGhpcztcblx0cmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuaXRlbXMpLm1hcChmdW5jdGlvbihpKSB7IHJldHVybiBzZWxmLml0ZW1zW2ldLnRvU3RyaW5nKCk7IH0pLmpvaW4oXCIgYW5kIFwiKTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gQ2x1bXA7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gQ29tYmF0QXR0YWNrKHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdOYW1lJyxcblx0XHQnSW1hZ2UnLFxuXHRcdCdSYW1taW5nQXR0YWNrJyxcblx0XHQnT25seVdoZW5FeHBvc2VkJyxcblx0XHQnUmFuZ2UnLFxuXHRcdCdPcmllbnRhdGlvbicsXG5cdFx0J0FyYycsXG5cdFx0J0Jhc2VIdWxsRGFtYWdlJyxcblx0XHQnQmFzZUxpZmVEYW1hZ2UnLFxuXHRcdCdFeHBvc2VkUXVhbGl0eURhbWFnZScsXHQvLyBWYWx1ZSB0byBhZGQgdG8gdGhlIGV4cG9zZWRRdWFsaXR5OiBwb3NpdGl2ZSBpbmNyZWFzZXMgcXVhbGl0eSBsZXZlbCAoZWcgVGVycm9yKSwgbmVnYXRpdmUgZGVjcmVhc2VzIGl0IChlZyBDcmV3KVxuXHRcdCdTdGFnZ2VyQW1vdW50Jyxcblx0XHQnQmFzZVdhcm1VcCcsXG5cdFx0J0FuaW1hdGlvbicsXG5cdFx0J0FuaW1hdGlvbk51bWJlcidcblx0XTtcblx0cmF3LklkID0gcmF3Lk5hbWU7XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLnF1YWxpdHlSZXF1aXJlZCA9IG51bGw7XG5cdHRoaXMucXVhbGl0eUNvc3QgPSBudWxsO1xuXHR0aGlzLmV4cG9zZWRRdWFsaXR5ID0gbnVsbDtcbn1cblxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IENvbWJhdEF0dGFjay5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5Db21iYXRBdHRhY2sucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xuXG5cdGFwaSA9IHRoZUFwaTtcblxuXHR0aGlzLnF1YWxpdHlSZXF1aXJlZCA9IGFwaS5nZXQoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5RdWFsaXR5UmVxdWlyZWRJZCwgdGhpcyk7XG5cdHRoaXMucXVhbGl0eUNvc3QgPSBhcGkuZ2V0KGFwaS50eXBlcy5RdWFsaXR5LCB0aGlzLmF0dHJpYnMuUXVhbGl0eUNvc3RJZCwgdGhpcyk7XG5cdHRoaXMuZXhwb3NlZFF1YWxpdHkgPSBhcGkuZ2V0KGFwaS50eXBlcy5RdWFsaXR5LCB0aGlzLmF0dHJpYnMuRXhwb3NlZFF1YWxpdHlJZCwgdGhpcyk7XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcbn07XG5cbkNvbWJhdEF0dGFjay5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5OYW1lICsgXCIgKCNcIiArIHRoaXMuSWQgKyBcIilcIjtcbn07XG5cbkNvbWJhdEF0dGFjay5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4pIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXHRpbmNsdWRlQ2hpbGRyZW4gPSBpbmNsdWRlQ2hpbGRyZW4gPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xuXG5cdHZhciBzZWxmID0gdGhpcztcblx0XG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRpZih0aGlzLkltYWdlICE9PSBudWxsICYmIHRoaXMuSW1hZ2UgIT09IFwiXCIpIHtcblx0XHRodG1sID0gXCI8aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5JbWFnZStcIi5wbmcnIC8+XCI7XG5cdH1cblxuXHRodG1sICs9IFwiXFxuPGgzIGNsYXNzPSd0aXRsZSc+XCIrdGhpcy5OYW1lK1wiPC9oMz5cIjtcblxuXHRpZih0aGlzLnF1YWxpdHlSZXF1aXJlZCB8fCB0aGlzLnF1YWxpdHlDb3N0KSB7XG5cdFx0aHRtbCArPSBcIjxkaXYgY2xhc3M9J3NpZGViYXInPlwiO1xuXG5cdFx0aWYodGhpcy5xdWFsaXR5UmVxdWlyZWQpIHtcblx0XHRcdGh0bWwgKz0gXCI8aDQ+UmVxdWlyZWQ8L2g0PlwiO1xuXHRcdFx0aHRtbCArPSAobmV3IENsdW1wKFt0aGlzLnF1YWxpdHlSZXF1aXJlZF0sIGFwaS50eXBlcy5RdWFsaXR5KSkudG9Eb20oXCJzbWFsbFwiLCBmYWxzZSwgXCJ1bFwiKS5vdXRlckhUTUw7XG5cdFx0fVxuXHRcdGlmKHRoaXMucXVhbGl0eUNvc3QpIHtcblx0XHRcdGh0bWwgKz0gXCI8aDQ+Q29zdDwvaDQ+XCI7XG5cdFx0XHRodG1sICs9IChuZXcgQ2x1bXAoW3RoaXMucXVhbGl0eUNvc3RdLCBhcGkudHlwZXMuUXVhbGl0eSkpLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xuXHRcdH1cblx0XHRodG1sICs9IFwiPC9kaXY+XCI7XG5cdH1cblxuXHRodG1sICs9IFwiPGRsIGNsYXNzPSdjbHVtcC1saXN0IHNtYWxsJz5cIjtcblx0WydSYW5nZScsICdBcmMnLCAnQmFzZUh1bGxEYW1hZ2UnLCAnQmFzZUxpZmVEYW1hZ2UnLCAnU3RhZ2dlckFtb3VudCcsICdCYXNlV2FybVVwJ10uZm9yRWFjaChmdW5jdGlvbihrZXkpIHtcblx0XHRodG1sICs9IFwiPGR0IGNsYXNzPSdpdGVtJz5cIitrZXkrXCI8L2R0PjxkZCBjbGFzcz0ncXVhbnRpdHknPlwiK3NlbGZba2V5XStcIjwvZGQ+XCI7XG5cdH0pO1xuXHRodG1sICs9IFwiPC9kbD5cIjtcblxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XG5cblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XG5cdFx0XHRpZihjaGlsZExpc3QpIHtcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdHZhciBzdWNjZXNzRXZlbnQgPSBzZWxmLnN1Y2Nlc3NFdmVudDtcblx0XHRcdFx0dmFyIGRlZmF1bHRFdmVudCA9IHNlbGYuZGVmYXVsdEV2ZW50O1xuXHRcdFx0XHR2YXIgcXVhbGl0aWVzUmVxdWlyZWQgPSAgc2VsZi5xdWFsaXRpZXNSZXF1aXJlZDtcblx0XHRcdFx0dmFyIGV2ZW50cyA9IFtdO1xuXHRcdFx0XHRpZihzdWNjZXNzRXZlbnQgJiYgcXVhbGl0aWVzUmVxdWlyZWQgJiYgcXVhbGl0aWVzUmVxdWlyZWQuc2l6ZSgpKSB7XG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goc3VjY2Vzc0V2ZW50KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZihkZWZhdWx0RXZlbnQpIHtcblx0XHRcdFx0XHRldmVudHMucHVzaChkZWZhdWx0RXZlbnQpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmKGV2ZW50cy5sZW5ndGgpIHtcblx0XHRcdFx0XHR2YXIgd3JhcHBlckNsdW1wID0gbmV3IENsdW1wKGV2ZW50cywgYXBpLnR5cGVzLkV2ZW50KTtcblx0XHRcdFx0XHR2YXIgY2hpbGRfZXZlbnRzID0gd3JhcHBlckNsdW1wLnRvRG9tKHNpemUsIHRydWUpO1xuXG5cdFx0XHRcdFx0Y2hpbGRfZXZlbnRzLmNsYXNzTGlzdC5hZGQoXCJjaGlsZC1saXN0XCIpO1xuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY2hpbGRfZXZlbnRzKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IENvbWJhdEF0dGFjazsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBFdmVudChyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0J05hbWUnLFxuXHQnRGVzY3JpcHRpb24nLFxuXHQnVGVhc2VyJyxcblx0J0ltYWdlJyxcblx0J0NhdGVnb3J5J1xuXHRdO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy50YWcgPSBudWxsO1xuXG5cdHRoaXMuRXhvdGljRWZmZWN0cyA9IHRoaXMuZ2V0RXhvdGljRWZmZWN0KHRoaXMuYXR0cmlicy5FeG90aWNFZmZlY3RzKTtcblxuXHR0aGlzLnF1YWxpdGllc1JlcXVpcmVkID0gbnVsbDtcblx0dGhpcy5xdWFsaXRpZXNBZmZlY3RlZCA9IG51bGw7XG5cdHRoaXMuaW50ZXJhY3Rpb25zID0gbnVsbDtcblx0dGhpcy5saW5rVG9FdmVudCA9IG51bGw7XG5cblx0dGhpcy5saW1pdGVkVG9BcmVhID0gbnVsbDtcblxuXHR0aGlzLnNldHRpbmcgPSBudWxsO1xuXHRcblx0Ly9EZWNrXG5cdC8vU3RpY2tpbmVzc1xuXHQvL1RyYW5zaWVudFxuXHQvL1VyZ2VuY3lcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBFdmVudC5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5FdmVudC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHRoaXMucXVhbGl0aWVzUmVxdWlyZWQgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlF1YWxpdGllc1JlcXVpcmVkIHx8IFtdLCBhcGkudHlwZXMuUXVhbGl0eVJlcXVpcmVtZW50LCB0aGlzKTtcblx0dGhpcy5xdWFsaXRpZXNBZmZlY3RlZCA9IG5ldyBDbHVtcCh0aGlzLmF0dHJpYnMuUXVhbGl0aWVzQWZmZWN0ZWQgfHwgW10sIGFwaS50eXBlcy5RdWFsaXR5RWZmZWN0LCB0aGlzKTtcblx0dGhpcy5pbnRlcmFjdGlvbnMgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLkNoaWxkQnJhbmNoZXN8fCBbXSwgYXBpLnR5cGVzLkludGVyYWN0aW9uLCB0aGlzKTtcblxuXHR0aGlzLmxpbmtUb0V2ZW50ID0gYXBpLmdldE9yQ3JlYXRlKGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLkxpbmtUb0V2ZW50LCB0aGlzKTtcblxuXHR0aGlzLmxpbWl0ZWRUb0FyZWEgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLkFyZWEsIHRoaXMuYXR0cmlicy5MaW1pdGVkVG9BcmVhLCB0aGlzKTtcblxuXHR0aGlzLnNldHRpbmcgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLlNldHRpbmcsIHRoaXMuYXR0cmlicy5TZXR0aW5nLCB0aGlzKTtcblx0XG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5FdmVudC5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbihsb25nKSB7XG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiBcIiArIChsb25nID8gXCIgW1wiICsgdGhpcy5DYXRlZ29yeSArIFwiXSBcIiA6IFwiXCIpICsgdGhpcy5OYW1lICsgXCIgKCNcIiArIHRoaXMuSWQgKyBcIilcIjtcbn07XG5cbkV2ZW50LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbikge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XG5cblx0dmFyIGh0bWwgPSBcIlwiO1xuXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdGlmKHRoaXMuSW1hZ2UgIT09IG51bGwgJiYgdGhpcy5JbWFnZSAhPT0gXCJcIikge1xuXHRcdGh0bWwgPSBcIjxpbWcgY2xhc3M9J2ljb24nIHNyYz0nXCIrYXBpLmNvbmZpZy5sb2NhdGlvbnMuaW1hZ2VzUGF0aCtcIi9cIit0aGlzLkltYWdlK1wic21hbGwucG5nJyAvPlwiO1xuXHR9XG5cblx0aHRtbCArPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIlxcblwiKyh0aGlzLnRhZyA/IFwiPHNwYW4gY2xhc3M9J3RhZyBcIit0aGlzLnRhZytcIic+XCIrdGhpcy50YWcrXCI8L3NwYW4+XCIgOiBcIlwiKStcIjwvaDM+XCI7XG5cblx0aWYoc2l6ZSAhPSBcInNtYWxsXCIgJiYgKHRoaXMucXVhbGl0aWVzUmVxdWlyZWQgfHwgdGhpcy5xdWFsaXRpZXNBZmZlY3RlZCkpIHtcblx0XHRodG1sICs9IFwiPGRpdiBjbGFzcz0nc2lkZWJhcic+XCI7XG5cdFx0aWYodGhpcy5xdWFsaXRpZXNSZXF1aXJlZCAmJiB0aGlzLnF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xuXHRcdFx0aHRtbCArPSBcIjxoND5SZXF1aXJlbWVudHM8L2g0PlxcblwiO1xuXHRcdFx0aHRtbCArPSB0aGlzLnF1YWxpdGllc1JlcXVpcmVkLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xuXHRcdH1cblx0XHRpZih0aGlzLnF1YWxpdGllc0FmZmVjdGVkICYmIHRoaXMucXVhbGl0aWVzQWZmZWN0ZWQuc2l6ZSgpKSB7XG5cdFx0XHRodG1sICs9IFwiPGg0PkVmZmVjdHM8L2g0PlxcblwiO1xuXHRcdFx0aHRtbCArPSB0aGlzLnF1YWxpdGllc0FmZmVjdGVkLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xuXHRcdH1cblx0XHRodG1sICs9IFwiPC9kaXY+XCI7XG5cdH1cblx0XG5cdGh0bWwgKz0gXCI8cCBjbGFzcz0nZGVzY3JpcHRpb24nPlwiK3RoaXMuRGVzY3JpcHRpb24rXCI8L3A+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKHRydWUpO1xuXG5cdGlmKGluY2x1ZGVDaGlsZHJlbikge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XG5cdFx0XHRpZihjaGlsZExpc3QpIHtcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdHZhciBpbnRlcmFjdGlvbnMgPSBzZWxmLmludGVyYWN0aW9ucztcblx0XHRcdFx0dmFyIGxpbmtUb0V2ZW50ID0gc2VsZi5saW5rVG9FdmVudDtcblx0XHRcdFx0aWYobGlua1RvRXZlbnQpIHtcblx0XHRcdFx0XHR2YXIgd3JhcHBlckNsdW1wID0gbmV3IENsdW1wKFtsaW5rVG9FdmVudF0sIGFwaS50eXBlcy5FdmVudCk7XG5cdFx0XHRcdFx0dmFyIGxpbmtUb0V2ZW50X2VsZW1lbnQgPSB3cmFwcGVyQ2x1bXAudG9Eb20oXCJub3JtYWxcIiwgdHJ1ZSk7XG5cblx0XHRcdFx0XHRsaW5rVG9FdmVudF9lbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJjaGlsZC1saXN0XCIpO1xuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQobGlua1RvRXZlbnRfZWxlbWVudCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0ZWxzZSBpZihpbnRlcmFjdGlvbnMgJiYgaW50ZXJhY3Rpb25zLnNpemUoKSA+IDApIHtcblx0XHRcdFx0XHR2YXIgaW50ZXJhY3Rpb25zX2VsZW1lbnQgPSBpbnRlcmFjdGlvbnMudG9Eb20oXCJub3JtYWxcIiwgdHJ1ZSk7XG5cblx0XHRcdFx0XHRpbnRlcmFjdGlvbnNfZWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGludGVyYWN0aW9uc19lbGVtZW50KTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEV2ZW50OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XG5cbnZhciBhcGk7XG5cbmZ1bmN0aW9uIEV4Y2hhbmdlKHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdJZCcsXG5cdFx0J05hbWUnLFxuXHRcdCdEZXNjcmlwdGlvbicsXG5cdFx0J0ltYWdlJyxcblx0XHQnU2V0dGluZ0lkcydcblx0XTtcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG5cdHRoaXMuc2hvcHMgPSBudWxsO1xuXHR0aGlzLnNldHRpbmdzID0gbnVsbDtcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBFeGNoYW5nZS5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5FeGNoYW5nZS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHZhciBzZWxmID0gdGhpcztcblxuXHR0aGlzLnNob3BzID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5TaG9wcyB8fCBbXSwgYXBpLnR5cGVzLlNob3AsIHRoaXMpO1xuXHRcblx0dGhpcy5zZXR0aW5ncyA9IGFwaS5saWJyYXJ5LlNldHRpbmcucXVlcnkoXCJJZFwiLCBmdW5jdGlvbihpZCkge1xuXHRcdHJldHVybiBzZWxmLlNldHRpbmdJZHMuaW5kZXhPZihpZCkgIT09IC0xO1xuXHR9KTtcblx0dGhpcy5zZXR0aW5ncy5mb3JFYWNoKGZ1bmN0aW9uIChzKSB7XG5cdFx0c2VsZi5wYXJlbnRzLnB1c2gocyk7XG5cdH0pO1xuXHRcblx0dGhpcy5wb3J0cyA9IGFwaS5saWJyYXJ5LlBvcnQucXVlcnkoXCJTZXR0aW5nSWRcIiwgZnVuY3Rpb24oaWQpIHtcblx0XHRyZXR1cm4gc2VsZi5TZXR0aW5nSWRzLmluZGV4T2YoaWQpICE9PSAtMTtcblx0fSk7XG5cdHRoaXMucG9ydHMuZm9yRWFjaChmdW5jdGlvbiAocCkge1xuXHRcdHNlbGYucGFyZW50cy5wdXNoKHApO1xuXHR9KTtcblxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzKTtcbn07XG5cbkV4Y2hhbmdlLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xufTtcblxuRXhjaGFuZ2UucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSwgaW5jbHVkZUNoaWxkcmVuLCB0YWcpIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXHRpbmNsdWRlQ2hpbGRyZW4gPSBpbmNsdWRlQ2hpbGRyZW4gPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xuXG5cdHZhciBzZWxmID0gdGhpcztcblx0dmFyIGh0bWwgPSBcIlwiO1xuXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdGh0bWwgPSBcIlxcbjxpbWcgY2xhc3M9J2ljb24nIHNyYz0nXCIrYXBpLmNvbmZpZy5sb2NhdGlvbnMuaW1hZ2VzUGF0aCtcIi9cIit0aGlzLkltYWdlK1wiLnBuZycgLz5cIjtcblx0aHRtbCArPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XG5cdGh0bWwgKz0gXCJcXG48cCBjbGFzcz0nZGVzY3JpcHRpb24nPlwiK3RoaXMuRGVzY3JpcHRpb24rXCI8L3A+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0aWYoaW5jbHVkZUNoaWxkcmVuKSB7XG5cdFx0ZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oZSkge1xuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblxuXHRcdFx0dmFyIGNoaWxkTGlzdCA9IGVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5jaGlsZC1saXN0XCIpO1xuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRpZihzZWxmLnNob3BzKSB7XG5cblx0XHRcdFx0XHR2YXIgY2hpbGRfZWxlbWVudHMgPSBzZWxmLnNob3BzLnRvRG9tKFwibm9ybWFsXCIsIHRydWUpO1xuXG5cdFx0XHRcdFx0Y2hpbGRfZWxlbWVudHMuY2xhc3NMaXN0LmFkZChcImNoaWxkLWxpc3RcIik7XG5cdFx0XHRcdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChjaGlsZF9lbGVtZW50cyk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdHJldHVybiBlbGVtZW50O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBFeGNoYW5nZTsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBJbnRlcmFjdGlvbihyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0J05hbWUnLFxuXHQnRGVzY3JpcHRpb24nLFxuXHQnQnV0dG9uVGV4dCcsXG5cdCdJbWFnZScsXG5cblx0J09yZGVyaW5nJ1xuXHRdO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy5xdWFsaXRpZXNSZXF1aXJlZCA9IG51bGw7XG5cdHRoaXMuc3VjY2Vzc0V2ZW50ID0gbnVsbDtcblx0dGhpcy5kZWZhdWx0RXZlbnQgPSBudWxsO1xuXG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgSW50ZXJhY3Rpb24ucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuSW50ZXJhY3Rpb24ucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xuXG5cdGFwaSA9IHRoZUFwaTtcblxuXHR0aGlzLnF1YWxpdGllc1JlcXVpcmVkID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5RdWFsaXRpZXNSZXF1aXJlZCB8fCBbXSwgYXBpLnR5cGVzLlF1YWxpdHlSZXF1aXJlbWVudCwgdGhpcyk7XG5cdHRoaXMuc3VjY2Vzc0V2ZW50ID0gYXBpLmdldE9yQ3JlYXRlKGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLlN1Y2Nlc3NFdmVudCwgdGhpcyk7XG5cdGlmKHRoaXMuc3VjY2Vzc0V2ZW50KSB7XG5cdFx0dGhpcy5zdWNjZXNzRXZlbnQudGFnID0gXCJzdWNjZXNzXCI7XG5cdH1cblx0dGhpcy5kZWZhdWx0RXZlbnQgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLkV2ZW50LCB0aGlzLmF0dHJpYnMuRGVmYXVsdEV2ZW50LCB0aGlzKTtcblx0dmFyIHF1YWxpdGllc1JlcXVpcmVkID0gIHRoaXMucXVhbGl0aWVzUmVxdWlyZWQ7XG5cdGlmKHRoaXMuZGVmYXVsdEV2ZW50ICYmIHRoaXMuc3VjY2Vzc0V2ZW50ICYmIHF1YWxpdGllc1JlcXVpcmVkICYmIHF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xuXHRcdHRoaXMuZGVmYXVsdEV2ZW50LnRhZyA9IFwiZmFpbHVyZVwiO1xuXHR9XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcbn07XG5cbkludGVyYWN0aW9uLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgW1wiICsgdGhpcy5PcmRlcmluZyArIFwiXSBcIiArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5JbnRlcmFjdGlvbi5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4pIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXHRpbmNsdWRlQ2hpbGRyZW4gPSBpbmNsdWRlQ2hpbGRyZW4gPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xuXG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRpZih0aGlzLkltYWdlICE9PSBudWxsICYmIHRoaXMuSW1hZ2UgIT09IFwiXCIpIHtcblx0XHRodG1sID0gXCI8aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5JbWFnZStcInNtYWxsLnBuZycgLz5cIjtcblx0fVxuXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCI8L2gzPlwiO1xuXG5cdGlmKHNpemUgIT0gXCJzbWFsbFwiICYmIHRoaXMucXVhbGl0aWVzUmVxdWlyZWQpIHtcblx0XHRodG1sICs9IFwiPGRpdiBjbGFzcz0nc2lkZWJhcic+XCI7XG5cdFx0aHRtbCArPSBcIjxoND5SZXF1aXJlbWVudHM8L2g0PlwiO1xuXHRcdGh0bWwgKz0gdGhpcy5xdWFsaXRpZXNSZXF1aXJlZC50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInVsXCIpLm91dGVySFRNTDtcblx0XHRodG1sICs9IFwiPC9kaXY+XCI7XG5cdH1cblxuXHRodG1sICs9IFwiPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xuXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcblxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xuXG5cdGlmKGluY2x1ZGVDaGlsZHJlbikge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XG5cdFx0XHRpZihjaGlsZExpc3QpIHtcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdHZhciBzdWNjZXNzRXZlbnQgPSBzZWxmLnN1Y2Nlc3NFdmVudDtcblx0XHRcdFx0dmFyIGRlZmF1bHRFdmVudCA9IHNlbGYuZGVmYXVsdEV2ZW50O1xuXHRcdFx0XHR2YXIgcXVhbGl0aWVzUmVxdWlyZWQgPSAgc2VsZi5xdWFsaXRpZXNSZXF1aXJlZDtcblx0XHRcdFx0dmFyIGV2ZW50cyA9IFtdO1xuXHRcdFx0XHRpZihzdWNjZXNzRXZlbnQgJiYgcXVhbGl0aWVzUmVxdWlyZWQgJiYgcXVhbGl0aWVzUmVxdWlyZWQuc2l6ZSgpKSB7XG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goc3VjY2Vzc0V2ZW50KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZihkZWZhdWx0RXZlbnQpIHtcblx0XHRcdFx0XHRldmVudHMucHVzaChkZWZhdWx0RXZlbnQpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmKGV2ZW50cy5sZW5ndGgpIHtcblx0XHRcdFx0XHR2YXIgd3JhcHBlckNsdW1wID0gbmV3IENsdW1wKGV2ZW50cywgYXBpLnR5cGVzLkV2ZW50KTtcblx0XHRcdFx0XHR2YXIgY2hpbGRfZXZlbnRzID0gd3JhcHBlckNsdW1wLnRvRG9tKFwibm9ybWFsXCIsIHRydWUpO1xuXG5cdFx0XHRcdFx0Y2hpbGRfZXZlbnRzLmNsYXNzTGlzdC5hZGQoXCJjaGlsZC1saXN0XCIpO1xuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY2hpbGRfZXZlbnRzKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEludGVyYWN0aW9uOyIsInZhciBsaWJyYXJ5ID0gcmVxdWlyZSgnLi4vbGlicmFyeScpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBMdW1wKHJhdywgcGFyZW50KSB7XG5cdGlmKHBhcmVudCkge1xuXHRcdHRoaXMucGFyZW50cyA9IHBhcmVudCBpbnN0YW5jZW9mIEFycmF5ID8gcGFyZW50IDogW3BhcmVudF07XG5cdH1cblx0ZWxzZSB7XG5cdFx0dGhpcy5wYXJlbnRzID0gW107XG5cdH1cblxuXHRpZighdGhpcy5zdHJhaWdodENvcHkpIHtcblx0XHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtdO1xuXHR9XG5cdHRoaXMuc3RyYWlnaHRDb3B5LnVuc2hpZnQoJ0lkJyk7XG5cblx0dGhpcy5hdHRyaWJzID0gcmF3O1xuXG5cdHZhciBzZWxmID0gdGhpcztcblx0dGhpcy5zdHJhaWdodENvcHkuZm9yRWFjaChmdW5jdGlvbihhdHRyaWIpIHtcblx0XHRzZWxmW2F0dHJpYl0gPSByYXdbYXR0cmliXTtcblx0XHRpZih0eXBlb2Ygc2VsZlthdHRyaWJdID09PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0XHRzZWxmW2F0dHJpYl0gPSBudWxsO1xuXHRcdH1cblx0fSk7XG5cdGRlbGV0ZSh0aGlzLnN0cmFpZ2h0Q29weSk7XG5cblx0dGhpcy53aXJlZCA9IGZhbHNlO1xuXG5cdGlmKCFsaWJyYXJ5W3RoaXMuY29uc3RydWN0b3IubmFtZV0pIHtcblx0XHRsaWJyYXJ5W3RoaXMuY29uc3RydWN0b3IubmFtZV0gPSBuZXcgQ2x1bXAoW10sIHRoaXMpO1xuXHR9XG5cblx0aWYobGlicmFyeVt0aGlzLmNvbnN0cnVjdG9yLm5hbWVdLml0ZW1zW3RoaXMuSWRdKSB7XHQvLyBTb21ldGhpbmcgd2l0aCB0aGlzIElEIGFscmVhZHkgZXhpc3RzIVxuXG5cdFx0dmFyIGV4aXN0aW5nT2JqZWN0ID0gbGlicmFyeVt0aGlzLmNvbnN0cnVjdG9yLm5hbWVdLml0ZW1zW3RoaXMuSWRdO1xuXG5cdFx0aWYoIWlzRnVuY3Rpb25hbGx5U2FtZSh0aGlzLmF0dHJpYnMsIGV4aXN0aW5nT2JqZWN0LmF0dHJpYnMpKSB7XHQvLyBXYXMgaXQgYSBmdW5jdGlvbmFsbHktaWRlbnRpY2FsIHJlZGVmaW5pdGlvbiBvZiB0aGlzIG9iamVjdD9cblx0XHRcdGNvbnNvbGUud2FybihcIkR1cGxpY2F0ZSBJRFwiLCB0aGlzLmNvbnN0cnVjdG9yLm5hbWUrXCIgXCIrdGhpcy5JZCtcIiBhbHJlYWR5IGV4aXN0cyBpbiB0aGUgbGlicmFyeSAtIHJlcGxhY2luZ1wiLCBleGlzdGluZ09iamVjdCwgXCJ3aXRoIHJlZGVmaW5pdGlvblwiLCB0aGlzKTtcblx0XHR9XG5cdH1cblx0bGlicmFyeVt0aGlzLmNvbnN0cnVjdG9yLm5hbWVdLml0ZW1zW3RoaXMuSWRdID0gdGhpcztcbn1cblxudmFyIGlzRnVuY3Rpb25hbGx5U2FtZSA9IGZ1bmN0aW9uKG9iajEsIG9iajIpIHtcblxuXHRpZihvYmoxID09PSBvYmoyKSB7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblxuXHRpZihvYmoxIGluc3RhbmNlb2YgT2JqZWN0KSB7XG5cdFx0aWYoIShvYmoyIGluc3RhbmNlb2YgT2JqZWN0KSB8fCBvYmoxLmNvbnN0cnVjdG9yICE9PSBvYmoyLmNvbnN0cnVjdG9yKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXG5cdFx0dmFyIGFsbEtleXMgPSBPYmplY3Qua2V5cyhvYmoxKS5jb25jYXQoT2JqZWN0LmtleXMob2JqMikpLmZpbHRlcihmdW5jdGlvbiAodmFsdWUsIGluZGV4LCBzZWxmKSB7IFxuICAgIFx0cmV0dXJuIHNlbGYuaW5kZXhPZih2YWx1ZSkgPT09IGluZGV4O1xuXHRcdH0pO1xuXG5cdFx0cmV0dXJuIGFsbEtleXMubWFwKGZ1bmN0aW9uKGtleSkge1xuXHRcdFx0cmV0dXJuIGlzRnVuY3Rpb25hbGx5U2FtZShvYmoxW2tleV0sIG9iajJba2V5XSk7XG5cdFx0fSkucmVkdWNlKGZ1bmN0aW9uKHByZXZpb3VzVmFsdWUsIGN1cnJlbnRWYWx1ZSkge1xuXHRcdFx0cmV0dXJuIHByZXZpb3VzVmFsdWUgJiYgY3VycmVudFZhbHVlO1xuXHRcdH0sIHRydWUpO1xuXHR9XG5cblx0cmV0dXJuIGZhbHNlO1xuXG59O1xuXG5MdW1wLnByb3RvdHlwZSA9IHtcblx0d2lyZVVwOiBmdW5jdGlvbih0aGVBcGkpIHtcblx0XHRhcGkgPSB0aGVBcGk7XG5cdFx0dGhpcy53aXJlZCA9IHRydWU7XG5cdH0sXG5cblx0Z2V0U3RhdGVzOiBmdW5jdGlvbihlbmNvZGVkKSB7XG5cdFx0aWYodHlwZW9mIGVuY29kZWQgPT09IFwic3RyaW5nXCIgJiYgZW5jb2RlZCAhPT0gXCJcIikge1xuXHRcdFx0dmFyIG1hcCA9IHt9O1xuXHRcdFx0ZW5jb2RlZC5zcGxpdChcIn5cIikuZm9yRWFjaChmdW5jdGlvbihzdGF0ZSkge1xuXHRcdFx0XHR2YXIgcGFpciA9IHN0YXRlLnNwbGl0KFwifFwiKTtcblx0XHRcdFx0bWFwW3BhaXJbMF1dID0gcGFpclsxXTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIG1hcDtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHRyZXR1cm4gbnVsbDtcblx0XHR9XG5cdH0sXG5cblx0Z2V0RXhvdGljRWZmZWN0OiBmdW5jdGlvbihlbmNvZGVkKSB7XG5cdFx0aWYodHlwZW9mIGVuY29kZWQgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdHZhciBlZmZlY3Q9e30sIGZpZWxkcz1bXCJvcGVyYXRpb25cIiwgXCJmaXJzdFwiLCBcInNlY29uZFwiXTtcblx0XHRcdGVuY29kZWQuc3BsaXQoXCIsXCIpLmZvckVhY2goZnVuY3Rpb24odmFsLCBpbmRleCkge1xuXHRcdFx0XHRlZmZlY3RbZmllbGRzW2luZGV4XV0gPSB2YWw7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBlZmZlY3Q7XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHR9LFxuXG5cdGV2YWxBZHZhbmNlZEV4cHJlc3Npb246IGZ1bmN0aW9uKGV4cHIpIHtcblx0XHRleHByID0gZXhwci5yZXBsYWNlKC9cXFtkOihcXGQrKVxcXS9naSwgXCJNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpKiQxKSsxKVwiKTtcdC8vIFJlcGxhY2UgW2Q6eF0gd2l0aCBKUyB0byBjYWxjdWxhdGUgcmFuZG9tIG51bWJlciBvbiBhIER4IGRpZVxuXHRcdC8qanNoaW50IC1XMDYxICovXG5cdFx0cmV0dXJuIGV2YWwoZXhwcik7XG5cdFx0Lypqc2hpbnQgK1cwNjEgKi9cblx0fSxcblxuXHRpc0E6IGZ1bmN0aW9uKHR5cGUpIHtcblx0XHRyZXR1cm4gdGhpcyBpbnN0YW5jZW9mIHR5cGU7XG5cdH0sXG5cblx0aXNPbmVPZjogZnVuY3Rpb24odHlwZXMpIHtcblx0XHR2YXIgc2VsZiA9IHRoaXM7XG5cdFx0cmV0dXJuIHR5cGVzLm1hcChmdW5jdGlvbih0eXBlKSB7XG5cdFx0XHRyZXR1cm4gc2VsZi5pc0EodHlwZSk7XG5cdFx0fSkucmVkdWNlKGZ1bmN0aW9uKHByZXZpb3VzVmFsdWUsIGN1cnJlbnRWYWx1ZSwgaW5kZXgsIGFycmF5KXtcblx0XHRcdHJldHVybiBwcmV2aW91c1ZhbHVlIHx8IGN1cnJlbnRWYWx1ZTtcblx0XHR9LCBmYWxzZSk7XG5cdH0sXG5cblx0dG9TdHJpbmc6IGZ1bmN0aW9uKCkge1xuXHRcdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xuXHR9LFxuXG5cdGlzRnVuY3Rpb25hbGx5U2FtZTogaXNGdW5jdGlvbmFsbHlTYW1lXHQvLyBDb252ZW5pZW5jZSB1dGlsaXR5IGZ1bmN0aW9uXG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEx1bXA7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gUG9ydChyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0XHQnTmFtZScsXG5cdFx0J1JvdGF0aW9uJyxcblx0XHQnUG9zaXRpb24nLFxuXHRcdCdEaXNjb3ZlcnlWYWx1ZScsXG5cdFx0J0lzU3RhcnRpbmdQb3J0J1xuXHRdO1xuXG5cblx0cmF3LklkID0gcGFyZW50Lk5hbWUrXCIvXCIrcmF3Lk5hbWU7XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLlNldHRpbmdJZCA9IHJhdy5TZXR0aW5nLklkO1xuXHR0aGlzLnNldHRpbmcgPSBudWxsO1xuXG5cdHRoaXMuYXJlYSA9IG51bGw7XG5cblx0dGhpcy5leGNoYW5nZXMgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFBvcnQucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuUG9ydC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cdFxuXHRhcGkgPSB0aGVBcGk7XG5cdHZhciBzZWxmID0gdGhpcztcblxuXHR0aGlzLnNldHRpbmcgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLlNldHRpbmcsIHRoaXMuYXR0cmlicy5TZXR0aW5nLCB0aGlzKTtcblx0XG5cdHRoaXMuYXJlYSA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuQXJlYSwgdGhpcy5hdHRyaWJzLkFyZWEsIHRoaXMpO1xuXG5cdHRoaXMuZXhjaGFuZ2VzID0gYXBpLmxpYnJhcnkuRXhjaGFuZ2UucXVlcnkoXCJTZXR0aW5nSWRzXCIsIGZ1bmN0aW9uKGlkcykgeyByZXR1cm4gaWRzLmluZGV4T2Yoc2VsZi5TZXR0aW5nSWQpICE9PSAtMTsgfSk7XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcbn07XG5cblBvcnQucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XG59O1xuXG5Qb3J0LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIHRhZykge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdHRhZyA9IHRhZyB8fCBcImxpXCI7XG5cblx0dmFyIGh0bWwgPSBcIlwiO1xuXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdGh0bWwgPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFBvcnQ7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gUXVhbGl0eUVmZmVjdChyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcIkxldmVsXCIsIFwiU2V0VG9FeGFjdGx5XCJdO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0Ly8gTWF5IGludm9sdmUgUXVhbGl0eSBvYmplY3QgcmVmZXJlbmNlcywgc28gY2FuJ3QgcmVzb2x2ZSB1bnRpbCBhZnRlciBhbGwgb2JqZWN0cyBhcmUgd2lyZWQgdXBcblx0dGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCA9IG51bGw7XG5cdHRoaXMuY2hhbmdlQnlBZHZhbmNlZCA9IG51bGw7XHRcblxuXHR0aGlzLmFzc29jaWF0ZWRRdWFsaXR5ID0gbnVsbDtcblx0XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgUXVhbGl0eUVmZmVjdC5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy5hc3NvY2lhdGVkUXVhbGl0eSA9IGFwaS5nZXQoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5Bc3NvY2lhdGVkUXVhbGl0eUlkLCB0aGlzKTtcblx0dGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCA9IGFwaS5kZXNjcmliZUFkdmFuY2VkRXhwcmVzc2lvbih0aGlzLmF0dHJpYnMuU2V0VG9FeGFjdGx5QWR2YW5jZWQpO1xuXHR0aGlzLmNoYW5nZUJ5QWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLkNoYW5nZUJ5QWR2YW5jZWQpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS5nZXRRdWFudGl0eSA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgY29uZGl0aW9uID0gXCJcIjtcblx0XG5cdGlmKHRoaXMuc2V0VG9FeGFjdGx5QWR2YW5jZWQgIT09IG51bGwpIHtcblx0XHRjb25kaXRpb24gPSBcIisoXCIgKyB0aGlzLnNldFRvRXhhY3RseUFkdmFuY2VkICsgXCIpXCI7XG5cdH1cblx0ZWxzZSBpZih0aGlzLlNldFRvRXhhY3RseSAhPT0gbnVsbCkge1xuXHRcdGNvbmRpdGlvbiA9IFwiPSBcIiArIHRoaXMuU2V0VG9FeGFjdGx5O1xuXHR9XG5cdGVsc2UgaWYodGhpcy5jaGFuZ2VCeUFkdmFuY2VkICE9PSBudWxsKSB7XG5cdFx0Y29uZGl0aW9uID0gXCIrKFwiICsgdGhpcy5jaGFuZ2VCeUFkdmFuY2VkICsgXCIpXCI7XG5cdH1cblx0ZWxzZSBpZih0aGlzLkxldmVsICE9PSBudWxsKSB7XG5cdFx0aWYodGhpcy5MZXZlbCA8IDApIHtcblx0XHRcdGNvbmRpdGlvbiA9IHRoaXMuTGV2ZWw7XG5cdFx0fVxuXHRcdGVsc2UgaWYodGhpcy5MZXZlbCA+IDApIHtcblx0XHRcdGNvbmRpdGlvbiA9IFwiK1wiICsgdGhpcy5MZXZlbDtcblx0XHR9XG5cdH1cblx0XG5cdHJldHVybiBjb25kaXRpb247XG59O1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS5pc0FkZGl0aXZlID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiB0aGlzLnNldFRvRXhhY3RseUFkdmFuY2VkIHx8IHRoaXMuU2V0VG9FeGFjdGx5IHx8IHRoaXMuY2hhbmdlQnlBZHZhbmNlZCB8fCAodGhpcy5MZXZlbCA+IDApO1xufTtcblxuUXVhbGl0eUVmZmVjdC5wcm90b3R5cGUuaXNTdWJ0cmFjdGl2ZSA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gIXRoaXMuc2V0VG9FeGFjdGx5QWR2YW5jZWQgJiYgIXRoaXMuU2V0VG9FeGFjdGx5ICYmICF0aGlzLmNoYW5nZUJ5QWR2YW5jZWQgJiYgKHRoaXMuTGV2ZWwgPD0gMCk7XG59O1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgcXVhbGl0eSA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoXCIrdGhpcy5JZCtcIikgb24gXCIgKyBxdWFsaXR5ICsgdGhpcy5nZXRRdWFudGl0eSgpO1xufTtcblxuUXVhbGl0eUVmZmVjdC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJzbWFsbFwiO1xuXG5cdHZhciBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0dmFyIHF1YWxpdHlfZWxlbWVudCA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XG5cblx0aWYoIXF1YWxpdHlfZWxlbWVudCkge1xuXHRcdHF1YWxpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRcdHF1YWxpdHlfZWxlbWVudC5pbm5lckhUTUwgPSBcIltJTlZBTElEXVwiO1xuXHR9XG5cdGVsc2Uge1xuXHRcdHF1YWxpdHlfZWxlbWVudCA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHkudG9Eb20oc2l6ZSwgZmFsc2UsIFwic3BhblwiKTtcblx0fVxuXG5cdHZhciBxdWFudGl0eV9lbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG5cdHF1YW50aXR5X2VsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIHF1YW50aXR5XCI7XG5cdHF1YW50aXR5X2VsZW1lbnQuaW5uZXJIVE1MID0gdGhpcy5nZXRRdWFudGl0eSgpO1xuXHRxdWFudGl0eV9lbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xuXG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQocXVhbGl0eV9lbGVtZW50KTtcblx0ZWxlbWVudC5hcHBlbmRDaGlsZChxdWFudGl0eV9lbGVtZW50KTtcblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gUXVhbGl0eUVmZmVjdDsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBRdWFsaXR5UmVxdWlyZW1lbnQocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbJ01pbkxldmVsJywgJ01heExldmVsJ107XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLmRpZmZpY3VsdHlBZHZhbmNlZCA9IG51bGw7XG5cdHRoaXMubWluQWR2YW5jZWQgPSBudWxsO1xuXHR0aGlzLm1heEFkdmFuY2VkID0gbnVsbDtcblxuXHR0aGlzLmFzc29jaWF0ZWRRdWFsaXR5ID0gbnVsbDtcblx0dGhpcy5jaGFuY2VRdWFsaXR5ID0gbnVsbDtcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBRdWFsaXR5UmVxdWlyZW1lbnQucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuUXVhbGl0eVJlcXVpcmVtZW50LnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy5kaWZmaWN1bHR5QWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLkRpZmZpY3VsdHlBZHZhbmNlZCk7XG5cdHRoaXMubWluQWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLk1pbkFkdmFuY2VkKTtcblx0dGhpcy5tYXhBZHZhbmNlZCA9IGFwaS5kZXNjcmliZUFkdmFuY2VkRXhwcmVzc2lvbih0aGlzLmF0dHJpYnMuTWF4QWR2YW5jZWQpO1xuXG5cdHRoaXMuYXNzb2NpYXRlZFF1YWxpdHkgPSBhcGkuZ2V0KGFwaS50eXBlcy5RdWFsaXR5LCB0aGlzLmF0dHJpYnMuQXNzb2NpYXRlZFF1YWxpdHlJZCwgdGhpcyk7XG5cblx0dGhpcy5jaGFuY2VRdWFsaXR5ID0gdGhpcy5nZXRDaGFuY2VDYXAoKTtcblxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzLCBhcGkpO1xufTtcblxuUXVhbGl0eVJlcXVpcmVtZW50LnByb3RvdHlwZS5nZXRDaGFuY2VDYXAgPSBmdW5jdGlvbigpIHtcblx0dmFyIHF1YWxpdHkgPSBudWxsO1xuXHRpZighdGhpcy5hdHRyaWJzLkRpZmZpY3VsdHlMZXZlbCkge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdHF1YWxpdHkgPSB0aGlzLmFzc29jaWF0ZWRRdWFsaXR5O1xuXHRpZighcXVhbGl0eSkge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdFxuXHRyZXR1cm4gTWF0aC5yb3VuZCh0aGlzLmF0dHJpYnMuRGlmZmljdWx0eUxldmVsICogKCgxMDAgKyBxdWFsaXR5LkRpZmZpY3VsdHlTY2FsZXIgKyA3KS8xMDApKTtcbn07XG5cblF1YWxpdHlSZXF1aXJlbWVudC5wcm90b3R5cGUuZ2V0UXVhbnRpdHkgPSBmdW5jdGlvbigpIHtcblx0dmFyIGNvbmRpdGlvbiA9IFwiXCI7XG5cbiAgaWYodGhpcy5kaWZmaWN1bHR5QWR2YW5jZWQgIT09IG51bGwpIHtcbiAgXHRjb25kaXRpb24gPSB0aGlzLmRpZmZpY3VsdHlBZHZhbmNlZDtcbiAgfVxuICBlbHNlIGlmKHRoaXMubWluQWR2YW5jZWQgIT09IG51bGwpIHtcbiAgXHRjb25kaXRpb24gPSB0aGlzLm1pbkFkdmFuY2VkO1xuICB9XG4gIGVsc2UgaWYodGhpcy5tYXhBZHZhbmNlZCAhPT0gbnVsbCkge1xuICBcdGNvbmRpdGlvbiA9IHRoaXMubWF4QWR2YW5jZWQ7XG4gIH1cblx0ZWxzZSBpZih0aGlzLmNoYW5jZVF1YWxpdHkgIT09IG51bGwpIHtcblx0XHRjb25kaXRpb24gPSB0aGlzLmNoYW5jZVF1YWxpdHkgKyBcIiBmb3IgMTAwJVwiO1xuXHR9XG5cdGVsc2UgaWYodGhpcy5NYXhMZXZlbCAhPT0gbnVsbCAmJiB0aGlzLk1pbkxldmVsICE9PSBudWxsKSB7XG5cdFx0aWYodGhpcy5NYXhMZXZlbCA9PT0gdGhpcy5NaW5MZXZlbCkge1xuXHRcdFx0Y29uZGl0aW9uID0gXCI9IFwiICsgdGhpcy5NaW5MZXZlbDtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25kaXRpb24gPSB0aGlzLk1pbkxldmVsICsgXCItXCIgKyB0aGlzLk1heExldmVsO1xuXHRcdH1cblx0fVxuXHRlbHNlIHtcblx0XHRpZih0aGlzLk1pbkxldmVsICE9PSBudWxsKSB7XG5cdFx0XHRjb25kaXRpb24gPSBcIiZnZTsgXCIgKyB0aGlzLk1pbkxldmVsO1xuXHRcdH1cblx0XHRpZih0aGlzLk1heExldmVsICE9PSBudWxsKSB7XG5cdFx0XHRjb25kaXRpb24gPSBcIiZsZTsgXCIgKyB0aGlzLk1heExldmVsO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gY29uZGl0aW9uO1xufTtcblxuUXVhbGl0eVJlcXVpcmVtZW50LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgcXVhbGl0eSA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoXCIrdGhpcy5JZCtcIikgb24gXCIgKyBxdWFsaXR5ICsgXCIgXCIgKyB0aGlzLmdldFF1YW50aXR5KCk7XG59O1xuXG5RdWFsaXR5UmVxdWlyZW1lbnQucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSkge1xuXG5cdHNpemUgPSBzaXplIHx8IFwic21hbGxcIjtcblxuXHR2YXIgZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdHZhciBxdWFsaXR5X2VsZW1lbnQgPSB0aGlzLmFzc29jaWF0ZWRRdWFsaXR5O1xuXG5cdGlmKCFxdWFsaXR5X2VsZW1lbnQpIHtcblx0XHRxdWFsaXR5X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcblx0XHRxdWFsaXR5X2VsZW1lbnQuaW5uZXJIVE1MID0gXCJbSU5WQUxJRF1cIjtcblx0fVxuXHRlbHNlIHtcblx0XHRxdWFsaXR5X2VsZW1lbnQgPSB0aGlzLmFzc29jaWF0ZWRRdWFsaXR5LnRvRG9tKHNpemUsIGZhbHNlLCBcInNwYW5cIik7XG5cdH1cblxuXHR2YXIgcXVhbnRpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRxdWFudGl0eV9lbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBxdWFudGl0eVwiO1xuXHRxdWFudGl0eV9lbGVtZW50LmlubmVySFRNTCA9IHRoaXMuZ2V0UXVhbnRpdHkoKTtcblx0cXVhbnRpdHlfZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRlbGVtZW50LmFwcGVuZENoaWxkKHF1YWxpdHlfZWxlbWVudCk7XG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQocXVhbnRpdHlfZWxlbWVudCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFF1YWxpdHlSZXF1aXJlbWVudDsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBRdWFsaXR5KHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdOYW1lJyxcblx0XHQnRGVzY3JpcHRpb24nLFxuXHRcdCdJbWFnZScsXG5cblx0XHQnQ2F0ZWdvcnknLFxuXHRcdCdOYXR1cmUnLFxuXHRcdCdUYWcnLFxuXG5cdFx0XCJJc1Nsb3RcIixcblxuXHRcdCdBbGxvd2VkT24nLFxuXHRcdFwiQXZhaWxhYmxlQXRcIixcblxuXHRcdCdDYXAnLFxuXHRcdCdEaWZmaWN1bHR5U2NhbGVyJyxcblx0XHQnRW5oYW5jZW1lbnRzJ1xuXHRdO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy5TdGF0ZXMgPSB0aGlzLmdldFN0YXRlcyhyYXcuQ2hhbmdlRGVzY3JpcHRpb25UZXh0KTtcblx0dGhpcy5MZXZlbERlc2NyaXB0aW9uVGV4dCA9IHRoaXMuZ2V0U3RhdGVzKHJhdy5MZXZlbERlc2NyaXB0aW9uVGV4dCk7XG5cdHRoaXMuTGV2ZWxJbWFnZVRleHQgPSB0aGlzLmdldFN0YXRlcyhyYXcuTGV2ZWxJbWFnZVRleHQpO1xuXG5cdHRoaXMudXNlRXZlbnQgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFF1YWxpdHkucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuUXVhbGl0eS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHRoaXMudXNlRXZlbnQgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLkV2ZW50LCB0aGlzLmF0dHJpYnMuVXNlRXZlbnQsIHRoaXMpO1xuXHRpZih0aGlzLnVzZUV2ZW50KSB7XG5cdFx0dGhpcy51c2VFdmVudC50YWcgPSBcInVzZVwiO1xuXHR9XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcbn07XG5cblF1YWxpdHkucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyAobG9uZyA/IFwiIFtcIiArIHRoaXMuTmF0dXJlICsgXCIgPiBcIiArIHRoaXMuQ2F0ZWdvcnkgKyBcIiA+IFwiICsgdGhpcy5UYWcgKyBcIl0gXCIgOiBcIlwiKSArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5RdWFsaXR5LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblx0dGFnID0gdGFnIHx8IFwibGlcIjtcblxuXHR2YXIgaHRtbCA9IFwiXCI7XG5cblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0aHRtbCA9IFwiXFxuPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCJzbWFsbC5wbmcnIC8+XCI7XG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCI8L2gzPlwiO1xuXHRodG1sICs9IFwiXFxuPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xuXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcblxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xuXG5cdGlmKGluY2x1ZGVDaGlsZHJlbikge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XG5cdFx0XHRpZihjaGlsZExpc3QpIHtcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGlmKHNlbGYudXNlRXZlbnQpIHtcblxuXHRcdFx0XHRcdHZhciB3cmFwcGVyQ2x1bXAgPSBuZXcgQ2x1bXAoW3NlbGYudXNlRXZlbnRdLCBhcGkudHlwZXMuRXZlbnQpO1xuXHRcdFx0XHRcdHZhciBjaGlsZF9ldmVudHMgPSB3cmFwcGVyQ2x1bXAudG9Eb20oc2l6ZSwgdHJ1ZSk7XG5cblx0XHRcdFx0XHRjaGlsZF9ldmVudHMuY2xhc3NMaXN0LmFkZChcImNoaWxkLWxpc3RcIik7XG5cdFx0XHRcdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChjaGlsZF9ldmVudHMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gUXVhbGl0eTsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBTZXR0aW5nKHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdJZCdcblx0XTtcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG5cdHRoaXMuc2hvcHMgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFNldHRpbmcucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuU2V0dGluZy5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMpO1xufTtcblxuU2V0dGluZy5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiICNcIiArIHRoaXMuSWQ7XG59O1xuXG5TZXR0aW5nLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblx0dGFnID0gdGFnIHx8IFwibGlcIjtcblxuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRodG1sID0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLklkK1wiPC9oMz5cIjtcblxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XG5cblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gU2V0dGluZzsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBTaG9wKHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdJZCcsXG5cdFx0J05hbWUnLFxuXHRcdCdEZXNjcmlwdGlvbicsXG5cdFx0J0ltYWdlJyxcblx0XHQnT3JkZXJpbmcnXG5cdF07XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLmF2YWlsYWJpbGl0aWVzID0gbnVsbDtcblx0dGhpcy51bmxvY2tDb3N0ID0gbnVsbDtcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBTaG9wLnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XG5cblNob3AucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xuXG5cdGFwaSA9IHRoZUFwaTtcblxuXHR0aGlzLmF2YWlsYWJpbGl0aWVzID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5BdmFpbGFiaWxpdGllcyB8fCBbXSwgYXBpLnR5cGVzLkF2YWlsYWJpbGl0eSwgdGhpcyk7XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcyk7XG59O1xuXG5TaG9wLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xufTtcblxuU2hvcC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4sIHRhZykge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XG5cdHRhZyA9IHRhZyB8fCBcImxpXCI7XG5cblx0dmFyIHNlbGYgPSB0aGlzO1xuXHR2YXIgaHRtbCA9IFwiXCI7XG5cblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0aHRtbCA9IFwiXFxuPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCIucG5nJyAvPlwiO1xuXHRodG1sICs9IFwiXFxuPGgzIGNsYXNzPSd0aXRsZSc+XCIrdGhpcy5OYW1lK1wiPC9oMz5cIjtcblx0aHRtbCArPSBcIlxcbjxwIGNsYXNzPSdkZXNjcmlwdGlvbic+XCIrdGhpcy5EZXNjcmlwdGlvbitcIjwvcD5cIjtcblxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XG5cblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XG5cdFx0XHRpZihjaGlsZExpc3QpIHtcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGlmKHNlbGYuYXZhaWxhYmlsaXRpZXMpIHtcblxuXHRcdFx0XHRcdHZhciBjaGlsZF9lbGVtZW50cyA9IHNlbGYuYXZhaWxhYmlsaXRpZXMudG9Eb20oXCJub3JtYWxcIiwgdHJ1ZSk7XG5cblx0XHRcdFx0XHRjaGlsZF9lbGVtZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2VsZW1lbnRzKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFNob3A7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gU3Bhd25lZEVudGl0eShyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0XHQnTmFtZScsXG5cdFx0J0h1bWFuTmFtZScsXG5cblx0XHQnTmV1dHJhbCcsXG5cdFx0J1ByZWZhYk5hbWUnLFxuXHRcdCdEb3JtYW50QmVoYXZpb3VyJyxcblx0XHQnQXdhcmVCZWhhdmlvdXInLFxuXG5cdFx0J0h1bGwnLFxuXHRcdCdDcmV3Jyxcblx0XHQnTGlmZScsXG5cdFx0J01vdmVtZW50U3BlZWQnLFxuXHRcdCdSb3RhdGlvblNwZWVkJyxcblx0XHQnQmVhc3RpZUNoYXJhY3RlcmlzdGljc05hbWUnLFxuXHRcdCdDb21iYXRJdGVtcycsXG5cdFx0J0xvb3RQcmVmYWJOYW1lJyxcblx0XHQnR2xlYW1WYWx1ZSdcblx0XTtcblx0cmF3LklkID0gcmF3Lk5hbWU7XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLnBhY2lmeUV2ZW50ID0gbnVsbDtcblx0dGhpcy5raWxsUXVhbGl0eUV2ZW50ID0gbnVsbDtcblx0dGhpcy5jb21iYXRBdHRhY2tOYW1lcyA9IFtdO1xuXG5cdHRoaXMuaW1hZ2UgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFNwYXduZWRFbnRpdHkucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuU3Bhd25lZEVudGl0eS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHZhciBzZWxmID0gdGhpcztcblx0XG5cdHRoaXMuY29tYmF0QXR0YWNrTmFtZXMgPSAodGhpcy5hdHRyaWJzLkNvbWJhdEF0dGFja05hbWVzIHx8IFtdKS5tYXAoZnVuY3Rpb24obmFtZSkge1xuXHRcdHJldHVybiBhcGkuZ2V0KGFwaS50eXBlcy5Db21iYXRBdHRhY2ssIG5hbWUsIHNlbGYpO1xuXHR9KS5maWx0ZXIoZnVuY3Rpb24oYXR0YWNrKSB7XG5cdFx0cmV0dXJuIHR5cGVvZiBhdHRhY2sgPT09IFwib2JqZWN0XCI7XG5cdH0pO1xuXG5cdHRoaXMucGFjaWZ5RXZlbnQgPSBhcGkuZ2V0KGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLlBhY2lmeUV2ZW50SWQsIHRoaXMpO1xuXHRpZih0aGlzLnBhY2lmeUV2ZW50KSB7XG5cdFx0dGhpcy5wYWNpZnlFdmVudC50YWcgPSBcInBhY2lmaWVkXCI7XG5cdH1cblxuXHR0aGlzLmtpbGxRdWFsaXR5RXZlbnQgPSBhcGkuZ2V0KGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLktpbGxRdWFsaXR5RXZlbnRJZCwgdGhpcyk7XG5cdGlmKHRoaXMua2lsbFF1YWxpdHlFdmVudCkge1xuXHRcdHRoaXMua2lsbFF1YWxpdHlFdmVudC50YWcgPSBcImtpbGxlZFwiO1xuXHR9XG5cblx0dGhpcy5pbWFnZSA9ICgodGhpcy5raWxsUXVhbGl0eUV2ZW50ICYmIHRoaXMua2lsbFF1YWxpdHlFdmVudC5JbWFnZSkgfHwgKHRoaXMucGFjaWZ5RXZlbnQgJiYgdGhpcy5wYWNpZnlFdmVudC5JbWFnZSkpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5TcGF3bmVkRW50aXR5LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLkh1bWFuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5TcGF3bmVkRW50aXR5LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbikge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XG5cblx0dmFyIHNlbGYgPSB0aGlzO1xuXG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRpZih0aGlzLkltYWdlICE9PSBudWxsICYmIHRoaXMuSW1hZ2UgIT09IFwiXCIpIHtcblx0XHRodG1sID0gXCI8aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5pbWFnZStcInNtYWxsLnBuZycgLz5cIjtcblx0fVxuXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLkh1bWFuTmFtZStcIjwvaDM+XCI7XG5cblx0aWYoc2l6ZSAhPT0gXCJzbWFsbFwiKSB7XG5cdFx0aWYodGhpcy5xdWFsaXRpZXNSZXF1aXJlZCkge1xuXHRcdFx0aHRtbCArPSBcIjxkaXYgY2xhc3M9J3NpZGViYXInPlwiO1xuXHRcdFx0aHRtbCArPSB0aGlzLnF1YWxpdGllc1JlcXVpcmVkLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xuXHRcdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xuXHRcdH1cblxuXHRcdGh0bWwgKz0gXCI8ZGwgY2xhc3M9J2NsdW1wLWxpc3Qgc21hbGwnPlwiO1xuXG5cdFx0WydIdWxsJywgJ0NyZXcnLCAnTGlmZScsICdNb3ZlbWVudFNwZWVkJywgJ1JvdGF0aW9uU3BlZWQnXS5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xuXHRcdFx0aHRtbCArPSBcIjxkdCBjbGFzcz0naXRlbSc+XCIra2V5K1wiPC9kdD48ZGQgY2xhc3M9J3F1YW50aXR5Jz5cIitzZWxmW2tleV0rXCI8L2RkPlwiO1xuXHRcdH0pO1xuXHRcdGh0bWwgKz0gXCI8L2RsPlwiO1xuXHR9XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0aWYoaW5jbHVkZUNoaWxkcmVuKSB7XG5cdFx0ZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oZSkge1xuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblxuXHRcdFx0dmFyIGNoaWxkTGlzdCA9IGVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5jaGlsZC1saXN0XCIpO1xuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR2YXIgc3VjY2Vzc0V2ZW50ID0gc2VsZi5zdWNjZXNzRXZlbnQ7XG5cdFx0XHRcdHZhciBkZWZhdWx0RXZlbnQgPSBzZWxmLmRlZmF1bHRFdmVudDtcblx0XHRcdFx0dmFyIHF1YWxpdGllc1JlcXVpcmVkID0gIHNlbGYucXVhbGl0aWVzUmVxdWlyZWQ7XG5cdFx0XHRcdHZhciBldmVudHMgPSBbXTtcblx0XHRcdFx0aWYoc3VjY2Vzc0V2ZW50ICYmIHF1YWxpdGllc1JlcXVpcmVkICYmIHF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xuXHRcdFx0XHRcdGV2ZW50cy5wdXNoKHN1Y2Nlc3NFdmVudCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYoZGVmYXVsdEV2ZW50KSB7XG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goZGVmYXVsdEV2ZW50KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZihldmVudHMubGVuZ3RoKSB7XG5cdFx0XHRcdFx0dmFyIHdyYXBwZXJDbHVtcCA9IG5ldyBDbHVtcChldmVudHMsIGFwaS50eXBlcy5FdmVudCk7XG5cdFx0XHRcdFx0dmFyIGNoaWxkX2V2ZW50cyA9IHdyYXBwZXJDbHVtcC50b0RvbShzaXplLCB0cnVlKTtcblxuXHRcdFx0XHRcdGNoaWxkX2V2ZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2V2ZW50cyk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdHJldHVybiBlbGVtZW50O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBTcGF3bmVkRW50aXR5OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XG52YXIgUG9ydCA9IHJlcXVpcmUoJy4vcG9ydCcpO1xudmFyIEFyZWEgPSByZXF1aXJlKCcuL2FyZWEnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gVGlsZVZhcmlhbnQocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXG5cdFx0J05hbWUnLFxuXHRcdCdIdW1hbk5hbWUnLFxuXHRcdCdEZXNjcmlwdGlvbicsXG5cblx0XHQnTWF4VGlsZVBvcHVsYXRpb24nLFxuXHRcdCdNaW5UaWxlUG9wdWxhdGlvbicsXG5cdFx0XG5cdFx0J1NlYUNvbG91cicsXG5cdFx0J011c2ljVHJhY2tOYW1lJyxcblx0XHQnQ2hhbmNlT2ZXZWF0aGVyJyxcblx0XHQnRm9nUmV2ZWFsVGhyZXNob2xkJ1xuXHRdO1xuXG4vKlxuTGFiZWxEYXRhOiBBcnJheVs2XVxuUGhlbm9tZW5hRGF0YTogQXJyYXlbMV1cblNwYXduUG9pbnRzOiBBcnJheVsyXVxuVGVycmFpbkRhdGE6IEFycmF5WzE0XVxuV2VhdGhlcjogQXJyYXlbMV1cbiovXG5cblx0cmF3LklkID0gcGFyZW50Lk5hbWUrXCIvXCIrcmF3Lk5hbWU7XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLlNldHRpbmdJZCA9IHJhdy5TZXR0aW5nLklkO1xuXHR0aGlzLnNldHRpbmcgPSBudWxsO1xuXG5cdHRoaXMucG9ydHMgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlBvcnREYXRhIHx8IFtdLCBQb3J0LCB0aGlzKTtcblxuXHR0aGlzLmFyZWFzID0gbnVsbDtcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBUaWxlVmFyaWFudC5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5UaWxlVmFyaWFudC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHRoaXMuc2V0dGluZyA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuU2V0dGluZywgdGhpcy5hdHRyaWJzLlNldHRpbmcsIHRoaXMpO1xuXG5cdHRoaXMucG9ydHMuZm9yRWFjaChmdW5jdGlvbihwKSB7IHAud2lyZVVwKGFwaSk7IH0pO1xuXG5cdC8vIEFsc28gY3JlYXRlIGEgbGlzdCBvZiBhbGwgdGhlIGFyZWFzIG9mIGVhY2ggb2YgdGhlIHBvcnRzIGluIHRoaXMgb2JqZWN0IGZvciBjb252ZW5pZW5jZVxuXHR0aGlzLmFyZWFzID0gbmV3IENsdW1wKHRoaXMucG9ydHMubWFwKGZ1bmN0aW9uKHApIHsgcmV0dXJuIHAuYXJlYTsgfSksIGFwaS50eXBlcy5BcmVhLCB0aGlzKTtcblxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzKTtcbn07XG5cblRpbGVWYXJpYW50LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKGxvbmcpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5IdW1hbk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XG59O1xuXG5UaWxlVmFyaWFudC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCB0YWcpIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xuXG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRodG1sID0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLkh1bWFuTmFtZStcIjwvaDM+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRpbGVWYXJpYW50OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XG52YXIgVGlsZVZhcmlhbnQgPSByZXF1aXJlKCcuL3RpbGUtdmFyaWFudCcpO1xudmFyIFBvcnQgPSByZXF1aXJlKCcuL3BvcnQnKTtcbnZhciBBcmVhID0gcmVxdWlyZSgnLi9hcmVhJyk7XG5cbnZhciBhcGk7XG5cbmZ1bmN0aW9uIFRpbGUocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXG5cdFx0J05hbWUnXG5cdF07XG5cdHJhdy5JZCA9IHJhdy5OYW1lO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy50aWxlVmFyaWFudHMgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlRpbGVzIHx8IFtdLCBUaWxlVmFyaWFudCwgdGhpcyk7XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgVGlsZS5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5UaWxlLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy50aWxlVmFyaWFudHMuZm9yRWFjaChmdW5jdGlvbih0dikgeyB0di53aXJlVXAoYXBpKTsgfSk7XG5cblx0Ly8gQWxzbyBjcmVhdGUgYSBsaXN0IG9mIGFsbCB0aGUgcG9ydHMgYW5kIGFyZWFzIG9mIGVhY2ggb2YgdGhlIHRpbGV2YXJpYW50cyBpbiB0aGlzIG9iamVjdCBmb3IgY29udmVuaWVuY2Vcblx0dmFyIGFsbF9wb3J0cyA9IHt9O1xuXHR2YXIgYWxsX2FyZWFzID0ge307XG5cdHRoaXMudGlsZVZhcmlhbnRzLmZvckVhY2goZnVuY3Rpb24odHYpIHtcblx0XHR0di5wb3J0cy5mb3JFYWNoKGZ1bmN0aW9uKHApIHtcblx0XHRcdGFsbF9wb3J0c1twLklkXSA9IHA7XG5cdFx0XHRhbGxfYXJlYXNbcC5hcmVhLklkXSA9IHAuYXJlYTtcblx0XHR9KTtcblx0fSk7XG5cdHRoaXMucG9ydHMgPSBuZXcgQ2x1bXAoT2JqZWN0LmtleXMoYWxsX3BvcnRzKS5tYXAoZnVuY3Rpb24ocCkgeyByZXR1cm4gYWxsX3BvcnRzW3BdOyB9KSwgYXBpLnR5cGVzLlBvcnQsIHRoaXMpO1xuXHR0aGlzLmFyZWFzID0gbmV3IENsdW1wKE9iamVjdC5rZXlzKGFsbF9hcmVhcykubWFwKGZ1bmN0aW9uKGEpIHsgcmV0dXJuIGFsbF9hcmVhc1thXTsgfSksIGFwaS50eXBlcy5BcmVhLCB0aGlzKTtcblxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzKTtcbn07XG5cblRpbGUucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XG59O1xuXG5UaWxlLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIHRhZykge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdHRhZyA9IHRhZyB8fCBcImxpXCI7XG5cblx0dmFyIGh0bWwgPSBcIlwiO1xuXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdGh0bWwgPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRpbGU7IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4vYXBpJyk7XG52YXIgZHJhZ25kcm9wID0gcmVxdWlyZSgnLi91aS9kcmFnbmRyb3AnKTtcbnZhciBxdWVyeSA9IHJlcXVpcmUoJy4vdWkvcXVlcnknKTtcblxuXG4kKFwiI3RhYnMgLmJ1dHRvbnMgbGlcIikub24oXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cbiAgdmFyIHR5cGUgPSAkKHRoaXMpLmF0dHIoXCJkYXRhLXR5cGVcIik7XG5cbiAgJChcIiN0YWJzIC5wYW5lcyAucGFuZVwiKS5oaWRlKCk7IC8vIEhpZGUgYWxsIHBhbmVzXG4gICQoXCIjdGFicyAuYnV0dG9ucyBsaVwiKS5yZW1vdmVDbGFzcyhcImFjdGl2ZVwiKTsgLy8gRGVhY3RpdmF0ZSBhbGwgYnV0dG9uc1xuXG4gICQoXCIjdGFicyAucGFuZXMgLlwiK3R5cGUudG9Mb3dlckNhc2UoKSkuc2hvdygpO1xuICAkKFwiI3RhYnMgLmJ1dHRvbnMgW2RhdGEtdHlwZT1cIit0eXBlK1wiXVwiKS5hZGRDbGFzcyhcImFjdGl2ZVwiKTtcbn0pO1xuXG4vLyBTZXR1cCB0aGUgZG5kIGxpc3RlbmVycy5cbnZhciBkcm9wWm9uZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkcm9wLXpvbmUnKTtcblxuZHJvcFpvbmUuYWRkRXZlbnRMaXN0ZW5lcignZHJhZ2VudGVyJywgZHJhZ25kcm9wLmhhbmRsZXJzLmRyYWdPdmVyLCBmYWxzZSk7XG5kcm9wWm9uZS5hZGRFdmVudExpc3RlbmVyKCdkcmFnbGVhdmUnLCBkcmFnbmRyb3AuaGFuZGxlcnMuZHJhZ0VuZCwgZmFsc2UpO1xuZHJvcFpvbmUuYWRkRXZlbnRMaXN0ZW5lcignZHJhZ292ZXInLCBkcmFnbmRyb3AuaGFuZGxlcnMuZHJhZ092ZXIsIGZhbHNlKTtcblxuZHJvcFpvbmUuYWRkRXZlbnRMaXN0ZW5lcignZHJvcCcsIGRyYWduZHJvcC5oYW5kbGVycy5kcmFnRHJvcCwgZmFsc2UpO1xuXG5kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncGF0aHMtdG8tbm9kZScpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgcXVlcnkucGF0aHNUb05vZGVVSSwgZmFsc2UpO1xuXG4vLyBGb3IgY29udmVuaWVuY2VcbndpbmRvdy5hcGkgPSBhcGk7XG53aW5kb3cuYXBpLnF1ZXJ5ID0gcXVlcnk7IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4uL2FwaScpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi4vb2JqZWN0cy9jbHVtcCcpO1xudmFyIGlvID0gcmVxdWlyZSgnLi4vaW8nKTtcblxudmFyIHJlbmRlciA9IHJlcXVpcmUoJy4vcmVuZGVyJyk7XG5cbmZ1bmN0aW9uIGhhbmRsZURyYWdPdmVyKGV2dCkge1xuICBldnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gIGV2dC5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICQoXCIjZHJvcC16b25lXCIpLmFkZENsYXNzKFwiZHJvcC10YXJnZXRcIik7XG59XG5cbmZ1bmN0aW9uIGhhbmRsZURyYWdFbmQoZXZ0KSB7XG4gIGV2dC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgZXZ0LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgJChcIiNkcm9wLXpvbmVcIikucmVtb3ZlQ2xhc3MoXCJkcm9wLXRhcmdldFwiKTtcbn1cblxuZnVuY3Rpb24gaGFuZGxlRHJhZ0Ryb3AoZXZ0KSB7XG5cbiAgJChcIiNkcm9wLXpvbmVcIikucmVtb3ZlQ2xhc3MoXCJkcm9wLXRhcmdldFwiKTtcblxuICBldnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gIGV2dC5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gIHZhciBmaWxlcyA9IGV2dC5kYXRhVHJhbnNmZXIuZmlsZXM7IC8vIEZpbGVMaXN0IG9iamVjdC5cblxuICAvLyBGaWxlcyBpcyBhIEZpbGVMaXN0IG9mIEZpbGUgb2JqZWN0cy4gTGlzdCBzb21lIHByb3BlcnRpZXMuXG4gIHZhciBvdXRwdXQgPSBbXTtcbiAgaW8ucmVzZXRGaWxlc1RvTG9hZCgpO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGZpbGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIGYgPSBmaWxlc1tpXTtcbiAgICB2YXIgZmlsZW5hbWUgPSBlc2NhcGUoZi5uYW1lKTtcbiAgICB2YXIgdHlwZU5hbWUgPSBpby5maWxlT2JqZWN0TWFwW2ZpbGVuYW1lXTtcbiAgICB2YXIgVHlwZSA9IGFwaS50eXBlc1t0eXBlTmFtZV07XG4gICAgaWYoVHlwZSkge1xuICAgICAgaW8uaW5jcmVtZW50RmlsZXNUb0xvYWQoKTtcbiAgICAgIGFwaS5yZWFkRnJvbUZpbGUoVHlwZSwgZiwgZnVuY3Rpb24oKSB7XG4gICAgICAgIGlvLmRlY3JlbWVudEZpbGVzVG9Mb2FkKCk7XG5cbiAgICAgICAgaWYoaW8uY291bnRGaWxlc1RvTG9hZCgpID09PSAwKSB7XG4gICAgICAgICAgYXBpLndpcmVVcE9iamVjdHMoKTtcbiAgICAgICAgICByZW5kZXIubGlzdHMoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBvdXRwdXQucHVzaCgnPGxpPjxzdHJvbmc+JywgZXNjYXBlKGYubmFtZSksICc8L3N0cm9uZz4gKCcsIGYudHlwZSB8fCAnbi9hJywgJykgLSAnLFxuICAgICAgICAgICAgICAgIGYuc2l6ZSwgJyBieXRlcywgbGFzdCBtb2RpZmllZDogJyxcbiAgICAgICAgICAgICAgICBmLmxhc3RNb2RpZmllZERhdGUgPyBmLmxhc3RNb2RpZmllZERhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCkgOiAnbi9hJyxcbiAgICAgICAgICAgICAgICAnPC9saT4nKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBvdXRwdXQucHVzaCgnPGxpPkVSUk9SOiBObyBoYW5kbGVyIGZvciBmaWxlIDxzdHJvbmc+JyAsIGVzY2FwZShmLm5hbWUpLCAnPC9zdHJvbmc+PC9saT4nKTtcbiAgICB9XG4gIH1cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xpc3QnKS5pbm5lckhUTUwgPSAnPHVsPicgKyBvdXRwdXQuam9pbignJykgKyAnPC91bD4nO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0aGFuZGxlcnM6IHtcblx0XHRkcmFnT3ZlcjogaGFuZGxlRHJhZ092ZXIsXG5cdFx0ZHJhZ0VuZDogaGFuZGxlRHJhZ0VuZCxcblx0XHRkcmFnRHJvcDogaGFuZGxlRHJhZ0Ryb3Bcblx0fVxufTsiLCJ2YXIgYXBpID0gcmVxdWlyZSgnLi4vYXBpJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuLi9vYmplY3RzL2NsdW1wJyk7XG5cbmZ1bmN0aW9uIFJvdXRlTm9kZShub2RlKSB7XG4gIHRoaXMubm9kZSA9IG5vZGU7XG4gIHRoaXMuY2hpbGRyZW4gPSBbXTtcbn1cblxuZnVuY3Rpb24gcGF0aHNUb05vZGVVSSgpIHtcblxuICB2YXIgdHlwZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0eXBlJyk7XG4gIHR5cGUgPSB0eXBlLm9wdGlvbnNbdHlwZS5zZWxlY3RlZEluZGV4XS52YWx1ZTtcblxuICB2YXIgb3BlcmF0aW9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ29wZXJhdGlvbicpO1xuICBvcGVyYXRpb24gPSBvcGVyYXRpb24ub3B0aW9uc1tvcGVyYXRpb24uc2VsZWN0ZWRJbmRleF0udmFsdWU7XG5cbiAgdmFyIGlkID0gcHJvbXB0KFwiSWQgb2YgXCIrdHlwZSk7XG5cbiAgaWYoIWlkKSB7ICAvLyBDYW5jZWxsZWQgZGlhbG9ndWVcbiAgICByZXR1cm47XG4gIH1cblxuICB2YXIgaXRlbSA9IGFwaS5saWJyYXJ5W3R5cGVdLmlkKGlkKTtcblxuICBpZighaXRlbSkge1xuICAgIGFsZXJ0KFwiQ291bGQgbm90IGZpbmQgXCIrdHlwZStcIiBcIitpZCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgdmFyIHJvb3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInF1ZXJ5LXRyZWVcIik7XG4gIHJvb3QuaW5uZXJIVE1MID0gXCJcIjtcblxuICB2YXIgdGl0bGUgPSAkKCcucGFuZS5xdWVyeSAucGFuZS10aXRsZScpLnRleHQoXCJRdWVyeTogXCIraXRlbS50b1N0cmluZygpKTtcblxuICB2YXIgcm91dGVzID0gcGF0aHNUb05vZGUoaXRlbSwge30pO1xuXG4gIGlmKHJvdXRlcyAmJiByb3V0ZXMuY2hpbGRyZW4ubGVuZ3RoKSB7XG5cbiAgICByb3V0ZXMgPSBmaWx0ZXJQYXRoc1RvTm9kZShyb3V0ZXMsIG9wZXJhdGlvbik7XG5cbiAgICB2YXIgdG9wX2NoaWxkcmVuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInVsXCIpO1xuICAgIHRvcF9jaGlsZHJlbi5jbGFzc05hbWUgKz0gXCJjbHVtcC1saXN0IHNtYWxsXCI7XG5cbiAgICByb3V0ZXMuY2hpbGRyZW4uZm9yRWFjaChmdW5jdGlvbihjaGlsZF9yb3V0ZSkge1xuICAgICAgdmFyIHRyZWUgPSByZW5kZXJQYXRoc1RvTm9kZShjaGlsZF9yb3V0ZSwgW10pO1xuICAgICAgdG9wX2NoaWxkcmVuLmFwcGVuZENoaWxkKHRyZWUpO1xuICAgIH0pO1xuXG4gICAgcm9vdC5hcHBlbmRDaGlsZCh0b3BfY2hpbGRyZW4pO1xuICB9XG4gIGVsc2Uge1xuICAgIGFsZXJ0KFwiVGhpcyBcIit0eXBlK1wiIGlzIGEgcm9vdCBub2RlIHdpdGggbm8gcGFyZW50cyB0aGF0IHNhdGlzZnkgdGhlIGNvbmRpdGlvbnNcIik7XG4gIH1cbiAgXG59XG5cbmZ1bmN0aW9uIHBhdGhzVG9Ob2RlKG5vZGUsIHNlZW4sIHBhcmVudCkge1xuXG4gIGlmKHNlZW5bbm9kZS5JZF0pIHsgICAvLyBEb24ndCByZWN1cnNlIGludG8gbm9kZXMgd2UndmUgYWxyZWFkeSBzZWVuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgdmFyIGFuY2VzdHJ5ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShzZWVuKSk7XG4gIGFuY2VzdHJ5W25vZGUuSWRdID0gdHJ1ZTtcblxuICB2YXIgdGhpc19ub2RlID0gbmV3IFJvdXRlTm9kZSgvKm5vZGUubGlua1RvRXZlbnQgPyBub2RlLmxpbmtUb0V2ZW50IDoqLyBub2RlKTsgLy8gSWYgdGhpcyBub2RlIGlzIGp1c3QgYSBsaW5rIHRvIGFub3RoZXIgb25lLCBza2lwIG92ZXIgdGhlIHVzZWxlc3MgbGlua1xuXG4gIGlmKG5vZGUgaW5zdGFuY2VvZiBhcGkudHlwZXMuU3Bhd25lZEVudGl0eSkge1xuICAgIHJldHVybiB0aGlzX25vZGU7ICAgLy8gTGVhZiBub2RlIGluIHRyZWVcbiAgfVxuICBlbHNlIGlmKG5vZGUgaW5zdGFuY2VvZiBhcGkudHlwZXMuRXZlbnQgJiYgbm9kZS50YWcgPT09IFwidXNlXCIpIHtcbiAgICByZXR1cm4gdGhpc19ub2RlOyAgIC8vIExlYWYgbm9kZSBpbiB0cmVlXG4gIH1cbiAgZWxzZSBpZihub2RlIGluc3RhbmNlb2YgYXBpLnR5cGVzLkV2ZW50ICYmIHBhcmVudCBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCAmJiAocGFyZW50LnRhZyA9PT0gXCJraWxsZWRcIiB8fCBwYXJlbnQudGFnID09PSBcInBhY2lmaWVkXCIpKSB7IC8vIElmIHRoaXMgaXMgYW4gZXZlbnQgdGhhdCdzIHJlYWNoYWJsZSBieSBraWxsaW5nIGEgbW9uc3RlciwgZG9uJ3QgcmVjdXJzZSBhbnkgb3RoZXIgY2F1c2VzIChhcyB0aGV5J3JlIHVzdWFsbHkgbWlzbGVhZGluZy9jaXJjdWxhcilcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZWxzZSBpZihub2RlIGluc3RhbmNlb2YgYXBpLnR5cGVzLlNldHRpbmcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZWxzZSBpZiAobm9kZSBpbnN0YW5jZW9mIGFwaS50eXBlcy5Qb3J0KSB7XG4gICAgcmV0dXJuIG5ldyBSb3V0ZU5vZGUobm9kZS5hcmVhKTtcbiAgfVxuICBlbHNlIGlmKG5vZGUubGltaXRlZFRvQXJlYSAmJiBub2RlLmxpbWl0ZWRUb0FyZWEuSWQgIT09IDEwMTk1Nikge1xuICAgIHZhciBhcmVhX25hbWUgPSBub2RlLmxpbWl0ZWRUb0FyZWEuTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIHZhciBldmVudF9uYW1lID0gKG5vZGUuTmFtZSAmJiBub2RlLk5hbWUudG9Mb3dlckNhc2UoKSkgfHwgXCJcIjtcbiAgICBpZihhcmVhX25hbWUuaW5kZXhPZihldmVudF9uYW1lKSAhPT0gLTEgfHwgZXZlbnRfbmFtZS5pbmRleE9mKGFyZWFfbmFtZSkgIT09IC0xKSB7ICAvLyBJZiBBcmVhIGhhcyBzaW1pbGFyIG5hbWUgdG8gRXZlbnQsIGlnbm9yZSB0aGUgZXZlbnQgYW5kIGp1c3Qgc3Vic3RpdHV0ZSB0aGUgYXJlYVxuICAgICAgcmV0dXJuIG5ldyBSb3V0ZU5vZGUobm9kZS5saW1pdGVkVG9BcmVhKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICB0aGlzX25vZGUuY2hpbGRyZW4ucHVzaChuZXcgUm91dGVOb2RlKG5vZGUubGltaXRlZFRvQXJlYSkpOyAgIC8vIEVsc2UgaW5jbHVkZSBib3RoIHRoZSBBcmVhIGFuZCB0aGUgRXZlbnRcbiAgICAgIHJldHVybiB0aGlzX25vZGU7XG4gICAgfVxuICAgIFxuICB9XG4gIGVsc2Uge1xuICAgIGZvcih2YXIgaT0wOyBpPG5vZGUucGFyZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHRoZV9wYXJlbnQgPSBub2RlLnBhcmVudHNbaV07XG4gICAgICB2YXIgc3VidHJlZSA9IHBhdGhzVG9Ob2RlKHRoZV9wYXJlbnQsIGFuY2VzdHJ5LCBub2RlKTtcbiAgICAgIGlmKHN1YnRyZWUpIHtcbiAgICAgICAgdGhpc19ub2RlLmNoaWxkcmVuLnB1c2goc3VidHJlZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmKCF0aGlzX25vZGUuY2hpbGRyZW4ubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRoaXNfbm9kZTtcbn1cblxuZnVuY3Rpb24gZmlsdGVyUGF0aHNUb05vZGUocm91dGVzLCBvcGVyYXRpb24pIHtcbiAgLy8gRmlsdGVyIHJvdXRlcyBieSBvcGVyYXRpb25cbiAgaWYocm91dGVzICYmIHJvdXRlcy5jaGlsZHJlbiAmJiBvcGVyYXRpb24gIT09IFwiYW55XCIpIHtcbiAgICByb3V0ZXMuY2hpbGRyZW4gPSByb3V0ZXMuY2hpbGRyZW4uZmlsdGVyKGZ1bmN0aW9uKHJvdXRlX25vZGUpIHtcblxuICAgICAgbHVtcCA9IHJvdXRlX25vZGUubm9kZTtcblxuICAgICAgaWYob3BlcmF0aW9uID09PSBcImFkZGl0aXZlXCIpIHtcbiAgICAgICAgcmV0dXJuIGx1bXAuaXNPbmVPZihbYXBpLnR5cGVzLlF1YWxpdHlFZmZlY3QsIGFwaS50eXBlcy5BdmFpbGFiaWxpdHldKSAmJiBsdW1wLmlzQWRkaXRpdmUoKTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYob3BlcmF0aW9uID09PSBcInN1YnRyYWN0aXZlXCIpIHtcbiAgICAgICAgcmV0dXJuIGx1bXAuaXNPbmVPZihbYXBpLnR5cGVzLlF1YWxpdHlFZmZlY3QsIGFwaS50eXBlcy5BdmFpbGFiaWxpdHldKSAmJiBsdW1wLmlzU3VidHJhY3RpdmUoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiByb3V0ZXM7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclBhdGhzVG9Ob2RlKHJvdXRlTm9kZSwgYW5jZXN0cnkpIHtcbiAgXG4gIGlmKCEocm91dGVOb2RlIGluc3RhbmNlb2YgUm91dGVOb2RlKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgdmFyIGVsZW1lbnQgPSByb3V0ZU5vZGUubm9kZS50b0RvbShcInNtYWxsXCIsIGZhbHNlKTtcbiAgXG4gIHZhciBjaGlsZF9saXN0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInVsXCIpO1xuICBjaGlsZF9saXN0LmNsYXNzTmFtZSArPSBcImNsdW1wLWxpc3Qgc21hbGwgY2hpbGQtbGlzdFwiO1xuXG4gIHZhciBuZXdfYW5jZXN0cnkgPSBhbmNlc3RyeS5zbGljZSgpO1xuICBuZXdfYW5jZXN0cnkucHVzaChyb3V0ZU5vZGUubm9kZSk7XG4gIHJvdXRlTm9kZS5jaGlsZHJlbi5mb3JFYWNoKGZ1bmN0aW9uKGNoaWxkX3JvdXRlLCBpbmRleCwgY2hpbGRyZW4pIHtcbiAgICB2YXIgY2hpbGRfY29udGVudCA9IHJlbmRlclBhdGhzVG9Ob2RlKGNoaWxkX3JvdXRlLCBuZXdfYW5jZXN0cnkpO1xuICAgIGNoaWxkX2xpc3QuYXBwZW5kQ2hpbGQoY2hpbGRfY29udGVudCk7XG4gIH0pO1xuXG4gIGlmKHJvdXRlTm9kZS5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICBlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2xpc3QpO1xuICB9XG4gIGVsc2Uge1xuICAgIHZhciBkZXNjcmlwdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcbiAgICBkZXNjcmlwdGlvbi5pbm5lckhUTUwgPSAnPHNwYW4gY2xhc3M9XCJyb3V0ZS1kZXNjcmlwdGlvblwiPkhJTlQ6ICcgKyBkZXNjcmliZVJvdXRlKG5ld19hbmNlc3RyeSkgKyAnPC9zcGFuPic7XG5cbiAgICB2YXIgcmVxc1RpdGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDUnKTtcbiAgICByZXFzVGl0bGUuaW5uZXJIVE1MID0gXCJSZXF1aXJlbWVudHNcIjtcbiAgICBkZXNjcmlwdGlvbi5hcHBlbmRDaGlsZChyZXFzVGl0bGUpO1xuXG4gICAgdmFyIHRvdGFsX3JlcXVpcmVtZW50cyA9IGdldFJvdXRlUmVxdWlyZW1lbnRzKG5ld19hbmNlc3RyeSk7XG4gICAgXG4gICAgZGVzY3JpcHRpb24uYXBwZW5kQ2hpbGQodG90YWxfcmVxdWlyZW1lbnRzLnRvRG9tKFwic21hbGxcIiwgZmFsc2UpKTtcbiAgICBlbGVtZW50LmFwcGVuZENoaWxkKGRlc2NyaXB0aW9uKTtcbiAgfVxuXG4gIHJldHVybiBlbGVtZW50O1xufVxuXG5mdW5jdGlvbiBsb3dlcih0ZXh0KSB7XG4gIHJldHVybiB0ZXh0LnNsaWNlKDAsMSkudG9Mb3dlckNhc2UoKSt0ZXh0LnNsaWNlKDEpO1xufVxuXG5mdW5jdGlvbiBkZXNjcmliZVJvdXRlKGFuY2VzdHJ5KSB7XG4gIHZhciBhID0gYW5jZXN0cnkuc2xpY2UoKS5yZXZlcnNlKCk7XG5cbiAgdmFyIGd1aWRlID0gXCJcIjtcbiAgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5BcmVhKSB7XG4gICAgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCkge1xuICAgICAgZ3VpZGUgPSBcIlNlZWsgXCIrYVsxXS5OYW1lK1wiIGluIFwiK2FbMF0uTmFtZTtcbiAgICAgIGlmKGFbMl0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIgYW5kIFwiO1xuICAgICAgICBpZihcIlxcXCInXCIuaW5kZXhPZihhWzJdLk5hbWVbMF0pICE9PSAtMSkge1xuICAgICAgICAgIGd1aWRlICs9IFwiZXhjbGFpbSBcIjtcbiAgICAgICAgfVxuICAgICAgICBndWlkZSArPSBsb3dlcihhWzJdLk5hbWUpO1xuICAgICAgfVxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZ3VpZGUgPSBcIlRyYXZlbCB0byBcIithWzBdLk5hbWU7XG5cbiAgICAgIGlmKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIgYW5kIFwiK2xvd2VyKGFbMV0uTmFtZSk7XG4gICAgICB9XG4gICAgICBlbHNlIGlmKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuRXhjaGFuZ2UgJiYgYVsyXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5TaG9wKSB7XG4gICAgICAgIGd1aWRlICs9IFwiIGFuZCBsb29rIGZvciB0aGUgXCIrYVsyXS5OYW1lK1wiIEVtcG9yaXVtIGluIFwiK2FbMV0uTmFtZTtcbiAgICAgIH1cblxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICB9XG4gIGVsc2UgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5TcGF3bmVkRW50aXR5KSB7XG4gICAgZ3VpZGUgPSBcIkZpbmQgYW5kIGJlc3QgYSBcIithWzBdLkh1bWFuTmFtZTtcbiAgICBpZihhWzJdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkludGVyYWN0aW9uKSB7XG4gICAgICBndWlkZSArPSBcIiwgdGhlbiBcIiArIGxvd2VyKGFbMl0uTmFtZSk7XG4gICAgfVxuICAgIGd1aWRlICs9IFwiLlwiO1xuICB9XG4gIGVsc2UgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCAmJiBhWzBdLnRhZyA9PT0gXCJ1c2VcIiAmJiAhKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuUXVhbGl0eVJlcXVpcmVtZW50KSkge1xuICAgIGlmKGFbMF0uTmFtZS5tYXRjaCgvXlxccypTcGVhay9pKSkge1xuICAgICAgZ3VpZGUgPSBhWzBdLk5hbWU7XG4gICAgfVxuICAgIGVsc2UgaWYoYVswXS5OYW1lLm1hdGNoKC9eXFxzKkEvaSkpIHtcbiAgICAgIGd1aWRlID0gXCJBY3F1aXJlIFwiK2xvd2VyKGFbMF0uTmFtZSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZ3VpZGUgPSBcIkZpbmQgYSBcIitsb3dlcihhWzBdLk5hbWUpO1xuICAgIH1cbiAgICBndWlkZSArPSBcIiBhbmQgXCIgKyBsb3dlcihhWzFdLk5hbWUpICsgXCIuXCI7XG4gIH1cblxuICByZXR1cm4gZ3VpZGU7XG59XG5cbmZ1bmN0aW9uIGRldGFpbFJvdXRlKGFuY2VzdHJ5KSB7XG4gIHZhciBhID0gYW5jZXN0cnkuc2xpY2UoKS5yZXZlcnNlKCk7XG5cbiAgdmFyIGd1aWRlID0gXCJcIjtcbiAgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5BcmVhKSB7XG4gICAgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCkge1xuICAgICAgZ3VpZGUgPSBcIllvdSBtdXN0IHRyYXZlbCB0byBcIithWzBdLk5hbWUrXCIgYW5kIGxvb2sgZm9yIFwiK2FbMV0uTmFtZStcIi5cIjtcbiAgICAgIGlmKGFbMl0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIgIFdoZW4geW91IGZpbmQgaXQgeW91IHNob3VsZCBcIjtcbiAgICAgICAgaWYoXCJcXFwiJ1wiLmluZGV4T2YoYVsyXS5OYW1lWzBdKSAhPT0gLTEpIHtcbiAgICAgICAgICBndWlkZSArPSBcInNheSBcIjtcbiAgICAgICAgfVxuICAgICAgICBndWlkZSArPSBsb3dlcihhWzJdLk5hbWUpO1xuICAgICAgfVxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZ3VpZGUgPSBcIk1ha2UgZm9yIFwiK2FbMF0uTmFtZTtcblxuICAgICAgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5JbnRlcmFjdGlvbikge1xuICAgICAgICBndWlkZSArPSBcIiBhbmQgXCIrbG93ZXIoYVsxXS5OYW1lKTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FeGNoYW5nZSAmJiBhWzJdIGluc3RhbmNlb2YgYXBpLnR5cGVzLlNob3ApIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIuICBVcG9uIGFycml2YWwgZ28gdG8gXCIrYVsxXS5OYW1lK1wiLCBhbmQgbG9vayBmb3IgdGhlIHNob3AgXCIrYVsyXS5OYW1lcztcbiAgICAgIH1cblxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICB9XG4gIGVsc2UgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5TcGF3bmVkRW50aXR5KSB7XG4gICAgZ3VpZGUgPSBcIllvdSBtdXN0IGh1bnQgdGhlIG15dGhpY2FsIHplZS1wZXJpbCBrbm93biBhcyB0aGUgXCIrYVswXS5IdW1hbk5hbWUrXCIsIGVuZ2FnZSBpdCBpbiBiYXR0bGUgYW5kIGRlZmVhdCBpdC5cIjtcbiAgICBpZihhWzJdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkludGVyYWN0aW9uKSB7XG4gICAgICBndWlkZSArPSBcIiAgT25jZSB5b3UgaGF2ZSBjb25xdWVyZWQgaXQgeW91IG11c3QgXCIgKyBsb3dlcihhWzJdLk5hbWUpICsgXCIgdG8gaGVscCBzZWN1cmUgeW91ciBwcml6ZS5cIjtcbiAgICB9XG4gIH1cbiAgZWxzZSBpZihhWzBdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkV2ZW50ICYmIGFbMF0udGFnID09PSBcInVzZVwiICYmICEoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5RdWFsaXR5UmVxdWlyZW1lbnQpKSB7XG4gICAgaWYoYVswXS5OYW1lLm1hdGNoKC9eXFxzKlNwZWFrL2kpKSB7XG4gICAgICBndWlkZSA9IFwiRmlyc3QgeW91IG11c3QgXCIrbG93ZXIoYVswXS5OYW1lKTtcbiAgICB9XG4gICAgZWxzZSBpZihhWzBdLk5hbWUubWF0Y2goL15cXHMqQS9pKSkge1xuICAgICAgZ3VpZGUgPSBcIlNvdXJjZSBcIitsb3dlcihhWzBdLk5hbWUpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGd1aWRlID0gXCJUcnkgdG8gbG9jYXRlIGEgXCIrbG93ZXIoYVswXS5OYW1lKTtcbiAgICB9XG4gICAgZ3VpZGUgKz0gXCIsIGFuZCB0aGVuIFwiICsgbG93ZXIoYVsxXS5OYW1lKSArIFwiLlwiO1xuICB9XG5cbiAgcmV0dXJuIGd1aWRlO1xufVxuXG5mdW5jdGlvbiBnZXRSb3V0ZVJlcXVpcmVtZW50cyhhbmNlc3RyeSkge1xuXG4gIHZhciByZXFzID0ge307XG5cbiAgLy8gQW5jZXN0cnkgaXMgb3JkZXJlZCBmcm9tIGxhc3QtPmZpcnN0LCBzbyBpdGVyYXRlIGJhY2t3YXJkcyBmcm9tIGZpbmFsIGVmZmVjdCAtPiBpbml0aWFsIGNhdXNlXG4gIGFuY2VzdHJ5LmZvckVhY2goZnVuY3Rpb24oc3RlcCkge1xuICAgIC8qIFNpbXBsaWZpY2F0aW9uOiBpZiBhbiBldmVudCBtb2RpZmllcyBhIHF1YWxpdHkgdGhlbiBhc3N1bWUgdGhhdCBsYXRlciByZXF1aXJlbWVudHNcbiAgICBvbiB0aGUgc2FtZSBxdWFsaXR5IGFyZSBwcm9iYWJseSBzYXRpc2ZpZWQgYnkgdGhhdCBtb2RpZmljYXRpb24gKGVnLCB3aGVuIHF1YWxpdGllc1xuICAgIGFyZSBpbmNyZW1lbnRlZC9kZWNyZW1lbnRlZCB0byBjb250cm9sIHN0b3J5LXF1ZXN0IHByb2dyZXNzKS4gKi9cbiAgICBpZihzdGVwLnF1YWxpdGllc0FmZmVjdGVkKSB7XG4gICAgICBzdGVwLnF1YWxpdGllc0FmZmVjdGVkLmZvckVhY2goZnVuY3Rpb24oZWZmZWN0KSB7XG4gICAgICAgIGRlbGV0ZShyZXFzW2VmZmVjdC5hc3NvY2lhdGVkUXVhbGl0eS5JZF0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIE5vdyBhZGQgYW55IHJlcXVpcmVtZW50cyBmb3IgdGhlIGN1cnJlbnQgc3RhZ2UgKGVhcmxpZXIgcmVxdWlyZW1lbnRzIG92ZXJ3cml0ZSBsYXRlciBvbmVzIG9uIHRoZSBzYW1lIHF1YWxpdHkpXG4gICAgaWYoc3RlcC5xdWFsaXRpZXNSZXF1aXJlZCkge1xuICAgICAgc3RlcC5xdWFsaXRpZXNSZXF1aXJlZC5mb3JFYWNoKGZ1bmN0aW9uKHJlcSkge1xuICAgICAgICBpZihyZXEuYXNzb2NpYXRlZFF1YWxpdHkpIHsgLy8gQ2hlY2sgdGhpcyBpcyBhIHZhbGlkIFF1YWxpdHlSZXF1aXJlbWVudCwgYW5kIG5vdCBvbmUgb2YgdGhlIGhhbGYtZmluaXNoZWQgZGVidWcgZWxlbWVudHMgcmVmZXJyaW5nIHRvIGFub24tZXhpc3RhbnQgUXVhbGl0eVxuICAgICAgICAgIHJlcXNbcmVxLmFzc29jaWF0ZWRRdWFsaXR5LklkXSA9IHJlcTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcblxuICB2YXIgcmVzdWx0ID0gT2JqZWN0LmtleXMocmVxcykubWFwKGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gcmVxc1trZXldOyB9KTtcblxuICByZXR1cm4gbmV3IENsdW1wKHJlc3VsdCwgYXBpLnR5cGVzLlF1YWxpdHlSZXF1aXJlbWVudCk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBSb3V0ZU5vZGU6IFJvdXRlTm9kZSxcbiAgcGF0aHNUb05vZGVVSTogcGF0aHNUb05vZGVVSSxcbiAgcGF0aHNUb05vZGU6IHBhdGhzVG9Ob2RlLFxuICBmaWx0ZXJQYXRoc1RvTm9kZTogZmlsdGVyUGF0aHNUb05vZGUsXG4gIHJlbmRlclBhdGhzVG9Ob2RlOiByZW5kZXJQYXRoc1RvTm9kZSxcbiAgZGVzY3JpYmVSb3V0ZTogZGVzY3JpYmVSb3V0ZSxcbiAgZGV0YWlsUm91dGU6IGRldGFpbFJvdXRlLFxuICBnZXRSb3V0ZVJlcXVpcmVtZW50czogZ2V0Um91dGVSZXF1aXJlbWVudHNcbn07IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4uL2FwaScpO1xuXG5mdW5jdGlvbiByZW5kZXJMaXN0cygpIHtcbiAgT2JqZWN0LmtleXMoYXBpLmxvYWRlZCkuZm9yRWFjaChmdW5jdGlvbih0eXBlKSB7XG4gICAgcmVuZGVyTGlzdChhcGkubG9hZGVkW3R5cGVdKTsgLy8gT25seSBkaXNwbGF5IGRpcmVjdGx5IGxvYWRlZCAocm9vdC1sZXZlbCkgTHVtcHMsIHRvIHByZXZlbnQgdGhlIGxpc3QgYmVjb21pbmcgdW53aWVsZHlcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckxpc3QoY2x1bXApIHtcblx0dmFyIHJvb3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChjbHVtcC50eXBlLm5hbWUudG9Mb3dlckNhc2UoKStcIi1saXN0XCIpO1xuICBpZihyb290KSB7XG5cdCByb290LmFwcGVuZENoaWxkKGNsdW1wLnRvRG9tKCkpO1xuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXHRsaXN0OiByZW5kZXJMaXN0LFxuXHRsaXN0czogcmVuZGVyTGlzdHNcbn07Il19
