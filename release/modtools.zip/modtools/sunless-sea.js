(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
module.exports={
	"title": "Sunless Sea",
	"paths": {
		"templates": "src/templates",
		"builddir": {
			"mod": "build/clockworacle",
			"ui": "build/modtools"
		}
	},
	"locations": {
		"imagesPath": "../../game-data/icons"
	},
	"baseGameIds": {
		"quality": 415000,
		"prelimEvent": 500000,
		"buyOracle": 5000010,
		"sellOracle": 500020,
		"event": 500025,
		"acquire": 600000,
		"learn": 700000,
		"suffer": 800000,
		"become": 900000
	}
}
},{}],2:[function(require,module,exports){

},{}],3:[function(require,module,exports){
(function (global){
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
 * @license  MIT
 */
/* eslint-disable no-proto */

var base64 = require('base64-js')
var ieee754 = require('ieee754')
var isArray = require('is-array')

exports.Buffer = Buffer
exports.SlowBuffer = SlowBuffer
exports.INSPECT_MAX_BYTES = 50
Buffer.poolSize = 8192 // not used by this implementation

var rootParent = {}

/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Use Object implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * Due to various browser bugs, sometimes the Object implementation will be used even
 * when the browser supports typed arrays.
 *
 * Note:
 *
 *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
 *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
 *
 *   - Safari 5-7 lacks support for changing the `Object.prototype.constructor` property
 *     on objects.
 *
 *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
 *
 *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
 *     incorrect length in some situations.

 * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
 * get the Object implementation, which is slower but behaves correctly.
 */
Buffer.TYPED_ARRAY_SUPPORT = global.TYPED_ARRAY_SUPPORT !== undefined
  ? global.TYPED_ARRAY_SUPPORT
  : (function () {
      function Bar () {}
      try {
        var arr = new Uint8Array(1)
        arr.foo = function () { return 42 }
        arr.constructor = Bar
        return arr.foo() === 42 && // typed array instances can be augmented
            arr.constructor === Bar && // constructor can be set
            typeof arr.subarray === 'function' && // chrome 9-10 lack `subarray`
            arr.subarray(1, 1).byteLength === 0 // ie10 has broken `subarray`
      } catch (e) {
        return false
      }
    })()

function kMaxLength () {
  return Buffer.TYPED_ARRAY_SUPPORT
    ? 0x7fffffff
    : 0x3fffffff
}

/**
 * Class: Buffer
 * =============
 *
 * The Buffer constructor returns instances of `Uint8Array` that are augmented
 * with function properties for all the node `Buffer` API functions. We use
 * `Uint8Array` so that square bracket notation works as expected -- it returns
 * a single octet.
 *
 * By augmenting the instances, we can avoid modifying the `Uint8Array`
 * prototype.
 */
function Buffer (arg) {
  if (!(this instanceof Buffer)) {
    // Avoid going through an ArgumentsAdaptorTrampoline in the common case.
    if (arguments.length > 1) return new Buffer(arg, arguments[1])
    return new Buffer(arg)
  }

  this.length = 0
  this.parent = undefined

  // Common case.
  if (typeof arg === 'number') {
    return fromNumber(this, arg)
  }

  // Slightly less common case.
  if (typeof arg === 'string') {
    return fromString(this, arg, arguments.length > 1 ? arguments[1] : 'utf8')
  }

  // Unusual.
  return fromObject(this, arg)
}

function fromNumber (that, length) {
  that = allocate(that, length < 0 ? 0 : checked(length) | 0)
  if (!Buffer.TYPED_ARRAY_SUPPORT) {
    for (var i = 0; i < length; i++) {
      that[i] = 0
    }
  }
  return that
}

function fromString (that, string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') encoding = 'utf8'

  // Assumption: byteLength() return value is always < kMaxLength.
  var length = byteLength(string, encoding) | 0
  that = allocate(that, length)

  that.write(string, encoding)
  return that
}

function fromObject (that, object) {
  if (Buffer.isBuffer(object)) return fromBuffer(that, object)

  if (isArray(object)) return fromArray(that, object)

  if (object == null) {
    throw new TypeError('must start with number, buffer, array or string')
  }

  if (typeof ArrayBuffer !== 'undefined') {
    if (object.buffer instanceof ArrayBuffer) {
      return fromTypedArray(that, object)
    }
    if (object instanceof ArrayBuffer) {
      return fromArrayBuffer(that, object)
    }
  }

  if (object.length) return fromArrayLike(that, object)

  return fromJsonObject(that, object)
}

function fromBuffer (that, buffer) {
  var length = checked(buffer.length) | 0
  that = allocate(that, length)
  buffer.copy(that, 0, 0, length)
  return that
}

function fromArray (that, array) {
  var length = checked(array.length) | 0
  that = allocate(that, length)
  for (var i = 0; i < length; i += 1) {
    that[i] = array[i] & 255
  }
  return that
}

// Duplicate of fromArray() to keep fromArray() monomorphic.
function fromTypedArray (that, array) {
  var length = checked(array.length) | 0
  that = allocate(that, length)
  // Truncating the elements is probably not what people expect from typed
  // arrays with BYTES_PER_ELEMENT > 1 but it's compatible with the behavior
  // of the old Buffer constructor.
  for (var i = 0; i < length; i += 1) {
    that[i] = array[i] & 255
  }
  return that
}

function fromArrayBuffer (that, array) {
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    // Return an augmented `Uint8Array` instance, for best performance
    array.byteLength
    that = Buffer._augment(new Uint8Array(array))
  } else {
    // Fallback: Return an object instance of the Buffer class
    that = fromTypedArray(that, new Uint8Array(array))
  }
  return that
}

function fromArrayLike (that, array) {
  var length = checked(array.length) | 0
  that = allocate(that, length)
  for (var i = 0; i < length; i += 1) {
    that[i] = array[i] & 255
  }
  return that
}

// Deserialize { type: 'Buffer', data: [1,2,3,...] } into a Buffer object.
// Returns a zero-length buffer for inputs that don't conform to the spec.
function fromJsonObject (that, object) {
  var array
  var length = 0

  if (object.type === 'Buffer' && isArray(object.data)) {
    array = object.data
    length = checked(array.length) | 0
  }
  that = allocate(that, length)

  for (var i = 0; i < length; i += 1) {
    that[i] = array[i] & 255
  }
  return that
}

if (Buffer.TYPED_ARRAY_SUPPORT) {
  Buffer.prototype.__proto__ = Uint8Array.prototype
  Buffer.__proto__ = Uint8Array
}

function allocate (that, length) {
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    // Return an augmented `Uint8Array` instance, for best performance
    that = Buffer._augment(new Uint8Array(length))
    that.__proto__ = Buffer.prototype
  } else {
    // Fallback: Return an object instance of the Buffer class
    that.length = length
    that._isBuffer = true
  }

  var fromPool = length !== 0 && length <= Buffer.poolSize >>> 1
  if (fromPool) that.parent = rootParent

  return that
}

function checked (length) {
  // Note: cannot use `length < kMaxLength` here because that fails when
  // length is NaN (which is otherwise coerced to zero.)
  if (length >= kMaxLength()) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                         'size: 0x' + kMaxLength().toString(16) + ' bytes')
  }
  return length | 0
}

function SlowBuffer (subject, encoding) {
  if (!(this instanceof SlowBuffer)) return new SlowBuffer(subject, encoding)

  var buf = new Buffer(subject, encoding)
  delete buf.parent
  return buf
}

Buffer.isBuffer = function isBuffer (b) {
  return !!(b != null && b._isBuffer)
}

Buffer.compare = function compare (a, b) {
  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
    throw new TypeError('Arguments must be Buffers')
  }

  if (a === b) return 0

  var x = a.length
  var y = b.length

  var i = 0
  var len = Math.min(x, y)
  while (i < len) {
    if (a[i] !== b[i]) break

    ++i
  }

  if (i !== len) {
    x = a[i]
    y = b[i]
  }

  if (x < y) return -1
  if (y < x) return 1
  return 0
}

Buffer.isEncoding = function isEncoding (encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'binary':
    case 'base64':
    case 'raw':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true
    default:
      return false
  }
}

Buffer.concat = function concat (list, length) {
  if (!isArray(list)) throw new TypeError('list argument must be an Array of Buffers.')

  if (list.length === 0) {
    return new Buffer(0)
  }

  var i
  if (length === undefined) {
    length = 0
    for (i = 0; i < list.length; i++) {
      length += list[i].length
    }
  }

  var buf = new Buffer(length)
  var pos = 0
  for (i = 0; i < list.length; i++) {
    var item = list[i]
    item.copy(buf, pos)
    pos += item.length
  }
  return buf
}

function byteLength (string, encoding) {
  if (typeof string !== 'string') string = '' + string

  var len = string.length
  if (len === 0) return 0

  // Use a for loop to avoid recursion
  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'binary':
      // Deprecated
      case 'raw':
      case 'raws':
        return len
      case 'utf8':
      case 'utf-8':
        return utf8ToBytes(string).length
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2
      case 'hex':
        return len >>> 1
      case 'base64':
        return base64ToBytes(string).length
      default:
        if (loweredCase) return utf8ToBytes(string).length // assume utf8
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}
Buffer.byteLength = byteLength

// pre-set for values that may exist in the future
Buffer.prototype.length = undefined
Buffer.prototype.parent = undefined

function slowToString (encoding, start, end) {
  var loweredCase = false

  start = start | 0
  end = end === undefined || end === Infinity ? this.length : end | 0

  if (!encoding) encoding = 'utf8'
  if (start < 0) start = 0
  if (end > this.length) end = this.length
  if (end <= start) return ''

  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end)

      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end)

      case 'ascii':
        return asciiSlice(this, start, end)

      case 'binary':
        return binarySlice(this, start, end)

      case 'base64':
        return base64Slice(this, start, end)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = (encoding + '').toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toString = function toString () {
  var length = this.length | 0
  if (length === 0) return ''
  if (arguments.length === 0) return utf8Slice(this, 0, length)
  return slowToString.apply(this, arguments)
}

Buffer.prototype.equals = function equals (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return true
  return Buffer.compare(this, b) === 0
}

Buffer.prototype.inspect = function inspect () {
  var str = ''
  var max = exports.INSPECT_MAX_BYTES
  if (this.length > 0) {
    str = this.toString('hex', 0, max).match(/.{2}/g).join(' ')
    if (this.length > max) str += ' ... '
  }
  return '<Buffer ' + str + '>'
}

Buffer.prototype.compare = function compare (b) {
  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
  if (this === b) return 0
  return Buffer.compare(this, b)
}

Buffer.prototype.indexOf = function indexOf (val, byteOffset) {
  if (byteOffset > 0x7fffffff) byteOffset = 0x7fffffff
  else if (byteOffset < -0x80000000) byteOffset = -0x80000000
  byteOffset >>= 0

  if (this.length === 0) return -1
  if (byteOffset >= this.length) return -1

  // Negative offsets start from the end of the buffer
  if (byteOffset < 0) byteOffset = Math.max(this.length + byteOffset, 0)

  if (typeof val === 'string') {
    if (val.length === 0) return -1 // special case: looking for empty string always fails
    return String.prototype.indexOf.call(this, val, byteOffset)
  }
  if (Buffer.isBuffer(val)) {
    return arrayIndexOf(this, val, byteOffset)
  }
  if (typeof val === 'number') {
    if (Buffer.TYPED_ARRAY_SUPPORT && Uint8Array.prototype.indexOf === 'function') {
      return Uint8Array.prototype.indexOf.call(this, val, byteOffset)
    }
    return arrayIndexOf(this, [ val ], byteOffset)
  }

  function arrayIndexOf (arr, val, byteOffset) {
    var foundIndex = -1
    for (var i = 0; byteOffset + i < arr.length; i++) {
      if (arr[byteOffset + i] === val[foundIndex === -1 ? 0 : i - foundIndex]) {
        if (foundIndex === -1) foundIndex = i
        if (i - foundIndex + 1 === val.length) return byteOffset + foundIndex
      } else {
        foundIndex = -1
      }
    }
    return -1
  }

  throw new TypeError('val must be string, number or Buffer')
}

// `get` is deprecated
Buffer.prototype.get = function get (offset) {
  console.log('.get() is deprecated. Access using array indexes instead.')
  return this.readUInt8(offset)
}

// `set` is deprecated
Buffer.prototype.set = function set (v, offset) {
  console.log('.set() is deprecated. Access using array indexes instead.')
  return this.writeUInt8(v, offset)
}

function hexWrite (buf, string, offset, length) {
  offset = Number(offset) || 0
  var remaining = buf.length - offset
  if (!length) {
    length = remaining
  } else {
    length = Number(length)
    if (length > remaining) {
      length = remaining
    }
  }

  // must be an even number of digits
  var strLen = string.length
  if (strLen % 2 !== 0) throw new Error('Invalid hex string')

  if (length > strLen / 2) {
    length = strLen / 2
  }
  for (var i = 0; i < length; i++) {
    var parsed = parseInt(string.substr(i * 2, 2), 16)
    if (isNaN(parsed)) throw new Error('Invalid hex string')
    buf[offset + i] = parsed
  }
  return i
}

function utf8Write (buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
}

function asciiWrite (buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length)
}

function binaryWrite (buf, string, offset, length) {
  return asciiWrite(buf, string, offset, length)
}

function base64Write (buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length)
}

function ucs2Write (buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
}

Buffer.prototype.write = function write (string, offset, length, encoding) {
  // Buffer#write(string)
  if (offset === undefined) {
    encoding = 'utf8'
    length = this.length
    offset = 0
  // Buffer#write(string, encoding)
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset
    length = this.length
    offset = 0
  // Buffer#write(string, offset[, length][, encoding])
  } else if (isFinite(offset)) {
    offset = offset | 0
    if (isFinite(length)) {
      length = length | 0
      if (encoding === undefined) encoding = 'utf8'
    } else {
      encoding = length
      length = undefined
    }
  // legacy write(string, encoding, offset, length) - remove in v0.13
  } else {
    var swap = encoding
    encoding = offset
    offset = length | 0
    length = swap
  }

  var remaining = this.length - offset
  if (length === undefined || length > remaining) length = remaining

  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
    throw new RangeError('attempt to write outside buffer bounds')
  }

  if (!encoding) encoding = 'utf8'

  var loweredCase = false
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length)

      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length)

      case 'ascii':
        return asciiWrite(this, string, offset, length)

      case 'binary':
        return binaryWrite(this, string, offset, length)

      case 'base64':
        // Warning: maxLength not taken into account in base64Write
        return base64Write(this, string, offset, length)

      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length)

      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
        encoding = ('' + encoding).toLowerCase()
        loweredCase = true
    }
  }
}

Buffer.prototype.toJSON = function toJSON () {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  }
}

function base64Slice (buf, start, end) {
  if (start === 0 && end === buf.length) {
    return base64.fromByteArray(buf)
  } else {
    return base64.fromByteArray(buf.slice(start, end))
  }
}

function utf8Slice (buf, start, end) {
  end = Math.min(buf.length, end)
  var res = []

  var i = start
  while (i < end) {
    var firstByte = buf[i]
    var codePoint = null
    var bytesPerSequence = (firstByte > 0xEF) ? 4
      : (firstByte > 0xDF) ? 3
      : (firstByte > 0xBF) ? 2
      : 1

    if (i + bytesPerSequence <= end) {
      var secondByte, thirdByte, fourthByte, tempCodePoint

      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte
          }
          break
        case 2:
          secondByte = buf[i + 1]
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint
            }
          }
          break
        case 3:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint
            }
          }
          break
        case 4:
          secondByte = buf[i + 1]
          thirdByte = buf[i + 2]
          fourthByte = buf[i + 3]
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint
            }
          }
      }
    }

    if (codePoint === null) {
      // we did not generate a valid codePoint so insert a
      // replacement char (U+FFFD) and advance only 1 byte
      codePoint = 0xFFFD
      bytesPerSequence = 1
    } else if (codePoint > 0xFFFF) {
      // encode to utf16 (surrogate pair dance)
      codePoint -= 0x10000
      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
      codePoint = 0xDC00 | codePoint & 0x3FF
    }

    res.push(codePoint)
    i += bytesPerSequence
  }

  return decodeCodePointsArray(res)
}

// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
var MAX_ARGUMENTS_LENGTH = 0x1000

function decodeCodePointsArray (codePoints) {
  var len = codePoints.length
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
  }

  // Decode in chunks to avoid "call stack size exceeded".
  var res = ''
  var i = 0
  while (i < len) {
    res += String.fromCharCode.apply(
      String,
      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
    )
  }
  return res
}

function asciiSlice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; i++) {
    ret += String.fromCharCode(buf[i] & 0x7F)
  }
  return ret
}

function binarySlice (buf, start, end) {
  var ret = ''
  end = Math.min(buf.length, end)

  for (var i = start; i < end; i++) {
    ret += String.fromCharCode(buf[i])
  }
  return ret
}

function hexSlice (buf, start, end) {
  var len = buf.length

  if (!start || start < 0) start = 0
  if (!end || end < 0 || end > len) end = len

  var out = ''
  for (var i = start; i < end; i++) {
    out += toHex(buf[i])
  }
  return out
}

function utf16leSlice (buf, start, end) {
  var bytes = buf.slice(start, end)
  var res = ''
  for (var i = 0; i < bytes.length; i += 2) {
    res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256)
  }
  return res
}

Buffer.prototype.slice = function slice (start, end) {
  var len = this.length
  start = ~~start
  end = end === undefined ? len : ~~end

  if (start < 0) {
    start += len
    if (start < 0) start = 0
  } else if (start > len) {
    start = len
  }

  if (end < 0) {
    end += len
    if (end < 0) end = 0
  } else if (end > len) {
    end = len
  }

  if (end < start) end = start

  var newBuf
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    newBuf = Buffer._augment(this.subarray(start, end))
  } else {
    var sliceLen = end - start
    newBuf = new Buffer(sliceLen, undefined)
    for (var i = 0; i < sliceLen; i++) {
      newBuf[i] = this[i + start]
    }
  }

  if (newBuf.length) newBuf.parent = this.parent || this

  return newBuf
}

/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */
function checkOffset (offset, ext, length) {
  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
}

Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }

  return val
}

Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length)
  }

  var val = this[offset + --byteLength]
  var mul = 1
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul
  }

  return val
}

Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length)
  return this[offset]
}

Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  return this[offset] | (this[offset + 1] << 8)
}

Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  return (this[offset] << 8) | this[offset + 1]
}

Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return ((this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16)) +
      (this[offset + 3] * 0x1000000)
}

Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] * 0x1000000) +
    ((this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    this[offset + 3])
}

Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var val = this[offset]
  var mul = 1
  var i = 0
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkOffset(offset, byteLength, this.length)

  var i = byteLength
  var mul = 1
  var val = this[offset + --i]
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul
  }
  mul *= 0x80

  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

  return val
}

Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length)
  if (!(this[offset] & 0x80)) return (this[offset])
  return ((0xff - this[offset] + 1) * -1)
}

Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset] | (this[offset + 1] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length)
  var val = this[offset + 1] | (this[offset] << 8)
  return (val & 0x8000) ? val | 0xFFFF0000 : val
}

Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset]) |
    (this[offset + 1] << 8) |
    (this[offset + 2] << 16) |
    (this[offset + 3] << 24)
}

Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)

  return (this[offset] << 24) |
    (this[offset + 1] << 16) |
    (this[offset + 2] << 8) |
    (this[offset + 3])
}

Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, true, 23, 4)
}

Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length)
  return ieee754.read(this, offset, false, 23, 4)
}

Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, true, 52, 8)
}

Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length)
  return ieee754.read(this, offset, false, 52, 8)
}

function checkInt (buf, value, offset, ext, max, min) {
  if (!Buffer.isBuffer(buf)) throw new TypeError('buffer must be a Buffer instance')
  if (value > max || value < min) throw new RangeError('value is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('index out of range')
}

Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkInt(this, value, offset, byteLength, Math.pow(2, 8 * byteLength), 0)

  var mul = 1
  var i = 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  byteLength = byteLength | 0
  if (!noAssert) checkInt(this, value, offset, byteLength, Math.pow(2, 8 * byteLength), 0)

  var i = byteLength - 1
  var mul = 1
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = (value / mul) & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
  this[offset] = value
  return offset + 1
}

function objectWriteUInt16 (buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffff + value + 1
  for (var i = 0, j = Math.min(buf.length - offset, 2); i < j; i++) {
    buf[offset + i] = (value & (0xff << (8 * (littleEndian ? i : 1 - i)))) >>>
      (littleEndian ? i : 1 - i) * 8
  }
}

Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = value
    this[offset + 1] = (value >>> 8)
  } else {
    objectWriteUInt16(this, value, offset, true)
  }
  return offset + 2
}

Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 8)
    this[offset + 1] = value
  } else {
    objectWriteUInt16(this, value, offset, false)
  }
  return offset + 2
}

function objectWriteUInt32 (buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffffffff + value + 1
  for (var i = 0, j = Math.min(buf.length - offset, 4); i < j; i++) {
    buf[offset + i] = (value >>> (littleEndian ? i : 3 - i) * 8) & 0xff
  }
}

Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset + 3] = (value >>> 24)
    this[offset + 2] = (value >>> 16)
    this[offset + 1] = (value >>> 8)
    this[offset] = value
  } else {
    objectWriteUInt32(this, value, offset, true)
  }
  return offset + 4
}

Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = value
  } else {
    objectWriteUInt32(this, value, offset, false)
  }
  return offset + 4
}

Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = 0
  var mul = 1
  var sub = value < 0 ? 1 : 0
  this[offset] = value & 0xFF
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1)

    checkInt(this, value, offset, byteLength, limit - 1, -limit)
  }

  var i = byteLength - 1
  var mul = 1
  var sub = value < 0 ? 1 : 0
  this[offset + i] = value & 0xFF
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
  }

  return offset + byteLength
}

Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
  if (value < 0) value = 0xff + value + 1
  this[offset] = value
  return offset + 1
}

Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = value
    this[offset + 1] = (value >>> 8)
  } else {
    objectWriteUInt16(this, value, offset, true)
  }
  return offset + 2
}

Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 8)
    this[offset + 1] = value
  } else {
    objectWriteUInt16(this, value, offset, false)
  }
  return offset + 2
}

Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = value
    this[offset + 1] = (value >>> 8)
    this[offset + 2] = (value >>> 16)
    this[offset + 3] = (value >>> 24)
  } else {
    objectWriteUInt32(this, value, offset, true)
  }
  return offset + 4
}

Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
  value = +value
  offset = offset | 0
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
  if (value < 0) value = 0xffffffff + value + 1
  if (Buffer.TYPED_ARRAY_SUPPORT) {
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = value
  } else {
    objectWriteUInt32(this, value, offset, false)
  }
  return offset + 4
}

function checkIEEE754 (buf, value, offset, ext, max, min) {
  if (value > max || value < min) throw new RangeError('value is out of bounds')
  if (offset + ext > buf.length) throw new RangeError('index out of range')
  if (offset < 0) throw new RangeError('index out of range')
}

function writeFloat (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
  }
  ieee754.write(buf, value, offset, littleEndian, 23, 4)
  return offset + 4
}

Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert)
}

Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert)
}

function writeDouble (buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
  }
  ieee754.write(buf, value, offset, littleEndian, 52, 8)
  return offset + 8
}

Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert)
}

Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert)
}

// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy (target, targetStart, start, end) {
  if (!start) start = 0
  if (!end && end !== 0) end = this.length
  if (targetStart >= target.length) targetStart = target.length
  if (!targetStart) targetStart = 0
  if (end > 0 && end < start) end = start

  // Copy 0 bytes; we're done
  if (end === start) return 0
  if (target.length === 0 || this.length === 0) return 0

  // Fatal error conditions
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds')
  }
  if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds')
  if (end < 0) throw new RangeError('sourceEnd out of bounds')

  // Are we oob?
  if (end > this.length) end = this.length
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start
  }

  var len = end - start
  var i

  if (this === target && start < targetStart && targetStart < end) {
    // descending copy from end
    for (i = len - 1; i >= 0; i--) {
      target[i + targetStart] = this[i + start]
    }
  } else if (len < 1000 || !Buffer.TYPED_ARRAY_SUPPORT) {
    // ascending copy from start
    for (i = 0; i < len; i++) {
      target[i + targetStart] = this[i + start]
    }
  } else {
    target._set(this.subarray(start, start + len), targetStart)
  }

  return len
}

// fill(value, start=0, end=buffer.length)
Buffer.prototype.fill = function fill (value, start, end) {
  if (!value) value = 0
  if (!start) start = 0
  if (!end) end = this.length

  if (end < start) throw new RangeError('end < start')

  // Fill 0 bytes; we're done
  if (end === start) return
  if (this.length === 0) return

  if (start < 0 || start >= this.length) throw new RangeError('start out of bounds')
  if (end < 0 || end > this.length) throw new RangeError('end out of bounds')

  var i
  if (typeof value === 'number') {
    for (i = start; i < end; i++) {
      this[i] = value
    }
  } else {
    var bytes = utf8ToBytes(value.toString())
    var len = bytes.length
    for (i = start; i < end; i++) {
      this[i] = bytes[i % len]
    }
  }

  return this
}

/**
 * Creates a new `ArrayBuffer` with the *copied* memory of the buffer instance.
 * Added in Node 0.12. Only available in browsers that support ArrayBuffer.
 */
Buffer.prototype.toArrayBuffer = function toArrayBuffer () {
  if (typeof Uint8Array !== 'undefined') {
    if (Buffer.TYPED_ARRAY_SUPPORT) {
      return (new Buffer(this)).buffer
    } else {
      var buf = new Uint8Array(this.length)
      for (var i = 0, len = buf.length; i < len; i += 1) {
        buf[i] = this[i]
      }
      return buf.buffer
    }
  } else {
    throw new TypeError('Buffer.toArrayBuffer not supported in this browser')
  }
}

// HELPER FUNCTIONS
// ================

var BP = Buffer.prototype

/**
 * Augment a Uint8Array *instance* (not the Uint8Array class!) with Buffer methods
 */
Buffer._augment = function _augment (arr) {
  arr.constructor = Buffer
  arr._isBuffer = true

  // save reference to original Uint8Array set method before overwriting
  arr._set = arr.set

  // deprecated
  arr.get = BP.get
  arr.set = BP.set

  arr.write = BP.write
  arr.toString = BP.toString
  arr.toLocaleString = BP.toString
  arr.toJSON = BP.toJSON
  arr.equals = BP.equals
  arr.compare = BP.compare
  arr.indexOf = BP.indexOf
  arr.copy = BP.copy
  arr.slice = BP.slice
  arr.readUIntLE = BP.readUIntLE
  arr.readUIntBE = BP.readUIntBE
  arr.readUInt8 = BP.readUInt8
  arr.readUInt16LE = BP.readUInt16LE
  arr.readUInt16BE = BP.readUInt16BE
  arr.readUInt32LE = BP.readUInt32LE
  arr.readUInt32BE = BP.readUInt32BE
  arr.readIntLE = BP.readIntLE
  arr.readIntBE = BP.readIntBE
  arr.readInt8 = BP.readInt8
  arr.readInt16LE = BP.readInt16LE
  arr.readInt16BE = BP.readInt16BE
  arr.readInt32LE = BP.readInt32LE
  arr.readInt32BE = BP.readInt32BE
  arr.readFloatLE = BP.readFloatLE
  arr.readFloatBE = BP.readFloatBE
  arr.readDoubleLE = BP.readDoubleLE
  arr.readDoubleBE = BP.readDoubleBE
  arr.writeUInt8 = BP.writeUInt8
  arr.writeUIntLE = BP.writeUIntLE
  arr.writeUIntBE = BP.writeUIntBE
  arr.writeUInt16LE = BP.writeUInt16LE
  arr.writeUInt16BE = BP.writeUInt16BE
  arr.writeUInt32LE = BP.writeUInt32LE
  arr.writeUInt32BE = BP.writeUInt32BE
  arr.writeIntLE = BP.writeIntLE
  arr.writeIntBE = BP.writeIntBE
  arr.writeInt8 = BP.writeInt8
  arr.writeInt16LE = BP.writeInt16LE
  arr.writeInt16BE = BP.writeInt16BE
  arr.writeInt32LE = BP.writeInt32LE
  arr.writeInt32BE = BP.writeInt32BE
  arr.writeFloatLE = BP.writeFloatLE
  arr.writeFloatBE = BP.writeFloatBE
  arr.writeDoubleLE = BP.writeDoubleLE
  arr.writeDoubleBE = BP.writeDoubleBE
  arr.fill = BP.fill
  arr.inspect = BP.inspect
  arr.toArrayBuffer = BP.toArrayBuffer

  return arr
}

var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g

function base64clean (str) {
  // Node strips out invalid characters like \n and \t from the string, base64-js does not
  str = stringtrim(str).replace(INVALID_BASE64_RE, '')
  // Node converts strings with length < 2 to ''
  if (str.length < 2) return ''
  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
  while (str.length % 4 !== 0) {
    str = str + '='
  }
  return str
}

function stringtrim (str) {
  if (str.trim) return str.trim()
  return str.replace(/^\s+|\s+$/g, '')
}

function toHex (n) {
  if (n < 16) return '0' + n.toString(16)
  return n.toString(16)
}

function utf8ToBytes (string, units) {
  units = units || Infinity
  var codePoint
  var length = string.length
  var leadSurrogate = null
  var bytes = []

  for (var i = 0; i < length; i++) {
    codePoint = string.charCodeAt(i)

    // is surrogate component
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      // last char was a lead
      if (!leadSurrogate) {
        // no lead yet
        if (codePoint > 0xDBFF) {
          // unexpected trail
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        } else if (i + 1 === length) {
          // unpaired lead
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          continue
        }

        // valid lead
        leadSurrogate = codePoint

        continue
      }

      // 2 leads in a row
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
        leadSurrogate = codePoint
        continue
      }

      // valid surrogate pair
      codePoint = leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00 | 0x10000
    } else if (leadSurrogate) {
      // valid bmp char, but last char was a lead
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
    }

    leadSurrogate = null

    // encode utf8
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break
      bytes.push(codePoint)
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break
      bytes.push(
        codePoint >> 0x6 | 0xC0,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break
      bytes.push(
        codePoint >> 0xC | 0xE0,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break
      bytes.push(
        codePoint >> 0x12 | 0xF0,
        codePoint >> 0xC & 0x3F | 0x80,
        codePoint >> 0x6 & 0x3F | 0x80,
        codePoint & 0x3F | 0x80
      )
    } else {
      throw new Error('Invalid code point')
    }
  }

  return bytes
}

function asciiToBytes (str) {
  var byteArray = []
  for (var i = 0; i < str.length; i++) {
    // Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF)
  }
  return byteArray
}

function utf16leToBytes (str, units) {
  var c, hi, lo
  var byteArray = []
  for (var i = 0; i < str.length; i++) {
    if ((units -= 2) < 0) break

    c = str.charCodeAt(i)
    hi = c >> 8
    lo = c % 256
    byteArray.push(lo)
    byteArray.push(hi)
  }

  return byteArray
}

function base64ToBytes (str) {
  return base64.toByteArray(base64clean(str))
}

function blitBuffer (src, dst, offset, length) {
  for (var i = 0; i < length; i++) {
    if ((i + offset >= dst.length) || (i >= src.length)) break
    dst[i + offset] = src[i]
  }
  return i
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"base64-js":4,"ieee754":5,"is-array":6}],4:[function(require,module,exports){
var lookup = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

;(function (exports) {
	'use strict';

  var Arr = (typeof Uint8Array !== 'undefined')
    ? Uint8Array
    : Array

	var PLUS   = '+'.charCodeAt(0)
	var SLASH  = '/'.charCodeAt(0)
	var NUMBER = '0'.charCodeAt(0)
	var LOWER  = 'a'.charCodeAt(0)
	var UPPER  = 'A'.charCodeAt(0)
	var PLUS_URL_SAFE = '-'.charCodeAt(0)
	var SLASH_URL_SAFE = '_'.charCodeAt(0)

	function decode (elt) {
		var code = elt.charCodeAt(0)
		if (code === PLUS ||
		    code === PLUS_URL_SAFE)
			return 62 // '+'
		if (code === SLASH ||
		    code === SLASH_URL_SAFE)
			return 63 // '/'
		if (code < NUMBER)
			return -1 //no match
		if (code < NUMBER + 10)
			return code - NUMBER + 26 + 26
		if (code < UPPER + 26)
			return code - UPPER
		if (code < LOWER + 26)
			return code - LOWER + 26
	}

	function b64ToByteArray (b64) {
		var i, j, l, tmp, placeHolders, arr

		if (b64.length % 4 > 0) {
			throw new Error('Invalid string. Length must be a multiple of 4')
		}

		// the number of equal signs (place holders)
		// if there are two placeholders, than the two characters before it
		// represent one byte
		// if there is only one, then the three characters before it represent 2 bytes
		// this is just a cheap hack to not do indexOf twice
		var len = b64.length
		placeHolders = '=' === b64.charAt(len - 2) ? 2 : '=' === b64.charAt(len - 1) ? 1 : 0

		// base64 is 4/3 + up to two characters of the original data
		arr = new Arr(b64.length * 3 / 4 - placeHolders)

		// if there are placeholders, only get up to the last complete 4 chars
		l = placeHolders > 0 ? b64.length - 4 : b64.length

		var L = 0

		function push (v) {
			arr[L++] = v
		}

		for (i = 0, j = 0; i < l; i += 4, j += 3) {
			tmp = (decode(b64.charAt(i)) << 18) | (decode(b64.charAt(i + 1)) << 12) | (decode(b64.charAt(i + 2)) << 6) | decode(b64.charAt(i + 3))
			push((tmp & 0xFF0000) >> 16)
			push((tmp & 0xFF00) >> 8)
			push(tmp & 0xFF)
		}

		if (placeHolders === 2) {
			tmp = (decode(b64.charAt(i)) << 2) | (decode(b64.charAt(i + 1)) >> 4)
			push(tmp & 0xFF)
		} else if (placeHolders === 1) {
			tmp = (decode(b64.charAt(i)) << 10) | (decode(b64.charAt(i + 1)) << 4) | (decode(b64.charAt(i + 2)) >> 2)
			push((tmp >> 8) & 0xFF)
			push(tmp & 0xFF)
		}

		return arr
	}

	function uint8ToBase64 (uint8) {
		var i,
			extraBytes = uint8.length % 3, // if we have 1 byte left, pad 2 bytes
			output = "",
			temp, length

		function encode (num) {
			return lookup.charAt(num)
		}

		function tripletToBase64 (num) {
			return encode(num >> 18 & 0x3F) + encode(num >> 12 & 0x3F) + encode(num >> 6 & 0x3F) + encode(num & 0x3F)
		}

		// go through the array every three bytes, we'll deal with trailing stuff later
		for (i = 0, length = uint8.length - extraBytes; i < length; i += 3) {
			temp = (uint8[i] << 16) + (uint8[i + 1] << 8) + (uint8[i + 2])
			output += tripletToBase64(temp)
		}

		// pad the end with zeros, but make sure to not forget the extra bytes
		switch (extraBytes) {
			case 1:
				temp = uint8[uint8.length - 1]
				output += encode(temp >> 2)
				output += encode((temp << 4) & 0x3F)
				output += '=='
				break
			case 2:
				temp = (uint8[uint8.length - 2] << 8) + (uint8[uint8.length - 1])
				output += encode(temp >> 10)
				output += encode((temp >> 4) & 0x3F)
				output += encode((temp << 2) & 0x3F)
				output += '='
				break
		}

		return output
	}

	exports.toByteArray = b64ToByteArray
	exports.fromByteArray = uint8ToBase64
}(typeof exports === 'undefined' ? (this.base64js = {}) : exports))

},{}],5:[function(require,module,exports){
exports.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var nBits = -7
  var i = isLE ? (nBytes - 1) : 0
  var d = isLE ? -1 : 1
  var s = buffer[offset + i]

  i += d

  e = s & ((1 << (-nBits)) - 1)
  s >>= (-nBits)
  nBits += eLen
  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1)
  e >>= (-nBits)
  nBits += mLen
  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen)
    e = e - eBias
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
}

exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c
  var eLen = nBytes * 8 - mLen - 1
  var eMax = (1 << eLen) - 1
  var eBias = eMax >> 1
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
  var i = isLE ? 0 : (nBytes - 1)
  var d = isLE ? 1 : -1
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

  value = Math.abs(value)

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0
    e = eMax
  } else {
    e = Math.floor(Math.log(value) / Math.LN2)
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--
      c *= 2
    }
    if (e + eBias >= 1) {
      value += rt / c
    } else {
      value += rt * Math.pow(2, 1 - eBias)
    }
    if (value * c >= 2) {
      e++
      c /= 2
    }

    if (e + eBias >= eMax) {
      m = 0
      e = eMax
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * Math.pow(2, mLen)
      e = e + eBias
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
      e = 0
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m
  eLen += mLen
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128
}

},{}],6:[function(require,module,exports){

/**
 * isArray
 */

var isArray = Array.isArray;

/**
 * toString
 */

var str = Object.prototype.toString;

/**
 * Whether or not the given `val`
 * is an array.
 *
 * example:
 *
 *        isArray([]);
 *        // > true
 *        isArray(arguments);
 *        // > false
 *        isArray('');
 *        // > false
 *
 * @param {mixed} val
 * @return {bool}
 */

module.exports = isArray || function (val) {
  return !! val && '[object Array]' == str.call(val);
};

},{}],7:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

function EventEmitter() {
  this._events = this._events || {};
  this._maxListeners = this._maxListeners || undefined;
}
module.exports = EventEmitter;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
EventEmitter.defaultMaxListeners = 10;

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function(n) {
  if (!isNumber(n) || n < 0 || isNaN(n))
    throw TypeError('n must be a positive number');
  this._maxListeners = n;
  return this;
};

EventEmitter.prototype.emit = function(type) {
  var er, handler, len, args, i, listeners;

  if (!this._events)
    this._events = {};

  // If there is no 'error' event listener then throw.
  if (type === 'error') {
    if (!this._events.error ||
        (isObject(this._events.error) && !this._events.error.length)) {
      er = arguments[1];
      if (er instanceof Error) {
        throw er; // Unhandled 'error' event
      }
      throw TypeError('Uncaught, unspecified "error" event.');
    }
  }

  handler = this._events[type];

  if (isUndefined(handler))
    return false;

  if (isFunction(handler)) {
    switch (arguments.length) {
      // fast cases
      case 1:
        handler.call(this);
        break;
      case 2:
        handler.call(this, arguments[1]);
        break;
      case 3:
        handler.call(this, arguments[1], arguments[2]);
        break;
      // slower
      default:
        len = arguments.length;
        args = new Array(len - 1);
        for (i = 1; i < len; i++)
          args[i - 1] = arguments[i];
        handler.apply(this, args);
    }
  } else if (isObject(handler)) {
    len = arguments.length;
    args = new Array(len - 1);
    for (i = 1; i < len; i++)
      args[i - 1] = arguments[i];

    listeners = handler.slice();
    len = listeners.length;
    for (i = 0; i < len; i++)
      listeners[i].apply(this, args);
  }

  return true;
};

EventEmitter.prototype.addListener = function(type, listener) {
  var m;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events)
    this._events = {};

  // To avoid recursion in the case that type === "newListener"! Before
  // adding it to the listeners, first emit "newListener".
  if (this._events.newListener)
    this.emit('newListener', type,
              isFunction(listener.listener) ?
              listener.listener : listener);

  if (!this._events[type])
    // Optimize the case of one listener. Don't need the extra array object.
    this._events[type] = listener;
  else if (isObject(this._events[type]))
    // If we've already got an array, just append.
    this._events[type].push(listener);
  else
    // Adding the second element, need to change to array.
    this._events[type] = [this._events[type], listener];

  // Check for listener leak
  if (isObject(this._events[type]) && !this._events[type].warned) {
    var m;
    if (!isUndefined(this._maxListeners)) {
      m = this._maxListeners;
    } else {
      m = EventEmitter.defaultMaxListeners;
    }

    if (m && m > 0 && this._events[type].length > m) {
      this._events[type].warned = true;
      console.error('(node) warning: possible EventEmitter memory ' +
                    'leak detected. %d listeners added. ' +
                    'Use emitter.setMaxListeners() to increase limit.',
                    this._events[type].length);
      if (typeof console.trace === 'function') {
        // not supported in IE 10
        console.trace();
      }
    }
  }

  return this;
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.once = function(type, listener) {
  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  var fired = false;

  function g() {
    this.removeListener(type, g);

    if (!fired) {
      fired = true;
      listener.apply(this, arguments);
    }
  }

  g.listener = listener;
  this.on(type, g);

  return this;
};

// emits a 'removeListener' event iff the listener was removed
EventEmitter.prototype.removeListener = function(type, listener) {
  var list, position, length, i;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events || !this._events[type])
    return this;

  list = this._events[type];
  length = list.length;
  position = -1;

  if (list === listener ||
      (isFunction(list.listener) && list.listener === listener)) {
    delete this._events[type];
    if (this._events.removeListener)
      this.emit('removeListener', type, listener);

  } else if (isObject(list)) {
    for (i = length; i-- > 0;) {
      if (list[i] === listener ||
          (list[i].listener && list[i].listener === listener)) {
        position = i;
        break;
      }
    }

    if (position < 0)
      return this;

    if (list.length === 1) {
      list.length = 0;
      delete this._events[type];
    } else {
      list.splice(position, 1);
    }

    if (this._events.removeListener)
      this.emit('removeListener', type, listener);
  }

  return this;
};

EventEmitter.prototype.removeAllListeners = function(type) {
  var key, listeners;

  if (!this._events)
    return this;

  // not listening for removeListener, no need to emit
  if (!this._events.removeListener) {
    if (arguments.length === 0)
      this._events = {};
    else if (this._events[type])
      delete this._events[type];
    return this;
  }

  // emit removeListener for all listeners on all events
  if (arguments.length === 0) {
    for (key in this._events) {
      if (key === 'removeListener') continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners('removeListener');
    this._events = {};
    return this;
  }

  listeners = this._events[type];

  if (isFunction(listeners)) {
    this.removeListener(type, listeners);
  } else {
    // LIFO order
    while (listeners.length)
      this.removeListener(type, listeners[listeners.length - 1]);
  }
  delete this._events[type];

  return this;
};

EventEmitter.prototype.listeners = function(type) {
  var ret;
  if (!this._events || !this._events[type])
    ret = [];
  else if (isFunction(this._events[type]))
    ret = [this._events[type]];
  else
    ret = this._events[type].slice();
  return ret;
};

EventEmitter.listenerCount = function(emitter, type) {
  var ret;
  if (!emitter._events || !emitter._events[type])
    ret = 0;
  else if (isFunction(emitter._events[type]))
    ret = 1;
  else
    ret = emitter._events[type].length;
  return ret;
};

function isFunction(arg) {
  return typeof arg === 'function';
}

function isNumber(arg) {
  return typeof arg === 'number';
}

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}

function isUndefined(arg) {
  return arg === void 0;
}

},{}],8:[function(require,module,exports){
// shim for using process in browser

var process = module.exports = {};
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = setTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    clearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        setTimeout(drainQueue, 0);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],9:[function(require,module,exports){
(function (process,Buffer){
//
// FileReader
//
// http://www.w3.org/TR/FileAPI/#dfn-filereader
// https://developer.mozilla.org/en/DOM/FileReader
(function () {
  "use strict";

  var fs = require("fs")
    , EventEmitter = require("events").EventEmitter
    ;

  function doop(fn, args, context) {
    if ('function' === typeof fn) {
      fn.apply(context, args);
    }
  }

  function toDataUrl(data, type) {
    // var data = self.result;
    var dataUrl = 'data:';

    if (type) {
      dataUrl += type + ';';
    }

    if (/text/i.test(type)) {
      dataUrl += 'charset=utf-8,';
      dataUrl += data.toString('utf8');
    } else {
      dataUrl += 'base64,';
      dataUrl += data.toString('base64');
    }

    return dataUrl;
  }

  function mapDataToFormat(file, data, format, encoding) {
    // var data = self.result;

    switch(format) {
      case 'buffer':
        return data;
        break;
      case 'binary':
        return data.toString('binary');
        break;
      case 'dataUrl':
        return toDataUrl(data, file.type);
        break;
      case 'text':
        return data.toString(encoding || 'utf8');
        break;
    }
  }

  function FileReader() {
    var self = this,
      emitter = new EventEmitter,
      file;

    self.addEventListener = function (on, callback) {
      emitter.on(on, callback);
    };
    self.removeEventListener = function (callback) {
      emitter.removeListener(callback);
    }
    self.dispatchEvent = function (on) {
      emitter.emit(on);
    }

    self.EMPTY = 0;
    self.LOADING = 1;
    self.DONE = 2;

    self.error = undefined;         // Read only
    self.readyState = self.EMPTY;   // Read only
    self.result = undefined;        // Road only

    // non-standard
    self.on = function () {
      emitter.on.apply(emitter, arguments);
    }
    self.nodeChunkedEncoding = false;
    self.setNodeChunkedEncoding = function (val) {
      self.nodeChunkedEncoding = val;
    };
    // end non-standard



    // Whatever the file object is, turn it into a Node.JS File.Stream
    function createFileStream() {
      var stream = new EventEmitter(),
        chunked = self.nodeChunkedEncoding;

      // attempt to make the length computable
      if (!file.size && chunked && file.path) {
        fs.stat(file.path, function (err, stat) {
          file.size = stat.size;
          file.lastModifiedDate = stat.mtime;
        });
      }


      // The stream exists, do nothing more
      if (file.stream) {
        return;
      }


      // Create a read stream from a buffer
      if (file.buffer) {
        process.nextTick(function () {
          stream.emit('data', file.buffer);
          stream.emit('end');
        });
        file.stream = stream;
        return;
      }


      // Create a read stream from a file
      if (file.path) {
        // TODO url
        if (!chunked) {
          fs.readFile(file.path, function (err, data) {
            if (err) {
              stream.emit('error', err);
            }
            if (data) {
              stream.emit('data', data);
              stream.emit('end');
            }
          });

          file.stream = stream;
          return;
        }

        // TODO don't duplicate this code here,
        // expose a method in File instead
        file.stream = fs.createReadStream(file.path);
      }
    }



    // before any other listeners are added
    emitter.on('abort', function () {
      self.readyState = self.DONE;
    });



    // Map `error`, `progress`, `load`, and `loadend`
    function mapStreamToEmitter(format, encoding) {
      var stream = file.stream,
        buffers = [],
        chunked = self.nodeChunkedEncoding;

      buffers.dataLength = 0;

      stream.on('error', function (err) {
        if (self.DONE === self.readyState) {
          return;
        }

        self.readyState = self.DONE;
        self.error = err;
        emitter.emit('error', err);
      });

      stream.on('data', function (data) {
        if (self.DONE === self.readyState) {
          return;
        }

        buffers.dataLength += data.length;
        buffers.push(data);

        emitter.emit('progress', {
          // fs.stat will probably complete before this
          // but possibly it will not, hence the check
          lengthComputable: (!isNaN(file.size)) ? true : false,
          loaded: buffers.dataLength,
          total: file.size
        });

        emitter.emit('data', data);
      });

      stream.on('end', function () {
        if (self.DONE === self.readyState) {
          return;
        }

        var data;

        if (buffers.length > 1 ) {
          data = Buffer.concat(buffers);
        } else {
          data = buffers[0];
        }

        self.readyState = self.DONE;
        self.result = mapDataToFormat(file, data, format, encoding);
        emitter.emit('load', {
          target: {
            // non-standard
            nodeBufferResult: data,
            result: self.result
          }
        });

        emitter.emit('loadend');
      });
    }


    // Abort is overwritten by readAsXyz
    self.abort = function () {
      if (self.readState == self.DONE) {
        return;
      }
      self.readyState = self.DONE;
      emitter.emit('abort');
    };



    // 
    function mapUserEvents() {
      emitter.on('start', function () {
        doop(self.onloadstart, arguments);
      });
      emitter.on('progress', function () {
        doop(self.onprogress, arguments);
      });
      emitter.on('error', function (err) {
        // TODO translate to FileError
        if (self.onerror) {
          self.onerror(err);
        } else {
          if (!emitter.listeners.error || !emitter.listeners.error.length) {
            throw err;
          }
        }
      });
      emitter.on('load', function () {
        doop(self.onload, arguments);
      });
      emitter.on('end', function () {
        doop(self.onloadend, arguments);
      });
      emitter.on('abort', function () {
        doop(self.onabort, arguments);
      });
    }



    function readFile(_file, format, encoding) {
      file = _file;
      if (!file || !file.name || !(file.path || file.stream || file.buffer)) {
        throw new Error("cannot read as File: " + JSON.stringify(file));
      }
      if (0 !== self.readyState) {
        console.log("already loading, request to change format ignored");
        return;
      }

      // 'process.nextTick' does not ensure order, (i.e. an fs.stat queued later may return faster)
      // but `onloadstart` must come before the first `data` event and must be asynchronous.
      // Hence we waste a single tick waiting
      process.nextTick(function () {
        self.readyState = self.LOADING;
        emitter.emit('loadstart');
        createFileStream();
        mapStreamToEmitter(format, encoding);
        mapUserEvents();
      });
    }

    self.readAsArrayBuffer = function (file) {
      readFile(file, 'buffer');
    };
    self.readAsBinaryString = function (file) {
      readFile(file, 'binary');
    };
    self.readAsDataURL = function (file) {
      readFile(file, 'dataUrl');
    };
    self.readAsText = function (file, encoding) {
      readFile(file, 'text', encoding);
    };
  }

  module.exports = FileReader;
}());

}).call(this,require('_process'),require("buffer").Buffer)

},{"_process":8,"buffer":3,"events":7,"fs":2}],10:[function(require,module,exports){
var config = require('../../config.json');
var Clump = require('./objects/clump');
var Lump = require('./objects/lump');

var io = require('./io');

var library = require('./library');
var loaded = {};

var types = {
  Quality: require('./objects/quality'),
  Event: require('./objects/event'),
  Interaction: require('./objects/interaction'),
  QualityEffect: require('./objects/quality-effect'),
  QualityRequirement: require('./objects/quality-requirement'),
  Area: require('./objects/area'),
  SpawnedEntity: require('./objects/spawned-entity'),
  CombatAttack: require('./objects/combat-attack'),
  Exchange: require('./objects/exchange'),
  Shop: require('./objects/shop'),
  Availability: require('./objects/availability'),
  Tile: require('./objects/tile'),
  TileVariant: require('./objects/tile-variant'),
  Port: require('./objects/port'),
  Setting: require('./objects/setting')
};

// Prepopulate library with Clumps of each type we know about
Object.keys(types).forEach(function(typeName) {
	var Type = types[typeName];
	if(!library[typeName]) {
		library[typeName] = new Clump([], Type);
		loaded[typeName] = new Clump([], Type);
	}
});

function get(Type, id, parent) {
	var typename = Type.name;	// Event, Quality, Interaction, etc

	var existingThingWithThisId = library[typename].id(id);
	if(existingThingWithThisId) {
		//console.log("Attached existing " + existingThingWithThisId + " to " + this.toString())
		var newParent = true;
		existingThingWithThisId.parents.forEach(function(p) {
			if(p.Id === parent.Id && p.constructor.name === parent.constructor.name) {
				newParent = false;
			}
		});
		if(newParent){
			existingThingWithThisId.parents.push(parent);
		}

		if(!existingThingWithThisId.wired) {
			existingThingWithThisId.wireUp(this);	// Pass in the api so object can add itself to the master-library
		}
		return existingThingWithThisId;
	}
	else {
		return null;
	}
}

function getOrCreate(Type, possNewThing, parent) {	// If an object already exists with this ID, use that.  Otherwise create a new object from the supplied details hash
	var typename = Type.name;	// Event, Quality, Interaction, etc
	if(possNewThing) {
  	var existingThingWithThisId = this.get(Type, possNewThing.Id, parent);
  	if(existingThingWithThisId) {
  		return existingThingWithThisId;
  	}
  	else {
			var newThing = new Type(possNewThing, parent);
			newThing.wireUp(this);
			//console.log("Recursively created " + newThing + " for " + this.toString());
			return newThing;
		}
	}
	else {
		return null;
	}
}

function wireUpObjects() {
	var api = this;
  Object.keys(types).forEach(function(type) {
    library[type].forEach(function(lump) {
      if(lump.wireUp) {
        lump.wireUp(api);
      }
    });
  });
}

var whatIs = function(id) {
  var possibilities = [];
  Object.keys(library).forEach(function(key) {
    if(library[key] instanceof Clump && library[key].id(id)) {
      possibilities.push(key);
    }
  });
  return possibilities;
};

function describeAdvancedExpression(expr) {
	var self = this;
	if(expr) {
		expr = expr.replace(/\[d:(\d+)\]/gi, "RANDOM[1-$1]");	// [d:x] = random number from 1-x(?)
		expr = expr.replace(/\[q:(\d+)\]/gi, function(match, backref, pos, whole_str) {
			var quality = self.library.Quality.id(backref);
			return "["+(quality ? quality.Name : 'INVALID')+"]";
		});

		return expr;
	}
	return null;
}

function readFromFile(Type, file, callback) {
	io.readFile(file, function (e) {
    var contents = e.target.result;
    
    var obj = JSON.parse(contents);
    loaded[Type.prototype.constructor.name] = new Clump(obj, Type);

    callback(contents, Type, loaded[Type.prototype.constructor.name]);
  });
}


module.exports = {
	'Clump': Clump,
	'Lump': Lump,
	'config': config,
	'types': types,
	'library': library,
	'loaded': loaded,
	'get': get,
	'whatIs': whatIs,
	'wireUpObjects': wireUpObjects,
	'getOrCreate': getOrCreate,
	'describeAdvancedExpression': describeAdvancedExpression,
	'readFromFile': readFromFile
};
},{"../../config.json":1,"./io":11,"./library":12,"./objects/area":13,"./objects/availability":14,"./objects/clump":15,"./objects/combat-attack":16,"./objects/event":17,"./objects/exchange":18,"./objects/interaction":19,"./objects/lump":20,"./objects/port":21,"./objects/quality":24,"./objects/quality-effect":22,"./objects/quality-requirement":23,"./objects/setting":25,"./objects/shop":26,"./objects/spawned-entity":27,"./objects/tile":29,"./objects/tile-variant":28}],11:[function(require,module,exports){

if(typeof FileReader === 'undefined') { // Running in node rather than a browser
  FileReader = require('filereader');
}

var fileObjectMap = {
    'events.json' : 'Event',
    'qualities.json' : 'Quality',
    'areas.json' : 'Area',
    'SpawnedEntities.json' : 'SpawnedEntity',
    'CombatAttacks.json' : 'CombatAttack',
    'exchanges.json' : 'Exchange',
    'Tiles.json': 'Tile'
  };

function readFile(file, callback) {
  var reader = new FileReader();
  reader.onload = callback;
  reader.readAsText(file);
}

var files_to_load = 0;
function resetFilesToLoad() {
	files_to_load = 0;
}
function incrementFilesToLoad() {
	files_to_load++;
}
function decrementFilesToLoad() {
	files_to_load--;
}
function countFilesToLoad() {
	return files_to_load;
}


module.exports = {
  readFile: readFile,
  resetFilesToLoad: resetFilesToLoad,
	incrementFilesToLoad: incrementFilesToLoad,
	decrementFilesToLoad: decrementFilesToLoad,
	countFilesToLoad: countFilesToLoad,
  fileObjectMap: fileObjectMap
};
},{"filereader":9}],12:[function(require,module,exports){
module.exports = {};
},{}],13:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Area(raw) {
	this.straightCopy = ["Name", "Description", "ImageName", "MoveMessage"];
	Lump.call(this, raw);
}
Object.keys(Lump.prototype).forEach(function(member) { Area.prototype[member] = Lump.prototype[member]; });

Area.prototype.wireUp = function(theApi) {
	api = theApi;
	Lump.prototype.wireUp.call(this);
};

Area.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Area.prototype.toDom = function(size) {

	size = size || "normal";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.ImageName !== null && this.Image !== "") {
		element.innerHTML = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.ImageName+".png' />";
	}

	element.innerHTML += "\n<h3 class='title'>"+this.Name+"</h3>\n<p class='description'>"+this.Description+"</p>";

	element.title = this.toString();

	return element;
};

module.exports = Area;
},{"./lump":20}],14:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Availability(raw, parent) {
	this.straightCopy = [
		'Cost',
		'SellPrice'
	];
	Lump.apply(this, arguments);

	this.quality = null;
	this.purchaseQuality = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Availability.prototype[member] = Lump.prototype[member]; });

Availability.prototype.wireUp = function(theApi) {

	api = theApi;

	this.quality = api.getOrCreate(api.types.Quality, this.attribs.Quality, this);
	this.purchaseQuality = api.getOrCreate(api.types.Quality, this.attribs.PurchaseQuality, this);

	Lump.prototype.wireUp.call(this, api);
};

Availability.prototype.isAdditive = function() {
	return this.Cost > 0;
};

Availability.prototype.isSubtractive = function() {
	return this.SellPrice > 0;
};

Availability.prototype.toString = function() {
	return this.constructor.name + " " + this.quality + " (buy: " + this.Cost + "x" + this.purchaseQuality.Name + " / sell: " + this.SellPrice + "x" + this.purchaseQuality.Name + ")";
};

Availability.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;
	
	var purchase_quality_element;

	if(!this.quality) {
		purchase_quality_element = document.createElement("span");
		purchase_quality_element.innerHTML = "[INVALID]";
	}
	else {
		purchase_quality_element = this.quality.toDom("small", false, "span");
	}

	var currency_quality_element = this.purchaseQuality.toDom("small", false, "span");
	currency_quality_element.className = "quantity item small";
	var currency_quality_markup = currency_quality_element.outerHTML;

	var currency_buy_amount_element = document.createElement("span");
	currency_buy_amount_element.className = "item quantity";
	currency_buy_amount_element.innerHTML = "Buy: " + (this.Cost ? this.Cost+"x" : "&#10007;");
	currency_buy_amount_element.title = this.toString();

	var currency_sell_amount_element = document.createElement("span");
	currency_sell_amount_element.className = "item quantity";
	currency_sell_amount_element.innerHTML = "Sell: " + (this.SellPrice ? this.SellPrice+"x" : "&#10007;");
	currency_sell_amount_element.title = this.toString();


	element.appendChild(purchase_quality_element);
	element.appendChild(currency_buy_amount_element);
	if(this.Cost) {
		element.appendChild($(currency_quality_markup)[0]);
	}
	element.appendChild(currency_sell_amount_element);
	if(this.SellPrice) {
		element.appendChild($(currency_quality_markup)[0]);
	}

	return element;
};

module.exports = Availability;
},{"./lump":20}],15:[function(require,module,exports){

function Clump(raw, Type, parent) {
	this.type = Type;
	this.items = {};
	var self = this;
	raw.forEach(function(item, index, collection) {
		if(!(item instanceof Type)) {
			item = new Type(item, parent);
		}
		else if(parent) {
			var newParent = true;
			item.parents.forEach(function(p) {
				if(p.Id === parent.Id && p.constructor.name === parent.constructor.name) {
					newParent = false;
				}
			});
			if(newParent){
				item.parents.push(parent);
			}
		}
		self.items[item.Id] = item;
	});
}

Clump.prototype.empty = function() {
	return !!this.size();
};

Clump.prototype.size = function() {
	return Object.keys(this.items).length;
};

Clump.prototype.get = function(index) {
	for(var id in this.items) {
		if(index === 0) {
			return this.items[id];
		}
		index--;
	}
};

Clump.prototype.id = function(id) {
	return this.items[id];
};

Clump.prototype.each = function() {
	var args = Array.prototype.slice.call(arguments);
	return this.map(function(item) {

		if(args[0] instanceof Array) {	// Passed in array of fields, so return values concatenated with optional separator
			var separator = (typeof args[1] === "undefined") ? "-" : args[1];
			return args[0].map(function(f) { return item[f]; }).join(separator);
		}
		else if(args.length > 1) {	// Passed in separate fields, so return array of values
			return args.map(function(f) { return item[f]; });
		}
		else {
			return item[args[0]];
		}
	});
};

Clump.prototype.forEach = function(callback) {
	for(var id in this.items) {
		var item = this.items[id];
		callback(item, id, this.items);
	}
};

Clump.prototype.map = function(callback) {
	var self = this;
	var arrayOfItems = Object.keys(this.items).map(function(key) {
		return self.items[key];
	});
	return arrayOfItems.map.call(arrayOfItems, callback);
};

Clump.prototype.sortBy = function(field, reverse) {
	var self = this;
	var objs = Object.keys(this.items).map(function(key) {
		return self.items[key];
	}).sort(function(a, b) {
		if(a[field] < b[field]) {
			return -1;
		}
		if(a[field] === b[field]) {
			return 0;
		}
		if(a[field] > b[field]) {
			return 1;
		}
	});

	return reverse ? objs.reverse() : objs;
};

Clump.prototype.same = function() {
	var self = this;

	var clone = function(obj) {
    var target = {};
    for (var i in obj) {
    	if (obj.hasOwnProperty(i)) {
    		if(typeof obj[i] === "object") {
    			target[i] = clone(obj[i]);
    		}
    		else {
      		target[i] = obj[i];
      	}
      }
    }
    return target;
  };

	var template = clone(this.get(0).attribs);

	for(var id in this.items) {
		var otherObj = this.items[id].attribs;
		for(var key in template) {
			if(template[key] !== otherObj[key]) {
				delete(template[key]);
			}
		}
	}

	return template;
};

Clump.prototype.distinct = function(field) {
	var sampleValues = {};
	this.forEach(function(item) {
		var value = item[field];
		sampleValues[value] = value;	// Cheap de-duping with a hash
	});
	return Object.keys(sampleValues).map(function(key) { return sampleValues[key]; });
};

Clump.prototype.distinctRaw = function(field) {
	var sampleValues = {};
	this.forEach(function(item) {
		var value = item.attribs[field];
		sampleValues[value] = value;	// Cheap de-duping with a hash
	});
	return Object.keys(sampleValues).map(function(key) { return sampleValues[key]; });
};

Clump.prototype.query = function(field, value) {
	var matches = [];
	var test;

	// Work out what sort of comparison to do:

	if(typeof value === "function") {	// If value is a function, pass it the candidate and return the result
		test = function(candidate) {
			return !!value(candidate);
		};
	}
	else if(typeof value === "object") {
		if(value instanceof RegExp) {
			test = function(candidate) {
				return value.test(candidate);
			};
		}
		else if(value instanceof Array) {	// If value is an array, test for the presence of the candidate value in the array
			test = function(candidate) {
				return value.indexOf(candidate) !== -1;
			};
		}
		else {
			test = function(candidate) {
				return candidate === value;	// Handle null, undefined or object-reference comparison
			};
		}
	}
	else {	// Else if it's a simple type, try a strict equality comparison
		test = function(candidate) {
			return candidate === value;
		};
	}
	
	// Now iterate over the items, filtering using the test function we defined
	this.forEach(function(item) {
		if(
			(field !== null && test(item[field])) ||
			(field === null && test(item))
		) {
			matches.push(item);
		}
	});
	return new Clump(matches, this.type);	// And wrap the resulting array of objects in a new Clump object for sexy method chaining like x.query().forEach() or x.query().query()
};

Clump.prototype.queryRaw = function(field, value) {
	var matches = [];
	var test;

	// Work out what sort of comparison to do:

	if(typeof value === "function") {	// If value is a function, pass it the candidate and return the result
		test = function(candidate) {
			return !!value(candidate);
		};
	}
	else if(typeof value === "object") {
		if(value instanceof RegExp) {
			test = function(candidate) {
				return value.test(candidate);
			};
		}
		else if(value instanceof Array) {	// If value is an array, test for the presence of the candidate value in the array
			test = function(candidate) {
				return value.indexOf(candidate) !== -1;
			};
		}
		else {	// If value is a hash... what do we do?
			// Check the candidate for each field in the hash in turn, and include the candidate if any/all of them have the same value as the corresponding value-hash field?
			throw "No idea what to do with an object as the value";
		}
	}
	else {	// Else if it's a simple type, try a strict equality comparison
		test = function(candidate) {
			return candidate === value;
		};
	}
	
	// Now iterate over them all, filtering using the test function we defined
	this.forEach(function(item) {
		if(
			(field !== null && test(item.attribs[field])) ||
			(field === null && test(item.attribs))
		) {
			matches.push(item);
		}
	});
	return new Clump(matches, this.type);	// And wrap the resulting array of objects in a new Clump object for sexy method chaining like x.query().forEach() or x.query().query()
};

Clump.prototype.toString = function() {
	return this.type.name + " Clump (" + this.size() + " items)";
};

Clump.prototype.toDom = function(size, includeChildren, tag, firstChild) {

	size = size || "normal";
	tag = tag || "ul";

	var element = document.createElement(tag);
	element.className = this.constructor.name.toLowerCase()+"-list "+size;
	if(firstChild) {
		element.appendChild(firstChild);
	}
	this.sortBy("Name").forEach(function(i) {
		element.appendChild(i.toDom(size, includeChildren));
	});
	return element;
};

Clump.prototype.describe = function() {
	var self = this;
	return Object.keys(this.items).map(function(i) { return self.items[i].toString(); }).join(" and ");
};

module.exports = Clump;
},{}],16:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function CombatAttack(raw, parent) {
	this.straightCopy = [
		'Name',
		'Image',
		'RammingAttack',
		'OnlyWhenExposed',
		'Range',
		'Orientation',
		'Arc',
		'BaseHullDamage',
		'BaseLifeDamage',
		'ExposedQualityDamage',	// Value to add to the exposedQuality: positive increases quality level (eg Terror), negative decreases it (eg Crew)
		'StaggerAmount',
		'BaseWarmUp',
		'Animation',
		'AnimationNumber'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.qualityRequired = null;
	this.qualityCost = null;
	this.exposedQuality = null;
}

Object.keys(Lump.prototype).forEach(function(member) { CombatAttack.prototype[member] = Lump.prototype[member]; });

CombatAttack.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualityRequired = api.get(api.types.Quality, this.attribs.QualityRequiredId, this);
	this.qualityCost = api.get(api.types.Quality, this.attribs.QualityCostId, this);
	this.exposedQuality = api.get(api.types.Quality, this.attribs.ExposedQualityId, this);

	Lump.prototype.wireUp.call(this, api);
};

CombatAttack.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

CombatAttack.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var self = this;
	
	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"</h3>";

	if(this.qualityRequired || this.qualityCost) {
		html += "<div class='sidebar'>";

		if(this.qualityRequired) {
			html += "<h4>Required</h4>";
			html += (new Clump([this.qualityRequired], api.types.Quality)).toDom("small", false, "ul").outerHTML;
		}
		if(this.qualityCost) {
			html += "<h4>Cost</h4>";
			html += (new Clump([this.qualityCost], api.types.Quality)).toDom("small", false, "ul").outerHTML;
		}
		html += "</div>";
	}

	html += "<dl class='clump-list small'>";
	['Range', 'Arc', 'BaseHullDamage', 'BaseLifeDamage', 'StaggerAmount', 'BaseWarmUp'].forEach(function(key) {
		html += "<dt class='item'>"+key+"</dt><dd class='quantity'>"+self[key]+"</dd>";
	});
	html += "</dl>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = CombatAttack;
},{"./clump":15,"./lump":20}],17:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Event(raw, parent) {
	this.straightCopy = [
	'Name',
	'Description',
	'Teaser',
	'Image',
	'Category'
	];
	Lump.apply(this, arguments);

	this.tag = null;

	this.ExoticEffects = this.getExoticEffect(this.attribs.ExoticEffects);

	this.qualitiesRequired = null;
	this.qualitiesAffected = null;
	this.interactions = null;
	this.linkToEvent = null;

	this.limitedToArea = null;

	this.setting = null;
	
	//Deck
	//Stickiness
	//Transient
	//Urgency
}
Object.keys(Lump.prototype).forEach(function(member) { Event.prototype[member] = Lump.prototype[member]; });

Event.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualitiesRequired = new Clump(this.attribs.QualitiesRequired || [], api.types.QualityRequirement, this);
	this.qualitiesAffected = new Clump(this.attribs.QualitiesAffected || [], api.types.QualityEffect, this);
	this.interactions = new Clump(this.attribs.ChildBranches|| [], api.types.Interaction, this);

	this.linkToEvent = api.getOrCreate(api.types.Event, this.attribs.LinkToEvent, this);

	this.limitedToArea = api.getOrCreate(api.types.Area, this.attribs.LimitedToArea, this);

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);
	
	Lump.prototype.wireUp.call(this, api);
};

Event.prototype.toString = function(long) {
	return this.constructor.name + " " + (long ? " [" + this.Category + "] " : "") + this.Name + " (#" + this.Id + ")";
};

Event.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"\n"+(this.tag ? "<span class='tag "+this.tag+"'>"+this.tag+"</span>" : "")+"</h3>";

	if(size != "small" && (this.qualitiesRequired || this.qualitiesAffected)) {
		html += "<div class='sidebar'>";
		if(this.qualitiesRequired && this.qualitiesRequired.size()) {
			html += "<h4>Requirements</h4>\n";
			html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
		}
		if(this.qualitiesAffected && this.qualitiesAffected.size()) {
			html += "<h4>Effects</h4>\n";
			html += this.qualitiesAffected.toDom("small", false, "ul").outerHTML;
		}
		html += "</div>";
	}
	
	html += "<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString(true);

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var interactions = self.interactions;
				var linkToEvent = self.linkToEvent;
				if(linkToEvent) {
					var wrapperClump = new Clump([linkToEvent], api.types.Event);
					var linkToEvent_element = wrapperClump.toDom("normal", true);

					linkToEvent_element.classList.add("child-list");
					element.appendChild(linkToEvent_element);
				}
				else if(interactions && interactions.size() > 0) {
					var interactions_element = interactions.toDom("normal", true);

					interactions_element.classList.add("child-list");
					element.appendChild(interactions_element);
				}
			}
		});
	}

	return element;
};

module.exports = Event;
},{"./clump":15,"./lump":20}],18:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Exchange(raw, parent) {
	this.straightCopy = [
		'Id',
		'Name',
		'Description',
		'Image',
		'SettingIds'
	];
	Lump.apply(this, arguments);

	this.shops = null;
	this.settings = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Exchange.prototype[member] = Lump.prototype[member]; });

Exchange.prototype.wireUp = function(theApi) {

	api = theApi;

	var self = this;

	this.shops = new Clump(this.attribs.Shops || [], api.types.Shop, this);
	
	this.settings = api.library.Setting.query("Id", function(id) {
		return self.SettingIds.indexOf(id) !== -1;
	});
	this.settings.forEach(function (s) {
		self.parents.push(s);
	});
	
	this.ports = api.library.Port.query("SettingId", function(id) {
		return self.SettingIds.indexOf(id) !== -1;
	});
	this.ports.forEach(function (p) {
		self.parents.push(p);
	});

	Lump.prototype.wireUp.call(this);
};

Exchange.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Exchange.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.shops) {

					var child_elements = self.shops.toDom("normal", true);

					child_elements.classList.add("child-list");
					element.appendChild(child_elements);
				}
			}
		});
	}

	return element;
};

module.exports = Exchange;
},{"./clump":15,"./lump":20}],19:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Interaction(raw, parent) {
	this.straightCopy = [
	'Name',
	'Description',
	'ButtonText',
	'Image',

	'Ordering'
	];
	Lump.apply(this, arguments);

	this.qualitiesRequired = null;
	this.successEvent = null;
	this.defaultEvent = null;

}
Object.keys(Lump.prototype).forEach(function(member) { Interaction.prototype[member] = Lump.prototype[member]; });

Interaction.prototype.wireUp = function(theApi) {

	api = theApi;

	this.qualitiesRequired = new Clump(this.attribs.QualitiesRequired || [], api.types.QualityRequirement, this);
	this.successEvent = api.getOrCreate(api.types.Event, this.attribs.SuccessEvent, this);
	if(this.successEvent) {
		this.successEvent.tag = "success";
	}
	this.defaultEvent = api.getOrCreate(api.types.Event, this.attribs.DefaultEvent, this);
	var qualitiesRequired =  this.qualitiesRequired;
	if(this.defaultEvent && this.successEvent && qualitiesRequired && qualitiesRequired.size()) {
		this.defaultEvent.tag = "failure";
	}

	Lump.prototype.wireUp.call(this, api);
};

Interaction.prototype.toString = function() {
	return this.constructor.name + " [" + this.Ordering + "] " + this.Name + " (#" + this.Id + ")";
};

Interaction.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.Name+"</h3>";

	if(size != "small" && this.qualitiesRequired) {
		html += "<div class='sidebar'>";
		html += "<h4>Requirements</h4>";
		html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
		html += "</div>";
	}

	html += "<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom("normal", true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = Interaction;
},{"./clump":15,"./lump":20}],20:[function(require,module,exports){
var library = require('../library');
var Clump = require('./clump');

var api;

function Lump(raw, parent) {
	if(parent) {
		this.parents = parent instanceof Array ? parent : [parent];
	}
	else {
		this.parents = [];
	}

	if(!this.straightCopy) {
		this.straightCopy = [];
	}
	this.straightCopy.unshift('Id');

	this.attribs = raw;

	var self = this;
	this.straightCopy.forEach(function(attrib) {
		self[attrib] = raw[attrib];
		if(typeof self[attrib] === "undefined") {
			self[attrib] = null;
		}
	});
	delete(this.straightCopy);

	this.wired = false;

	if(!library[this.constructor.name]) {
		library[this.constructor.name] = new Clump([], this);
	}
	library[this.constructor.name].items[this.Id] = this;
}

Lump.prototype = {
	wireUp: function(theApi) {
		api = theApi;
		this.wired = true;
	},

	getStates: function(encoded) {
		if(typeof encoded === "string" && encoded !== "") {
			var map = {};
			encoded.split("~").forEach(function(state) {
				var pair = state.split("|");
				map[pair[0]] = pair[1];
			});
			return map;
		}
		else {
			return null;
		}
	},

	getExoticEffect: function(encoded) {
		if(typeof encoded === "string") {
			var effect={}, fields=["operation", "first", "second"];
			encoded.split(",").forEach(function(val, index) {
				effect[fields[index]] = val;
			});
			return effect;
		}
		else {
			return null;
		}
	},

	evalAdvancedExpression: function(expr) {
		expr = expr.replace(/\[d:(\d+)\]/gi, "Math.floor((Math.random()*$1)+1)");	// Replace [d:x] with JS to calculate random number on a Dx die
		/*jshint -W061 */
		return eval(expr);
		/*jshint +W061 */
	},

	isA: function(type) {
		return this instanceof type;
	},

	isOneOf: function(types) {
		var self = this;
		return types.map(function(type) {
			return self.isA(type);
		}).reduce(function(previousValue, currentValue, index, array){
			return previousValue || currentValue;
		}, false);
	},

	toString: function() {
		return this.constructor.name + " (#" + this.Id + ")";
	}
};

module.exports = Lump;
},{"../library":12,"./clump":15}],21:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Port(raw, parent) {
	this.straightCopy = [
		'Name',
		'Rotation',
		'Position',
		'DiscoveryValue',
		'IsStartingPort'
	];


	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.SettingId = raw.Setting.Id;
	this.setting = null;

	this.area = null;

	this.exchanges = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Port.prototype[member] = Lump.prototype[member]; });

Port.prototype.wireUp = function(theApi) {
	
	api = theApi;
	var self = this;

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);
	
	this.area = api.getOrCreate(api.types.Area, this.attribs.Area, this);

	this.exchanges = api.library.Exchange.query("SettingIds", function(ids) { return ids.indexOf(self.SettingId) !== -1; });

	Lump.prototype.wireUp.call(this, api);
};

Port.prototype.toString = function(long) {
	return this.constructor.name + " " + this.Name + " (#" + this.Name + ")";
};

Port.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Name+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Port;
},{"./lump":20}],22:[function(require,module,exports){
var Lump = require('./lump');

var api;

function QualityEffect(raw, parent) {
	this.straightCopy = ["Level", "SetToExactly"];
	Lump.apply(this, arguments);

	// May involve Quality object references, so can't resolve until after all objects are wired up
	this.setToExactlyAdvanced = null;
	this.changeByAdvanced = null;	

	this.associatedQuality = null;
	
}
Object.keys(Lump.prototype).forEach(function(member) { QualityEffect.prototype[member] = Lump.prototype[member]; });

QualityEffect.prototype.wireUp = function(theApi) {

	api = theApi;

	this.associatedQuality = api.get(api.types.Quality, this.attribs.AssociatedQualityId, this);
	this.setToExactlyAdvanced = api.describeAdvancedExpression(this.attribs.SetToExactlyAdvanced);
	this.changeByAdvanced = api.describeAdvancedExpression(this.attribs.ChangeByAdvanced);

	Lump.prototype.wireUp.call(this, api);
};

QualityEffect.prototype.getQuantity = function() {
	var condition = "";
	
	if(this.setToExactlyAdvanced !== null) {
		condition = "+(" + this.setToExactlyAdvanced + ")";
	}
	else if(this.SetToExactly !== null) {
		condition = "= " + this.SetToExactly;
	}
	else if(this.changeByAdvanced !== null) {
		condition = "+(" + this.changeByAdvanced + ")";
	}
	else if(this.Level !== null) {
		if(this.Level < 0) {
			condition = this.Level;
		}
		else if(this.Level > 0) {
			condition = "+" + this.Level;
		}
	}
	
	return condition;
};

QualityEffect.prototype.isAdditive = function() {
	return this.setToExactlyAdvanced || this.SetToExactly || this.changeByAdvanced || (this.Level > 0);
};

QualityEffect.prototype.isSubtractive = function() {
	return !this.setToExactlyAdvanced && !this.SetToExactly && !this.changeByAdvanced && (this.Level <= 0);
};

QualityEffect.prototype.toString = function() {
	var quality = this.associatedQuality;
	return this.constructor.name + " ("+this.Id+") on " + quality + this.getQuantity();
};

QualityEffect.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	var quality_element = this.associatedQuality;

	if(!quality_element) {
		quality_element = document.createElement("span");
		quality_element.innerHTML = "[INVALID]";
	}
	else {
		quality_element = this.associatedQuality.toDom(size, false, "span");
	}

	var quantity_element = document.createElement("span");
	quantity_element.className = "item quantity";
	quantity_element.innerHTML = this.getQuantity();
	quantity_element.title = this.toString();

	element.appendChild(quality_element);
	element.appendChild(quantity_element);

	return element;
};

module.exports = QualityEffect;
},{"./lump":20}],23:[function(require,module,exports){
var Lump = require('./lump');

var api;

function QualityRequirement(raw, parent) {
	this.straightCopy = ['MinLevel', 'MaxLevel'];
	Lump.apply(this, arguments);

	this.difficultyAdvanced = null;
	this.minAdvanced = null;
	this.maxAdvanced = null;

	this.associatedQuality = null;
	this.chanceQuality = null;
}
Object.keys(Lump.prototype).forEach(function(member) { QualityRequirement.prototype[member] = Lump.prototype[member]; });

QualityRequirement.prototype.wireUp = function(theApi) {

	api = theApi;

	this.difficultyAdvanced = api.describeAdvancedExpression(this.attribs.DifficultyAdvanced);
	this.minAdvanced = api.describeAdvancedExpression(this.attribs.MinAdvanced);
	this.maxAdvanced = api.describeAdvancedExpression(this.attribs.MaxAdvanced);

	this.associatedQuality = api.get(api.types.Quality, this.attribs.AssociatedQualityId, this);

	this.chanceQuality = this.getChanceCap();

	Lump.prototype.wireUp.call(this, api);
};

QualityRequirement.prototype.getChanceCap = function() {
	var quality = null;
	if(!this.attribs.DifficultyLevel) {
		return null;
	}
	quality = this.associatedQuality;
	if(!quality) {
		return null;
	}
	
	return Math.round(this.attribs.DifficultyLevel * ((100 + quality.DifficultyScaler + 7)/100));
};

QualityRequirement.prototype.getQuantity = function() {
	var condition = "";

  if(this.difficultyAdvanced !== null) {
  	condition = this.difficultyAdvanced;
  }
  else if(this.minAdvanced !== null) {
  	condition = this.minAdvanced;
  }
  else if(this.maxAdvanced !== null) {
  	condition = this.maxAdvanced;
  }
	else if(this.chanceQuality !== null) {
		condition = this.chanceQuality + " for 100%";
	}
	else if(this.MaxLevel !== null && this.MinLevel !== null) {
		if(this.MaxLevel === this.MinLevel) {
			condition = "= " + this.MinLevel;
		}
		else {
			condition = this.MinLevel + "-" + this.MaxLevel;
		}
	}
	else {
		if(this.MinLevel !== null) {
			condition = "&ge; " + this.MinLevel;
		}
		if(this.MaxLevel !== null) {
			condition = "&le; " + this.MaxLevel;
		}
	}
	return condition;
};

QualityRequirement.prototype.toString = function() {
	var quality = this.associatedQuality;
	return this.constructor.name + " ("+this.Id+") on " + quality + " " + this.getQuantity();
};

QualityRequirement.prototype.toDom = function(size) {

	size = size || "small";

	var element = document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	var quality_element = this.associatedQuality;

	if(!quality_element) {
		quality_element = document.createElement("span");
		quality_element.innerHTML = "[INVALID]";
	}
	else {
		quality_element = this.associatedQuality.toDom(size, false, "span");
	}

	var quantity_element = document.createElement("span");
	quantity_element.className = "item quantity";
	quantity_element.innerHTML = this.getQuantity();
	quantity_element.title = this.toString();

	element.appendChild(quality_element);
	element.appendChild(quantity_element);

	return element;
};

module.exports = QualityRequirement;
},{"./lump":20}],24:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Quality(raw, parent) {
	this.straightCopy = [
		'Name',
		'Description',
		'Image',

		'Category',
		'Nature',
		'Tag',

		"IsSlot",

		'AllowedOn',
		"AvailableAt",

		'Cap',
		'DifficultyScaler',
		'Enhancements'
	];
	Lump.apply(this, arguments);

	this.States = this.getStates(raw.ChangeDescriptionText);
	this.LevelDescriptionText = this.getStates(raw.LevelDescriptionText);
	this.LevelImageText = this.getStates(raw.LevelImageText);

	this.useEvent = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Quality.prototype[member] = Lump.prototype[member]; });

Quality.prototype.wireUp = function(theApi) {

	api = theApi;

	this.useEvent = api.getOrCreate(api.types.Event, this.attribs.UseEvent, this);
	if(this.useEvent) {
		this.useEvent.tag = "use";
	}

	Lump.prototype.wireUp.call(this, api);
};

Quality.prototype.toString = function(long) {
	return this.constructor.name + " " + (long ? " [" + this.Nature + " > " + this.Category + " > " + this.Tag + "] " : "") + this.Name + " (#" + this.Id + ")";
};

Quality.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+"small.png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		var self = this;
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.useEvent) {

					var wrapperClump = new Clump([self.useEvent], api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = Quality;
},{"./clump":15,"./lump":20}],25:[function(require,module,exports){
var Lump = require('./lump');

var api;

function Setting(raw, parent) {
	this.straightCopy = [
		'Id'
	];
	Lump.apply(this, arguments);

	this.shops = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Setting.prototype[member] = Lump.prototype[member]; });

Setting.prototype.wireUp = function(theApi) {

	api = theApi;

	Lump.prototype.wireUp.call(this);
};

Setting.prototype.toString = function() {
	return this.constructor.name + " #" + this.Id;
};

Setting.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Id+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Setting;
},{"./lump":20}],26:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function Shop(raw, parent) {
	this.straightCopy = [
		'Id',
		'Name',
		'Description',
		'Image',
		'Ordering'
	];
	Lump.apply(this, arguments);

	this.availabilities = null;
	this.unlockCost = null;
}
Object.keys(Lump.prototype).forEach(function(member) { Shop.prototype[member] = Lump.prototype[member]; });

Shop.prototype.wireUp = function(theApi) {

	api = theApi;

	this.availabilities = new Clump(this.attribs.Availabilities || [], api.types.Availability, this);

	Lump.prototype.wireUp.call(this);
};

Shop.prototype.toString = function() {
	return this.constructor.name + " " + this.Name + " (#" + this.Id + ")";
};

Shop.prototype.toDom = function(size, includeChildren, tag) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;
	tag = tag || "li";

	var self = this;
	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.Image+".png' />";
	html += "\n<h3 class='title'>"+this.Name+"</h3>";
	html += "\n<p class='description'>"+this.Description+"</p>";

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				if(self.availabilities) {

					var child_elements = self.availabilities.toDom("normal", true);

					child_elements.classList.add("child-list");
					element.appendChild(child_elements);
				}
			}
		});
	}

	return element;
};

module.exports = Shop;
},{"./clump":15,"./lump":20}],27:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');

var api;

function SpawnedEntity(raw, parent) {
	this.straightCopy = [
		'Name',
		'HumanName',

		'Neutral',
		'PrefabName',
		'DormantBehaviour',
		'AwareBehaviour',

		'Hull',
		'Crew',
		'Life',
		'MovementSpeed',
		'RotationSpeed',
		'BeastieCharacteristicsName',
		'CombatItems',
		'LootPrefabName',
		'GleamValue'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.pacifyEvent = null;
	this.killQualityEvent = null;
	this.combatAttackNames = [];

	this.image = null;
}
Object.keys(Lump.prototype).forEach(function(member) { SpawnedEntity.prototype[member] = Lump.prototype[member]; });

SpawnedEntity.prototype.wireUp = function(theApi) {

	api = theApi;

	var self = this;
	
	this.combatAttackNames = (this.attribs.CombatAttackNames || []).map(function(name) {
		return api.get(api.types.CombatAttack, name, self);
	}).filter(function(attack) {
		return typeof attack === "object";
	});

	this.pacifyEvent = api.get(api.types.Event, this.attribs.PacifyEventId, this);
	if(this.pacifyEvent) {
		this.pacifyEvent.tag = "pacified";
	}

	this.killQualityEvent = api.get(api.types.Event, this.attribs.KillQualityEventId, this);
	if(this.killQualityEvent) {
		this.killQualityEvent.tag = "killed";
	}

	this.image = ((this.killQualityEvent && this.killQualityEvent.Image) || (this.pacifyEvent && this.pacifyEvent.Image));

	Lump.prototype.wireUp.call(this, api);
};

SpawnedEntity.prototype.toString = function() {
	return this.constructor.name + " " + this.HumanName + " (#" + this.Id + ")";
};

SpawnedEntity.prototype.toDom = function(size, includeChildren) {

	size = size || "normal";
	includeChildren = includeChildren === false ? false : true;

	var self = this;

	var html = "";

	var element =  document.createElement("li");
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	if(this.Image !== null && this.Image !== "") {
		html = "<img class='icon' src='"+api.config.locations.imagesPath+"/"+this.image+"small.png' />";
	}

	html += "\n<h3 class='title'>"+this.HumanName+"</h3>";

	if(size !== "small") {
		if(this.qualitiesRequired) {
			html += "<div class='sidebar'>";
			html += this.qualitiesRequired.toDom("small", false, "ul").outerHTML;
			html += "</div>";
		}

		html += "<dl class='clump-list small'>";

		['Hull', 'Crew', 'Life', 'MovementSpeed', 'RotationSpeed'].forEach(function(key) {
			html += "<dt class='item'>"+key+"</dt><dd class='quantity'>"+self[key]+"</dd>";
		});
		html += "</dl>";
	}

	element.innerHTML = html;

	element.title = this.toString();

	if(includeChildren) {
		element.addEventListener("click", function(e) {
			e.stopPropagation();

			var childList = element.querySelector(".child-list");
			if(childList) {
				element.removeChild(childList);
			}
			else {
				var successEvent = self.successEvent;
				var defaultEvent = self.defaultEvent;
				var qualitiesRequired =  self.qualitiesRequired;
				var events = [];
				if(successEvent && qualitiesRequired && qualitiesRequired.size()) {
					events.push(successEvent);
				}
				if(defaultEvent) {
					events.push(defaultEvent);
				}
				if(events.length) {
					var wrapperClump = new Clump(events, api.types.Event);
					var child_events = wrapperClump.toDom(size, true);

					child_events.classList.add("child-list");
					element.appendChild(child_events);
				}
			}
		});
	}

	return element;
};

module.exports = SpawnedEntity;
},{"./clump":15,"./lump":20}],28:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');
var Port = require('./port');
var Area = require('./area');

var api;

function TileVariant(raw, parent) {
	this.straightCopy = [
		'Name',
		'HumanName',
		'Description',

		'MaxTilePopulation',
		'MinTilePopulation',
		
		'SeaColour',
		'MusicTrackName',
		'ChanceOfWeather',
		'FogRevealThreshold'
	];

/*
LabelData: Array[6]
PhenomenaData: Array[1]
SpawnPoints: Array[2]
TerrainData: Array[14]
Weather: Array[1]
*/

	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.SettingId = raw.Setting.Id;
	this.setting = null;

	this.ports = new Clump(this.attribs.PortData || [], Port, this);

	this.areas = null;
}
Object.keys(Lump.prototype).forEach(function(member) { TileVariant.prototype[member] = Lump.prototype[member]; });

TileVariant.prototype.wireUp = function(theApi) {

	api = theApi;

	this.setting = api.getOrCreate(api.types.Setting, this.attribs.Setting, this);

	this.ports.forEach(function(p) { p.wireUp(api); });

	// Also create a list of all the areas of each of the ports in this object for convenience
	this.areas = new Clump(this.ports.map(function(p) { return p.area; }), api.types.Area, this);

	Lump.prototype.wireUp.call(this);
};

TileVariant.prototype.toString = function(long) {
	return this.constructor.name + " " + this.HumanName + " (#" + this.Name + ")";
};

TileVariant.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.HumanName+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = TileVariant;
},{"./area":13,"./clump":15,"./lump":20,"./port":21}],29:[function(require,module,exports){
var Lump = require('./lump');
var Clump = require('./clump');
var TileVariant = require('./tile-variant');
var Port = require('./port');
var Area = require('./area');

var api;

function Tile(raw, parent) {
	this.straightCopy = [
		'Name'
	];
	raw.Id = raw.Name;
	Lump.apply(this, arguments);

	this.tileVariants = new Clump(this.attribs.Tiles || [], TileVariant, this);
}
Object.keys(Lump.prototype).forEach(function(member) { Tile.prototype[member] = Lump.prototype[member]; });

Tile.prototype.wireUp = function(theApi) {

	api = theApi;

	this.tileVariants.forEach(function(tv) { tv.wireUp(api); });

	// Also create a list of all the ports and areas of each of the tilevariants in this object for convenience
	var all_ports = {};
	var all_areas = {};
	this.tileVariants.forEach(function(tv) {
		tv.ports.forEach(function(p) {
			all_ports[p.Id] = p;
			all_areas[p.area.Id] = p.area;
		});
	});
	this.ports = new Clump(Object.keys(all_ports).map(function(p) { return all_ports[p]; }), api.types.Port, this);
	this.areas = new Clump(Object.keys(all_areas).map(function(a) { return all_areas[a]; }), api.types.Area, this);

	Lump.prototype.wireUp.call(this);
};

Tile.prototype.toString = function(long) {
	return this.constructor.name + " " + this.Name + " (#" + this.Name + ")";
};

Tile.prototype.toDom = function(size, tag) {

	size = size || "normal";
	tag = tag || "li";

	var html = "";

	var element =  document.createElement(tag);
	element.className = "item "+this.constructor.name.toLowerCase()+"-item "+size;

	html = "\n<h3 class='title'>"+this.Name+"</h3>";

	element.innerHTML = html;

	element.title = this.toString();

	return element;
};

module.exports = Tile;
},{"./area":13,"./clump":15,"./lump":20,"./port":21,"./tile-variant":28}],30:[function(require,module,exports){
var api = require('./api');
var dragndrop = require('./ui/dragndrop');
var query = require('./ui/query');


$("#tabs .buttons li").on("click", function(e) {

  var type = $(this).attr("data-type");

  $("#tabs .panes .pane").hide(); // Hide all panes
  $("#tabs .buttons li").removeClass("active"); // Deactivate all buttons

  $("#tabs .panes ."+type.toLowerCase()).show();
  $("#tabs .buttons [data-type="+type+"]").addClass("active");
});

// Setup the dnd listeners.
var dropZone = document.getElementById('drop-zone');

dropZone.addEventListener('dragenter', dragndrop.handlers.dragOver, false);
dropZone.addEventListener('dragleave', dragndrop.handlers.dragEnd, false);
dropZone.addEventListener('dragover', dragndrop.handlers.dragOver, false);

dropZone.addEventListener('drop', dragndrop.handlers.dragDrop, false);

document.getElementById('paths-to-node').addEventListener('click', query.pathsToNodeUI, false);

// For convenience
window.api = api;
window.api.query = query;
},{"./api":10,"./ui/dragndrop":31,"./ui/query":32}],31:[function(require,module,exports){
var api = require('../api');
var Clump = require('../objects/clump');
var io = require('../io');

var render = require('./render');

function handleDragOver(evt) {
  evt.stopPropagation();
  evt.preventDefault();

  $("#drop-zone").addClass("drop-target");
}

function handleDragEnd(evt) {
  evt.stopPropagation();
  evt.preventDefault();

  $("#drop-zone").removeClass("drop-target");
}

function handleDragDrop(evt) {

  $("#drop-zone").removeClass("drop-target");

  evt.stopPropagation();
  evt.preventDefault();

  var files = evt.dataTransfer.files; // FileList object.

  // Files is a FileList of File objects. List some properties.
  var output = [];
  io.resetFilesToLoad();
  for (var i = 0; i < files.length; i++) {
    var f = files[i];
    var filename = escape(f.name);
    var typeName = io.fileObjectMap[filename];
    var Type = api.types[typeName];
    if(Type) {
      io.incrementFilesToLoad();
      api.readFromFile(Type, f, function() {
        io.decrementFilesToLoad();

        if(io.countFilesToLoad() === 0) {
          api.wireUpObjects();
          render.lists();
        }
      });
      output.push('<li><strong>', escape(f.name), '</strong> (', f.type || 'n/a', ') - ',
                f.size, ' bytes, last modified: ',
                f.lastModifiedDate ? f.lastModifiedDate.toLocaleDateString() : 'n/a',
                '</li>');
    }
    else {
      output.push('<li>ERROR: No handler for file <strong>' , escape(f.name), '</strong></li>');
    }
  }
  document.getElementById('list').innerHTML = '<ul>' + output.join('') + '</ul>';
}

module.exports = {
	handlers: {
		dragOver: handleDragOver,
		dragEnd: handleDragEnd,
		dragDrop: handleDragDrop
	}
};
},{"../api":10,"../io":11,"../objects/clump":15,"./render":33}],32:[function(require,module,exports){
var api = require('../api');
var Clump = require('../objects/clump');

function RouteNode(node) {
  this.node = node;
  this.children = [];
}

function pathsToNodeUI() {

  var type = document.getElementById('type');
  type = type.options[type.selectedIndex].value;

  var operation = document.getElementById('operation');
  operation = operation.options[operation.selectedIndex].value;

  var id = prompt("Id of "+type);

  if(!id) {  // Cancelled dialogue
    return;
  }

  var item = api.library[type].id(id);

  if(!item) {
    alert("Could not find "+type+" "+id);
    return;
  }

  var root = document.getElementById("query-tree");
  root.innerHTML = "";

  var title = $('.pane.query .pane-title').text("Query: "+item.toString());

  var routes = pathsToNode(item, {});

  if(routes && routes.children.length) {

    routes = filterPathsToNode(routes, operation);

    var top_children = document.createElement("ul");
    top_children.className += "clump-list small";

    routes.children.forEach(function(child_route) {
      var tree = renderPathsToNode(child_route, []);
      top_children.appendChild(tree);
    });

    root.appendChild(top_children);
  }
  else {
    alert("This "+type+" is a root node with no parents that satisfy the conditions");
  }
  
}

function pathsToNode(node, seen, parent) {

  if(seen[node.Id]) {   // Don't recurse into nodes we've already seen
    return false;
  }

  var ancestry = JSON.parse(JSON.stringify(seen));
  ancestry[node.Id] = true;

  var this_node = new RouteNode(/*node.linkToEvent ? node.linkToEvent :*/ node); // If this node is just a link to another one, skip over the useless link

  if(node instanceof api.types.SpawnedEntity) {
    return this_node;   // Leaf node in tree
  }
  else if(node instanceof api.types.Event && node.tag === "use") {
    return this_node;   // Leaf node in tree
  }
  else if(node instanceof api.types.Event && parent instanceof api.types.Event && (parent.tag === "killed" || parent.tag === "pacified")) { // If this is an event that's reachable by killing a monster, don't recurse any other causes (as they're usually misleading/circular)
    return false;
  }
  else if(node instanceof api.types.Setting) {
    return false;
  }
  else if (node instanceof api.types.Port) {
    return new RouteNode(node.area);
  }
  else if(node.limitedToArea && node.limitedToArea.Id !== 101956) {
    var area_name = node.limitedToArea.Name.toLowerCase();
    var event_name = (node.Name && node.Name.toLowerCase()) || "";
    if(area_name.indexOf(event_name) !== -1 || event_name.indexOf(area_name) !== -1) {  // If Area has similar name to Event, ignore the event and just substitute the area
      return new RouteNode(node.limitedToArea);
    }
    else {
      this_node.children.push(new RouteNode(node.limitedToArea));   // Else include both the Area and the Event
      return this_node;
    }
    
  }
  else {
    for(var i=0; i<node.parents.length; i++) {
      var the_parent = node.parents[i];
      var subtree = pathsToNode(the_parent, ancestry, node);
      if(subtree) {
        this_node.children.push(subtree);
      }
    }
    if(!this_node.children.length) {
      return false;
    }
  }

  return this_node;
}

function filterPathsToNode(routes, operation) {
  // Filter routes by operation
  if(routes && routes.children && operation !== "any") {
    routes.children = routes.children.filter(function(route_node) {

      lump = route_node.node;

      if(operation === "additive") {
        return lump.isOneOf([api.types.QualityEffect, api.types.Availability]) && lump.isAdditive();
      }
      else if(operation === "subtractive") {
        return lump.isOneOf([api.types.QualityEffect, api.types.Availability]) && lump.isSubtractive();
      }
    });
  }

  return routes;
}

function renderPathsToNode(routeNode, ancestry) {
  
  if(!(routeNode instanceof RouteNode)) {
    return null;
  }

  var element = routeNode.node.toDom("small", false);
  
  var child_list = document.createElement("ul");
  child_list.className += "clump-list small child-list";

  var new_ancestry = ancestry.slice();
  new_ancestry.push(routeNode.node);
  routeNode.children.forEach(function(child_route, index, children) {
    var child_content = renderPathsToNode(child_route, new_ancestry);
    child_list.appendChild(child_content);
  });

  if(routeNode.children.length) {
    element.appendChild(child_list);
  }
  else {
    var description = document.createElement("li");
    description.innerHTML = '<span class="route-description">HINT: ' + describeRoute(new_ancestry) + '</span>';

    var reqsTitle = document.createElement('h5');
    reqsTitle.innerHTML = "Requirements";
    description.appendChild(reqsTitle);

    var total_requirements = getRouteRequirements(new_ancestry);
    
    description.appendChild(total_requirements.toDom("small", false));
    element.appendChild(description);
  }

  return element;
}

function lower(text) {
  return text.slice(0,1).toLowerCase()+text.slice(1);
}

function describeRoute(ancestry) {
  var a = ancestry.slice().reverse();

  var guide = "";
  if(a[0] instanceof api.types.Area) {
    if(a[1] instanceof api.types.Event) {
      guide = "Seek "+a[1].Name+" in "+a[0].Name;
      if(a[2] instanceof api.types.Interaction) {
        guide += " and ";
        if("\"'".indexOf(a[2].Name[0]) !== -1) {
          guide += "exclaim ";
        }
        guide += lower(a[2].Name);
      }
      guide += ".";
    }
    else {
      guide = "Travel to "+a[0].Name;

      if(a[1] instanceof api.types.Interaction) {
        guide += " and "+lower(a[1].Name);
      }
      else if(a[1] instanceof api.types.Exchange && a[2] instanceof api.types.Shop) {
        guide += " and look for the "+a[2].Name+" Emporium in "+a[1].Name;
      }

      guide += ".";
    }
  }
  else if(a[0] instanceof api.types.SpawnedEntity) {
    guide = "Find and best a "+a[0].HumanName;
    if(a[2] instanceof api.types.Interaction) {
      guide += ", then " + lower(a[2].Name);
    }
    guide += ".";
  }
  else if(a[0] instanceof api.types.Event && a[0].tag === "use" && !(a[1] instanceof api.types.QualityRequirement)) {
    if(a[0].Name.match(/^\s*Speak/i)) {
      guide = a[0].Name;
    }
    else if(a[0].Name.match(/^\s*A/i)) {
      guide = "Acquire "+lower(a[0].Name);
    }
    else {
      guide = "Find a "+lower(a[0].Name);
    }
    guide += " and " + lower(a[1].Name) + ".";
  }

  return guide;
}

function detailRoute(ancestry) {
  var a = ancestry.slice().reverse();

  var guide = "";
  if(a[0] instanceof api.types.Area) {
    if(a[1] instanceof api.types.Event) {
      guide = "You must travel to "+a[0].Name+" and look for "+a[1].Name+".";
      if(a[2] instanceof api.types.Interaction) {
        guide += "  When you find it you should ";
        if("\"'".indexOf(a[2].Name[0]) !== -1) {
          guide += "say ";
        }
        guide += lower(a[2].Name);
      }
      guide += ".";
    }
    else {
      guide = "Make for "+a[0].Name;

      if(a[1] instanceof api.types.Interaction) {
        guide += " and "+lower(a[1].Name);
      }
      else if(a[1] instanceof api.types.Exchange && a[2] instanceof api.types.Shop) {
        guide += ".  Upon arrival go to "+a[1].Name+", and look for the shop "+a[2].Names;
      }

      guide += ".";
    }
  }
  else if(a[0] instanceof api.types.SpawnedEntity) {
    guide = "You must hunt the mythical zee-peril known as the "+a[0].HumanName+", engage it in battle and defeat it.";
    if(a[2] instanceof api.types.Interaction) {
      guide += "  Once you have conquered it you must " + lower(a[2].Name) + " to help secure your prize.";
    }
  }
  else if(a[0] instanceof api.types.Event && a[0].tag === "use" && !(a[1] instanceof api.types.QualityRequirement)) {
    if(a[0].Name.match(/^\s*Speak/i)) {
      guide = "First you must "+lower(a[0].Name);
    }
    else if(a[0].Name.match(/^\s*A/i)) {
      guide = "Source "+lower(a[0].Name);
    }
    else {
      guide = "Try to locate a "+lower(a[0].Name);
    }
    guide += ", and then " + lower(a[1].Name) + ".";
  }

  return guide;
}

function getRouteRequirements(ancestry) {

  var reqs = {};

  // Ancestry is ordered from last->first, so iterate backwards from final effect -> initial cause
  ancestry.forEach(function(step) {
    /* Simplification: if an event modifies a quality then assume that later requirements
    on the same quality are probably satisfied by that modification (eg, when qualities
    are incremented/decremented to control story-quest progress). */
    if(step.qualitiesAffected) {
      step.qualitiesAffected.forEach(function(effect) {
        delete(reqs[effect.associatedQuality.Id]);
      });
    }
    // Now add any requirements for the current stage (earlier requirements overwrite later ones on the same quality)
    if(step.qualitiesRequired) {
      step.qualitiesRequired.forEach(function(req) {
        if(req.associatedQuality) { // Check this is a valid QualityRequirement, and not one of the half-finished debug elements referring to anon-existant Quality
          reqs[req.associatedQuality.Id] = req;
        }
      });
    }
  });

  var result = Object.keys(reqs).map(function(key) { return reqs[key]; });

  return new Clump(result, api.types.QualityRequirement);
}

module.exports = {
  RouteNode: RouteNode,
  pathsToNodeUI: pathsToNodeUI,
  pathsToNode: pathsToNode,
  filterPathsToNode: filterPathsToNode,
  renderPathsToNode: renderPathsToNode,
  describeRoute: describeRoute,
  detailRoute: detailRoute,
  getRouteRequirements: getRouteRequirements
};
},{"../api":10,"../objects/clump":15}],33:[function(require,module,exports){
var api = require('../api');

function renderLists() {
  Object.keys(api.loaded).forEach(function(type) {
    renderList(api.loaded[type]); // Only display directly loaded (root-level) Lumps, to prevent the list becoming unwieldy
  });
}

function renderList(clump) {
	var root = document.getElementById(clump.type.name.toLowerCase()+"-list");
  if(root) {
	 root.appendChild(clump.toDom());
  }
}

module.exports = {
	list: renderList,
	lists: renderLists
};
},{"../api":10}]},{},[10,11,12,30])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJjb25maWcuanNvbiIsIm5vZGVfbW9kdWxlcy9icm93c2VyaWZ5L2xpYi9fZW1wdHkuanMiLCJub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvYnVmZmVyL2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2J1ZmZlci9ub2RlX21vZHVsZXMvYmFzZTY0LWpzL2xpYi9iNjQuanMiLCJub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvYnVmZmVyL25vZGVfbW9kdWxlcy9pZWVlNzU0L2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2J1ZmZlci9ub2RlX21vZHVsZXMvaXMtYXJyYXkvaW5kZXguanMiLCJub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvZXZlbnRzL2V2ZW50cy5qcyIsIm5vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9wcm9jZXNzL2Jyb3dzZXIuanMiLCJub2RlX21vZHVsZXMvZmlsZXJlYWRlci9GaWxlUmVhZGVyLmpzIiwic3JjL3NjcmlwdHMvYXBpLmpzIiwic3JjL3NjcmlwdHMvaW8uanMiLCJzcmMvc2NyaXB0cy9saWJyYXJ5LmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9hcmVhLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9hdmFpbGFiaWxpdHkuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL2NsdW1wLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9jb21iYXQtYXR0YWNrLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9ldmVudC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvZXhjaGFuZ2UuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL2ludGVyYWN0aW9uLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9sdW1wLmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9wb3J0LmpzIiwic3JjL3NjcmlwdHMvb2JqZWN0cy9xdWFsaXR5LWVmZmVjdC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvcXVhbGl0eS1yZXF1aXJlbWVudC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvcXVhbGl0eS5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvc2V0dGluZy5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvc2hvcC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvc3Bhd25lZC1lbnRpdHkuanMiLCJzcmMvc2NyaXB0cy9vYmplY3RzL3RpbGUtdmFyaWFudC5qcyIsInNyYy9zY3JpcHRzL29iamVjdHMvdGlsZS5qcyIsInNyYy9zY3JpcHRzL3VpLmpzIiwic3JjL3NjcmlwdHMvdWkvZHJhZ25kcm9wLmpzIiwic3JjL3NjcmlwdHMvdWkvcXVlcnkuanMiLCJzcmMvc2NyaXB0cy91aS9yZW5kZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdkJBOzs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQ3RnREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM1SEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcEZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUMzRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUM1U0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0lBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0NBOztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDckNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0UUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzFIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzSEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzVGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM1R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9GQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOUZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6SUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN4VEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwibW9kdWxlLmV4cG9ydHM9e1xuXHRcInRpdGxlXCI6IFwiU3VubGVzcyBTZWFcIixcblx0XCJwYXRoc1wiOiB7XG5cdFx0XCJ0ZW1wbGF0ZXNcIjogXCJzcmMvdGVtcGxhdGVzXCIsXG5cdFx0XCJidWlsZGRpclwiOiB7XG5cdFx0XHRcIm1vZFwiOiBcImJ1aWxkL2Nsb2Nrd29yYWNsZVwiLFxuXHRcdFx0XCJ1aVwiOiBcImJ1aWxkL21vZHRvb2xzXCJcblx0XHR9XG5cdH0sXG5cdFwibG9jYXRpb25zXCI6IHtcblx0XHRcImltYWdlc1BhdGhcIjogXCIuLi8uLi9nYW1lLWRhdGEvaWNvbnNcIlxuXHR9LFxuXHRcImJhc2VHYW1lSWRzXCI6IHtcblx0XHRcInF1YWxpdHlcIjogNDE1MDAwLFxuXHRcdFwicHJlbGltRXZlbnRcIjogNTAwMDAwLFxuXHRcdFwiYnV5T3JhY2xlXCI6IDUwMDAwMTAsXG5cdFx0XCJzZWxsT3JhY2xlXCI6IDUwMDAyMCxcblx0XHRcImV2ZW50XCI6IDUwMDAyNSxcblx0XHRcImFjcXVpcmVcIjogNjAwMDAwLFxuXHRcdFwibGVhcm5cIjogNzAwMDAwLFxuXHRcdFwic3VmZmVyXCI6IDgwMDAwMCxcblx0XHRcImJlY29tZVwiOiA5MDAwMDBcblx0fVxufSIsbnVsbCwiLyohXG4gKiBUaGUgYnVmZmVyIG1vZHVsZSBmcm9tIG5vZGUuanMsIGZvciB0aGUgYnJvd3Nlci5cbiAqXG4gKiBAYXV0aG9yICAgRmVyb3NzIEFib3VraGFkaWplaCA8ZmVyb3NzQGZlcm9zcy5vcmc+IDxodHRwOi8vZmVyb3NzLm9yZz5cbiAqIEBsaWNlbnNlICBNSVRcbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbm8tcHJvdG8gKi9cblxudmFyIGJhc2U2NCA9IHJlcXVpcmUoJ2Jhc2U2NC1qcycpXG52YXIgaWVlZTc1NCA9IHJlcXVpcmUoJ2llZWU3NTQnKVxudmFyIGlzQXJyYXkgPSByZXF1aXJlKCdpcy1hcnJheScpXG5cbmV4cG9ydHMuQnVmZmVyID0gQnVmZmVyXG5leHBvcnRzLlNsb3dCdWZmZXIgPSBTbG93QnVmZmVyXG5leHBvcnRzLklOU1BFQ1RfTUFYX0JZVEVTID0gNTBcbkJ1ZmZlci5wb29sU2l6ZSA9IDgxOTIgLy8gbm90IHVzZWQgYnkgdGhpcyBpbXBsZW1lbnRhdGlvblxuXG52YXIgcm9vdFBhcmVudCA9IHt9XG5cbi8qKlxuICogSWYgYEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUYDpcbiAqICAgPT09IHRydWUgICAgVXNlIFVpbnQ4QXJyYXkgaW1wbGVtZW50YXRpb24gKGZhc3Rlc3QpXG4gKiAgID09PSBmYWxzZSAgIFVzZSBPYmplY3QgaW1wbGVtZW50YXRpb24gKG1vc3QgY29tcGF0aWJsZSwgZXZlbiBJRTYpXG4gKlxuICogQnJvd3NlcnMgdGhhdCBzdXBwb3J0IHR5cGVkIGFycmF5cyBhcmUgSUUgMTArLCBGaXJlZm94IDQrLCBDaHJvbWUgNyssIFNhZmFyaSA1LjErLFxuICogT3BlcmEgMTEuNissIGlPUyA0LjIrLlxuICpcbiAqIER1ZSB0byB2YXJpb3VzIGJyb3dzZXIgYnVncywgc29tZXRpbWVzIHRoZSBPYmplY3QgaW1wbGVtZW50YXRpb24gd2lsbCBiZSB1c2VkIGV2ZW5cbiAqIHdoZW4gdGhlIGJyb3dzZXIgc3VwcG9ydHMgdHlwZWQgYXJyYXlzLlxuICpcbiAqIE5vdGU6XG4gKlxuICogICAtIEZpcmVmb3ggNC0yOSBsYWNrcyBzdXBwb3J0IGZvciBhZGRpbmcgbmV3IHByb3BlcnRpZXMgdG8gYFVpbnQ4QXJyYXlgIGluc3RhbmNlcyxcbiAqICAgICBTZWU6IGh0dHBzOi8vYnVnemlsbGEubW96aWxsYS5vcmcvc2hvd19idWcuY2dpP2lkPTY5NTQzOC5cbiAqXG4gKiAgIC0gU2FmYXJpIDUtNyBsYWNrcyBzdXBwb3J0IGZvciBjaGFuZ2luZyB0aGUgYE9iamVjdC5wcm90b3R5cGUuY29uc3RydWN0b3JgIHByb3BlcnR5XG4gKiAgICAgb24gb2JqZWN0cy5cbiAqXG4gKiAgIC0gQ2hyb21lIDktMTAgaXMgbWlzc2luZyB0aGUgYFR5cGVkQXJyYXkucHJvdG90eXBlLnN1YmFycmF5YCBmdW5jdGlvbi5cbiAqXG4gKiAgIC0gSUUxMCBoYXMgYSBicm9rZW4gYFR5cGVkQXJyYXkucHJvdG90eXBlLnN1YmFycmF5YCBmdW5jdGlvbiB3aGljaCByZXR1cm5zIGFycmF5cyBvZlxuICogICAgIGluY29ycmVjdCBsZW5ndGggaW4gc29tZSBzaXR1YXRpb25zLlxuXG4gKiBXZSBkZXRlY3QgdGhlc2UgYnVnZ3kgYnJvd3NlcnMgYW5kIHNldCBgQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlRgIHRvIGBmYWxzZWAgc28gdGhleVxuICogZ2V0IHRoZSBPYmplY3QgaW1wbGVtZW50YXRpb24sIHdoaWNoIGlzIHNsb3dlciBidXQgYmVoYXZlcyBjb3JyZWN0bHkuXG4gKi9cbkJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUID0gZ2xvYmFsLlRZUEVEX0FSUkFZX1NVUFBPUlQgIT09IHVuZGVmaW5lZFxuICA/IGdsb2JhbC5UWVBFRF9BUlJBWV9TVVBQT1JUXG4gIDogKGZ1bmN0aW9uICgpIHtcbiAgICAgIGZ1bmN0aW9uIEJhciAoKSB7fVxuICAgICAgdHJ5IHtcbiAgICAgICAgdmFyIGFyciA9IG5ldyBVaW50OEFycmF5KDEpXG4gICAgICAgIGFyci5mb28gPSBmdW5jdGlvbiAoKSB7IHJldHVybiA0MiB9XG4gICAgICAgIGFyci5jb25zdHJ1Y3RvciA9IEJhclxuICAgICAgICByZXR1cm4gYXJyLmZvbygpID09PSA0MiAmJiAvLyB0eXBlZCBhcnJheSBpbnN0YW5jZXMgY2FuIGJlIGF1Z21lbnRlZFxuICAgICAgICAgICAgYXJyLmNvbnN0cnVjdG9yID09PSBCYXIgJiYgLy8gY29uc3RydWN0b3IgY2FuIGJlIHNldFxuICAgICAgICAgICAgdHlwZW9mIGFyci5zdWJhcnJheSA9PT0gJ2Z1bmN0aW9uJyAmJiAvLyBjaHJvbWUgOS0xMCBsYWNrIGBzdWJhcnJheWBcbiAgICAgICAgICAgIGFyci5zdWJhcnJheSgxLCAxKS5ieXRlTGVuZ3RoID09PSAwIC8vIGllMTAgaGFzIGJyb2tlbiBgc3ViYXJyYXlgXG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgIH0pKClcblxuZnVuY3Rpb24ga01heExlbmd0aCAoKSB7XG4gIHJldHVybiBCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVFxuICAgID8gMHg3ZmZmZmZmZlxuICAgIDogMHgzZmZmZmZmZlxufVxuXG4vKipcbiAqIENsYXNzOiBCdWZmZXJcbiAqID09PT09PT09PT09PT1cbiAqXG4gKiBUaGUgQnVmZmVyIGNvbnN0cnVjdG9yIHJldHVybnMgaW5zdGFuY2VzIG9mIGBVaW50OEFycmF5YCB0aGF0IGFyZSBhdWdtZW50ZWRcbiAqIHdpdGggZnVuY3Rpb24gcHJvcGVydGllcyBmb3IgYWxsIHRoZSBub2RlIGBCdWZmZXJgIEFQSSBmdW5jdGlvbnMuIFdlIHVzZVxuICogYFVpbnQ4QXJyYXlgIHNvIHRoYXQgc3F1YXJlIGJyYWNrZXQgbm90YXRpb24gd29ya3MgYXMgZXhwZWN0ZWQgLS0gaXQgcmV0dXJuc1xuICogYSBzaW5nbGUgb2N0ZXQuXG4gKlxuICogQnkgYXVnbWVudGluZyB0aGUgaW5zdGFuY2VzLCB3ZSBjYW4gYXZvaWQgbW9kaWZ5aW5nIHRoZSBgVWludDhBcnJheWBcbiAqIHByb3RvdHlwZS5cbiAqL1xuZnVuY3Rpb24gQnVmZmVyIChhcmcpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIEJ1ZmZlcikpIHtcbiAgICAvLyBBdm9pZCBnb2luZyB0aHJvdWdoIGFuIEFyZ3VtZW50c0FkYXB0b3JUcmFtcG9saW5lIGluIHRoZSBjb21tb24gY2FzZS5cbiAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDEpIHJldHVybiBuZXcgQnVmZmVyKGFyZywgYXJndW1lbnRzWzFdKVxuICAgIHJldHVybiBuZXcgQnVmZmVyKGFyZylcbiAgfVxuXG4gIHRoaXMubGVuZ3RoID0gMFxuICB0aGlzLnBhcmVudCA9IHVuZGVmaW5lZFxuXG4gIC8vIENvbW1vbiBjYXNlLlxuICBpZiAodHlwZW9mIGFyZyA9PT0gJ251bWJlcicpIHtcbiAgICByZXR1cm4gZnJvbU51bWJlcih0aGlzLCBhcmcpXG4gIH1cblxuICAvLyBTbGlnaHRseSBsZXNzIGNvbW1vbiBjYXNlLlxuICBpZiAodHlwZW9mIGFyZyA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gZnJvbVN0cmluZyh0aGlzLCBhcmcsIGFyZ3VtZW50cy5sZW5ndGggPiAxID8gYXJndW1lbnRzWzFdIDogJ3V0ZjgnKVxuICB9XG5cbiAgLy8gVW51c3VhbC5cbiAgcmV0dXJuIGZyb21PYmplY3QodGhpcywgYXJnKVxufVxuXG5mdW5jdGlvbiBmcm9tTnVtYmVyICh0aGF0LCBsZW5ndGgpIHtcbiAgdGhhdCA9IGFsbG9jYXRlKHRoYXQsIGxlbmd0aCA8IDAgPyAwIDogY2hlY2tlZChsZW5ndGgpIHwgMClcbiAgaWYgKCFCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIHRoYXRbaV0gPSAwXG4gICAgfVxuICB9XG4gIHJldHVybiB0aGF0XG59XG5cbmZ1bmN0aW9uIGZyb21TdHJpbmcgKHRoYXQsIHN0cmluZywgZW5jb2RpbmcpIHtcbiAgaWYgKHR5cGVvZiBlbmNvZGluZyAhPT0gJ3N0cmluZycgfHwgZW5jb2RpbmcgPT09ICcnKSBlbmNvZGluZyA9ICd1dGY4J1xuXG4gIC8vIEFzc3VtcHRpb246IGJ5dGVMZW5ndGgoKSByZXR1cm4gdmFsdWUgaXMgYWx3YXlzIDwga01heExlbmd0aC5cbiAgdmFyIGxlbmd0aCA9IGJ5dGVMZW5ndGgoc3RyaW5nLCBlbmNvZGluZykgfCAwXG4gIHRoYXQgPSBhbGxvY2F0ZSh0aGF0LCBsZW5ndGgpXG5cbiAgdGhhdC53cml0ZShzdHJpbmcsIGVuY29kaW5nKVxuICByZXR1cm4gdGhhdFxufVxuXG5mdW5jdGlvbiBmcm9tT2JqZWN0ICh0aGF0LCBvYmplY3QpIHtcbiAgaWYgKEJ1ZmZlci5pc0J1ZmZlcihvYmplY3QpKSByZXR1cm4gZnJvbUJ1ZmZlcih0aGF0LCBvYmplY3QpXG5cbiAgaWYgKGlzQXJyYXkob2JqZWN0KSkgcmV0dXJuIGZyb21BcnJheSh0aGF0LCBvYmplY3QpXG5cbiAgaWYgKG9iamVjdCA9PSBudWxsKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignbXVzdCBzdGFydCB3aXRoIG51bWJlciwgYnVmZmVyLCBhcnJheSBvciBzdHJpbmcnKVxuICB9XG5cbiAgaWYgKHR5cGVvZiBBcnJheUJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBpZiAob2JqZWN0LmJ1ZmZlciBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSB7XG4gICAgICByZXR1cm4gZnJvbVR5cGVkQXJyYXkodGhhdCwgb2JqZWN0KVxuICAgIH1cbiAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHtcbiAgICAgIHJldHVybiBmcm9tQXJyYXlCdWZmZXIodGhhdCwgb2JqZWN0KVxuICAgIH1cbiAgfVxuXG4gIGlmIChvYmplY3QubGVuZ3RoKSByZXR1cm4gZnJvbUFycmF5TGlrZSh0aGF0LCBvYmplY3QpXG5cbiAgcmV0dXJuIGZyb21Kc29uT2JqZWN0KHRoYXQsIG9iamVjdClcbn1cblxuZnVuY3Rpb24gZnJvbUJ1ZmZlciAodGhhdCwgYnVmZmVyKSB7XG4gIHZhciBsZW5ndGggPSBjaGVja2VkKGJ1ZmZlci5sZW5ndGgpIHwgMFxuICB0aGF0ID0gYWxsb2NhdGUodGhhdCwgbGVuZ3RoKVxuICBidWZmZXIuY29weSh0aGF0LCAwLCAwLCBsZW5ndGgpXG4gIHJldHVybiB0aGF0XG59XG5cbmZ1bmN0aW9uIGZyb21BcnJheSAodGhhdCwgYXJyYXkpIHtcbiAgdmFyIGxlbmd0aCA9IGNoZWNrZWQoYXJyYXkubGVuZ3RoKSB8IDBcbiAgdGhhdCA9IGFsbG9jYXRlKHRoYXQsIGxlbmd0aClcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkgKz0gMSkge1xuICAgIHRoYXRbaV0gPSBhcnJheVtpXSAmIDI1NVxuICB9XG4gIHJldHVybiB0aGF0XG59XG5cbi8vIER1cGxpY2F0ZSBvZiBmcm9tQXJyYXkoKSB0byBrZWVwIGZyb21BcnJheSgpIG1vbm9tb3JwaGljLlxuZnVuY3Rpb24gZnJvbVR5cGVkQXJyYXkgKHRoYXQsIGFycmF5KSB7XG4gIHZhciBsZW5ndGggPSBjaGVja2VkKGFycmF5Lmxlbmd0aCkgfCAwXG4gIHRoYXQgPSBhbGxvY2F0ZSh0aGF0LCBsZW5ndGgpXG4gIC8vIFRydW5jYXRpbmcgdGhlIGVsZW1lbnRzIGlzIHByb2JhYmx5IG5vdCB3aGF0IHBlb3BsZSBleHBlY3QgZnJvbSB0eXBlZFxuICAvLyBhcnJheXMgd2l0aCBCWVRFU19QRVJfRUxFTUVOVCA+IDEgYnV0IGl0J3MgY29tcGF0aWJsZSB3aXRoIHRoZSBiZWhhdmlvclxuICAvLyBvZiB0aGUgb2xkIEJ1ZmZlciBjb25zdHJ1Y3Rvci5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkgKz0gMSkge1xuICAgIHRoYXRbaV0gPSBhcnJheVtpXSAmIDI1NVxuICB9XG4gIHJldHVybiB0aGF0XG59XG5cbmZ1bmN0aW9uIGZyb21BcnJheUJ1ZmZlciAodGhhdCwgYXJyYXkpIHtcbiAgaWYgKEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gICAgLy8gUmV0dXJuIGFuIGF1Z21lbnRlZCBgVWludDhBcnJheWAgaW5zdGFuY2UsIGZvciBiZXN0IHBlcmZvcm1hbmNlXG4gICAgYXJyYXkuYnl0ZUxlbmd0aFxuICAgIHRoYXQgPSBCdWZmZXIuX2F1Z21lbnQobmV3IFVpbnQ4QXJyYXkoYXJyYXkpKVxuICB9IGVsc2Uge1xuICAgIC8vIEZhbGxiYWNrOiBSZXR1cm4gYW4gb2JqZWN0IGluc3RhbmNlIG9mIHRoZSBCdWZmZXIgY2xhc3NcbiAgICB0aGF0ID0gZnJvbVR5cGVkQXJyYXkodGhhdCwgbmV3IFVpbnQ4QXJyYXkoYXJyYXkpKVxuICB9XG4gIHJldHVybiB0aGF0XG59XG5cbmZ1bmN0aW9uIGZyb21BcnJheUxpa2UgKHRoYXQsIGFycmF5KSB7XG4gIHZhciBsZW5ndGggPSBjaGVja2VkKGFycmF5Lmxlbmd0aCkgfCAwXG4gIHRoYXQgPSBhbGxvY2F0ZSh0aGF0LCBsZW5ndGgpXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpICs9IDEpIHtcbiAgICB0aGF0W2ldID0gYXJyYXlbaV0gJiAyNTVcbiAgfVxuICByZXR1cm4gdGhhdFxufVxuXG4vLyBEZXNlcmlhbGl6ZSB7IHR5cGU6ICdCdWZmZXInLCBkYXRhOiBbMSwyLDMsLi4uXSB9IGludG8gYSBCdWZmZXIgb2JqZWN0LlxuLy8gUmV0dXJucyBhIHplcm8tbGVuZ3RoIGJ1ZmZlciBmb3IgaW5wdXRzIHRoYXQgZG9uJ3QgY29uZm9ybSB0byB0aGUgc3BlYy5cbmZ1bmN0aW9uIGZyb21Kc29uT2JqZWN0ICh0aGF0LCBvYmplY3QpIHtcbiAgdmFyIGFycmF5XG4gIHZhciBsZW5ndGggPSAwXG5cbiAgaWYgKG9iamVjdC50eXBlID09PSAnQnVmZmVyJyAmJiBpc0FycmF5KG9iamVjdC5kYXRhKSkge1xuICAgIGFycmF5ID0gb2JqZWN0LmRhdGFcbiAgICBsZW5ndGggPSBjaGVja2VkKGFycmF5Lmxlbmd0aCkgfCAwXG4gIH1cbiAgdGhhdCA9IGFsbG9jYXRlKHRoYXQsIGxlbmd0aClcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSArPSAxKSB7XG4gICAgdGhhdFtpXSA9IGFycmF5W2ldICYgMjU1XG4gIH1cbiAgcmV0dXJuIHRoYXRcbn1cblxuaWYgKEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gIEJ1ZmZlci5wcm90b3R5cGUuX19wcm90b19fID0gVWludDhBcnJheS5wcm90b3R5cGVcbiAgQnVmZmVyLl9fcHJvdG9fXyA9IFVpbnQ4QXJyYXlcbn1cblxuZnVuY3Rpb24gYWxsb2NhdGUgKHRoYXQsIGxlbmd0aCkge1xuICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICAvLyBSZXR1cm4gYW4gYXVnbWVudGVkIGBVaW50OEFycmF5YCBpbnN0YW5jZSwgZm9yIGJlc3QgcGVyZm9ybWFuY2VcbiAgICB0aGF0ID0gQnVmZmVyLl9hdWdtZW50KG5ldyBVaW50OEFycmF5KGxlbmd0aCkpXG4gICAgdGhhdC5fX3Byb3RvX18gPSBCdWZmZXIucHJvdG90eXBlXG4gIH0gZWxzZSB7XG4gICAgLy8gRmFsbGJhY2s6IFJldHVybiBhbiBvYmplY3QgaW5zdGFuY2Ugb2YgdGhlIEJ1ZmZlciBjbGFzc1xuICAgIHRoYXQubGVuZ3RoID0gbGVuZ3RoXG4gICAgdGhhdC5faXNCdWZmZXIgPSB0cnVlXG4gIH1cblxuICB2YXIgZnJvbVBvb2wgPSBsZW5ndGggIT09IDAgJiYgbGVuZ3RoIDw9IEJ1ZmZlci5wb29sU2l6ZSA+Pj4gMVxuICBpZiAoZnJvbVBvb2wpIHRoYXQucGFyZW50ID0gcm9vdFBhcmVudFxuXG4gIHJldHVybiB0aGF0XG59XG5cbmZ1bmN0aW9uIGNoZWNrZWQgKGxlbmd0aCkge1xuICAvLyBOb3RlOiBjYW5ub3QgdXNlIGBsZW5ndGggPCBrTWF4TGVuZ3RoYCBoZXJlIGJlY2F1c2UgdGhhdCBmYWlscyB3aGVuXG4gIC8vIGxlbmd0aCBpcyBOYU4gKHdoaWNoIGlzIG90aGVyd2lzZSBjb2VyY2VkIHRvIHplcm8uKVxuICBpZiAobGVuZ3RoID49IGtNYXhMZW5ndGgoKSkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdBdHRlbXB0IHRvIGFsbG9jYXRlIEJ1ZmZlciBsYXJnZXIgdGhhbiBtYXhpbXVtICcgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICdzaXplOiAweCcgKyBrTWF4TGVuZ3RoKCkudG9TdHJpbmcoMTYpICsgJyBieXRlcycpXG4gIH1cbiAgcmV0dXJuIGxlbmd0aCB8IDBcbn1cblxuZnVuY3Rpb24gU2xvd0J1ZmZlciAoc3ViamVjdCwgZW5jb2RpbmcpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFNsb3dCdWZmZXIpKSByZXR1cm4gbmV3IFNsb3dCdWZmZXIoc3ViamVjdCwgZW5jb2RpbmcpXG5cbiAgdmFyIGJ1ZiA9IG5ldyBCdWZmZXIoc3ViamVjdCwgZW5jb2RpbmcpXG4gIGRlbGV0ZSBidWYucGFyZW50XG4gIHJldHVybiBidWZcbn1cblxuQnVmZmVyLmlzQnVmZmVyID0gZnVuY3Rpb24gaXNCdWZmZXIgKGIpIHtcbiAgcmV0dXJuICEhKGIgIT0gbnVsbCAmJiBiLl9pc0J1ZmZlcilcbn1cblxuQnVmZmVyLmNvbXBhcmUgPSBmdW5jdGlvbiBjb21wYXJlIChhLCBiKSB7XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGEpIHx8ICFCdWZmZXIuaXNCdWZmZXIoYikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudHMgbXVzdCBiZSBCdWZmZXJzJylcbiAgfVxuXG4gIGlmIChhID09PSBiKSByZXR1cm4gMFxuXG4gIHZhciB4ID0gYS5sZW5ndGhcbiAgdmFyIHkgPSBiLmxlbmd0aFxuXG4gIHZhciBpID0gMFxuICB2YXIgbGVuID0gTWF0aC5taW4oeCwgeSlcbiAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICBpZiAoYVtpXSAhPT0gYltpXSkgYnJlYWtcblxuICAgICsraVxuICB9XG5cbiAgaWYgKGkgIT09IGxlbikge1xuICAgIHggPSBhW2ldXG4gICAgeSA9IGJbaV1cbiAgfVxuXG4gIGlmICh4IDwgeSkgcmV0dXJuIC0xXG4gIGlmICh5IDwgeCkgcmV0dXJuIDFcbiAgcmV0dXJuIDBcbn1cblxuQnVmZmVyLmlzRW5jb2RpbmcgPSBmdW5jdGlvbiBpc0VuY29kaW5nIChlbmNvZGluZykge1xuICBzd2l0Y2ggKFN0cmluZyhlbmNvZGluZykudG9Mb3dlckNhc2UoKSkge1xuICAgIGNhc2UgJ2hleCc6XG4gICAgY2FzZSAndXRmOCc6XG4gICAgY2FzZSAndXRmLTgnOlxuICAgIGNhc2UgJ2FzY2lpJzpcbiAgICBjYXNlICdiaW5hcnknOlxuICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgY2FzZSAncmF3JzpcbiAgICBjYXNlICd1Y3MyJzpcbiAgICBjYXNlICd1Y3MtMic6XG4gICAgY2FzZSAndXRmMTZsZSc6XG4gICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgcmV0dXJuIHRydWVcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIGZhbHNlXG4gIH1cbn1cblxuQnVmZmVyLmNvbmNhdCA9IGZ1bmN0aW9uIGNvbmNhdCAobGlzdCwgbGVuZ3RoKSB7XG4gIGlmICghaXNBcnJheShsaXN0KSkgdGhyb3cgbmV3IFR5cGVFcnJvcignbGlzdCBhcmd1bWVudCBtdXN0IGJlIGFuIEFycmF5IG9mIEJ1ZmZlcnMuJylcblxuICBpZiAobGlzdC5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gbmV3IEJ1ZmZlcigwKVxuICB9XG5cbiAgdmFyIGlcbiAgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgbGVuZ3RoID0gMFxuICAgIGZvciAoaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICBsZW5ndGggKz0gbGlzdFtpXS5sZW5ndGhcbiAgICB9XG4gIH1cblxuICB2YXIgYnVmID0gbmV3IEJ1ZmZlcihsZW5ndGgpXG4gIHZhciBwb3MgPSAwXG4gIGZvciAoaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIGl0ZW0gPSBsaXN0W2ldXG4gICAgaXRlbS5jb3B5KGJ1ZiwgcG9zKVxuICAgIHBvcyArPSBpdGVtLmxlbmd0aFxuICB9XG4gIHJldHVybiBidWZcbn1cblxuZnVuY3Rpb24gYnl0ZUxlbmd0aCAoc3RyaW5nLCBlbmNvZGluZykge1xuICBpZiAodHlwZW9mIHN0cmluZyAhPT0gJ3N0cmluZycpIHN0cmluZyA9ICcnICsgc3RyaW5nXG5cbiAgdmFyIGxlbiA9IHN0cmluZy5sZW5ndGhcbiAgaWYgKGxlbiA9PT0gMCkgcmV0dXJuIDBcblxuICAvLyBVc2UgYSBmb3IgbG9vcCB0byBhdm9pZCByZWN1cnNpb25cbiAgdmFyIGxvd2VyZWRDYXNlID0gZmFsc2VcbiAgZm9yICg7Oykge1xuICAgIHN3aXRjaCAoZW5jb2RpbmcpIHtcbiAgICAgIGNhc2UgJ2FzY2lpJzpcbiAgICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICAvLyBEZXByZWNhdGVkXG4gICAgICBjYXNlICdyYXcnOlxuICAgICAgY2FzZSAncmF3cyc6XG4gICAgICAgIHJldHVybiBsZW5cbiAgICAgIGNhc2UgJ3V0ZjgnOlxuICAgICAgY2FzZSAndXRmLTgnOlxuICAgICAgICByZXR1cm4gdXRmOFRvQnl0ZXMoc3RyaW5nKS5sZW5ndGhcbiAgICAgIGNhc2UgJ3VjczInOlxuICAgICAgY2FzZSAndWNzLTInOlxuICAgICAgY2FzZSAndXRmMTZsZSc6XG4gICAgICBjYXNlICd1dGYtMTZsZSc6XG4gICAgICAgIHJldHVybiBsZW4gKiAyXG4gICAgICBjYXNlICdoZXgnOlxuICAgICAgICByZXR1cm4gbGVuID4+PiAxXG4gICAgICBjYXNlICdiYXNlNjQnOlxuICAgICAgICByZXR1cm4gYmFzZTY0VG9CeXRlcyhzdHJpbmcpLmxlbmd0aFxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaWYgKGxvd2VyZWRDYXNlKSByZXR1cm4gdXRmOFRvQnl0ZXMoc3RyaW5nKS5sZW5ndGggLy8gYXNzdW1lIHV0ZjhcbiAgICAgICAgZW5jb2RpbmcgPSAoJycgKyBlbmNvZGluZykudG9Mb3dlckNhc2UoKVxuICAgICAgICBsb3dlcmVkQ2FzZSA9IHRydWVcbiAgICB9XG4gIH1cbn1cbkJ1ZmZlci5ieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aFxuXG4vLyBwcmUtc2V0IGZvciB2YWx1ZXMgdGhhdCBtYXkgZXhpc3QgaW4gdGhlIGZ1dHVyZVxuQnVmZmVyLnByb3RvdHlwZS5sZW5ndGggPSB1bmRlZmluZWRcbkJ1ZmZlci5wcm90b3R5cGUucGFyZW50ID0gdW5kZWZpbmVkXG5cbmZ1bmN0aW9uIHNsb3dUb1N0cmluZyAoZW5jb2RpbmcsIHN0YXJ0LCBlbmQpIHtcbiAgdmFyIGxvd2VyZWRDYXNlID0gZmFsc2VcblxuICBzdGFydCA9IHN0YXJ0IHwgMFxuICBlbmQgPSBlbmQgPT09IHVuZGVmaW5lZCB8fCBlbmQgPT09IEluZmluaXR5ID8gdGhpcy5sZW5ndGggOiBlbmQgfCAwXG5cbiAgaWYgKCFlbmNvZGluZykgZW5jb2RpbmcgPSAndXRmOCdcbiAgaWYgKHN0YXJ0IDwgMCkgc3RhcnQgPSAwXG4gIGlmIChlbmQgPiB0aGlzLmxlbmd0aCkgZW5kID0gdGhpcy5sZW5ndGhcbiAgaWYgKGVuZCA8PSBzdGFydCkgcmV0dXJuICcnXG5cbiAgd2hpbGUgKHRydWUpIHtcbiAgICBzd2l0Y2ggKGVuY29kaW5nKSB7XG4gICAgICBjYXNlICdoZXgnOlxuICAgICAgICByZXR1cm4gaGV4U2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgY2FzZSAndXRmOCc6XG4gICAgICBjYXNlICd1dGYtOCc6XG4gICAgICAgIHJldHVybiB1dGY4U2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgY2FzZSAnYXNjaWknOlxuICAgICAgICByZXR1cm4gYXNjaWlTbGljZSh0aGlzLCBzdGFydCwgZW5kKVxuXG4gICAgICBjYXNlICdiaW5hcnknOlxuICAgICAgICByZXR1cm4gYmluYXJ5U2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgY2FzZSAnYmFzZTY0JzpcbiAgICAgICAgcmV0dXJuIGJhc2U2NFNsaWNlKHRoaXMsIHN0YXJ0LCBlbmQpXG5cbiAgICAgIGNhc2UgJ3VjczInOlxuICAgICAgY2FzZSAndWNzLTInOlxuICAgICAgY2FzZSAndXRmMTZsZSc6XG4gICAgICBjYXNlICd1dGYtMTZsZSc6XG4gICAgICAgIHJldHVybiB1dGYxNmxlU2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaWYgKGxvd2VyZWRDYXNlKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jb2RpbmcpXG4gICAgICAgIGVuY29kaW5nID0gKGVuY29kaW5nICsgJycpLnRvTG93ZXJDYXNlKClcbiAgICAgICAgbG93ZXJlZENhc2UgPSB0cnVlXG4gICAgfVxuICB9XG59XG5cbkJ1ZmZlci5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbiB0b1N0cmluZyAoKSB7XG4gIHZhciBsZW5ndGggPSB0aGlzLmxlbmd0aCB8IDBcbiAgaWYgKGxlbmd0aCA9PT0gMCkgcmV0dXJuICcnXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAwKSByZXR1cm4gdXRmOFNsaWNlKHRoaXMsIDAsIGxlbmd0aClcbiAgcmV0dXJuIHNsb3dUb1N0cmluZy5hcHBseSh0aGlzLCBhcmd1bWVudHMpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuZXF1YWxzID0gZnVuY3Rpb24gZXF1YWxzIChiKSB7XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IGJlIGEgQnVmZmVyJylcbiAgaWYgKHRoaXMgPT09IGIpIHJldHVybiB0cnVlXG4gIHJldHVybiBCdWZmZXIuY29tcGFyZSh0aGlzLCBiKSA9PT0gMFxufVxuXG5CdWZmZXIucHJvdG90eXBlLmluc3BlY3QgPSBmdW5jdGlvbiBpbnNwZWN0ICgpIHtcbiAgdmFyIHN0ciA9ICcnXG4gIHZhciBtYXggPSBleHBvcnRzLklOU1BFQ1RfTUFYX0JZVEVTXG4gIGlmICh0aGlzLmxlbmd0aCA+IDApIHtcbiAgICBzdHIgPSB0aGlzLnRvU3RyaW5nKCdoZXgnLCAwLCBtYXgpLm1hdGNoKC8uezJ9L2cpLmpvaW4oJyAnKVxuICAgIGlmICh0aGlzLmxlbmd0aCA+IG1heCkgc3RyICs9ICcgLi4uICdcbiAgfVxuICByZXR1cm4gJzxCdWZmZXIgJyArIHN0ciArICc+J1xufVxuXG5CdWZmZXIucHJvdG90eXBlLmNvbXBhcmUgPSBmdW5jdGlvbiBjb21wYXJlIChiKSB7XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcmd1bWVudCBtdXN0IGJlIGEgQnVmZmVyJylcbiAgaWYgKHRoaXMgPT09IGIpIHJldHVybiAwXG4gIHJldHVybiBCdWZmZXIuY29tcGFyZSh0aGlzLCBiKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLmluZGV4T2YgPSBmdW5jdGlvbiBpbmRleE9mICh2YWwsIGJ5dGVPZmZzZXQpIHtcbiAgaWYgKGJ5dGVPZmZzZXQgPiAweDdmZmZmZmZmKSBieXRlT2Zmc2V0ID0gMHg3ZmZmZmZmZlxuICBlbHNlIGlmIChieXRlT2Zmc2V0IDwgLTB4ODAwMDAwMDApIGJ5dGVPZmZzZXQgPSAtMHg4MDAwMDAwMFxuICBieXRlT2Zmc2V0ID4+PSAwXG5cbiAgaWYgKHRoaXMubGVuZ3RoID09PSAwKSByZXR1cm4gLTFcbiAgaWYgKGJ5dGVPZmZzZXQgPj0gdGhpcy5sZW5ndGgpIHJldHVybiAtMVxuXG4gIC8vIE5lZ2F0aXZlIG9mZnNldHMgc3RhcnQgZnJvbSB0aGUgZW5kIG9mIHRoZSBidWZmZXJcbiAgaWYgKGJ5dGVPZmZzZXQgPCAwKSBieXRlT2Zmc2V0ID0gTWF0aC5tYXgodGhpcy5sZW5ndGggKyBieXRlT2Zmc2V0LCAwKVxuXG4gIGlmICh0eXBlb2YgdmFsID09PSAnc3RyaW5nJykge1xuICAgIGlmICh2YWwubGVuZ3RoID09PSAwKSByZXR1cm4gLTEgLy8gc3BlY2lhbCBjYXNlOiBsb29raW5nIGZvciBlbXB0eSBzdHJpbmcgYWx3YXlzIGZhaWxzXG4gICAgcmV0dXJuIFN0cmluZy5wcm90b3R5cGUuaW5kZXhPZi5jYWxsKHRoaXMsIHZhbCwgYnl0ZU9mZnNldClcbiAgfVxuICBpZiAoQnVmZmVyLmlzQnVmZmVyKHZhbCkpIHtcbiAgICByZXR1cm4gYXJyYXlJbmRleE9mKHRoaXMsIHZhbCwgYnl0ZU9mZnNldClcbiAgfVxuICBpZiAodHlwZW9mIHZhbCA9PT0gJ251bWJlcicpIHtcbiAgICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQgJiYgVWludDhBcnJheS5wcm90b3R5cGUuaW5kZXhPZiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgcmV0dXJuIFVpbnQ4QXJyYXkucHJvdG90eXBlLmluZGV4T2YuY2FsbCh0aGlzLCB2YWwsIGJ5dGVPZmZzZXQpXG4gICAgfVxuICAgIHJldHVybiBhcnJheUluZGV4T2YodGhpcywgWyB2YWwgXSwgYnl0ZU9mZnNldClcbiAgfVxuXG4gIGZ1bmN0aW9uIGFycmF5SW5kZXhPZiAoYXJyLCB2YWwsIGJ5dGVPZmZzZXQpIHtcbiAgICB2YXIgZm91bmRJbmRleCA9IC0xXG4gICAgZm9yICh2YXIgaSA9IDA7IGJ5dGVPZmZzZXQgKyBpIDwgYXJyLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoYXJyW2J5dGVPZmZzZXQgKyBpXSA9PT0gdmFsW2ZvdW5kSW5kZXggPT09IC0xID8gMCA6IGkgLSBmb3VuZEluZGV4XSkge1xuICAgICAgICBpZiAoZm91bmRJbmRleCA9PT0gLTEpIGZvdW5kSW5kZXggPSBpXG4gICAgICAgIGlmIChpIC0gZm91bmRJbmRleCArIDEgPT09IHZhbC5sZW5ndGgpIHJldHVybiBieXRlT2Zmc2V0ICsgZm91bmRJbmRleFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZm91bmRJbmRleCA9IC0xXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiAtMVxuICB9XG5cbiAgdGhyb3cgbmV3IFR5cGVFcnJvcigndmFsIG11c3QgYmUgc3RyaW5nLCBudW1iZXIgb3IgQnVmZmVyJylcbn1cblxuLy8gYGdldGAgaXMgZGVwcmVjYXRlZFxuQnVmZmVyLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiBnZXQgKG9mZnNldCkge1xuICBjb25zb2xlLmxvZygnLmdldCgpIGlzIGRlcHJlY2F0ZWQuIEFjY2VzcyB1c2luZyBhcnJheSBpbmRleGVzIGluc3RlYWQuJylcbiAgcmV0dXJuIHRoaXMucmVhZFVJbnQ4KG9mZnNldClcbn1cblxuLy8gYHNldGAgaXMgZGVwcmVjYXRlZFxuQnVmZmVyLnByb3RvdHlwZS5zZXQgPSBmdW5jdGlvbiBzZXQgKHYsIG9mZnNldCkge1xuICBjb25zb2xlLmxvZygnLnNldCgpIGlzIGRlcHJlY2F0ZWQuIEFjY2VzcyB1c2luZyBhcnJheSBpbmRleGVzIGluc3RlYWQuJylcbiAgcmV0dXJuIHRoaXMud3JpdGVVSW50OCh2LCBvZmZzZXQpXG59XG5cbmZ1bmN0aW9uIGhleFdyaXRlIChidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgb2Zmc2V0ID0gTnVtYmVyKG9mZnNldCkgfHwgMFxuICB2YXIgcmVtYWluaW5nID0gYnVmLmxlbmd0aCAtIG9mZnNldFxuICBpZiAoIWxlbmd0aCkge1xuICAgIGxlbmd0aCA9IHJlbWFpbmluZ1xuICB9IGVsc2Uge1xuICAgIGxlbmd0aCA9IE51bWJlcihsZW5ndGgpXG4gICAgaWYgKGxlbmd0aCA+IHJlbWFpbmluZykge1xuICAgICAgbGVuZ3RoID0gcmVtYWluaW5nXG4gICAgfVxuICB9XG5cbiAgLy8gbXVzdCBiZSBhbiBldmVuIG51bWJlciBvZiBkaWdpdHNcbiAgdmFyIHN0ckxlbiA9IHN0cmluZy5sZW5ndGhcbiAgaWYgKHN0ckxlbiAlIDIgIT09IDApIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBoZXggc3RyaW5nJylcblxuICBpZiAobGVuZ3RoID4gc3RyTGVuIC8gMikge1xuICAgIGxlbmd0aCA9IHN0ckxlbiAvIDJcbiAgfVxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIHBhcnNlZCA9IHBhcnNlSW50KHN0cmluZy5zdWJzdHIoaSAqIDIsIDIpLCAxNilcbiAgICBpZiAoaXNOYU4ocGFyc2VkKSkgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGhleCBzdHJpbmcnKVxuICAgIGJ1ZltvZmZzZXQgKyBpXSA9IHBhcnNlZFxuICB9XG4gIHJldHVybiBpXG59XG5cbmZ1bmN0aW9uIHV0ZjhXcml0ZSAoYnVmLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKSB7XG4gIHJldHVybiBibGl0QnVmZmVyKHV0ZjhUb0J5dGVzKHN0cmluZywgYnVmLmxlbmd0aCAtIG9mZnNldCksIGJ1Ziwgb2Zmc2V0LCBsZW5ndGgpXG59XG5cbmZ1bmN0aW9uIGFzY2lpV3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkge1xuICByZXR1cm4gYmxpdEJ1ZmZlcihhc2NpaVRvQnl0ZXMoc3RyaW5nKSwgYnVmLCBvZmZzZXQsIGxlbmd0aClcbn1cblxuZnVuY3Rpb24gYmluYXJ5V3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkge1xuICByZXR1cm4gYXNjaWlXcml0ZShidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG59XG5cbmZ1bmN0aW9uIGJhc2U2NFdyaXRlIChidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgcmV0dXJuIGJsaXRCdWZmZXIoYmFzZTY0VG9CeXRlcyhzdHJpbmcpLCBidWYsIG9mZnNldCwgbGVuZ3RoKVxufVxuXG5mdW5jdGlvbiB1Y3MyV3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkge1xuICByZXR1cm4gYmxpdEJ1ZmZlcih1dGYxNmxlVG9CeXRlcyhzdHJpbmcsIGJ1Zi5sZW5ndGggLSBvZmZzZXQpLCBidWYsIG9mZnNldCwgbGVuZ3RoKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlID0gZnVuY3Rpb24gd3JpdGUgKHN0cmluZywgb2Zmc2V0LCBsZW5ndGgsIGVuY29kaW5nKSB7XG4gIC8vIEJ1ZmZlciN3cml0ZShzdHJpbmcpXG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkge1xuICAgIGVuY29kaW5nID0gJ3V0ZjgnXG4gICAgbGVuZ3RoID0gdGhpcy5sZW5ndGhcbiAgICBvZmZzZXQgPSAwXG4gIC8vIEJ1ZmZlciN3cml0ZShzdHJpbmcsIGVuY29kaW5nKVxuICB9IGVsc2UgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvZmZzZXQgPT09ICdzdHJpbmcnKSB7XG4gICAgZW5jb2RpbmcgPSBvZmZzZXRcbiAgICBsZW5ndGggPSB0aGlzLmxlbmd0aFxuICAgIG9mZnNldCA9IDBcbiAgLy8gQnVmZmVyI3dyaXRlKHN0cmluZywgb2Zmc2V0WywgbGVuZ3RoXVssIGVuY29kaW5nXSlcbiAgfSBlbHNlIGlmIChpc0Zpbml0ZShvZmZzZXQpKSB7XG4gICAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICAgIGlmIChpc0Zpbml0ZShsZW5ndGgpKSB7XG4gICAgICBsZW5ndGggPSBsZW5ndGggfCAwXG4gICAgICBpZiAoZW5jb2RpbmcgPT09IHVuZGVmaW5lZCkgZW5jb2RpbmcgPSAndXRmOCdcbiAgICB9IGVsc2Uge1xuICAgICAgZW5jb2RpbmcgPSBsZW5ndGhcbiAgICAgIGxlbmd0aCA9IHVuZGVmaW5lZFxuICAgIH1cbiAgLy8gbGVnYWN5IHdyaXRlKHN0cmluZywgZW5jb2RpbmcsIG9mZnNldCwgbGVuZ3RoKSAtIHJlbW92ZSBpbiB2MC4xM1xuICB9IGVsc2Uge1xuICAgIHZhciBzd2FwID0gZW5jb2RpbmdcbiAgICBlbmNvZGluZyA9IG9mZnNldFxuICAgIG9mZnNldCA9IGxlbmd0aCB8IDBcbiAgICBsZW5ndGggPSBzd2FwXG4gIH1cblxuICB2YXIgcmVtYWluaW5nID0gdGhpcy5sZW5ndGggLSBvZmZzZXRcbiAgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkIHx8IGxlbmd0aCA+IHJlbWFpbmluZykgbGVuZ3RoID0gcmVtYWluaW5nXG5cbiAgaWYgKChzdHJpbmcubGVuZ3RoID4gMCAmJiAobGVuZ3RoIDwgMCB8fCBvZmZzZXQgPCAwKSkgfHwgb2Zmc2V0ID4gdGhpcy5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignYXR0ZW1wdCB0byB3cml0ZSBvdXRzaWRlIGJ1ZmZlciBib3VuZHMnKVxuICB9XG5cbiAgaWYgKCFlbmNvZGluZykgZW5jb2RpbmcgPSAndXRmOCdcblxuICB2YXIgbG93ZXJlZENhc2UgPSBmYWxzZVxuICBmb3IgKDs7KSB7XG4gICAgc3dpdGNoIChlbmNvZGluZykge1xuICAgICAgY2FzZSAnaGV4JzpcbiAgICAgICAgcmV0dXJuIGhleFdyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG5cbiAgICAgIGNhc2UgJ3V0ZjgnOlxuICAgICAgY2FzZSAndXRmLTgnOlxuICAgICAgICByZXR1cm4gdXRmOFdyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG5cbiAgICAgIGNhc2UgJ2FzY2lpJzpcbiAgICAgICAgcmV0dXJuIGFzY2lpV3JpdGUodGhpcywgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aClcblxuICAgICAgY2FzZSAnYmluYXJ5JzpcbiAgICAgICAgcmV0dXJuIGJpbmFyeVdyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG5cbiAgICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgICAgIC8vIFdhcm5pbmc6IG1heExlbmd0aCBub3QgdGFrZW4gaW50byBhY2NvdW50IGluIGJhc2U2NFdyaXRlXG4gICAgICAgIHJldHVybiBiYXNlNjRXcml0ZSh0aGlzLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKVxuXG4gICAgICBjYXNlICd1Y3MyJzpcbiAgICAgIGNhc2UgJ3Vjcy0yJzpcbiAgICAgIGNhc2UgJ3V0ZjE2bGUnOlxuICAgICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgICByZXR1cm4gdWNzMldyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG5cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGlmIChsb3dlcmVkQ2FzZSkgdGhyb3cgbmV3IFR5cGVFcnJvcignVW5rbm93biBlbmNvZGluZzogJyArIGVuY29kaW5nKVxuICAgICAgICBlbmNvZGluZyA9ICgnJyArIGVuY29kaW5nKS50b0xvd2VyQ2FzZSgpXG4gICAgICAgIGxvd2VyZWRDYXNlID0gdHJ1ZVxuICAgIH1cbiAgfVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTiAoKSB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogJ0J1ZmZlcicsXG4gICAgZGF0YTogQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodGhpcy5fYXJyIHx8IHRoaXMsIDApXG4gIH1cbn1cblxuZnVuY3Rpb24gYmFzZTY0U2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICBpZiAoc3RhcnQgPT09IDAgJiYgZW5kID09PSBidWYubGVuZ3RoKSB7XG4gICAgcmV0dXJuIGJhc2U2NC5mcm9tQnl0ZUFycmF5KGJ1ZilcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gYmFzZTY0LmZyb21CeXRlQXJyYXkoYnVmLnNsaWNlKHN0YXJ0LCBlbmQpKVxuICB9XG59XG5cbmZ1bmN0aW9uIHV0ZjhTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7XG4gIGVuZCA9IE1hdGgubWluKGJ1Zi5sZW5ndGgsIGVuZClcbiAgdmFyIHJlcyA9IFtdXG5cbiAgdmFyIGkgPSBzdGFydFxuICB3aGlsZSAoaSA8IGVuZCkge1xuICAgIHZhciBmaXJzdEJ5dGUgPSBidWZbaV1cbiAgICB2YXIgY29kZVBvaW50ID0gbnVsbFxuICAgIHZhciBieXRlc1BlclNlcXVlbmNlID0gKGZpcnN0Qnl0ZSA+IDB4RUYpID8gNFxuICAgICAgOiAoZmlyc3RCeXRlID4gMHhERikgPyAzXG4gICAgICA6IChmaXJzdEJ5dGUgPiAweEJGKSA/IDJcbiAgICAgIDogMVxuXG4gICAgaWYgKGkgKyBieXRlc1BlclNlcXVlbmNlIDw9IGVuZCkge1xuICAgICAgdmFyIHNlY29uZEJ5dGUsIHRoaXJkQnl0ZSwgZm91cnRoQnl0ZSwgdGVtcENvZGVQb2ludFxuXG4gICAgICBzd2l0Y2ggKGJ5dGVzUGVyU2VxdWVuY2UpIHtcbiAgICAgICAgY2FzZSAxOlxuICAgICAgICAgIGlmIChmaXJzdEJ5dGUgPCAweDgwKSB7XG4gICAgICAgICAgICBjb2RlUG9pbnQgPSBmaXJzdEJ5dGVcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAyOlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgaWYgKChzZWNvbmRCeXRlICYgMHhDMCkgPT09IDB4ODApIHtcbiAgICAgICAgICAgIHRlbXBDb2RlUG9pbnQgPSAoZmlyc3RCeXRlICYgMHgxRikgPDwgMHg2IHwgKHNlY29uZEJ5dGUgJiAweDNGKVxuICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweDdGKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAzOlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgdGhpcmRCeXRlID0gYnVmW2kgKyAyXVxuICAgICAgICAgIGlmICgoc2Vjb25kQnl0ZSAmIDB4QzApID09PSAweDgwICYmICh0aGlyZEJ5dGUgJiAweEMwKSA9PT0gMHg4MCkge1xuICAgICAgICAgICAgdGVtcENvZGVQb2ludCA9IChmaXJzdEJ5dGUgJiAweEYpIDw8IDB4QyB8IChzZWNvbmRCeXRlICYgMHgzRikgPDwgMHg2IHwgKHRoaXJkQnl0ZSAmIDB4M0YpXG4gICAgICAgICAgICBpZiAodGVtcENvZGVQb2ludCA+IDB4N0ZGICYmICh0ZW1wQ29kZVBvaW50IDwgMHhEODAwIHx8IHRlbXBDb2RlUG9pbnQgPiAweERGRkYpKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSA0OlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgdGhpcmRCeXRlID0gYnVmW2kgKyAyXVxuICAgICAgICAgIGZvdXJ0aEJ5dGUgPSBidWZbaSArIDNdXG4gICAgICAgICAgaWYgKChzZWNvbmRCeXRlICYgMHhDMCkgPT09IDB4ODAgJiYgKHRoaXJkQnl0ZSAmIDB4QzApID09PSAweDgwICYmIChmb3VydGhCeXRlICYgMHhDMCkgPT09IDB4ODApIHtcbiAgICAgICAgICAgIHRlbXBDb2RlUG9pbnQgPSAoZmlyc3RCeXRlICYgMHhGKSA8PCAweDEyIHwgKHNlY29uZEJ5dGUgJiAweDNGKSA8PCAweEMgfCAodGhpcmRCeXRlICYgMHgzRikgPDwgMHg2IHwgKGZvdXJ0aEJ5dGUgJiAweDNGKVxuICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweEZGRkYgJiYgdGVtcENvZGVQb2ludCA8IDB4MTEwMDAwKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGNvZGVQb2ludCA9PT0gbnVsbCkge1xuICAgICAgLy8gd2UgZGlkIG5vdCBnZW5lcmF0ZSBhIHZhbGlkIGNvZGVQb2ludCBzbyBpbnNlcnQgYVxuICAgICAgLy8gcmVwbGFjZW1lbnQgY2hhciAoVStGRkZEKSBhbmQgYWR2YW5jZSBvbmx5IDEgYnl0ZVxuICAgICAgY29kZVBvaW50ID0gMHhGRkZEXG4gICAgICBieXRlc1BlclNlcXVlbmNlID0gMVxuICAgIH0gZWxzZSBpZiAoY29kZVBvaW50ID4gMHhGRkZGKSB7XG4gICAgICAvLyBlbmNvZGUgdG8gdXRmMTYgKHN1cnJvZ2F0ZSBwYWlyIGRhbmNlKVxuICAgICAgY29kZVBvaW50IC09IDB4MTAwMDBcbiAgICAgIHJlcy5wdXNoKGNvZGVQb2ludCA+Pj4gMTAgJiAweDNGRiB8IDB4RDgwMClcbiAgICAgIGNvZGVQb2ludCA9IDB4REMwMCB8IGNvZGVQb2ludCAmIDB4M0ZGXG4gICAgfVxuXG4gICAgcmVzLnB1c2goY29kZVBvaW50KVxuICAgIGkgKz0gYnl0ZXNQZXJTZXF1ZW5jZVxuICB9XG5cbiAgcmV0dXJuIGRlY29kZUNvZGVQb2ludHNBcnJheShyZXMpXG59XG5cbi8vIEJhc2VkIG9uIGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzIyNzQ3MjcyLzY4MDc0MiwgdGhlIGJyb3dzZXIgd2l0aFxuLy8gdGhlIGxvd2VzdCBsaW1pdCBpcyBDaHJvbWUsIHdpdGggMHgxMDAwMCBhcmdzLlxuLy8gV2UgZ28gMSBtYWduaXR1ZGUgbGVzcywgZm9yIHNhZmV0eVxudmFyIE1BWF9BUkdVTUVOVFNfTEVOR1RIID0gMHgxMDAwXG5cbmZ1bmN0aW9uIGRlY29kZUNvZGVQb2ludHNBcnJheSAoY29kZVBvaW50cykge1xuICB2YXIgbGVuID0gY29kZVBvaW50cy5sZW5ndGhcbiAgaWYgKGxlbiA8PSBNQVhfQVJHVU1FTlRTX0xFTkdUSCkge1xuICAgIHJldHVybiBTdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KFN0cmluZywgY29kZVBvaW50cykgLy8gYXZvaWQgZXh0cmEgc2xpY2UoKVxuICB9XG5cbiAgLy8gRGVjb2RlIGluIGNodW5rcyB0byBhdm9pZCBcImNhbGwgc3RhY2sgc2l6ZSBleGNlZWRlZFwiLlxuICB2YXIgcmVzID0gJydcbiAgdmFyIGkgPSAwXG4gIHdoaWxlIChpIDwgbGVuKSB7XG4gICAgcmVzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkoXG4gICAgICBTdHJpbmcsXG4gICAgICBjb2RlUG9pbnRzLnNsaWNlKGksIGkgKz0gTUFYX0FSR1VNRU5UU19MRU5HVEgpXG4gICAgKVxuICB9XG4gIHJldHVybiByZXNcbn1cblxuZnVuY3Rpb24gYXNjaWlTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7XG4gIHZhciByZXQgPSAnJ1xuICBlbmQgPSBNYXRoLm1pbihidWYubGVuZ3RoLCBlbmQpXG5cbiAgZm9yICh2YXIgaSA9IHN0YXJ0OyBpIDwgZW5kOyBpKyspIHtcbiAgICByZXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShidWZbaV0gJiAweDdGKVxuICB9XG4gIHJldHVybiByZXRcbn1cblxuZnVuY3Rpb24gYmluYXJ5U2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICB2YXIgcmV0ID0gJydcbiAgZW5kID0gTWF0aC5taW4oYnVmLmxlbmd0aCwgZW5kKVxuXG4gIGZvciAodmFyIGkgPSBzdGFydDsgaSA8IGVuZDsgaSsrKSB7XG4gICAgcmV0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYnVmW2ldKVxuICB9XG4gIHJldHVybiByZXRcbn1cblxuZnVuY3Rpb24gaGV4U2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICB2YXIgbGVuID0gYnVmLmxlbmd0aFxuXG4gIGlmICghc3RhcnQgfHwgc3RhcnQgPCAwKSBzdGFydCA9IDBcbiAgaWYgKCFlbmQgfHwgZW5kIDwgMCB8fCBlbmQgPiBsZW4pIGVuZCA9IGxlblxuXG4gIHZhciBvdXQgPSAnJ1xuICBmb3IgKHZhciBpID0gc3RhcnQ7IGkgPCBlbmQ7IGkrKykge1xuICAgIG91dCArPSB0b0hleChidWZbaV0pXG4gIH1cbiAgcmV0dXJuIG91dFxufVxuXG5mdW5jdGlvbiB1dGYxNmxlU2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICB2YXIgYnl0ZXMgPSBidWYuc2xpY2Uoc3RhcnQsIGVuZClcbiAgdmFyIHJlcyA9ICcnXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpICs9IDIpIHtcbiAgICByZXMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShieXRlc1tpXSArIGJ5dGVzW2kgKyAxXSAqIDI1NilcbiAgfVxuICByZXR1cm4gcmVzXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuc2xpY2UgPSBmdW5jdGlvbiBzbGljZSAoc3RhcnQsIGVuZCkge1xuICB2YXIgbGVuID0gdGhpcy5sZW5ndGhcbiAgc3RhcnQgPSB+fnN0YXJ0XG4gIGVuZCA9IGVuZCA9PT0gdW5kZWZpbmVkID8gbGVuIDogfn5lbmRcblxuICBpZiAoc3RhcnQgPCAwKSB7XG4gICAgc3RhcnQgKz0gbGVuXG4gICAgaWYgKHN0YXJ0IDwgMCkgc3RhcnQgPSAwXG4gIH0gZWxzZSBpZiAoc3RhcnQgPiBsZW4pIHtcbiAgICBzdGFydCA9IGxlblxuICB9XG5cbiAgaWYgKGVuZCA8IDApIHtcbiAgICBlbmQgKz0gbGVuXG4gICAgaWYgKGVuZCA8IDApIGVuZCA9IDBcbiAgfSBlbHNlIGlmIChlbmQgPiBsZW4pIHtcbiAgICBlbmQgPSBsZW5cbiAgfVxuXG4gIGlmIChlbmQgPCBzdGFydCkgZW5kID0gc3RhcnRcblxuICB2YXIgbmV3QnVmXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIG5ld0J1ZiA9IEJ1ZmZlci5fYXVnbWVudCh0aGlzLnN1YmFycmF5KHN0YXJ0LCBlbmQpKVxuICB9IGVsc2Uge1xuICAgIHZhciBzbGljZUxlbiA9IGVuZCAtIHN0YXJ0XG4gICAgbmV3QnVmID0gbmV3IEJ1ZmZlcihzbGljZUxlbiwgdW5kZWZpbmVkKVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2xpY2VMZW47IGkrKykge1xuICAgICAgbmV3QnVmW2ldID0gdGhpc1tpICsgc3RhcnRdXG4gICAgfVxuICB9XG5cbiAgaWYgKG5ld0J1Zi5sZW5ndGgpIG5ld0J1Zi5wYXJlbnQgPSB0aGlzLnBhcmVudCB8fCB0aGlzXG5cbiAgcmV0dXJuIG5ld0J1ZlxufVxuXG4vKlxuICogTmVlZCB0byBtYWtlIHN1cmUgdGhhdCBidWZmZXIgaXNuJ3QgdHJ5aW5nIHRvIHdyaXRlIG91dCBvZiBib3VuZHMuXG4gKi9cbmZ1bmN0aW9uIGNoZWNrT2Zmc2V0IChvZmZzZXQsIGV4dCwgbGVuZ3RoKSB7XG4gIGlmICgob2Zmc2V0ICUgMSkgIT09IDAgfHwgb2Zmc2V0IDwgMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ29mZnNldCBpcyBub3QgdWludCcpXG4gIGlmIChvZmZzZXQgKyBleHQgPiBsZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdUcnlpbmcgdG8gYWNjZXNzIGJleW9uZCBidWZmZXIgbGVuZ3RoJylcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludExFID0gZnVuY3Rpb24gcmVhZFVJbnRMRSAob2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoIHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIGJ5dGVMZW5ndGgsIHRoaXMubGVuZ3RoKVxuXG4gIHZhciB2YWwgPSB0aGlzW29mZnNldF1cbiAgdmFyIG11bCA9IDFcbiAgdmFyIGkgPSAwXG4gIHdoaWxlICgrK2kgPCBieXRlTGVuZ3RoICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgdmFsICs9IHRoaXNbb2Zmc2V0ICsgaV0gKiBtdWxcbiAgfVxuXG4gIHJldHVybiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludEJFID0gZnVuY3Rpb24gcmVhZFVJbnRCRSAob2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoIHwgMFxuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcbiAgfVxuXG4gIHZhciB2YWwgPSB0aGlzW29mZnNldCArIC0tYnl0ZUxlbmd0aF1cbiAgdmFyIG11bCA9IDFcbiAgd2hpbGUgKGJ5dGVMZW5ndGggPiAwICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgdmFsICs9IHRoaXNbb2Zmc2V0ICsgLS1ieXRlTGVuZ3RoXSAqIG11bFxuICB9XG5cbiAgcmV0dXJuIHZhbFxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50OCA9IGZ1bmN0aW9uIHJlYWRVSW50OCAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDEsIHRoaXMubGVuZ3RoKVxuICByZXR1cm4gdGhpc1tvZmZzZXRdXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnQxNkxFID0gZnVuY3Rpb24gcmVhZFVJbnQxNkxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMiwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiB0aGlzW29mZnNldF0gfCAodGhpc1tvZmZzZXQgKyAxXSA8PCA4KVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50MTZCRSA9IGZ1bmN0aW9uIHJlYWRVSW50MTZCRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKVxuICByZXR1cm4gKHRoaXNbb2Zmc2V0XSA8PCA4KSB8IHRoaXNbb2Zmc2V0ICsgMV1cbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludDMyTEUgPSBmdW5jdGlvbiByZWFkVUludDMyTEUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA0LCB0aGlzLmxlbmd0aClcblxuICByZXR1cm4gKCh0aGlzW29mZnNldF0pIHxcbiAgICAgICh0aGlzW29mZnNldCArIDFdIDw8IDgpIHxcbiAgICAgICh0aGlzW29mZnNldCArIDJdIDw8IDE2KSkgK1xuICAgICAgKHRoaXNbb2Zmc2V0ICsgM10gKiAweDEwMDAwMDApXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnQzMkJFID0gZnVuY3Rpb24gcmVhZFVJbnQzMkJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG5cbiAgcmV0dXJuICh0aGlzW29mZnNldF0gKiAweDEwMDAwMDApICtcbiAgICAoKHRoaXNbb2Zmc2V0ICsgMV0gPDwgMTYpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAyXSA8PCA4KSB8XG4gICAgdGhpc1tvZmZzZXQgKyAzXSlcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50TEUgPSBmdW5jdGlvbiByZWFkSW50TEUgKG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcblxuICB2YXIgdmFsID0gdGhpc1tvZmZzZXRdXG4gIHZhciBtdWwgPSAxXG4gIHZhciBpID0gMFxuICB3aGlsZSAoKytpIDwgYnl0ZUxlbmd0aCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHZhbCArPSB0aGlzW29mZnNldCArIGldICogbXVsXG4gIH1cbiAgbXVsICo9IDB4ODBcblxuICBpZiAodmFsID49IG11bCkgdmFsIC09IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoKVxuXG4gIHJldHVybiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50QkUgPSBmdW5jdGlvbiByZWFkSW50QkUgKG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcblxuICB2YXIgaSA9IGJ5dGVMZW5ndGhcbiAgdmFyIG11bCA9IDFcbiAgdmFyIHZhbCA9IHRoaXNbb2Zmc2V0ICsgLS1pXVxuICB3aGlsZSAoaSA+IDAgJiYgKG11bCAqPSAweDEwMCkpIHtcbiAgICB2YWwgKz0gdGhpc1tvZmZzZXQgKyAtLWldICogbXVsXG4gIH1cbiAgbXVsICo9IDB4ODBcblxuICBpZiAodmFsID49IG11bCkgdmFsIC09IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoKVxuXG4gIHJldHVybiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50OCA9IGZ1bmN0aW9uIHJlYWRJbnQ4IChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMSwgdGhpcy5sZW5ndGgpXG4gIGlmICghKHRoaXNbb2Zmc2V0XSAmIDB4ODApKSByZXR1cm4gKHRoaXNbb2Zmc2V0XSlcbiAgcmV0dXJuICgoMHhmZiAtIHRoaXNbb2Zmc2V0XSArIDEpICogLTEpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZEludDE2TEUgPSBmdW5jdGlvbiByZWFkSW50MTZMRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKVxuICB2YXIgdmFsID0gdGhpc1tvZmZzZXRdIHwgKHRoaXNbb2Zmc2V0ICsgMV0gPDwgOClcbiAgcmV0dXJuICh2YWwgJiAweDgwMDApID8gdmFsIHwgMHhGRkZGMDAwMCA6IHZhbFxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRJbnQxNkJFID0gZnVuY3Rpb24gcmVhZEludDE2QkUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCAyLCB0aGlzLmxlbmd0aClcbiAgdmFyIHZhbCA9IHRoaXNbb2Zmc2V0ICsgMV0gfCAodGhpc1tvZmZzZXRdIDw8IDgpXG4gIHJldHVybiAodmFsICYgMHg4MDAwKSA/IHZhbCB8IDB4RkZGRjAwMDAgOiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50MzJMRSA9IGZ1bmN0aW9uIHJlYWRJbnQzMkxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG5cbiAgcmV0dXJuICh0aGlzW29mZnNldF0pIHxcbiAgICAodGhpc1tvZmZzZXQgKyAxXSA8PCA4KSB8XG4gICAgKHRoaXNbb2Zmc2V0ICsgMl0gPDwgMTYpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAzXSA8PCAyNClcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50MzJCRSA9IGZ1bmN0aW9uIHJlYWRJbnQzMkJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG5cbiAgcmV0dXJuICh0aGlzW29mZnNldF0gPDwgMjQpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAxXSA8PCAxNikgfFxuICAgICh0aGlzW29mZnNldCArIDJdIDw8IDgpIHxcbiAgICAodGhpc1tvZmZzZXQgKyAzXSlcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkRmxvYXRMRSA9IGZ1bmN0aW9uIHJlYWRGbG9hdExFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCB0cnVlLCAyMywgNClcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkRmxvYXRCRSA9IGZ1bmN0aW9uIHJlYWRGbG9hdEJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCBmYWxzZSwgMjMsIDQpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZERvdWJsZUxFID0gZnVuY3Rpb24gcmVhZERvdWJsZUxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgOCwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCB0cnVlLCA1MiwgOClcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkRG91YmxlQkUgPSBmdW5jdGlvbiByZWFkRG91YmxlQkUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA4LCB0aGlzLmxlbmd0aClcbiAgcmV0dXJuIGllZWU3NTQucmVhZCh0aGlzLCBvZmZzZXQsIGZhbHNlLCA1MiwgOClcbn1cblxuZnVuY3Rpb24gY2hlY2tJbnQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgZXh0LCBtYXgsIG1pbikge1xuICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihidWYpKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdidWZmZXIgbXVzdCBiZSBhIEJ1ZmZlciBpbnN0YW5jZScpXG4gIGlmICh2YWx1ZSA+IG1heCB8fCB2YWx1ZSA8IG1pbikgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ3ZhbHVlIGlzIG91dCBvZiBib3VuZHMnKVxuICBpZiAob2Zmc2V0ICsgZXh0ID4gYnVmLmxlbmd0aCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ2luZGV4IG91dCBvZiByYW5nZScpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50TEUgPSBmdW5jdGlvbiB3cml0ZVVJbnRMRSAodmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpLCAwKVxuXG4gIHZhciBtdWwgPSAxXG4gIHZhciBpID0gMFxuICB0aGlzW29mZnNldF0gPSB2YWx1ZSAmIDB4RkZcbiAgd2hpbGUgKCsraSA8IGJ5dGVMZW5ndGggJiYgKG11bCAqPSAweDEwMCkpIHtcbiAgICB0aGlzW29mZnNldCArIGldID0gKHZhbHVlIC8gbXVsKSAmIDB4RkZcbiAgfVxuXG4gIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50QkUgPSBmdW5jdGlvbiB3cml0ZVVJbnRCRSAodmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpLCAwKVxuXG4gIHZhciBpID0gYnl0ZUxlbmd0aCAtIDFcbiAgdmFyIG11bCA9IDFcbiAgdGhpc1tvZmZzZXQgKyBpXSA9IHZhbHVlICYgMHhGRlxuICB3aGlsZSAoLS1pID49IDAgJiYgKG11bCAqPSAweDEwMCkpIHtcbiAgICB0aGlzW29mZnNldCArIGldID0gKHZhbHVlIC8gbXVsKSAmIDB4RkZcbiAgfVxuXG4gIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50OCA9IGZ1bmN0aW9uIHdyaXRlVUludDggKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCB8IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgMSwgMHhmZiwgMClcbiAgaWYgKCFCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkgdmFsdWUgPSBNYXRoLmZsb29yKHZhbHVlKVxuICB0aGlzW29mZnNldF0gPSB2YWx1ZVxuICByZXR1cm4gb2Zmc2V0ICsgMVxufVxuXG5mdW5jdGlvbiBvYmplY3RXcml0ZVVJbnQxNiAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4pIHtcbiAgaWYgKHZhbHVlIDwgMCkgdmFsdWUgPSAweGZmZmYgKyB2YWx1ZSArIDFcbiAgZm9yICh2YXIgaSA9IDAsIGogPSBNYXRoLm1pbihidWYubGVuZ3RoIC0gb2Zmc2V0LCAyKTsgaSA8IGo7IGkrKykge1xuICAgIGJ1ZltvZmZzZXQgKyBpXSA9ICh2YWx1ZSAmICgweGZmIDw8ICg4ICogKGxpdHRsZUVuZGlhbiA/IGkgOiAxIC0gaSkpKSkgPj4+XG4gICAgICAobGl0dGxlRW5kaWFuID8gaSA6IDEgLSBpKSAqIDhcbiAgfVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlVUludDE2TEUgPSBmdW5jdGlvbiB3cml0ZVVJbnQxNkxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4ZmZmZiwgMClcbiAgaWYgKEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gICAgdGhpc1tvZmZzZXRdID0gdmFsdWVcbiAgICB0aGlzW29mZnNldCArIDFdID0gKHZhbHVlID4+PiA4KVxuICB9IGVsc2Uge1xuICAgIG9iamVjdFdyaXRlVUludDE2KHRoaXMsIHZhbHVlLCBvZmZzZXQsIHRydWUpXG4gIH1cbiAgcmV0dXJuIG9mZnNldCArIDJcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQxNkJFID0gZnVuY3Rpb24gd3JpdGVVSW50MTZCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAyLCAweGZmZmYsIDApXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSA+Pj4gOClcbiAgICB0aGlzW29mZnNldCArIDFdID0gdmFsdWVcbiAgfSBlbHNlIHtcbiAgICBvYmplY3RXcml0ZVVJbnQxNih0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgMlxufVxuXG5mdW5jdGlvbiBvYmplY3RXcml0ZVVJbnQzMiAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4pIHtcbiAgaWYgKHZhbHVlIDwgMCkgdmFsdWUgPSAweGZmZmZmZmZmICsgdmFsdWUgKyAxXG4gIGZvciAodmFyIGkgPSAwLCBqID0gTWF0aC5taW4oYnVmLmxlbmd0aCAtIG9mZnNldCwgNCk7IGkgPCBqOyBpKyspIHtcbiAgICBidWZbb2Zmc2V0ICsgaV0gPSAodmFsdWUgPj4+IChsaXR0bGVFbmRpYW4gPyBpIDogMyAtIGkpICogOCkgJiAweGZmXG4gIH1cbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQzMkxFID0gZnVuY3Rpb24gd3JpdGVVSW50MzJMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCA0LCAweGZmZmZmZmZmLCAwKVxuICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICB0aGlzW29mZnNldCArIDNdID0gKHZhbHVlID4+PiAyNClcbiAgICB0aGlzW29mZnNldCArIDJdID0gKHZhbHVlID4+PiAxNilcbiAgICB0aGlzW29mZnNldCArIDFdID0gKHZhbHVlID4+PiA4KVxuICAgIHRoaXNbb2Zmc2V0XSA9IHZhbHVlXG4gIH0gZWxzZSB7XG4gICAgb2JqZWN0V3JpdGVVSW50MzIodGhpcywgdmFsdWUsIG9mZnNldCwgdHJ1ZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlVUludDMyQkUgPSBmdW5jdGlvbiB3cml0ZVVJbnQzMkJFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDQsIDB4ZmZmZmZmZmYsIDApXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSA+Pj4gMjQpXG4gICAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gMTYpXG4gICAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gOClcbiAgICB0aGlzW29mZnNldCArIDNdID0gdmFsdWVcbiAgfSBlbHNlIHtcbiAgICBvYmplY3RXcml0ZVVJbnQzMih0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlSW50TEUgPSBmdW5jdGlvbiB3cml0ZUludExFICh2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIHtcbiAgICB2YXIgbGltaXQgPSBNYXRoLnBvdygyLCA4ICogYnl0ZUxlbmd0aCAtIDEpXG5cbiAgICBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBsaW1pdCAtIDEsIC1saW1pdClcbiAgfVxuXG4gIHZhciBpID0gMFxuICB2YXIgbXVsID0gMVxuICB2YXIgc3ViID0gdmFsdWUgPCAwID8gMSA6IDBcbiAgdGhpc1tvZmZzZXRdID0gdmFsdWUgJiAweEZGXG4gIHdoaWxlICgrK2kgPCBieXRlTGVuZ3RoICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgdGhpc1tvZmZzZXQgKyBpXSA9ICgodmFsdWUgLyBtdWwpID4+IDApIC0gc3ViICYgMHhGRlxuICB9XG5cbiAgcmV0dXJuIG9mZnNldCArIGJ5dGVMZW5ndGhcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZUludEJFID0gZnVuY3Rpb24gd3JpdGVJbnRCRSAodmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgdmFyIGxpbWl0ID0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGggLSAxKVxuXG4gICAgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbGltaXQgLSAxLCAtbGltaXQpXG4gIH1cblxuICB2YXIgaSA9IGJ5dGVMZW5ndGggLSAxXG4gIHZhciBtdWwgPSAxXG4gIHZhciBzdWIgPSB2YWx1ZSA8IDAgPyAxIDogMFxuICB0aGlzW29mZnNldCArIGldID0gdmFsdWUgJiAweEZGXG4gIHdoaWxlICgtLWkgPj0gMCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHRoaXNbb2Zmc2V0ICsgaV0gPSAoKHZhbHVlIC8gbXVsKSA+PiAwKSAtIHN1YiAmIDB4RkZcbiAgfVxuXG4gIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQ4ID0gZnVuY3Rpb24gd3JpdGVJbnQ4ICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDEsIDB4N2YsIC0weDgwKVxuICBpZiAoIUJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB2YWx1ZSA9IE1hdGguZmxvb3IodmFsdWUpXG4gIGlmICh2YWx1ZSA8IDApIHZhbHVlID0gMHhmZiArIHZhbHVlICsgMVxuICB0aGlzW29mZnNldF0gPSB2YWx1ZVxuICByZXR1cm4gb2Zmc2V0ICsgMVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlSW50MTZMRSA9IGZ1bmN0aW9uIHdyaXRlSW50MTZMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAyLCAweDdmZmYsIC0weDgwMDApXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIHRoaXNbb2Zmc2V0XSA9IHZhbHVlXG4gICAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gOClcbiAgfSBlbHNlIHtcbiAgICBvYmplY3RXcml0ZVVJbnQxNih0aGlzLCB2YWx1ZSwgb2Zmc2V0LCB0cnVlKVxuICB9XG4gIHJldHVybiBvZmZzZXQgKyAyXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQxNkJFID0gZnVuY3Rpb24gd3JpdGVJbnQxNkJFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4N2ZmZiwgLTB4ODAwMClcbiAgaWYgKEJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gICAgdGhpc1tvZmZzZXRdID0gKHZhbHVlID4+PiA4KVxuICAgIHRoaXNbb2Zmc2V0ICsgMV0gPSB2YWx1ZVxuICB9IGVsc2Uge1xuICAgIG9iamVjdFdyaXRlVUludDE2KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGZhbHNlKVxuICB9XG4gIHJldHVybiBvZmZzZXQgKyAyXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQzMkxFID0gZnVuY3Rpb24gd3JpdGVJbnQzMkxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgfCAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDQsIDB4N2ZmZmZmZmYsIC0weDgwMDAwMDAwKVxuICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICB0aGlzW29mZnNldF0gPSB2YWx1ZVxuICAgIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDgpXG4gICAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gMTYpXG4gICAgdGhpc1tvZmZzZXQgKyAzXSA9ICh2YWx1ZSA+Pj4gMjQpXG4gIH0gZWxzZSB7XG4gICAgb2JqZWN0V3JpdGVVSW50MzIodGhpcywgdmFsdWUsIG9mZnNldCwgdHJ1ZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlSW50MzJCRSA9IGZ1bmN0aW9uIHdyaXRlSW50MzJCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0IHwgMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCA0LCAweDdmZmZmZmZmLCAtMHg4MDAwMDAwMClcbiAgaWYgKHZhbHVlIDwgMCkgdmFsdWUgPSAweGZmZmZmZmZmICsgdmFsdWUgKyAxXG4gIGlmIChCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCkge1xuICAgIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSA+Pj4gMjQpXG4gICAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gMTYpXG4gICAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gOClcbiAgICB0aGlzW29mZnNldCArIDNdID0gdmFsdWVcbiAgfSBlbHNlIHtcbiAgICBvYmplY3RXcml0ZVVJbnQzMih0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSlcbiAgfVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5mdW5jdGlvbiBjaGVja0lFRUU3NTQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgZXh0LCBtYXgsIG1pbikge1xuICBpZiAodmFsdWUgPiBtYXggfHwgdmFsdWUgPCBtaW4pIHRocm93IG5ldyBSYW5nZUVycm9yKCd2YWx1ZSBpcyBvdXQgb2YgYm91bmRzJylcbiAgaWYgKG9mZnNldCArIGV4dCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdpbmRleCBvdXQgb2YgcmFuZ2UnKVxuICBpZiAob2Zmc2V0IDwgMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ2luZGV4IG91dCBvZiByYW5nZScpXG59XG5cbmZ1bmN0aW9uIHdyaXRlRmxvYXQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbGl0dGxlRW5kaWFuLCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgY2hlY2tJRUVFNzU0KGJ1ZiwgdmFsdWUsIG9mZnNldCwgNCwgMy40MDI4MjM0NjYzODUyODg2ZSszOCwgLTMuNDAyODIzNDY2Mzg1Mjg4NmUrMzgpXG4gIH1cbiAgaWVlZTc1NC53cml0ZShidWYsIHZhbHVlLCBvZmZzZXQsIGxpdHRsZUVuZGlhbiwgMjMsIDQpXG4gIHJldHVybiBvZmZzZXQgKyA0XG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVGbG9hdExFID0gZnVuY3Rpb24gd3JpdGVGbG9hdExFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICByZXR1cm4gd3JpdGVGbG9hdCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCB0cnVlLCBub0Fzc2VydClcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZUZsb2F0QkUgPSBmdW5jdGlvbiB3cml0ZUZsb2F0QkUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHJldHVybiB3cml0ZUZsb2F0KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGZhbHNlLCBub0Fzc2VydClcbn1cblxuZnVuY3Rpb24gd3JpdGVEb3VibGUgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbGl0dGxlRW5kaWFuLCBub0Fzc2VydCkge1xuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgY2hlY2tJRUVFNzU0KGJ1ZiwgdmFsdWUsIG9mZnNldCwgOCwgMS43OTc2OTMxMzQ4NjIzMTU3RSszMDgsIC0xLjc5NzY5MzEzNDg2MjMxNTdFKzMwOClcbiAgfVxuICBpZWVlNzU0LndyaXRlKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbGl0dGxlRW5kaWFuLCA1MiwgOClcbiAgcmV0dXJuIG9mZnNldCArIDhcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZURvdWJsZUxFID0gZnVuY3Rpb24gd3JpdGVEb3VibGVMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgcmV0dXJuIHdyaXRlRG91YmxlKHRoaXMsIHZhbHVlLCBvZmZzZXQsIHRydWUsIG5vQXNzZXJ0KVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlRG91YmxlQkUgPSBmdW5jdGlvbiB3cml0ZURvdWJsZUJFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICByZXR1cm4gd3JpdGVEb3VibGUodGhpcywgdmFsdWUsIG9mZnNldCwgZmFsc2UsIG5vQXNzZXJ0KVxufVxuXG4vLyBjb3B5KHRhcmdldEJ1ZmZlciwgdGFyZ2V0U3RhcnQ9MCwgc291cmNlU3RhcnQ9MCwgc291cmNlRW5kPWJ1ZmZlci5sZW5ndGgpXG5CdWZmZXIucHJvdG90eXBlLmNvcHkgPSBmdW5jdGlvbiBjb3B5ICh0YXJnZXQsIHRhcmdldFN0YXJ0LCBzdGFydCwgZW5kKSB7XG4gIGlmICghc3RhcnQpIHN0YXJ0ID0gMFxuICBpZiAoIWVuZCAmJiBlbmQgIT09IDApIGVuZCA9IHRoaXMubGVuZ3RoXG4gIGlmICh0YXJnZXRTdGFydCA+PSB0YXJnZXQubGVuZ3RoKSB0YXJnZXRTdGFydCA9IHRhcmdldC5sZW5ndGhcbiAgaWYgKCF0YXJnZXRTdGFydCkgdGFyZ2V0U3RhcnQgPSAwXG4gIGlmIChlbmQgPiAwICYmIGVuZCA8IHN0YXJ0KSBlbmQgPSBzdGFydFxuXG4gIC8vIENvcHkgMCBieXRlczsgd2UncmUgZG9uZVxuICBpZiAoZW5kID09PSBzdGFydCkgcmV0dXJuIDBcbiAgaWYgKHRhcmdldC5sZW5ndGggPT09IDAgfHwgdGhpcy5sZW5ndGggPT09IDApIHJldHVybiAwXG5cbiAgLy8gRmF0YWwgZXJyb3IgY29uZGl0aW9uc1xuICBpZiAodGFyZ2V0U3RhcnQgPCAwKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ3RhcmdldFN0YXJ0IG91dCBvZiBib3VuZHMnKVxuICB9XG4gIGlmIChzdGFydCA8IDAgfHwgc3RhcnQgPj0gdGhpcy5sZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdzb3VyY2VTdGFydCBvdXQgb2YgYm91bmRzJylcbiAgaWYgKGVuZCA8IDApIHRocm93IG5ldyBSYW5nZUVycm9yKCdzb3VyY2VFbmQgb3V0IG9mIGJvdW5kcycpXG5cbiAgLy8gQXJlIHdlIG9vYj9cbiAgaWYgKGVuZCA+IHRoaXMubGVuZ3RoKSBlbmQgPSB0aGlzLmxlbmd0aFxuICBpZiAodGFyZ2V0Lmxlbmd0aCAtIHRhcmdldFN0YXJ0IDwgZW5kIC0gc3RhcnQpIHtcbiAgICBlbmQgPSB0YXJnZXQubGVuZ3RoIC0gdGFyZ2V0U3RhcnQgKyBzdGFydFxuICB9XG5cbiAgdmFyIGxlbiA9IGVuZCAtIHN0YXJ0XG4gIHZhciBpXG5cbiAgaWYgKHRoaXMgPT09IHRhcmdldCAmJiBzdGFydCA8IHRhcmdldFN0YXJ0ICYmIHRhcmdldFN0YXJ0IDwgZW5kKSB7XG4gICAgLy8gZGVzY2VuZGluZyBjb3B5IGZyb20gZW5kXG4gICAgZm9yIChpID0gbGVuIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIHRhcmdldFtpICsgdGFyZ2V0U3RhcnRdID0gdGhpc1tpICsgc3RhcnRdXG4gICAgfVxuICB9IGVsc2UgaWYgKGxlbiA8IDEwMDAgfHwgIUJ1ZmZlci5UWVBFRF9BUlJBWV9TVVBQT1JUKSB7XG4gICAgLy8gYXNjZW5kaW5nIGNvcHkgZnJvbSBzdGFydFxuICAgIGZvciAoaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgdGFyZ2V0W2kgKyB0YXJnZXRTdGFydF0gPSB0aGlzW2kgKyBzdGFydF1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdGFyZ2V0Ll9zZXQodGhpcy5zdWJhcnJheShzdGFydCwgc3RhcnQgKyBsZW4pLCB0YXJnZXRTdGFydClcbiAgfVxuXG4gIHJldHVybiBsZW5cbn1cblxuLy8gZmlsbCh2YWx1ZSwgc3RhcnQ9MCwgZW5kPWJ1ZmZlci5sZW5ndGgpXG5CdWZmZXIucHJvdG90eXBlLmZpbGwgPSBmdW5jdGlvbiBmaWxsICh2YWx1ZSwgc3RhcnQsIGVuZCkge1xuICBpZiAoIXZhbHVlKSB2YWx1ZSA9IDBcbiAgaWYgKCFzdGFydCkgc3RhcnQgPSAwXG4gIGlmICghZW5kKSBlbmQgPSB0aGlzLmxlbmd0aFxuXG4gIGlmIChlbmQgPCBzdGFydCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ2VuZCA8IHN0YXJ0JylcblxuICAvLyBGaWxsIDAgYnl0ZXM7IHdlJ3JlIGRvbmVcbiAgaWYgKGVuZCA9PT0gc3RhcnQpIHJldHVyblxuICBpZiAodGhpcy5sZW5ndGggPT09IDApIHJldHVyblxuXG4gIGlmIChzdGFydCA8IDAgfHwgc3RhcnQgPj0gdGhpcy5sZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdzdGFydCBvdXQgb2YgYm91bmRzJylcbiAgaWYgKGVuZCA8IDAgfHwgZW5kID4gdGhpcy5sZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdlbmQgb3V0IG9mIGJvdW5kcycpXG5cbiAgdmFyIGlcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcbiAgICBmb3IgKGkgPSBzdGFydDsgaSA8IGVuZDsgaSsrKSB7XG4gICAgICB0aGlzW2ldID0gdmFsdWVcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdmFyIGJ5dGVzID0gdXRmOFRvQnl0ZXModmFsdWUudG9TdHJpbmcoKSlcbiAgICB2YXIgbGVuID0gYnl0ZXMubGVuZ3RoXG4gICAgZm9yIChpID0gc3RhcnQ7IGkgPCBlbmQ7IGkrKykge1xuICAgICAgdGhpc1tpXSA9IGJ5dGVzW2kgJSBsZW5dXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRoaXNcbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IGBBcnJheUJ1ZmZlcmAgd2l0aCB0aGUgKmNvcGllZCogbWVtb3J5IG9mIHRoZSBidWZmZXIgaW5zdGFuY2UuXG4gKiBBZGRlZCBpbiBOb2RlIDAuMTIuIE9ubHkgYXZhaWxhYmxlIGluIGJyb3dzZXJzIHRoYXQgc3VwcG9ydCBBcnJheUJ1ZmZlci5cbiAqL1xuQnVmZmVyLnByb3RvdHlwZS50b0FycmF5QnVmZmVyID0gZnVuY3Rpb24gdG9BcnJheUJ1ZmZlciAoKSB7XG4gIGlmICh0eXBlb2YgVWludDhBcnJheSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBpZiAoQnVmZmVyLlRZUEVEX0FSUkFZX1NVUFBPUlQpIHtcbiAgICAgIHJldHVybiAobmV3IEJ1ZmZlcih0aGlzKSkuYnVmZmVyXG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciBidWYgPSBuZXcgVWludDhBcnJheSh0aGlzLmxlbmd0aClcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSBidWYubGVuZ3RoOyBpIDwgbGVuOyBpICs9IDEpIHtcbiAgICAgICAgYnVmW2ldID0gdGhpc1tpXVxuICAgICAgfVxuICAgICAgcmV0dXJuIGJ1Zi5idWZmZXJcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQnVmZmVyLnRvQXJyYXlCdWZmZXIgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGJyb3dzZXInKVxuICB9XG59XG5cbi8vIEhFTFBFUiBGVU5DVElPTlNcbi8vID09PT09PT09PT09PT09PT1cblxudmFyIEJQID0gQnVmZmVyLnByb3RvdHlwZVxuXG4vKipcbiAqIEF1Z21lbnQgYSBVaW50OEFycmF5ICppbnN0YW5jZSogKG5vdCB0aGUgVWludDhBcnJheSBjbGFzcyEpIHdpdGggQnVmZmVyIG1ldGhvZHNcbiAqL1xuQnVmZmVyLl9hdWdtZW50ID0gZnVuY3Rpb24gX2F1Z21lbnQgKGFycikge1xuICBhcnIuY29uc3RydWN0b3IgPSBCdWZmZXJcbiAgYXJyLl9pc0J1ZmZlciA9IHRydWVcblxuICAvLyBzYXZlIHJlZmVyZW5jZSB0byBvcmlnaW5hbCBVaW50OEFycmF5IHNldCBtZXRob2QgYmVmb3JlIG92ZXJ3cml0aW5nXG4gIGFyci5fc2V0ID0gYXJyLnNldFxuXG4gIC8vIGRlcHJlY2F0ZWRcbiAgYXJyLmdldCA9IEJQLmdldFxuICBhcnIuc2V0ID0gQlAuc2V0XG5cbiAgYXJyLndyaXRlID0gQlAud3JpdGVcbiAgYXJyLnRvU3RyaW5nID0gQlAudG9TdHJpbmdcbiAgYXJyLnRvTG9jYWxlU3RyaW5nID0gQlAudG9TdHJpbmdcbiAgYXJyLnRvSlNPTiA9IEJQLnRvSlNPTlxuICBhcnIuZXF1YWxzID0gQlAuZXF1YWxzXG4gIGFyci5jb21wYXJlID0gQlAuY29tcGFyZVxuICBhcnIuaW5kZXhPZiA9IEJQLmluZGV4T2ZcbiAgYXJyLmNvcHkgPSBCUC5jb3B5XG4gIGFyci5zbGljZSA9IEJQLnNsaWNlXG4gIGFyci5yZWFkVUludExFID0gQlAucmVhZFVJbnRMRVxuICBhcnIucmVhZFVJbnRCRSA9IEJQLnJlYWRVSW50QkVcbiAgYXJyLnJlYWRVSW50OCA9IEJQLnJlYWRVSW50OFxuICBhcnIucmVhZFVJbnQxNkxFID0gQlAucmVhZFVJbnQxNkxFXG4gIGFyci5yZWFkVUludDE2QkUgPSBCUC5yZWFkVUludDE2QkVcbiAgYXJyLnJlYWRVSW50MzJMRSA9IEJQLnJlYWRVSW50MzJMRVxuICBhcnIucmVhZFVJbnQzMkJFID0gQlAucmVhZFVJbnQzMkJFXG4gIGFyci5yZWFkSW50TEUgPSBCUC5yZWFkSW50TEVcbiAgYXJyLnJlYWRJbnRCRSA9IEJQLnJlYWRJbnRCRVxuICBhcnIucmVhZEludDggPSBCUC5yZWFkSW50OFxuICBhcnIucmVhZEludDE2TEUgPSBCUC5yZWFkSW50MTZMRVxuICBhcnIucmVhZEludDE2QkUgPSBCUC5yZWFkSW50MTZCRVxuICBhcnIucmVhZEludDMyTEUgPSBCUC5yZWFkSW50MzJMRVxuICBhcnIucmVhZEludDMyQkUgPSBCUC5yZWFkSW50MzJCRVxuICBhcnIucmVhZEZsb2F0TEUgPSBCUC5yZWFkRmxvYXRMRVxuICBhcnIucmVhZEZsb2F0QkUgPSBCUC5yZWFkRmxvYXRCRVxuICBhcnIucmVhZERvdWJsZUxFID0gQlAucmVhZERvdWJsZUxFXG4gIGFyci5yZWFkRG91YmxlQkUgPSBCUC5yZWFkRG91YmxlQkVcbiAgYXJyLndyaXRlVUludDggPSBCUC53cml0ZVVJbnQ4XG4gIGFyci53cml0ZVVJbnRMRSA9IEJQLndyaXRlVUludExFXG4gIGFyci53cml0ZVVJbnRCRSA9IEJQLndyaXRlVUludEJFXG4gIGFyci53cml0ZVVJbnQxNkxFID0gQlAud3JpdGVVSW50MTZMRVxuICBhcnIud3JpdGVVSW50MTZCRSA9IEJQLndyaXRlVUludDE2QkVcbiAgYXJyLndyaXRlVUludDMyTEUgPSBCUC53cml0ZVVJbnQzMkxFXG4gIGFyci53cml0ZVVJbnQzMkJFID0gQlAud3JpdGVVSW50MzJCRVxuICBhcnIud3JpdGVJbnRMRSA9IEJQLndyaXRlSW50TEVcbiAgYXJyLndyaXRlSW50QkUgPSBCUC53cml0ZUludEJFXG4gIGFyci53cml0ZUludDggPSBCUC53cml0ZUludDhcbiAgYXJyLndyaXRlSW50MTZMRSA9IEJQLndyaXRlSW50MTZMRVxuICBhcnIud3JpdGVJbnQxNkJFID0gQlAud3JpdGVJbnQxNkJFXG4gIGFyci53cml0ZUludDMyTEUgPSBCUC53cml0ZUludDMyTEVcbiAgYXJyLndyaXRlSW50MzJCRSA9IEJQLndyaXRlSW50MzJCRVxuICBhcnIud3JpdGVGbG9hdExFID0gQlAud3JpdGVGbG9hdExFXG4gIGFyci53cml0ZUZsb2F0QkUgPSBCUC53cml0ZUZsb2F0QkVcbiAgYXJyLndyaXRlRG91YmxlTEUgPSBCUC53cml0ZURvdWJsZUxFXG4gIGFyci53cml0ZURvdWJsZUJFID0gQlAud3JpdGVEb3VibGVCRVxuICBhcnIuZmlsbCA9IEJQLmZpbGxcbiAgYXJyLmluc3BlY3QgPSBCUC5pbnNwZWN0XG4gIGFyci50b0FycmF5QnVmZmVyID0gQlAudG9BcnJheUJ1ZmZlclxuXG4gIHJldHVybiBhcnJcbn1cblxudmFyIElOVkFMSURfQkFTRTY0X1JFID0gL1teK1xcLzAtOUEtWmEtei1fXS9nXG5cbmZ1bmN0aW9uIGJhc2U2NGNsZWFuIChzdHIpIHtcbiAgLy8gTm9kZSBzdHJpcHMgb3V0IGludmFsaWQgY2hhcmFjdGVycyBsaWtlIFxcbiBhbmQgXFx0IGZyb20gdGhlIHN0cmluZywgYmFzZTY0LWpzIGRvZXMgbm90XG4gIHN0ciA9IHN0cmluZ3RyaW0oc3RyKS5yZXBsYWNlKElOVkFMSURfQkFTRTY0X1JFLCAnJylcbiAgLy8gTm9kZSBjb252ZXJ0cyBzdHJpbmdzIHdpdGggbGVuZ3RoIDwgMiB0byAnJ1xuICBpZiAoc3RyLmxlbmd0aCA8IDIpIHJldHVybiAnJ1xuICAvLyBOb2RlIGFsbG93cyBmb3Igbm9uLXBhZGRlZCBiYXNlNjQgc3RyaW5ncyAobWlzc2luZyB0cmFpbGluZyA9PT0pLCBiYXNlNjQtanMgZG9lcyBub3RcbiAgd2hpbGUgKHN0ci5sZW5ndGggJSA0ICE9PSAwKSB7XG4gICAgc3RyID0gc3RyICsgJz0nXG4gIH1cbiAgcmV0dXJuIHN0clxufVxuXG5mdW5jdGlvbiBzdHJpbmd0cmltIChzdHIpIHtcbiAgaWYgKHN0ci50cmltKSByZXR1cm4gc3RyLnRyaW0oKVxuICByZXR1cm4gc3RyLnJlcGxhY2UoL15cXHMrfFxccyskL2csICcnKVxufVxuXG5mdW5jdGlvbiB0b0hleCAobikge1xuICBpZiAobiA8IDE2KSByZXR1cm4gJzAnICsgbi50b1N0cmluZygxNilcbiAgcmV0dXJuIG4udG9TdHJpbmcoMTYpXG59XG5cbmZ1bmN0aW9uIHV0ZjhUb0J5dGVzIChzdHJpbmcsIHVuaXRzKSB7XG4gIHVuaXRzID0gdW5pdHMgfHwgSW5maW5pdHlcbiAgdmFyIGNvZGVQb2ludFxuICB2YXIgbGVuZ3RoID0gc3RyaW5nLmxlbmd0aFxuICB2YXIgbGVhZFN1cnJvZ2F0ZSA9IG51bGxcbiAgdmFyIGJ5dGVzID0gW11cblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgY29kZVBvaW50ID0gc3RyaW5nLmNoYXJDb2RlQXQoaSlcblxuICAgIC8vIGlzIHN1cnJvZ2F0ZSBjb21wb25lbnRcbiAgICBpZiAoY29kZVBvaW50ID4gMHhEN0ZGICYmIGNvZGVQb2ludCA8IDB4RTAwMCkge1xuICAgICAgLy8gbGFzdCBjaGFyIHdhcyBhIGxlYWRcbiAgICAgIGlmICghbGVhZFN1cnJvZ2F0ZSkge1xuICAgICAgICAvLyBubyBsZWFkIHlldFxuICAgICAgICBpZiAoY29kZVBvaW50ID4gMHhEQkZGKSB7XG4gICAgICAgICAgLy8gdW5leHBlY3RlZCB0cmFpbFxuICAgICAgICAgIGlmICgodW5pdHMgLT0gMykgPiAtMSkgYnl0ZXMucHVzaCgweEVGLCAweEJGLCAweEJEKVxuICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgIH0gZWxzZSBpZiAoaSArIDEgPT09IGxlbmd0aCkge1xuICAgICAgICAgIC8vIHVucGFpcmVkIGxlYWRcbiAgICAgICAgICBpZiAoKHVuaXRzIC09IDMpID4gLTEpIGJ5dGVzLnB1c2goMHhFRiwgMHhCRiwgMHhCRClcbiAgICAgICAgICBjb250aW51ZVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gdmFsaWQgbGVhZFxuICAgICAgICBsZWFkU3Vycm9nYXRlID0gY29kZVBvaW50XG5cbiAgICAgICAgY29udGludWVcbiAgICAgIH1cblxuICAgICAgLy8gMiBsZWFkcyBpbiBhIHJvd1xuICAgICAgaWYgKGNvZGVQb2ludCA8IDB4REMwMCkge1xuICAgICAgICBpZiAoKHVuaXRzIC09IDMpID4gLTEpIGJ5dGVzLnB1c2goMHhFRiwgMHhCRiwgMHhCRClcbiAgICAgICAgbGVhZFN1cnJvZ2F0ZSA9IGNvZGVQb2ludFxuICAgICAgICBjb250aW51ZVxuICAgICAgfVxuXG4gICAgICAvLyB2YWxpZCBzdXJyb2dhdGUgcGFpclxuICAgICAgY29kZVBvaW50ID0gbGVhZFN1cnJvZ2F0ZSAtIDB4RDgwMCA8PCAxMCB8IGNvZGVQb2ludCAtIDB4REMwMCB8IDB4MTAwMDBcbiAgICB9IGVsc2UgaWYgKGxlYWRTdXJyb2dhdGUpIHtcbiAgICAgIC8vIHZhbGlkIGJtcCBjaGFyLCBidXQgbGFzdCBjaGFyIHdhcyBhIGxlYWRcbiAgICAgIGlmICgodW5pdHMgLT0gMykgPiAtMSkgYnl0ZXMucHVzaCgweEVGLCAweEJGLCAweEJEKVxuICAgIH1cblxuICAgIGxlYWRTdXJyb2dhdGUgPSBudWxsXG5cbiAgICAvLyBlbmNvZGUgdXRmOFxuICAgIGlmIChjb2RlUG9pbnQgPCAweDgwKSB7XG4gICAgICBpZiAoKHVuaXRzIC09IDEpIDwgMCkgYnJlYWtcbiAgICAgIGJ5dGVzLnB1c2goY29kZVBvaW50KVxuICAgIH0gZWxzZSBpZiAoY29kZVBvaW50IDwgMHg4MDApIHtcbiAgICAgIGlmICgodW5pdHMgLT0gMikgPCAwKSBicmVha1xuICAgICAgYnl0ZXMucHVzaChcbiAgICAgICAgY29kZVBvaW50ID4+IDB4NiB8IDB4QzAsXG4gICAgICAgIGNvZGVQb2ludCAmIDB4M0YgfCAweDgwXG4gICAgICApXG4gICAgfSBlbHNlIGlmIChjb2RlUG9pbnQgPCAweDEwMDAwKSB7XG4gICAgICBpZiAoKHVuaXRzIC09IDMpIDwgMCkgYnJlYWtcbiAgICAgIGJ5dGVzLnB1c2goXG4gICAgICAgIGNvZGVQb2ludCA+PiAweEMgfCAweEUwLFxuICAgICAgICBjb2RlUG9pbnQgPj4gMHg2ICYgMHgzRiB8IDB4ODAsXG4gICAgICAgIGNvZGVQb2ludCAmIDB4M0YgfCAweDgwXG4gICAgICApXG4gICAgfSBlbHNlIGlmIChjb2RlUG9pbnQgPCAweDExMDAwMCkge1xuICAgICAgaWYgKCh1bml0cyAtPSA0KSA8IDApIGJyZWFrXG4gICAgICBieXRlcy5wdXNoKFxuICAgICAgICBjb2RlUG9pbnQgPj4gMHgxMiB8IDB4RjAsXG4gICAgICAgIGNvZGVQb2ludCA+PiAweEMgJiAweDNGIHwgMHg4MCxcbiAgICAgICAgY29kZVBvaW50ID4+IDB4NiAmIDB4M0YgfCAweDgwLFxuICAgICAgICBjb2RlUG9pbnQgJiAweDNGIHwgMHg4MFxuICAgICAgKVxuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgY29kZSBwb2ludCcpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGJ5dGVzXG59XG5cbmZ1bmN0aW9uIGFzY2lpVG9CeXRlcyAoc3RyKSB7XG4gIHZhciBieXRlQXJyYXkgPSBbXVxuICBmb3IgKHZhciBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgIC8vIE5vZGUncyBjb2RlIHNlZW1zIHRvIGJlIGRvaW5nIHRoaXMgYW5kIG5vdCAmIDB4N0YuLlxuICAgIGJ5dGVBcnJheS5wdXNoKHN0ci5jaGFyQ29kZUF0KGkpICYgMHhGRilcbiAgfVxuICByZXR1cm4gYnl0ZUFycmF5XG59XG5cbmZ1bmN0aW9uIHV0ZjE2bGVUb0J5dGVzIChzdHIsIHVuaXRzKSB7XG4gIHZhciBjLCBoaSwgbG9cbiAgdmFyIGJ5dGVBcnJheSA9IFtdXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKCh1bml0cyAtPSAyKSA8IDApIGJyZWFrXG5cbiAgICBjID0gc3RyLmNoYXJDb2RlQXQoaSlcbiAgICBoaSA9IGMgPj4gOFxuICAgIGxvID0gYyAlIDI1NlxuICAgIGJ5dGVBcnJheS5wdXNoKGxvKVxuICAgIGJ5dGVBcnJheS5wdXNoKGhpKVxuICB9XG5cbiAgcmV0dXJuIGJ5dGVBcnJheVxufVxuXG5mdW5jdGlvbiBiYXNlNjRUb0J5dGVzIChzdHIpIHtcbiAgcmV0dXJuIGJhc2U2NC50b0J5dGVBcnJheShiYXNlNjRjbGVhbihzdHIpKVxufVxuXG5mdW5jdGlvbiBibGl0QnVmZmVyIChzcmMsIGRzdCwgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgIGlmICgoaSArIG9mZnNldCA+PSBkc3QubGVuZ3RoKSB8fCAoaSA+PSBzcmMubGVuZ3RoKSkgYnJlYWtcbiAgICBkc3RbaSArIG9mZnNldF0gPSBzcmNbaV1cbiAgfVxuICByZXR1cm4gaVxufVxuIiwidmFyIGxvb2t1cCA9ICdBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvJztcblxuOyhmdW5jdGlvbiAoZXhwb3J0cykge1xuXHQndXNlIHN0cmljdCc7XG5cbiAgdmFyIEFyciA9ICh0eXBlb2YgVWludDhBcnJheSAhPT0gJ3VuZGVmaW5lZCcpXG4gICAgPyBVaW50OEFycmF5XG4gICAgOiBBcnJheVxuXG5cdHZhciBQTFVTICAgPSAnKycuY2hhckNvZGVBdCgwKVxuXHR2YXIgU0xBU0ggID0gJy8nLmNoYXJDb2RlQXQoMClcblx0dmFyIE5VTUJFUiA9ICcwJy5jaGFyQ29kZUF0KDApXG5cdHZhciBMT1dFUiAgPSAnYScuY2hhckNvZGVBdCgwKVxuXHR2YXIgVVBQRVIgID0gJ0EnLmNoYXJDb2RlQXQoMClcblx0dmFyIFBMVVNfVVJMX1NBRkUgPSAnLScuY2hhckNvZGVBdCgwKVxuXHR2YXIgU0xBU0hfVVJMX1NBRkUgPSAnXycuY2hhckNvZGVBdCgwKVxuXG5cdGZ1bmN0aW9uIGRlY29kZSAoZWx0KSB7XG5cdFx0dmFyIGNvZGUgPSBlbHQuY2hhckNvZGVBdCgwKVxuXHRcdGlmIChjb2RlID09PSBQTFVTIHx8XG5cdFx0ICAgIGNvZGUgPT09IFBMVVNfVVJMX1NBRkUpXG5cdFx0XHRyZXR1cm4gNjIgLy8gJysnXG5cdFx0aWYgKGNvZGUgPT09IFNMQVNIIHx8XG5cdFx0ICAgIGNvZGUgPT09IFNMQVNIX1VSTF9TQUZFKVxuXHRcdFx0cmV0dXJuIDYzIC8vICcvJ1xuXHRcdGlmIChjb2RlIDwgTlVNQkVSKVxuXHRcdFx0cmV0dXJuIC0xIC8vbm8gbWF0Y2hcblx0XHRpZiAoY29kZSA8IE5VTUJFUiArIDEwKVxuXHRcdFx0cmV0dXJuIGNvZGUgLSBOVU1CRVIgKyAyNiArIDI2XG5cdFx0aWYgKGNvZGUgPCBVUFBFUiArIDI2KVxuXHRcdFx0cmV0dXJuIGNvZGUgLSBVUFBFUlxuXHRcdGlmIChjb2RlIDwgTE9XRVIgKyAyNilcblx0XHRcdHJldHVybiBjb2RlIC0gTE9XRVIgKyAyNlxuXHR9XG5cblx0ZnVuY3Rpb24gYjY0VG9CeXRlQXJyYXkgKGI2NCkge1xuXHRcdHZhciBpLCBqLCBsLCB0bXAsIHBsYWNlSG9sZGVycywgYXJyXG5cblx0XHRpZiAoYjY0Lmxlbmd0aCAlIDQgPiAwKSB7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgc3RyaW5nLiBMZW5ndGggbXVzdCBiZSBhIG11bHRpcGxlIG9mIDQnKVxuXHRcdH1cblxuXHRcdC8vIHRoZSBudW1iZXIgb2YgZXF1YWwgc2lnbnMgKHBsYWNlIGhvbGRlcnMpXG5cdFx0Ly8gaWYgdGhlcmUgYXJlIHR3byBwbGFjZWhvbGRlcnMsIHRoYW4gdGhlIHR3byBjaGFyYWN0ZXJzIGJlZm9yZSBpdFxuXHRcdC8vIHJlcHJlc2VudCBvbmUgYnl0ZVxuXHRcdC8vIGlmIHRoZXJlIGlzIG9ubHkgb25lLCB0aGVuIHRoZSB0aHJlZSBjaGFyYWN0ZXJzIGJlZm9yZSBpdCByZXByZXNlbnQgMiBieXRlc1xuXHRcdC8vIHRoaXMgaXMganVzdCBhIGNoZWFwIGhhY2sgdG8gbm90IGRvIGluZGV4T2YgdHdpY2Vcblx0XHR2YXIgbGVuID0gYjY0Lmxlbmd0aFxuXHRcdHBsYWNlSG9sZGVycyA9ICc9JyA9PT0gYjY0LmNoYXJBdChsZW4gLSAyKSA/IDIgOiAnPScgPT09IGI2NC5jaGFyQXQobGVuIC0gMSkgPyAxIDogMFxuXG5cdFx0Ly8gYmFzZTY0IGlzIDQvMyArIHVwIHRvIHR3byBjaGFyYWN0ZXJzIG9mIHRoZSBvcmlnaW5hbCBkYXRhXG5cdFx0YXJyID0gbmV3IEFycihiNjQubGVuZ3RoICogMyAvIDQgLSBwbGFjZUhvbGRlcnMpXG5cblx0XHQvLyBpZiB0aGVyZSBhcmUgcGxhY2Vob2xkZXJzLCBvbmx5IGdldCB1cCB0byB0aGUgbGFzdCBjb21wbGV0ZSA0IGNoYXJzXG5cdFx0bCA9IHBsYWNlSG9sZGVycyA+IDAgPyBiNjQubGVuZ3RoIC0gNCA6IGI2NC5sZW5ndGhcblxuXHRcdHZhciBMID0gMFxuXG5cdFx0ZnVuY3Rpb24gcHVzaCAodikge1xuXHRcdFx0YXJyW0wrK10gPSB2XG5cdFx0fVxuXG5cdFx0Zm9yIChpID0gMCwgaiA9IDA7IGkgPCBsOyBpICs9IDQsIGogKz0gMykge1xuXHRcdFx0dG1wID0gKGRlY29kZShiNjQuY2hhckF0KGkpKSA8PCAxOCkgfCAoZGVjb2RlKGI2NC5jaGFyQXQoaSArIDEpKSA8PCAxMikgfCAoZGVjb2RlKGI2NC5jaGFyQXQoaSArIDIpKSA8PCA2KSB8IGRlY29kZShiNjQuY2hhckF0KGkgKyAzKSlcblx0XHRcdHB1c2goKHRtcCAmIDB4RkYwMDAwKSA+PiAxNilcblx0XHRcdHB1c2goKHRtcCAmIDB4RkYwMCkgPj4gOClcblx0XHRcdHB1c2godG1wICYgMHhGRilcblx0XHR9XG5cblx0XHRpZiAocGxhY2VIb2xkZXJzID09PSAyKSB7XG5cdFx0XHR0bXAgPSAoZGVjb2RlKGI2NC5jaGFyQXQoaSkpIDw8IDIpIHwgKGRlY29kZShiNjQuY2hhckF0KGkgKyAxKSkgPj4gNClcblx0XHRcdHB1c2godG1wICYgMHhGRilcblx0XHR9IGVsc2UgaWYgKHBsYWNlSG9sZGVycyA9PT0gMSkge1xuXHRcdFx0dG1wID0gKGRlY29kZShiNjQuY2hhckF0KGkpKSA8PCAxMCkgfCAoZGVjb2RlKGI2NC5jaGFyQXQoaSArIDEpKSA8PCA0KSB8IChkZWNvZGUoYjY0LmNoYXJBdChpICsgMikpID4+IDIpXG5cdFx0XHRwdXNoKCh0bXAgPj4gOCkgJiAweEZGKVxuXHRcdFx0cHVzaCh0bXAgJiAweEZGKVxuXHRcdH1cblxuXHRcdHJldHVybiBhcnJcblx0fVxuXG5cdGZ1bmN0aW9uIHVpbnQ4VG9CYXNlNjQgKHVpbnQ4KSB7XG5cdFx0dmFyIGksXG5cdFx0XHRleHRyYUJ5dGVzID0gdWludDgubGVuZ3RoICUgMywgLy8gaWYgd2UgaGF2ZSAxIGJ5dGUgbGVmdCwgcGFkIDIgYnl0ZXNcblx0XHRcdG91dHB1dCA9IFwiXCIsXG5cdFx0XHR0ZW1wLCBsZW5ndGhcblxuXHRcdGZ1bmN0aW9uIGVuY29kZSAobnVtKSB7XG5cdFx0XHRyZXR1cm4gbG9va3VwLmNoYXJBdChudW0pXG5cdFx0fVxuXG5cdFx0ZnVuY3Rpb24gdHJpcGxldFRvQmFzZTY0IChudW0pIHtcblx0XHRcdHJldHVybiBlbmNvZGUobnVtID4+IDE4ICYgMHgzRikgKyBlbmNvZGUobnVtID4+IDEyICYgMHgzRikgKyBlbmNvZGUobnVtID4+IDYgJiAweDNGKSArIGVuY29kZShudW0gJiAweDNGKVxuXHRcdH1cblxuXHRcdC8vIGdvIHRocm91Z2ggdGhlIGFycmF5IGV2ZXJ5IHRocmVlIGJ5dGVzLCB3ZSdsbCBkZWFsIHdpdGggdHJhaWxpbmcgc3R1ZmYgbGF0ZXJcblx0XHRmb3IgKGkgPSAwLCBsZW5ndGggPSB1aW50OC5sZW5ndGggLSBleHRyYUJ5dGVzOyBpIDwgbGVuZ3RoOyBpICs9IDMpIHtcblx0XHRcdHRlbXAgPSAodWludDhbaV0gPDwgMTYpICsgKHVpbnQ4W2kgKyAxXSA8PCA4KSArICh1aW50OFtpICsgMl0pXG5cdFx0XHRvdXRwdXQgKz0gdHJpcGxldFRvQmFzZTY0KHRlbXApXG5cdFx0fVxuXG5cdFx0Ly8gcGFkIHRoZSBlbmQgd2l0aCB6ZXJvcywgYnV0IG1ha2Ugc3VyZSB0byBub3QgZm9yZ2V0IHRoZSBleHRyYSBieXRlc1xuXHRcdHN3aXRjaCAoZXh0cmFCeXRlcykge1xuXHRcdFx0Y2FzZSAxOlxuXHRcdFx0XHR0ZW1wID0gdWludDhbdWludDgubGVuZ3RoIC0gMV1cblx0XHRcdFx0b3V0cHV0ICs9IGVuY29kZSh0ZW1wID4+IDIpXG5cdFx0XHRcdG91dHB1dCArPSBlbmNvZGUoKHRlbXAgPDwgNCkgJiAweDNGKVxuXHRcdFx0XHRvdXRwdXQgKz0gJz09J1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAyOlxuXHRcdFx0XHR0ZW1wID0gKHVpbnQ4W3VpbnQ4Lmxlbmd0aCAtIDJdIDw8IDgpICsgKHVpbnQ4W3VpbnQ4Lmxlbmd0aCAtIDFdKVxuXHRcdFx0XHRvdXRwdXQgKz0gZW5jb2RlKHRlbXAgPj4gMTApXG5cdFx0XHRcdG91dHB1dCArPSBlbmNvZGUoKHRlbXAgPj4gNCkgJiAweDNGKVxuXHRcdFx0XHRvdXRwdXQgKz0gZW5jb2RlKCh0ZW1wIDw8IDIpICYgMHgzRilcblx0XHRcdFx0b3V0cHV0ICs9ICc9J1xuXHRcdFx0XHRicmVha1xuXHRcdH1cblxuXHRcdHJldHVybiBvdXRwdXRcblx0fVxuXG5cdGV4cG9ydHMudG9CeXRlQXJyYXkgPSBiNjRUb0J5dGVBcnJheVxuXHRleHBvcnRzLmZyb21CeXRlQXJyYXkgPSB1aW50OFRvQmFzZTY0XG59KHR5cGVvZiBleHBvcnRzID09PSAndW5kZWZpbmVkJyA/ICh0aGlzLmJhc2U2NGpzID0ge30pIDogZXhwb3J0cykpXG4iLCJleHBvcnRzLnJlYWQgPSBmdW5jdGlvbiAoYnVmZmVyLCBvZmZzZXQsIGlzTEUsIG1MZW4sIG5CeXRlcykge1xuICB2YXIgZSwgbVxuICB2YXIgZUxlbiA9IG5CeXRlcyAqIDggLSBtTGVuIC0gMVxuICB2YXIgZU1heCA9ICgxIDw8IGVMZW4pIC0gMVxuICB2YXIgZUJpYXMgPSBlTWF4ID4+IDFcbiAgdmFyIG5CaXRzID0gLTdcbiAgdmFyIGkgPSBpc0xFID8gKG5CeXRlcyAtIDEpIDogMFxuICB2YXIgZCA9IGlzTEUgPyAtMSA6IDFcbiAgdmFyIHMgPSBidWZmZXJbb2Zmc2V0ICsgaV1cblxuICBpICs9IGRcblxuICBlID0gcyAmICgoMSA8PCAoLW5CaXRzKSkgLSAxKVxuICBzID4+PSAoLW5CaXRzKVxuICBuQml0cyArPSBlTGVuXG4gIGZvciAoOyBuQml0cyA+IDA7IGUgPSBlICogMjU2ICsgYnVmZmVyW29mZnNldCArIGldLCBpICs9IGQsIG5CaXRzIC09IDgpIHt9XG5cbiAgbSA9IGUgJiAoKDEgPDwgKC1uQml0cykpIC0gMSlcbiAgZSA+Pj0gKC1uQml0cylcbiAgbkJpdHMgKz0gbUxlblxuICBmb3IgKDsgbkJpdHMgPiAwOyBtID0gbSAqIDI1NiArIGJ1ZmZlcltvZmZzZXQgKyBpXSwgaSArPSBkLCBuQml0cyAtPSA4KSB7fVxuXG4gIGlmIChlID09PSAwKSB7XG4gICAgZSA9IDEgLSBlQmlhc1xuICB9IGVsc2UgaWYgKGUgPT09IGVNYXgpIHtcbiAgICByZXR1cm4gbSA/IE5hTiA6ICgocyA/IC0xIDogMSkgKiBJbmZpbml0eSlcbiAgfSBlbHNlIHtcbiAgICBtID0gbSArIE1hdGgucG93KDIsIG1MZW4pXG4gICAgZSA9IGUgLSBlQmlhc1xuICB9XG4gIHJldHVybiAocyA/IC0xIDogMSkgKiBtICogTWF0aC5wb3coMiwgZSAtIG1MZW4pXG59XG5cbmV4cG9ydHMud3JpdGUgPSBmdW5jdGlvbiAoYnVmZmVyLCB2YWx1ZSwgb2Zmc2V0LCBpc0xFLCBtTGVuLCBuQnl0ZXMpIHtcbiAgdmFyIGUsIG0sIGNcbiAgdmFyIGVMZW4gPSBuQnl0ZXMgKiA4IC0gbUxlbiAtIDFcbiAgdmFyIGVNYXggPSAoMSA8PCBlTGVuKSAtIDFcbiAgdmFyIGVCaWFzID0gZU1heCA+PiAxXG4gIHZhciBydCA9IChtTGVuID09PSAyMyA/IE1hdGgucG93KDIsIC0yNCkgLSBNYXRoLnBvdygyLCAtNzcpIDogMClcbiAgdmFyIGkgPSBpc0xFID8gMCA6IChuQnl0ZXMgLSAxKVxuICB2YXIgZCA9IGlzTEUgPyAxIDogLTFcbiAgdmFyIHMgPSB2YWx1ZSA8IDAgfHwgKHZhbHVlID09PSAwICYmIDEgLyB2YWx1ZSA8IDApID8gMSA6IDBcblxuICB2YWx1ZSA9IE1hdGguYWJzKHZhbHVlKVxuXG4gIGlmIChpc05hTih2YWx1ZSkgfHwgdmFsdWUgPT09IEluZmluaXR5KSB7XG4gICAgbSA9IGlzTmFOKHZhbHVlKSA/IDEgOiAwXG4gICAgZSA9IGVNYXhcbiAgfSBlbHNlIHtcbiAgICBlID0gTWF0aC5mbG9vcihNYXRoLmxvZyh2YWx1ZSkgLyBNYXRoLkxOMilcbiAgICBpZiAodmFsdWUgKiAoYyA9IE1hdGgucG93KDIsIC1lKSkgPCAxKSB7XG4gICAgICBlLS1cbiAgICAgIGMgKj0gMlxuICAgIH1cbiAgICBpZiAoZSArIGVCaWFzID49IDEpIHtcbiAgICAgIHZhbHVlICs9IHJ0IC8gY1xuICAgIH0gZWxzZSB7XG4gICAgICB2YWx1ZSArPSBydCAqIE1hdGgucG93KDIsIDEgLSBlQmlhcylcbiAgICB9XG4gICAgaWYgKHZhbHVlICogYyA+PSAyKSB7XG4gICAgICBlKytcbiAgICAgIGMgLz0gMlxuICAgIH1cblxuICAgIGlmIChlICsgZUJpYXMgPj0gZU1heCkge1xuICAgICAgbSA9IDBcbiAgICAgIGUgPSBlTWF4XG4gICAgfSBlbHNlIGlmIChlICsgZUJpYXMgPj0gMSkge1xuICAgICAgbSA9ICh2YWx1ZSAqIGMgLSAxKSAqIE1hdGgucG93KDIsIG1MZW4pXG4gICAgICBlID0gZSArIGVCaWFzXG4gICAgfSBlbHNlIHtcbiAgICAgIG0gPSB2YWx1ZSAqIE1hdGgucG93KDIsIGVCaWFzIC0gMSkgKiBNYXRoLnBvdygyLCBtTGVuKVxuICAgICAgZSA9IDBcbiAgICB9XG4gIH1cblxuICBmb3IgKDsgbUxlbiA+PSA4OyBidWZmZXJbb2Zmc2V0ICsgaV0gPSBtICYgMHhmZiwgaSArPSBkLCBtIC89IDI1NiwgbUxlbiAtPSA4KSB7fVxuXG4gIGUgPSAoZSA8PCBtTGVuKSB8IG1cbiAgZUxlbiArPSBtTGVuXG4gIGZvciAoOyBlTGVuID4gMDsgYnVmZmVyW29mZnNldCArIGldID0gZSAmIDB4ZmYsIGkgKz0gZCwgZSAvPSAyNTYsIGVMZW4gLT0gOCkge31cblxuICBidWZmZXJbb2Zmc2V0ICsgaSAtIGRdIHw9IHMgKiAxMjhcbn1cbiIsIlxuLyoqXG4gKiBpc0FycmF5XG4gKi9cblxudmFyIGlzQXJyYXkgPSBBcnJheS5pc0FycmF5O1xuXG4vKipcbiAqIHRvU3RyaW5nXG4gKi9cblxudmFyIHN0ciA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG5cbi8qKlxuICogV2hldGhlciBvciBub3QgdGhlIGdpdmVuIGB2YWxgXG4gKiBpcyBhbiBhcnJheS5cbiAqXG4gKiBleGFtcGxlOlxuICpcbiAqICAgICAgICBpc0FycmF5KFtdKTtcbiAqICAgICAgICAvLyA+IHRydWVcbiAqICAgICAgICBpc0FycmF5KGFyZ3VtZW50cyk7XG4gKiAgICAgICAgLy8gPiBmYWxzZVxuICogICAgICAgIGlzQXJyYXkoJycpO1xuICogICAgICAgIC8vID4gZmFsc2VcbiAqXG4gKiBAcGFyYW0ge21peGVkfSB2YWxcbiAqIEByZXR1cm4ge2Jvb2x9XG4gKi9cblxubW9kdWxlLmV4cG9ydHMgPSBpc0FycmF5IHx8IGZ1bmN0aW9uICh2YWwpIHtcbiAgcmV0dXJuICEhIHZhbCAmJiAnW29iamVjdCBBcnJheV0nID09IHN0ci5jYWxsKHZhbCk7XG59O1xuIiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG5cbmZ1bmN0aW9uIEV2ZW50RW1pdHRlcigpIHtcbiAgdGhpcy5fZXZlbnRzID0gdGhpcy5fZXZlbnRzIHx8IHt9O1xuICB0aGlzLl9tYXhMaXN0ZW5lcnMgPSB0aGlzLl9tYXhMaXN0ZW5lcnMgfHwgdW5kZWZpbmVkO1xufVxubW9kdWxlLmV4cG9ydHMgPSBFdmVudEVtaXR0ZXI7XG5cbi8vIEJhY2t3YXJkcy1jb21wYXQgd2l0aCBub2RlIDAuMTAueFxuRXZlbnRFbWl0dGVyLkV2ZW50RW1pdHRlciA9IEV2ZW50RW1pdHRlcjtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5fZXZlbnRzID0gdW5kZWZpbmVkO1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5fbWF4TGlzdGVuZXJzID0gdW5kZWZpbmVkO1xuXG4vLyBCeSBkZWZhdWx0IEV2ZW50RW1pdHRlcnMgd2lsbCBwcmludCBhIHdhcm5pbmcgaWYgbW9yZSB0aGFuIDEwIGxpc3RlbmVycyBhcmVcbi8vIGFkZGVkIHRvIGl0LiBUaGlzIGlzIGEgdXNlZnVsIGRlZmF1bHQgd2hpY2ggaGVscHMgZmluZGluZyBtZW1vcnkgbGVha3MuXG5FdmVudEVtaXR0ZXIuZGVmYXVsdE1heExpc3RlbmVycyA9IDEwO1xuXG4vLyBPYnZpb3VzbHkgbm90IGFsbCBFbWl0dGVycyBzaG91bGQgYmUgbGltaXRlZCB0byAxMC4gVGhpcyBmdW5jdGlvbiBhbGxvd3Ncbi8vIHRoYXQgdG8gYmUgaW5jcmVhc2VkLiBTZXQgdG8gemVybyBmb3IgdW5saW1pdGVkLlxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5zZXRNYXhMaXN0ZW5lcnMgPSBmdW5jdGlvbihuKSB7XG4gIGlmICghaXNOdW1iZXIobikgfHwgbiA8IDAgfHwgaXNOYU4obikpXG4gICAgdGhyb3cgVHlwZUVycm9yKCduIG11c3QgYmUgYSBwb3NpdGl2ZSBudW1iZXInKTtcbiAgdGhpcy5fbWF4TGlzdGVuZXJzID0gbjtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLmVtaXQgPSBmdW5jdGlvbih0eXBlKSB7XG4gIHZhciBlciwgaGFuZGxlciwgbGVuLCBhcmdzLCBpLCBsaXN0ZW5lcnM7XG5cbiAgaWYgKCF0aGlzLl9ldmVudHMpXG4gICAgdGhpcy5fZXZlbnRzID0ge307XG5cbiAgLy8gSWYgdGhlcmUgaXMgbm8gJ2Vycm9yJyBldmVudCBsaXN0ZW5lciB0aGVuIHRocm93LlxuICBpZiAodHlwZSA9PT0gJ2Vycm9yJykge1xuICAgIGlmICghdGhpcy5fZXZlbnRzLmVycm9yIHx8XG4gICAgICAgIChpc09iamVjdCh0aGlzLl9ldmVudHMuZXJyb3IpICYmICF0aGlzLl9ldmVudHMuZXJyb3IubGVuZ3RoKSkge1xuICAgICAgZXIgPSBhcmd1bWVudHNbMV07XG4gICAgICBpZiAoZXIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICB0aHJvdyBlcjsgLy8gVW5oYW5kbGVkICdlcnJvcicgZXZlbnRcbiAgICAgIH1cbiAgICAgIHRocm93IFR5cGVFcnJvcignVW5jYXVnaHQsIHVuc3BlY2lmaWVkIFwiZXJyb3JcIiBldmVudC4nKTtcbiAgICB9XG4gIH1cblxuICBoYW5kbGVyID0gdGhpcy5fZXZlbnRzW3R5cGVdO1xuXG4gIGlmIChpc1VuZGVmaW5lZChoYW5kbGVyKSlcbiAgICByZXR1cm4gZmFsc2U7XG5cbiAgaWYgKGlzRnVuY3Rpb24oaGFuZGxlcikpIHtcbiAgICBzd2l0Y2ggKGFyZ3VtZW50cy5sZW5ndGgpIHtcbiAgICAgIC8vIGZhc3QgY2FzZXNcbiAgICAgIGNhc2UgMTpcbiAgICAgICAgaGFuZGxlci5jYWxsKHRoaXMpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgMjpcbiAgICAgICAgaGFuZGxlci5jYWxsKHRoaXMsIGFyZ3VtZW50c1sxXSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAzOlxuICAgICAgICBoYW5kbGVyLmNhbGwodGhpcywgYXJndW1lbnRzWzFdLCBhcmd1bWVudHNbMl0pO1xuICAgICAgICBicmVhaztcbiAgICAgIC8vIHNsb3dlclxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgbGVuID0gYXJndW1lbnRzLmxlbmd0aDtcbiAgICAgICAgYXJncyA9IG5ldyBBcnJheShsZW4gLSAxKTtcbiAgICAgICAgZm9yIChpID0gMTsgaSA8IGxlbjsgaSsrKVxuICAgICAgICAgIGFyZ3NbaSAtIDFdID0gYXJndW1lbnRzW2ldO1xuICAgICAgICBoYW5kbGVyLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChpc09iamVjdChoYW5kbGVyKSkge1xuICAgIGxlbiA9IGFyZ3VtZW50cy5sZW5ndGg7XG4gICAgYXJncyA9IG5ldyBBcnJheShsZW4gLSAxKTtcbiAgICBmb3IgKGkgPSAxOyBpIDwgbGVuOyBpKyspXG4gICAgICBhcmdzW2kgLSAxXSA9IGFyZ3VtZW50c1tpXTtcblxuICAgIGxpc3RlbmVycyA9IGhhbmRsZXIuc2xpY2UoKTtcbiAgICBsZW4gPSBsaXN0ZW5lcnMubGVuZ3RoO1xuICAgIGZvciAoaSA9IDA7IGkgPCBsZW47IGkrKylcbiAgICAgIGxpc3RlbmVyc1tpXS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgfVxuXG4gIHJldHVybiB0cnVlO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5hZGRMaXN0ZW5lciA9IGZ1bmN0aW9uKHR5cGUsIGxpc3RlbmVyKSB7XG4gIHZhciBtO1xuXG4gIGlmICghaXNGdW5jdGlvbihsaXN0ZW5lcikpXG4gICAgdGhyb3cgVHlwZUVycm9yKCdsaXN0ZW5lciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcblxuICBpZiAoIXRoaXMuX2V2ZW50cylcbiAgICB0aGlzLl9ldmVudHMgPSB7fTtcblxuICAvLyBUbyBhdm9pZCByZWN1cnNpb24gaW4gdGhlIGNhc2UgdGhhdCB0eXBlID09PSBcIm5ld0xpc3RlbmVyXCIhIEJlZm9yZVxuICAvLyBhZGRpbmcgaXQgdG8gdGhlIGxpc3RlbmVycywgZmlyc3QgZW1pdCBcIm5ld0xpc3RlbmVyXCIuXG4gIGlmICh0aGlzLl9ldmVudHMubmV3TGlzdGVuZXIpXG4gICAgdGhpcy5lbWl0KCduZXdMaXN0ZW5lcicsIHR5cGUsXG4gICAgICAgICAgICAgIGlzRnVuY3Rpb24obGlzdGVuZXIubGlzdGVuZXIpID9cbiAgICAgICAgICAgICAgbGlzdGVuZXIubGlzdGVuZXIgOiBsaXN0ZW5lcik7XG5cbiAgaWYgKCF0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgLy8gT3B0aW1pemUgdGhlIGNhc2Ugb2Ygb25lIGxpc3RlbmVyLiBEb24ndCBuZWVkIHRoZSBleHRyYSBhcnJheSBvYmplY3QuXG4gICAgdGhpcy5fZXZlbnRzW3R5cGVdID0gbGlzdGVuZXI7XG4gIGVsc2UgaWYgKGlzT2JqZWN0KHRoaXMuX2V2ZW50c1t0eXBlXSkpXG4gICAgLy8gSWYgd2UndmUgYWxyZWFkeSBnb3QgYW4gYXJyYXksIGp1c3QgYXBwZW5kLlxuICAgIHRoaXMuX2V2ZW50c1t0eXBlXS5wdXNoKGxpc3RlbmVyKTtcbiAgZWxzZVxuICAgIC8vIEFkZGluZyB0aGUgc2Vjb25kIGVsZW1lbnQsIG5lZWQgdG8gY2hhbmdlIHRvIGFycmF5LlxuICAgIHRoaXMuX2V2ZW50c1t0eXBlXSA9IFt0aGlzLl9ldmVudHNbdHlwZV0sIGxpc3RlbmVyXTtcblxuICAvLyBDaGVjayBmb3IgbGlzdGVuZXIgbGVha1xuICBpZiAoaXNPYmplY3QodGhpcy5fZXZlbnRzW3R5cGVdKSAmJiAhdGhpcy5fZXZlbnRzW3R5cGVdLndhcm5lZCkge1xuICAgIHZhciBtO1xuICAgIGlmICghaXNVbmRlZmluZWQodGhpcy5fbWF4TGlzdGVuZXJzKSkge1xuICAgICAgbSA9IHRoaXMuX21heExpc3RlbmVycztcbiAgICB9IGVsc2Uge1xuICAgICAgbSA9IEV2ZW50RW1pdHRlci5kZWZhdWx0TWF4TGlzdGVuZXJzO1xuICAgIH1cblxuICAgIGlmIChtICYmIG0gPiAwICYmIHRoaXMuX2V2ZW50c1t0eXBlXS5sZW5ndGggPiBtKSB7XG4gICAgICB0aGlzLl9ldmVudHNbdHlwZV0ud2FybmVkID0gdHJ1ZTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJyhub2RlKSB3YXJuaW5nOiBwb3NzaWJsZSBFdmVudEVtaXR0ZXIgbWVtb3J5ICcgK1xuICAgICAgICAgICAgICAgICAgICAnbGVhayBkZXRlY3RlZC4gJWQgbGlzdGVuZXJzIGFkZGVkLiAnICtcbiAgICAgICAgICAgICAgICAgICAgJ1VzZSBlbWl0dGVyLnNldE1heExpc3RlbmVycygpIHRvIGluY3JlYXNlIGxpbWl0LicsXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2V2ZW50c1t0eXBlXS5sZW5ndGgpO1xuICAgICAgaWYgKHR5cGVvZiBjb25zb2xlLnRyYWNlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIC8vIG5vdCBzdXBwb3J0ZWQgaW4gSUUgMTBcbiAgICAgICAgY29uc29sZS50cmFjZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0aGlzO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5vbiA9IEV2ZW50RW1pdHRlci5wcm90b3R5cGUuYWRkTGlzdGVuZXI7XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUub25jZSA9IGZ1bmN0aW9uKHR5cGUsIGxpc3RlbmVyKSB7XG4gIGlmICghaXNGdW5jdGlvbihsaXN0ZW5lcikpXG4gICAgdGhyb3cgVHlwZUVycm9yKCdsaXN0ZW5lciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcblxuICB2YXIgZmlyZWQgPSBmYWxzZTtcblxuICBmdW5jdGlvbiBnKCkge1xuICAgIHRoaXMucmVtb3ZlTGlzdGVuZXIodHlwZSwgZyk7XG5cbiAgICBpZiAoIWZpcmVkKSB7XG4gICAgICBmaXJlZCA9IHRydWU7XG4gICAgICBsaXN0ZW5lci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH1cbiAgfVxuXG4gIGcubGlzdGVuZXIgPSBsaXN0ZW5lcjtcbiAgdGhpcy5vbih0eXBlLCBnKTtcblxuICByZXR1cm4gdGhpcztcbn07XG5cbi8vIGVtaXRzIGEgJ3JlbW92ZUxpc3RlbmVyJyBldmVudCBpZmYgdGhlIGxpc3RlbmVyIHdhcyByZW1vdmVkXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyID0gZnVuY3Rpb24odHlwZSwgbGlzdGVuZXIpIHtcbiAgdmFyIGxpc3QsIHBvc2l0aW9uLCBsZW5ndGgsIGk7XG5cbiAgaWYgKCFpc0Z1bmN0aW9uKGxpc3RlbmVyKSlcbiAgICB0aHJvdyBUeXBlRXJyb3IoJ2xpc3RlbmVyIG11c3QgYmUgYSBmdW5jdGlvbicpO1xuXG4gIGlmICghdGhpcy5fZXZlbnRzIHx8ICF0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgcmV0dXJuIHRoaXM7XG5cbiAgbGlzdCA9IHRoaXMuX2V2ZW50c1t0eXBlXTtcbiAgbGVuZ3RoID0gbGlzdC5sZW5ndGg7XG4gIHBvc2l0aW9uID0gLTE7XG5cbiAgaWYgKGxpc3QgPT09IGxpc3RlbmVyIHx8XG4gICAgICAoaXNGdW5jdGlvbihsaXN0Lmxpc3RlbmVyKSAmJiBsaXN0Lmxpc3RlbmVyID09PSBsaXN0ZW5lcikpIHtcbiAgICBkZWxldGUgdGhpcy5fZXZlbnRzW3R5cGVdO1xuICAgIGlmICh0aGlzLl9ldmVudHMucmVtb3ZlTGlzdGVuZXIpXG4gICAgICB0aGlzLmVtaXQoJ3JlbW92ZUxpc3RlbmVyJywgdHlwZSwgbGlzdGVuZXIpO1xuXG4gIH0gZWxzZSBpZiAoaXNPYmplY3QobGlzdCkpIHtcbiAgICBmb3IgKGkgPSBsZW5ndGg7IGktLSA+IDA7KSB7XG4gICAgICBpZiAobGlzdFtpXSA9PT0gbGlzdGVuZXIgfHxcbiAgICAgICAgICAobGlzdFtpXS5saXN0ZW5lciAmJiBsaXN0W2ldLmxpc3RlbmVyID09PSBsaXN0ZW5lcikpIHtcbiAgICAgICAgcG9zaXRpb24gPSBpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAocG9zaXRpb24gPCAwKVxuICAgICAgcmV0dXJuIHRoaXM7XG5cbiAgICBpZiAobGlzdC5sZW5ndGggPT09IDEpIHtcbiAgICAgIGxpc3QubGVuZ3RoID0gMDtcbiAgICAgIGRlbGV0ZSB0aGlzLl9ldmVudHNbdHlwZV07XG4gICAgfSBlbHNlIHtcbiAgICAgIGxpc3Quc3BsaWNlKHBvc2l0aW9uLCAxKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5fZXZlbnRzLnJlbW92ZUxpc3RlbmVyKVxuICAgICAgdGhpcy5lbWl0KCdyZW1vdmVMaXN0ZW5lcicsIHR5cGUsIGxpc3RlbmVyKTtcbiAgfVxuXG4gIHJldHVybiB0aGlzO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBmdW5jdGlvbih0eXBlKSB7XG4gIHZhciBrZXksIGxpc3RlbmVycztcblxuICBpZiAoIXRoaXMuX2V2ZW50cylcbiAgICByZXR1cm4gdGhpcztcblxuICAvLyBub3QgbGlzdGVuaW5nIGZvciByZW1vdmVMaXN0ZW5lciwgbm8gbmVlZCB0byBlbWl0XG4gIGlmICghdGhpcy5fZXZlbnRzLnJlbW92ZUxpc3RlbmVyKSB7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApXG4gICAgICB0aGlzLl9ldmVudHMgPSB7fTtcbiAgICBlbHNlIGlmICh0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgICBkZWxldGUgdGhpcy5fZXZlbnRzW3R5cGVdO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLy8gZW1pdCByZW1vdmVMaXN0ZW5lciBmb3IgYWxsIGxpc3RlbmVycyBvbiBhbGwgZXZlbnRzXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgZm9yIChrZXkgaW4gdGhpcy5fZXZlbnRzKSB7XG4gICAgICBpZiAoa2V5ID09PSAncmVtb3ZlTGlzdGVuZXInKSBjb250aW51ZTtcbiAgICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKGtleSk7XG4gICAgfVxuICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCdyZW1vdmVMaXN0ZW5lcicpO1xuICAgIHRoaXMuX2V2ZW50cyA9IHt9O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgbGlzdGVuZXJzID0gdGhpcy5fZXZlbnRzW3R5cGVdO1xuXG4gIGlmIChpc0Z1bmN0aW9uKGxpc3RlbmVycykpIHtcbiAgICB0aGlzLnJlbW92ZUxpc3RlbmVyKHR5cGUsIGxpc3RlbmVycyk7XG4gIH0gZWxzZSB7XG4gICAgLy8gTElGTyBvcmRlclxuICAgIHdoaWxlIChsaXN0ZW5lcnMubGVuZ3RoKVxuICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcnNbbGlzdGVuZXJzLmxlbmd0aCAtIDFdKTtcbiAgfVxuICBkZWxldGUgdGhpcy5fZXZlbnRzW3R5cGVdO1xuXG4gIHJldHVybiB0aGlzO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5saXN0ZW5lcnMgPSBmdW5jdGlvbih0eXBlKSB7XG4gIHZhciByZXQ7XG4gIGlmICghdGhpcy5fZXZlbnRzIHx8ICF0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgcmV0ID0gW107XG4gIGVsc2UgaWYgKGlzRnVuY3Rpb24odGhpcy5fZXZlbnRzW3R5cGVdKSlcbiAgICByZXQgPSBbdGhpcy5fZXZlbnRzW3R5cGVdXTtcbiAgZWxzZVxuICAgIHJldCA9IHRoaXMuX2V2ZW50c1t0eXBlXS5zbGljZSgpO1xuICByZXR1cm4gcmV0O1xufTtcblxuRXZlbnRFbWl0dGVyLmxpc3RlbmVyQ291bnQgPSBmdW5jdGlvbihlbWl0dGVyLCB0eXBlKSB7XG4gIHZhciByZXQ7XG4gIGlmICghZW1pdHRlci5fZXZlbnRzIHx8ICFlbWl0dGVyLl9ldmVudHNbdHlwZV0pXG4gICAgcmV0ID0gMDtcbiAgZWxzZSBpZiAoaXNGdW5jdGlvbihlbWl0dGVyLl9ldmVudHNbdHlwZV0pKVxuICAgIHJldCA9IDE7XG4gIGVsc2VcbiAgICByZXQgPSBlbWl0dGVyLl9ldmVudHNbdHlwZV0ubGVuZ3RoO1xuICByZXR1cm4gcmV0O1xufTtcblxuZnVuY3Rpb24gaXNGdW5jdGlvbihhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdmdW5jdGlvbic7XG59XG5cbmZ1bmN0aW9uIGlzTnVtYmVyKGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ251bWJlcic7XG59XG5cbmZ1bmN0aW9uIGlzT2JqZWN0KGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ29iamVjdCcgJiYgYXJnICE9PSBudWxsO1xufVxuXG5mdW5jdGlvbiBpc1VuZGVmaW5lZChhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PT0gdm9pZCAwO1xufVxuIiwiLy8gc2hpbSBmb3IgdXNpbmcgcHJvY2VzcyBpbiBicm93c2VyXG5cbnZhciBwcm9jZXNzID0gbW9kdWxlLmV4cG9ydHMgPSB7fTtcbnZhciBxdWV1ZSA9IFtdO1xudmFyIGRyYWluaW5nID0gZmFsc2U7XG52YXIgY3VycmVudFF1ZXVlO1xudmFyIHF1ZXVlSW5kZXggPSAtMTtcblxuZnVuY3Rpb24gY2xlYW5VcE5leHRUaWNrKCkge1xuICAgIGRyYWluaW5nID0gZmFsc2U7XG4gICAgaWYgKGN1cnJlbnRRdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgcXVldWUgPSBjdXJyZW50UXVldWUuY29uY2F0KHF1ZXVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBxdWV1ZUluZGV4ID0gLTE7XG4gICAgfVxuICAgIGlmIChxdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgZHJhaW5RdWV1ZSgpO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gZHJhaW5RdWV1ZSgpIHtcbiAgICBpZiAoZHJhaW5pbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgdGltZW91dCA9IHNldFRpbWVvdXQoY2xlYW5VcE5leHRUaWNrKTtcbiAgICBkcmFpbmluZyA9IHRydWU7XG5cbiAgICB2YXIgbGVuID0gcXVldWUubGVuZ3RoO1xuICAgIHdoaWxlKGxlbikge1xuICAgICAgICBjdXJyZW50UXVldWUgPSBxdWV1ZTtcbiAgICAgICAgcXVldWUgPSBbXTtcbiAgICAgICAgd2hpbGUgKCsrcXVldWVJbmRleCA8IGxlbikge1xuICAgICAgICAgICAgaWYgKGN1cnJlbnRRdWV1ZSkge1xuICAgICAgICAgICAgICAgIGN1cnJlbnRRdWV1ZVtxdWV1ZUluZGV4XS5ydW4oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBxdWV1ZUluZGV4ID0gLTE7XG4gICAgICAgIGxlbiA9IHF1ZXVlLmxlbmd0aDtcbiAgICB9XG4gICAgY3VycmVudFF1ZXVlID0gbnVsbDtcbiAgICBkcmFpbmluZyA9IGZhbHNlO1xuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbn1cblxucHJvY2Vzcy5uZXh0VGljayA9IGZ1bmN0aW9uIChmdW4pIHtcbiAgICB2YXIgYXJncyA9IG5ldyBBcnJheShhcmd1bWVudHMubGVuZ3RoIC0gMSk7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBhcmdzW2kgLSAxXSA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBxdWV1ZS5wdXNoKG5ldyBJdGVtKGZ1biwgYXJncykpO1xuICAgIGlmIChxdWV1ZS5sZW5ndGggPT09IDEgJiYgIWRyYWluaW5nKSB7XG4gICAgICAgIHNldFRpbWVvdXQoZHJhaW5RdWV1ZSwgMCk7XG4gICAgfVxufTtcblxuLy8gdjggbGlrZXMgcHJlZGljdGlibGUgb2JqZWN0c1xuZnVuY3Rpb24gSXRlbShmdW4sIGFycmF5KSB7XG4gICAgdGhpcy5mdW4gPSBmdW47XG4gICAgdGhpcy5hcnJheSA9IGFycmF5O1xufVxuSXRlbS5wcm90b3R5cGUucnVuID0gZnVuY3Rpb24gKCkge1xuICAgIHRoaXMuZnVuLmFwcGx5KG51bGwsIHRoaXMuYXJyYXkpO1xufTtcbnByb2Nlc3MudGl0bGUgPSAnYnJvd3Nlcic7XG5wcm9jZXNzLmJyb3dzZXIgPSB0cnVlO1xucHJvY2Vzcy5lbnYgPSB7fTtcbnByb2Nlc3MuYXJndiA9IFtdO1xucHJvY2Vzcy52ZXJzaW9uID0gJyc7IC8vIGVtcHR5IHN0cmluZyB0byBhdm9pZCByZWdleHAgaXNzdWVzXG5wcm9jZXNzLnZlcnNpb25zID0ge307XG5cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5wcm9jZXNzLm9uID0gbm9vcDtcbnByb2Nlc3MuYWRkTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5vbmNlID0gbm9vcDtcbnByb2Nlc3Mub2ZmID0gbm9vcDtcbnByb2Nlc3MucmVtb3ZlTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBub29wO1xucHJvY2Vzcy5lbWl0ID0gbm9vcDtcblxucHJvY2Vzcy5iaW5kaW5nID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3Byb2Nlc3MuYmluZGluZyBpcyBub3Qgc3VwcG9ydGVkJyk7XG59O1xuXG5wcm9jZXNzLmN3ZCA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuICcvJyB9O1xucHJvY2Vzcy5jaGRpciA9IGZ1bmN0aW9uIChkaXIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3Byb2Nlc3MuY2hkaXIgaXMgbm90IHN1cHBvcnRlZCcpO1xufTtcbnByb2Nlc3MudW1hc2sgPSBmdW5jdGlvbigpIHsgcmV0dXJuIDA7IH07XG4iLCIvL1xuLy8gRmlsZVJlYWRlclxuLy9cbi8vIGh0dHA6Ly93d3cudzMub3JnL1RSL0ZpbGVBUEkvI2Rmbi1maWxlcmVhZGVyXG4vLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi9ET00vRmlsZVJlYWRlclxuKGZ1bmN0aW9uICgpIHtcbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgdmFyIGZzID0gcmVxdWlyZShcImZzXCIpXG4gICAgLCBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlclxuICAgIDtcblxuICBmdW5jdGlvbiBkb29wKGZuLCBhcmdzLCBjb250ZXh0KSB7XG4gICAgaWYgKCdmdW5jdGlvbicgPT09IHR5cGVvZiBmbikge1xuICAgICAgZm4uYXBwbHkoY29udGV4dCwgYXJncyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gdG9EYXRhVXJsKGRhdGEsIHR5cGUpIHtcbiAgICAvLyB2YXIgZGF0YSA9IHNlbGYucmVzdWx0O1xuICAgIHZhciBkYXRhVXJsID0gJ2RhdGE6JztcblxuICAgIGlmICh0eXBlKSB7XG4gICAgICBkYXRhVXJsICs9IHR5cGUgKyAnOyc7XG4gICAgfVxuXG4gICAgaWYgKC90ZXh0L2kudGVzdCh0eXBlKSkge1xuICAgICAgZGF0YVVybCArPSAnY2hhcnNldD11dGYtOCwnO1xuICAgICAgZGF0YVVybCArPSBkYXRhLnRvU3RyaW5nKCd1dGY4Jyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRhdGFVcmwgKz0gJ2Jhc2U2NCwnO1xuICAgICAgZGF0YVVybCArPSBkYXRhLnRvU3RyaW5nKCdiYXNlNjQnKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZGF0YVVybDtcbiAgfVxuXG4gIGZ1bmN0aW9uIG1hcERhdGFUb0Zvcm1hdChmaWxlLCBkYXRhLCBmb3JtYXQsIGVuY29kaW5nKSB7XG4gICAgLy8gdmFyIGRhdGEgPSBzZWxmLnJlc3VsdDtcblxuICAgIHN3aXRjaChmb3JtYXQpIHtcbiAgICAgIGNhc2UgJ2J1ZmZlcic6XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICAgIHJldHVybiBkYXRhLnRvU3RyaW5nKCdiaW5hcnknKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdkYXRhVXJsJzpcbiAgICAgICAgcmV0dXJuIHRvRGF0YVVybChkYXRhLCBmaWxlLnR5cGUpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ3RleHQnOlxuICAgICAgICByZXR1cm4gZGF0YS50b1N0cmluZyhlbmNvZGluZyB8fCAndXRmOCcpO1xuICAgICAgICBicmVhaztcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBGaWxlUmVhZGVyKCkge1xuICAgIHZhciBzZWxmID0gdGhpcyxcbiAgICAgIGVtaXR0ZXIgPSBuZXcgRXZlbnRFbWl0dGVyLFxuICAgICAgZmlsZTtcblxuICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lciA9IGZ1bmN0aW9uIChvbiwgY2FsbGJhY2spIHtcbiAgICAgIGVtaXR0ZXIub24ob24sIGNhbGxiYWNrKTtcbiAgICB9O1xuICAgIHNlbGYucmVtb3ZlRXZlbnRMaXN0ZW5lciA9IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICAgICAgZW1pdHRlci5yZW1vdmVMaXN0ZW5lcihjYWxsYmFjayk7XG4gICAgfVxuICAgIHNlbGYuZGlzcGF0Y2hFdmVudCA9IGZ1bmN0aW9uIChvbikge1xuICAgICAgZW1pdHRlci5lbWl0KG9uKTtcbiAgICB9XG5cbiAgICBzZWxmLkVNUFRZID0gMDtcbiAgICBzZWxmLkxPQURJTkcgPSAxO1xuICAgIHNlbGYuRE9ORSA9IDI7XG5cbiAgICBzZWxmLmVycm9yID0gdW5kZWZpbmVkOyAgICAgICAgIC8vIFJlYWQgb25seVxuICAgIHNlbGYucmVhZHlTdGF0ZSA9IHNlbGYuRU1QVFk7ICAgLy8gUmVhZCBvbmx5XG4gICAgc2VsZi5yZXN1bHQgPSB1bmRlZmluZWQ7ICAgICAgICAvLyBSb2FkIG9ubHlcblxuICAgIC8vIG5vbi1zdGFuZGFyZFxuICAgIHNlbGYub24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICBlbWl0dGVyLm9uLmFwcGx5KGVtaXR0ZXIsIGFyZ3VtZW50cyk7XG4gICAgfVxuICAgIHNlbGYubm9kZUNodW5rZWRFbmNvZGluZyA9IGZhbHNlO1xuICAgIHNlbGYuc2V0Tm9kZUNodW5rZWRFbmNvZGluZyA9IGZ1bmN0aW9uICh2YWwpIHtcbiAgICAgIHNlbGYubm9kZUNodW5rZWRFbmNvZGluZyA9IHZhbDtcbiAgICB9O1xuICAgIC8vIGVuZCBub24tc3RhbmRhcmRcblxuXG5cbiAgICAvLyBXaGF0ZXZlciB0aGUgZmlsZSBvYmplY3QgaXMsIHR1cm4gaXQgaW50byBhIE5vZGUuSlMgRmlsZS5TdHJlYW1cbiAgICBmdW5jdGlvbiBjcmVhdGVGaWxlU3RyZWFtKCkge1xuICAgICAgdmFyIHN0cmVhbSA9IG5ldyBFdmVudEVtaXR0ZXIoKSxcbiAgICAgICAgY2h1bmtlZCA9IHNlbGYubm9kZUNodW5rZWRFbmNvZGluZztcblxuICAgICAgLy8gYXR0ZW1wdCB0byBtYWtlIHRoZSBsZW5ndGggY29tcHV0YWJsZVxuICAgICAgaWYgKCFmaWxlLnNpemUgJiYgY2h1bmtlZCAmJiBmaWxlLnBhdGgpIHtcbiAgICAgICAgZnMuc3RhdChmaWxlLnBhdGgsIGZ1bmN0aW9uIChlcnIsIHN0YXQpIHtcbiAgICAgICAgICBmaWxlLnNpemUgPSBzdGF0LnNpemU7XG4gICAgICAgICAgZmlsZS5sYXN0TW9kaWZpZWREYXRlID0gc3RhdC5tdGltZTtcbiAgICAgICAgfSk7XG4gICAgICB9XG5cblxuICAgICAgLy8gVGhlIHN0cmVhbSBleGlzdHMsIGRvIG5vdGhpbmcgbW9yZVxuICAgICAgaWYgKGZpbGUuc3RyZWFtKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuXG4gICAgICAvLyBDcmVhdGUgYSByZWFkIHN0cmVhbSBmcm9tIGEgYnVmZmVyXG4gICAgICBpZiAoZmlsZS5idWZmZXIpIHtcbiAgICAgICAgcHJvY2Vzcy5uZXh0VGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgc3RyZWFtLmVtaXQoJ2RhdGEnLCBmaWxlLmJ1ZmZlcik7XG4gICAgICAgICAgc3RyZWFtLmVtaXQoJ2VuZCcpO1xuICAgICAgICB9KTtcbiAgICAgICAgZmlsZS5zdHJlYW0gPSBzdHJlYW07XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuXG4gICAgICAvLyBDcmVhdGUgYSByZWFkIHN0cmVhbSBmcm9tIGEgZmlsZVxuICAgICAgaWYgKGZpbGUucGF0aCkge1xuICAgICAgICAvLyBUT0RPIHVybFxuICAgICAgICBpZiAoIWNodW5rZWQpIHtcbiAgICAgICAgICBmcy5yZWFkRmlsZShmaWxlLnBhdGgsIGZ1bmN0aW9uIChlcnIsIGRhdGEpIHtcbiAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgc3RyZWFtLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgICAgIHN0cmVhbS5lbWl0KCdkYXRhJywgZGF0YSk7XG4gICAgICAgICAgICAgIHN0cmVhbS5lbWl0KCdlbmQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGZpbGUuc3RyZWFtID0gc3RyZWFtO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRPRE8gZG9uJ3QgZHVwbGljYXRlIHRoaXMgY29kZSBoZXJlLFxuICAgICAgICAvLyBleHBvc2UgYSBtZXRob2QgaW4gRmlsZSBpbnN0ZWFkXG4gICAgICAgIGZpbGUuc3RyZWFtID0gZnMuY3JlYXRlUmVhZFN0cmVhbShmaWxlLnBhdGgpO1xuICAgICAgfVxuICAgIH1cblxuXG5cbiAgICAvLyBiZWZvcmUgYW55IG90aGVyIGxpc3RlbmVycyBhcmUgYWRkZWRcbiAgICBlbWl0dGVyLm9uKCdhYm9ydCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYucmVhZHlTdGF0ZSA9IHNlbGYuRE9ORTtcbiAgICB9KTtcblxuXG5cbiAgICAvLyBNYXAgYGVycm9yYCwgYHByb2dyZXNzYCwgYGxvYWRgLCBhbmQgYGxvYWRlbmRgXG4gICAgZnVuY3Rpb24gbWFwU3RyZWFtVG9FbWl0dGVyKGZvcm1hdCwgZW5jb2RpbmcpIHtcbiAgICAgIHZhciBzdHJlYW0gPSBmaWxlLnN0cmVhbSxcbiAgICAgICAgYnVmZmVycyA9IFtdLFxuICAgICAgICBjaHVua2VkID0gc2VsZi5ub2RlQ2h1bmtlZEVuY29kaW5nO1xuXG4gICAgICBidWZmZXJzLmRhdGFMZW5ndGggPSAwO1xuXG4gICAgICBzdHJlYW0ub24oJ2Vycm9yJywgZnVuY3Rpb24gKGVycikge1xuICAgICAgICBpZiAoc2VsZi5ET05FID09PSBzZWxmLnJlYWR5U3RhdGUpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZWxmLnJlYWR5U3RhdGUgPSBzZWxmLkRPTkU7XG4gICAgICAgIHNlbGYuZXJyb3IgPSBlcnI7XG4gICAgICAgIGVtaXR0ZXIuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgfSk7XG5cbiAgICAgIHN0cmVhbS5vbignZGF0YScsIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgIGlmIChzZWxmLkRPTkUgPT09IHNlbGYucmVhZHlTdGF0ZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGJ1ZmZlcnMuZGF0YUxlbmd0aCArPSBkYXRhLmxlbmd0aDtcbiAgICAgICAgYnVmZmVycy5wdXNoKGRhdGEpO1xuXG4gICAgICAgIGVtaXR0ZXIuZW1pdCgncHJvZ3Jlc3MnLCB7XG4gICAgICAgICAgLy8gZnMuc3RhdCB3aWxsIHByb2JhYmx5IGNvbXBsZXRlIGJlZm9yZSB0aGlzXG4gICAgICAgICAgLy8gYnV0IHBvc3NpYmx5IGl0IHdpbGwgbm90LCBoZW5jZSB0aGUgY2hlY2tcbiAgICAgICAgICBsZW5ndGhDb21wdXRhYmxlOiAoIWlzTmFOKGZpbGUuc2l6ZSkpID8gdHJ1ZSA6IGZhbHNlLFxuICAgICAgICAgIGxvYWRlZDogYnVmZmVycy5kYXRhTGVuZ3RoLFxuICAgICAgICAgIHRvdGFsOiBmaWxlLnNpemVcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZW1pdHRlci5lbWl0KCdkYXRhJywgZGF0YSk7XG4gICAgICB9KTtcblxuICAgICAgc3RyZWFtLm9uKCdlbmQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmIChzZWxmLkRPTkUgPT09IHNlbGYucmVhZHlTdGF0ZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBkYXRhO1xuXG4gICAgICAgIGlmIChidWZmZXJzLmxlbmd0aCA+IDEgKSB7XG4gICAgICAgICAgZGF0YSA9IEJ1ZmZlci5jb25jYXQoYnVmZmVycyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGF0YSA9IGJ1ZmZlcnNbMF07XG4gICAgICAgIH1cblxuICAgICAgICBzZWxmLnJlYWR5U3RhdGUgPSBzZWxmLkRPTkU7XG4gICAgICAgIHNlbGYucmVzdWx0ID0gbWFwRGF0YVRvRm9ybWF0KGZpbGUsIGRhdGEsIGZvcm1hdCwgZW5jb2RpbmcpO1xuICAgICAgICBlbWl0dGVyLmVtaXQoJ2xvYWQnLCB7XG4gICAgICAgICAgdGFyZ2V0OiB7XG4gICAgICAgICAgICAvLyBub24tc3RhbmRhcmRcbiAgICAgICAgICAgIG5vZGVCdWZmZXJSZXN1bHQ6IGRhdGEsXG4gICAgICAgICAgICByZXN1bHQ6IHNlbGYucmVzdWx0XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICBlbWl0dGVyLmVtaXQoJ2xvYWRlbmQnKTtcbiAgICAgIH0pO1xuICAgIH1cblxuXG4gICAgLy8gQWJvcnQgaXMgb3ZlcndyaXR0ZW4gYnkgcmVhZEFzWHl6XG4gICAgc2VsZi5hYm9ydCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLnJlYWRTdGF0ZSA9PSBzZWxmLkRPTkUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2VsZi5yZWFkeVN0YXRlID0gc2VsZi5ET05FO1xuICAgICAgZW1pdHRlci5lbWl0KCdhYm9ydCcpO1xuICAgIH07XG5cblxuXG4gICAgLy8gXG4gICAgZnVuY3Rpb24gbWFwVXNlckV2ZW50cygpIHtcbiAgICAgIGVtaXR0ZXIub24oJ3N0YXJ0JywgZnVuY3Rpb24gKCkge1xuICAgICAgICBkb29wKHNlbGYub25sb2Fkc3RhcnQsIGFyZ3VtZW50cyk7XG4gICAgICB9KTtcbiAgICAgIGVtaXR0ZXIub24oJ3Byb2dyZXNzJywgZnVuY3Rpb24gKCkge1xuICAgICAgICBkb29wKHNlbGYub25wcm9ncmVzcywgYXJndW1lbnRzKTtcbiAgICAgIH0pO1xuICAgICAgZW1pdHRlci5vbignZXJyb3InLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIC8vIFRPRE8gdHJhbnNsYXRlIHRvIEZpbGVFcnJvclxuICAgICAgICBpZiAoc2VsZi5vbmVycm9yKSB7XG4gICAgICAgICAgc2VsZi5vbmVycm9yKGVycik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKCFlbWl0dGVyLmxpc3RlbmVycy5lcnJvciB8fCAhZW1pdHRlci5saXN0ZW5lcnMuZXJyb3IubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGVtaXR0ZXIub24oJ2xvYWQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGRvb3Aoc2VsZi5vbmxvYWQsIGFyZ3VtZW50cyk7XG4gICAgICB9KTtcbiAgICAgIGVtaXR0ZXIub24oJ2VuZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZG9vcChzZWxmLm9ubG9hZGVuZCwgYXJndW1lbnRzKTtcbiAgICAgIH0pO1xuICAgICAgZW1pdHRlci5vbignYWJvcnQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGRvb3Aoc2VsZi5vbmFib3J0LCBhcmd1bWVudHMpO1xuICAgICAgfSk7XG4gICAgfVxuXG5cblxuICAgIGZ1bmN0aW9uIHJlYWRGaWxlKF9maWxlLCBmb3JtYXQsIGVuY29kaW5nKSB7XG4gICAgICBmaWxlID0gX2ZpbGU7XG4gICAgICBpZiAoIWZpbGUgfHwgIWZpbGUubmFtZSB8fCAhKGZpbGUucGF0aCB8fCBmaWxlLnN0cmVhbSB8fCBmaWxlLmJ1ZmZlcikpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiY2Fubm90IHJlYWQgYXMgRmlsZTogXCIgKyBKU09OLnN0cmluZ2lmeShmaWxlKSk7XG4gICAgICB9XG4gICAgICBpZiAoMCAhPT0gc2VsZi5yZWFkeVN0YXRlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiYWxyZWFkeSBsb2FkaW5nLCByZXF1ZXN0IHRvIGNoYW5nZSBmb3JtYXQgaWdub3JlZFwiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyAncHJvY2Vzcy5uZXh0VGljaycgZG9lcyBub3QgZW5zdXJlIG9yZGVyLCAoaS5lLiBhbiBmcy5zdGF0IHF1ZXVlZCBsYXRlciBtYXkgcmV0dXJuIGZhc3RlcilcbiAgICAgIC8vIGJ1dCBgb25sb2Fkc3RhcnRgIG11c3QgY29tZSBiZWZvcmUgdGhlIGZpcnN0IGBkYXRhYCBldmVudCBhbmQgbXVzdCBiZSBhc3luY2hyb25vdXMuXG4gICAgICAvLyBIZW5jZSB3ZSB3YXN0ZSBhIHNpbmdsZSB0aWNrIHdhaXRpbmdcbiAgICAgIHByb2Nlc3MubmV4dFRpY2soZnVuY3Rpb24gKCkge1xuICAgICAgICBzZWxmLnJlYWR5U3RhdGUgPSBzZWxmLkxPQURJTkc7XG4gICAgICAgIGVtaXR0ZXIuZW1pdCgnbG9hZHN0YXJ0Jyk7XG4gICAgICAgIGNyZWF0ZUZpbGVTdHJlYW0oKTtcbiAgICAgICAgbWFwU3RyZWFtVG9FbWl0dGVyKGZvcm1hdCwgZW5jb2RpbmcpO1xuICAgICAgICBtYXBVc2VyRXZlbnRzKCk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBzZWxmLnJlYWRBc0FycmF5QnVmZmVyID0gZnVuY3Rpb24gKGZpbGUpIHtcbiAgICAgIHJlYWRGaWxlKGZpbGUsICdidWZmZXInKTtcbiAgICB9O1xuICAgIHNlbGYucmVhZEFzQmluYXJ5U3RyaW5nID0gZnVuY3Rpb24gKGZpbGUpIHtcbiAgICAgIHJlYWRGaWxlKGZpbGUsICdiaW5hcnknKTtcbiAgICB9O1xuICAgIHNlbGYucmVhZEFzRGF0YVVSTCA9IGZ1bmN0aW9uIChmaWxlKSB7XG4gICAgICByZWFkRmlsZShmaWxlLCAnZGF0YVVybCcpO1xuICAgIH07XG4gICAgc2VsZi5yZWFkQXNUZXh0ID0gZnVuY3Rpb24gKGZpbGUsIGVuY29kaW5nKSB7XG4gICAgICByZWFkRmlsZShmaWxlLCAndGV4dCcsIGVuY29kaW5nKTtcbiAgICB9O1xuICB9XG5cbiAgbW9kdWxlLmV4cG9ydHMgPSBGaWxlUmVhZGVyO1xufSgpKTtcbiIsInZhciBjb25maWcgPSByZXF1aXJlKCcuLi8uLi9jb25maWcuanNvbicpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9vYmplY3RzL2NsdW1wJyk7XG52YXIgTHVtcCA9IHJlcXVpcmUoJy4vb2JqZWN0cy9sdW1wJyk7XG5cbnZhciBpbyA9IHJlcXVpcmUoJy4vaW8nKTtcblxudmFyIGxpYnJhcnkgPSByZXF1aXJlKCcuL2xpYnJhcnknKTtcbnZhciBsb2FkZWQgPSB7fTtcblxudmFyIHR5cGVzID0ge1xuICBRdWFsaXR5OiByZXF1aXJlKCcuL29iamVjdHMvcXVhbGl0eScpLFxuICBFdmVudDogcmVxdWlyZSgnLi9vYmplY3RzL2V2ZW50JyksXG4gIEludGVyYWN0aW9uOiByZXF1aXJlKCcuL29iamVjdHMvaW50ZXJhY3Rpb24nKSxcbiAgUXVhbGl0eUVmZmVjdDogcmVxdWlyZSgnLi9vYmplY3RzL3F1YWxpdHktZWZmZWN0JyksXG4gIFF1YWxpdHlSZXF1aXJlbWVudDogcmVxdWlyZSgnLi9vYmplY3RzL3F1YWxpdHktcmVxdWlyZW1lbnQnKSxcbiAgQXJlYTogcmVxdWlyZSgnLi9vYmplY3RzL2FyZWEnKSxcbiAgU3Bhd25lZEVudGl0eTogcmVxdWlyZSgnLi9vYmplY3RzL3NwYXduZWQtZW50aXR5JyksXG4gIENvbWJhdEF0dGFjazogcmVxdWlyZSgnLi9vYmplY3RzL2NvbWJhdC1hdHRhY2snKSxcbiAgRXhjaGFuZ2U6IHJlcXVpcmUoJy4vb2JqZWN0cy9leGNoYW5nZScpLFxuICBTaG9wOiByZXF1aXJlKCcuL29iamVjdHMvc2hvcCcpLFxuICBBdmFpbGFiaWxpdHk6IHJlcXVpcmUoJy4vb2JqZWN0cy9hdmFpbGFiaWxpdHknKSxcbiAgVGlsZTogcmVxdWlyZSgnLi9vYmplY3RzL3RpbGUnKSxcbiAgVGlsZVZhcmlhbnQ6IHJlcXVpcmUoJy4vb2JqZWN0cy90aWxlLXZhcmlhbnQnKSxcbiAgUG9ydDogcmVxdWlyZSgnLi9vYmplY3RzL3BvcnQnKSxcbiAgU2V0dGluZzogcmVxdWlyZSgnLi9vYmplY3RzL3NldHRpbmcnKVxufTtcblxuLy8gUHJlcG9wdWxhdGUgbGlicmFyeSB3aXRoIENsdW1wcyBvZiBlYWNoIHR5cGUgd2Uga25vdyBhYm91dFxuT2JqZWN0LmtleXModHlwZXMpLmZvckVhY2goZnVuY3Rpb24odHlwZU5hbWUpIHtcblx0dmFyIFR5cGUgPSB0eXBlc1t0eXBlTmFtZV07XG5cdGlmKCFsaWJyYXJ5W3R5cGVOYW1lXSkge1xuXHRcdGxpYnJhcnlbdHlwZU5hbWVdID0gbmV3IENsdW1wKFtdLCBUeXBlKTtcblx0XHRsb2FkZWRbdHlwZU5hbWVdID0gbmV3IENsdW1wKFtdLCBUeXBlKTtcblx0fVxufSk7XG5cbmZ1bmN0aW9uIGdldChUeXBlLCBpZCwgcGFyZW50KSB7XG5cdHZhciB0eXBlbmFtZSA9IFR5cGUubmFtZTtcdC8vIEV2ZW50LCBRdWFsaXR5LCBJbnRlcmFjdGlvbiwgZXRjXG5cblx0dmFyIGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkID0gbGlicmFyeVt0eXBlbmFtZV0uaWQoaWQpO1xuXHRpZihleGlzdGluZ1RoaW5nV2l0aFRoaXNJZCkge1xuXHRcdC8vY29uc29sZS5sb2coXCJBdHRhY2hlZCBleGlzdGluZyBcIiArIGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkICsgXCIgdG8gXCIgKyB0aGlzLnRvU3RyaW5nKCkpXG5cdFx0dmFyIG5ld1BhcmVudCA9IHRydWU7XG5cdFx0ZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQucGFyZW50cy5mb3JFYWNoKGZ1bmN0aW9uKHApIHtcblx0XHRcdGlmKHAuSWQgPT09IHBhcmVudC5JZCAmJiBwLmNvbnN0cnVjdG9yLm5hbWUgPT09IHBhcmVudC5jb25zdHJ1Y3Rvci5uYW1lKSB7XG5cdFx0XHRcdG5ld1BhcmVudCA9IGZhbHNlO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGlmKG5ld1BhcmVudCl7XG5cdFx0XHRleGlzdGluZ1RoaW5nV2l0aFRoaXNJZC5wYXJlbnRzLnB1c2gocGFyZW50KTtcblx0XHR9XG5cblx0XHRpZighZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQud2lyZWQpIHtcblx0XHRcdGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkLndpcmVVcCh0aGlzKTtcdC8vIFBhc3MgaW4gdGhlIGFwaSBzbyBvYmplY3QgY2FuIGFkZCBpdHNlbGYgdG8gdGhlIG1hc3Rlci1saWJyYXJ5XG5cdFx0fVxuXHRcdHJldHVybiBleGlzdGluZ1RoaW5nV2l0aFRoaXNJZDtcblx0fVxuXHRlbHNlIHtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxufVxuXG5mdW5jdGlvbiBnZXRPckNyZWF0ZShUeXBlLCBwb3NzTmV3VGhpbmcsIHBhcmVudCkge1x0Ly8gSWYgYW4gb2JqZWN0IGFscmVhZHkgZXhpc3RzIHdpdGggdGhpcyBJRCwgdXNlIHRoYXQuICBPdGhlcndpc2UgY3JlYXRlIGEgbmV3IG9iamVjdCBmcm9tIHRoZSBzdXBwbGllZCBkZXRhaWxzIGhhc2hcblx0dmFyIHR5cGVuYW1lID0gVHlwZS5uYW1lO1x0Ly8gRXZlbnQsIFF1YWxpdHksIEludGVyYWN0aW9uLCBldGNcblx0aWYocG9zc05ld1RoaW5nKSB7XG4gIFx0dmFyIGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkID0gdGhpcy5nZXQoVHlwZSwgcG9zc05ld1RoaW5nLklkLCBwYXJlbnQpO1xuICBcdGlmKGV4aXN0aW5nVGhpbmdXaXRoVGhpc0lkKSB7XG4gIFx0XHRyZXR1cm4gZXhpc3RpbmdUaGluZ1dpdGhUaGlzSWQ7XG4gIFx0fVxuICBcdGVsc2Uge1xuXHRcdFx0dmFyIG5ld1RoaW5nID0gbmV3IFR5cGUocG9zc05ld1RoaW5nLCBwYXJlbnQpO1xuXHRcdFx0bmV3VGhpbmcud2lyZVVwKHRoaXMpO1xuXHRcdFx0Ly9jb25zb2xlLmxvZyhcIlJlY3Vyc2l2ZWx5IGNyZWF0ZWQgXCIgKyBuZXdUaGluZyArIFwiIGZvciBcIiArIHRoaXMudG9TdHJpbmcoKSk7XG5cdFx0XHRyZXR1cm4gbmV3VGhpbmc7XG5cdFx0fVxuXHR9XG5cdGVsc2Uge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG59XG5cbmZ1bmN0aW9uIHdpcmVVcE9iamVjdHMoKSB7XG5cdHZhciBhcGkgPSB0aGlzO1xuICBPYmplY3Qua2V5cyh0eXBlcykuZm9yRWFjaChmdW5jdGlvbih0eXBlKSB7XG4gICAgbGlicmFyeVt0eXBlXS5mb3JFYWNoKGZ1bmN0aW9uKGx1bXApIHtcbiAgICAgIGlmKGx1bXAud2lyZVVwKSB7XG4gICAgICAgIGx1bXAud2lyZVVwKGFwaSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0pO1xufVxuXG52YXIgd2hhdElzID0gZnVuY3Rpb24oaWQpIHtcbiAgdmFyIHBvc3NpYmlsaXRpZXMgPSBbXTtcbiAgT2JqZWN0LmtleXMobGlicmFyeSkuZm9yRWFjaChmdW5jdGlvbihrZXkpIHtcbiAgICBpZihsaWJyYXJ5W2tleV0gaW5zdGFuY2VvZiBDbHVtcCAmJiBsaWJyYXJ5W2tleV0uaWQoaWQpKSB7XG4gICAgICBwb3NzaWJpbGl0aWVzLnB1c2goa2V5KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gcG9zc2liaWxpdGllcztcbn07XG5cbmZ1bmN0aW9uIGRlc2NyaWJlQWR2YW5jZWRFeHByZXNzaW9uKGV4cHIpIHtcblx0dmFyIHNlbGYgPSB0aGlzO1xuXHRpZihleHByKSB7XG5cdFx0ZXhwciA9IGV4cHIucmVwbGFjZSgvXFxbZDooXFxkKylcXF0vZ2ksIFwiUkFORE9NWzEtJDFdXCIpO1x0Ly8gW2Q6eF0gPSByYW5kb20gbnVtYmVyIGZyb20gMS14KD8pXG5cdFx0ZXhwciA9IGV4cHIucmVwbGFjZSgvXFxbcTooXFxkKylcXF0vZ2ksIGZ1bmN0aW9uKG1hdGNoLCBiYWNrcmVmLCBwb3MsIHdob2xlX3N0cikge1xuXHRcdFx0dmFyIHF1YWxpdHkgPSBzZWxmLmxpYnJhcnkuUXVhbGl0eS5pZChiYWNrcmVmKTtcblx0XHRcdHJldHVybiBcIltcIisocXVhbGl0eSA/IHF1YWxpdHkuTmFtZSA6ICdJTlZBTElEJykrXCJdXCI7XG5cdFx0fSk7XG5cblx0XHRyZXR1cm4gZXhwcjtcblx0fVxuXHRyZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gcmVhZEZyb21GaWxlKFR5cGUsIGZpbGUsIGNhbGxiYWNrKSB7XG5cdGlvLnJlYWRGaWxlKGZpbGUsIGZ1bmN0aW9uIChlKSB7XG4gICAgdmFyIGNvbnRlbnRzID0gZS50YXJnZXQucmVzdWx0O1xuICAgIFxuICAgIHZhciBvYmogPSBKU09OLnBhcnNlKGNvbnRlbnRzKTtcbiAgICBsb2FkZWRbVHlwZS5wcm90b3R5cGUuY29uc3RydWN0b3IubmFtZV0gPSBuZXcgQ2x1bXAob2JqLCBUeXBlKTtcblxuICAgIGNhbGxiYWNrKGNvbnRlbnRzLCBUeXBlLCBsb2FkZWRbVHlwZS5wcm90b3R5cGUuY29uc3RydWN0b3IubmFtZV0pO1xuICB9KTtcbn1cblxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0J0NsdW1wJzogQ2x1bXAsXG5cdCdMdW1wJzogTHVtcCxcblx0J2NvbmZpZyc6IGNvbmZpZyxcblx0J3R5cGVzJzogdHlwZXMsXG5cdCdsaWJyYXJ5JzogbGlicmFyeSxcblx0J2xvYWRlZCc6IGxvYWRlZCxcblx0J2dldCc6IGdldCxcblx0J3doYXRJcyc6IHdoYXRJcyxcblx0J3dpcmVVcE9iamVjdHMnOiB3aXJlVXBPYmplY3RzLFxuXHQnZ2V0T3JDcmVhdGUnOiBnZXRPckNyZWF0ZSxcblx0J2Rlc2NyaWJlQWR2YW5jZWRFeHByZXNzaW9uJzogZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24sXG5cdCdyZWFkRnJvbUZpbGUnOiByZWFkRnJvbUZpbGVcbn07IiwiXG5pZih0eXBlb2YgRmlsZVJlYWRlciA9PT0gJ3VuZGVmaW5lZCcpIHsgLy8gUnVubmluZyBpbiBub2RlIHJhdGhlciB0aGFuIGEgYnJvd3NlclxuICBGaWxlUmVhZGVyID0gcmVxdWlyZSgnZmlsZXJlYWRlcicpO1xufVxuXG52YXIgZmlsZU9iamVjdE1hcCA9IHtcbiAgICAnZXZlbnRzLmpzb24nIDogJ0V2ZW50JyxcbiAgICAncXVhbGl0aWVzLmpzb24nIDogJ1F1YWxpdHknLFxuICAgICdhcmVhcy5qc29uJyA6ICdBcmVhJyxcbiAgICAnU3Bhd25lZEVudGl0aWVzLmpzb24nIDogJ1NwYXduZWRFbnRpdHknLFxuICAgICdDb21iYXRBdHRhY2tzLmpzb24nIDogJ0NvbWJhdEF0dGFjaycsXG4gICAgJ2V4Y2hhbmdlcy5qc29uJyA6ICdFeGNoYW5nZScsXG4gICAgJ1RpbGVzLmpzb24nOiAnVGlsZSdcbiAgfTtcblxuZnVuY3Rpb24gcmVhZEZpbGUoZmlsZSwgY2FsbGJhY2spIHtcbiAgdmFyIHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gIHJlYWRlci5vbmxvYWQgPSBjYWxsYmFjaztcbiAgcmVhZGVyLnJlYWRBc1RleHQoZmlsZSk7XG59XG5cbnZhciBmaWxlc190b19sb2FkID0gMDtcbmZ1bmN0aW9uIHJlc2V0RmlsZXNUb0xvYWQoKSB7XG5cdGZpbGVzX3RvX2xvYWQgPSAwO1xufVxuZnVuY3Rpb24gaW5jcmVtZW50RmlsZXNUb0xvYWQoKSB7XG5cdGZpbGVzX3RvX2xvYWQrKztcbn1cbmZ1bmN0aW9uIGRlY3JlbWVudEZpbGVzVG9Mb2FkKCkge1xuXHRmaWxlc190b19sb2FkLS07XG59XG5mdW5jdGlvbiBjb3VudEZpbGVzVG9Mb2FkKCkge1xuXHRyZXR1cm4gZmlsZXNfdG9fbG9hZDtcbn1cblxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgcmVhZEZpbGU6IHJlYWRGaWxlLFxuICByZXNldEZpbGVzVG9Mb2FkOiByZXNldEZpbGVzVG9Mb2FkLFxuXHRpbmNyZW1lbnRGaWxlc1RvTG9hZDogaW5jcmVtZW50RmlsZXNUb0xvYWQsXG5cdGRlY3JlbWVudEZpbGVzVG9Mb2FkOiBkZWNyZW1lbnRGaWxlc1RvTG9hZCxcblx0Y291bnRGaWxlc1RvTG9hZDogY291bnRGaWxlc1RvTG9hZCxcbiAgZmlsZU9iamVjdE1hcDogZmlsZU9iamVjdE1hcFxufTsiLCJtb2R1bGUuZXhwb3J0cyA9IHt9OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XG5cbnZhciBhcGk7XG5cbmZ1bmN0aW9uIEFyZWEocmF3KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1wiTmFtZVwiLCBcIkRlc2NyaXB0aW9uXCIsIFwiSW1hZ2VOYW1lXCIsIFwiTW92ZU1lc3NhZ2VcIl07XG5cdEx1bXAuY2FsbCh0aGlzLCByYXcpO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IEFyZWEucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuQXJlYS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cdGFwaSA9IHRoZUFwaTtcblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcyk7XG59O1xuXG5BcmVhLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xufTtcblxuQXJlYS5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRpZih0aGlzLkltYWdlTmFtZSAhPT0gbnVsbCAmJiB0aGlzLkltYWdlICE9PSBcIlwiKSB7XG5cdFx0ZWxlbWVudC5pbm5lckhUTUwgPSBcIjxpbWcgY2xhc3M9J2ljb24nIHNyYz0nXCIrYXBpLmNvbmZpZy5sb2NhdGlvbnMuaW1hZ2VzUGF0aCtcIi9cIit0aGlzLkltYWdlTmFtZStcIi5wbmcnIC8+XCI7XG5cdH1cblxuXHRlbGVtZW50LmlubmVySFRNTCArPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XFxuPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEFyZWE7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gQXZhaWxhYmlsaXR5KHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdDb3N0Jyxcblx0XHQnU2VsbFByaWNlJ1xuXHRdO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy5xdWFsaXR5ID0gbnVsbDtcblx0dGhpcy5wdXJjaGFzZVF1YWxpdHkgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IEF2YWlsYWJpbGl0eS5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5BdmFpbGFiaWxpdHkucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xuXG5cdGFwaSA9IHRoZUFwaTtcblxuXHR0aGlzLnF1YWxpdHkgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5RdWFsaXR5LCB0aGlzKTtcblx0dGhpcy5wdXJjaGFzZVF1YWxpdHkgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5QdXJjaGFzZVF1YWxpdHksIHRoaXMpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5BdmFpbGFiaWxpdHkucHJvdG90eXBlLmlzQWRkaXRpdmUgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuQ29zdCA+IDA7XG59O1xuXG5BdmFpbGFiaWxpdHkucHJvdG90eXBlLmlzU3VidHJhY3RpdmUgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuU2VsbFByaWNlID4gMDtcbn07XG5cbkF2YWlsYWJpbGl0eS5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5xdWFsaXR5ICsgXCIgKGJ1eTogXCIgKyB0aGlzLkNvc3QgKyBcInhcIiArIHRoaXMucHVyY2hhc2VRdWFsaXR5Lk5hbWUgKyBcIiAvIHNlbGw6IFwiICsgdGhpcy5TZWxsUHJpY2UgKyBcInhcIiArIHRoaXMucHVyY2hhc2VRdWFsaXR5Lk5hbWUgKyBcIilcIjtcbn07XG5cbkF2YWlsYWJpbGl0eS5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJzbWFsbFwiO1xuXG5cdHZhciBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cdFxuXHR2YXIgcHVyY2hhc2VfcXVhbGl0eV9lbGVtZW50O1xuXG5cdGlmKCF0aGlzLnF1YWxpdHkpIHtcblx0XHRwdXJjaGFzZV9xdWFsaXR5X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcblx0XHRwdXJjaGFzZV9xdWFsaXR5X2VsZW1lbnQuaW5uZXJIVE1MID0gXCJbSU5WQUxJRF1cIjtcblx0fVxuXHRlbHNlIHtcblx0XHRwdXJjaGFzZV9xdWFsaXR5X2VsZW1lbnQgPSB0aGlzLnF1YWxpdHkudG9Eb20oXCJzbWFsbFwiLCBmYWxzZSwgXCJzcGFuXCIpO1xuXHR9XG5cblx0dmFyIGN1cnJlbmN5X3F1YWxpdHlfZWxlbWVudCA9IHRoaXMucHVyY2hhc2VRdWFsaXR5LnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwic3BhblwiKTtcblx0Y3VycmVuY3lfcXVhbGl0eV9lbGVtZW50LmNsYXNzTmFtZSA9IFwicXVhbnRpdHkgaXRlbSBzbWFsbFwiO1xuXHR2YXIgY3VycmVuY3lfcXVhbGl0eV9tYXJrdXAgPSBjdXJyZW5jeV9xdWFsaXR5X2VsZW1lbnQub3V0ZXJIVE1MO1xuXG5cdHZhciBjdXJyZW5jeV9idXlfYW1vdW50X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcblx0Y3VycmVuY3lfYnV5X2Ftb3VudF9lbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBxdWFudGl0eVwiO1xuXHRjdXJyZW5jeV9idXlfYW1vdW50X2VsZW1lbnQuaW5uZXJIVE1MID0gXCJCdXk6IFwiICsgKHRoaXMuQ29zdCA/IHRoaXMuQ29zdCtcInhcIiA6IFwiJiMxMDAwNztcIik7XG5cdGN1cnJlbmN5X2J1eV9hbW91bnRfZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHR2YXIgY3VycmVuY3lfc2VsbF9hbW91bnRfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRjdXJyZW5jeV9zZWxsX2Ftb3VudF9lbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBxdWFudGl0eVwiO1xuXHRjdXJyZW5jeV9zZWxsX2Ftb3VudF9lbGVtZW50LmlubmVySFRNTCA9IFwiU2VsbDogXCIgKyAodGhpcy5TZWxsUHJpY2UgPyB0aGlzLlNlbGxQcmljZStcInhcIiA6IFwiJiMxMDAwNztcIik7XG5cdGN1cnJlbmN5X3NlbGxfYW1vdW50X2VsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblxuXHRlbGVtZW50LmFwcGVuZENoaWxkKHB1cmNoYXNlX3F1YWxpdHlfZWxlbWVudCk7XG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY3VycmVuY3lfYnV5X2Ftb3VudF9lbGVtZW50KTtcblx0aWYodGhpcy5Db3N0KSB7XG5cdFx0ZWxlbWVudC5hcHBlbmRDaGlsZCgkKGN1cnJlbmN5X3F1YWxpdHlfbWFya3VwKVswXSk7XG5cdH1cblx0ZWxlbWVudC5hcHBlbmRDaGlsZChjdXJyZW5jeV9zZWxsX2Ftb3VudF9lbGVtZW50KTtcblx0aWYodGhpcy5TZWxsUHJpY2UpIHtcblx0XHRlbGVtZW50LmFwcGVuZENoaWxkKCQoY3VycmVuY3lfcXVhbGl0eV9tYXJrdXApWzBdKTtcblx0fVxuXG5cdHJldHVybiBlbGVtZW50O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBBdmFpbGFiaWxpdHk7IiwiXG5mdW5jdGlvbiBDbHVtcChyYXcsIFR5cGUsIHBhcmVudCkge1xuXHR0aGlzLnR5cGUgPSBUeXBlO1xuXHR0aGlzLml0ZW1zID0ge307XG5cdHZhciBzZWxmID0gdGhpcztcblx0cmF3LmZvckVhY2goZnVuY3Rpb24oaXRlbSwgaW5kZXgsIGNvbGxlY3Rpb24pIHtcblx0XHRpZighKGl0ZW0gaW5zdGFuY2VvZiBUeXBlKSkge1xuXHRcdFx0aXRlbSA9IG5ldyBUeXBlKGl0ZW0sIHBhcmVudCk7XG5cdFx0fVxuXHRcdGVsc2UgaWYocGFyZW50KSB7XG5cdFx0XHR2YXIgbmV3UGFyZW50ID0gdHJ1ZTtcblx0XHRcdGl0ZW0ucGFyZW50cy5mb3JFYWNoKGZ1bmN0aW9uKHApIHtcblx0XHRcdFx0aWYocC5JZCA9PT0gcGFyZW50LklkICYmIHAuY29uc3RydWN0b3IubmFtZSA9PT0gcGFyZW50LmNvbnN0cnVjdG9yLm5hbWUpIHtcblx0XHRcdFx0XHRuZXdQYXJlbnQgPSBmYWxzZTtcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0XHRpZihuZXdQYXJlbnQpe1xuXHRcdFx0XHRpdGVtLnBhcmVudHMucHVzaChwYXJlbnQpO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRzZWxmLml0ZW1zW2l0ZW0uSWRdID0gaXRlbTtcblx0fSk7XG59XG5cbkNsdW1wLnByb3RvdHlwZS5lbXB0eSA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gISF0aGlzLnNpemUoKTtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS5zaXplID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiBPYmplY3Qua2V5cyh0aGlzLml0ZW1zKS5sZW5ndGg7XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24oaW5kZXgpIHtcblx0Zm9yKHZhciBpZCBpbiB0aGlzLml0ZW1zKSB7XG5cdFx0aWYoaW5kZXggPT09IDApIHtcblx0XHRcdHJldHVybiB0aGlzLml0ZW1zW2lkXTtcblx0XHR9XG5cdFx0aW5kZXgtLTtcblx0fVxufTtcblxuQ2x1bXAucHJvdG90eXBlLmlkID0gZnVuY3Rpb24oaWQpIHtcblx0cmV0dXJuIHRoaXMuaXRlbXNbaWRdO1xufTtcblxuQ2x1bXAucHJvdG90eXBlLmVhY2ggPSBmdW5jdGlvbigpIHtcblx0dmFyIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMpO1xuXHRyZXR1cm4gdGhpcy5tYXAoZnVuY3Rpb24oaXRlbSkge1xuXG5cdFx0aWYoYXJnc1swXSBpbnN0YW5jZW9mIEFycmF5KSB7XHQvLyBQYXNzZWQgaW4gYXJyYXkgb2YgZmllbGRzLCBzbyByZXR1cm4gdmFsdWVzIGNvbmNhdGVuYXRlZCB3aXRoIG9wdGlvbmFsIHNlcGFyYXRvclxuXHRcdFx0dmFyIHNlcGFyYXRvciA9ICh0eXBlb2YgYXJnc1sxXSA9PT0gXCJ1bmRlZmluZWRcIikgPyBcIi1cIiA6IGFyZ3NbMV07XG5cdFx0XHRyZXR1cm4gYXJnc1swXS5tYXAoZnVuY3Rpb24oZikgeyByZXR1cm4gaXRlbVtmXTsgfSkuam9pbihzZXBhcmF0b3IpO1xuXHRcdH1cblx0XHRlbHNlIGlmKGFyZ3MubGVuZ3RoID4gMSkge1x0Ly8gUGFzc2VkIGluIHNlcGFyYXRlIGZpZWxkcywgc28gcmV0dXJuIGFycmF5IG9mIHZhbHVlc1xuXHRcdFx0cmV0dXJuIGFyZ3MubWFwKGZ1bmN0aW9uKGYpIHsgcmV0dXJuIGl0ZW1bZl07IH0pO1xuXHRcdH1cblx0XHRlbHNlIHtcblx0XHRcdHJldHVybiBpdGVtW2FyZ3NbMF1dO1xuXHRcdH1cblx0fSk7XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuZm9yRWFjaCA9IGZ1bmN0aW9uKGNhbGxiYWNrKSB7XG5cdGZvcih2YXIgaWQgaW4gdGhpcy5pdGVtcykge1xuXHRcdHZhciBpdGVtID0gdGhpcy5pdGVtc1tpZF07XG5cdFx0Y2FsbGJhY2soaXRlbSwgaWQsIHRoaXMuaXRlbXMpO1xuXHR9XG59O1xuXG5DbHVtcC5wcm90b3R5cGUubWFwID0gZnVuY3Rpb24oY2FsbGJhY2spIHtcblx0dmFyIHNlbGYgPSB0aGlzO1xuXHR2YXIgYXJyYXlPZkl0ZW1zID0gT2JqZWN0LmtleXModGhpcy5pdGVtcykubWFwKGZ1bmN0aW9uKGtleSkge1xuXHRcdHJldHVybiBzZWxmLml0ZW1zW2tleV07XG5cdH0pO1xuXHRyZXR1cm4gYXJyYXlPZkl0ZW1zLm1hcC5jYWxsKGFycmF5T2ZJdGVtcywgY2FsbGJhY2spO1xufTtcblxuQ2x1bXAucHJvdG90eXBlLnNvcnRCeSA9IGZ1bmN0aW9uKGZpZWxkLCByZXZlcnNlKSB7XG5cdHZhciBzZWxmID0gdGhpcztcblx0dmFyIG9ianMgPSBPYmplY3Qua2V5cyh0aGlzLml0ZW1zKS5tYXAoZnVuY3Rpb24oa2V5KSB7XG5cdFx0cmV0dXJuIHNlbGYuaXRlbXNba2V5XTtcblx0fSkuc29ydChmdW5jdGlvbihhLCBiKSB7XG5cdFx0aWYoYVtmaWVsZF0gPCBiW2ZpZWxkXSkge1xuXHRcdFx0cmV0dXJuIC0xO1xuXHRcdH1cblx0XHRpZihhW2ZpZWxkXSA9PT0gYltmaWVsZF0pIHtcblx0XHRcdHJldHVybiAwO1xuXHRcdH1cblx0XHRpZihhW2ZpZWxkXSA+IGJbZmllbGRdKSB7XG5cdFx0XHRyZXR1cm4gMTtcblx0XHR9XG5cdH0pO1xuXG5cdHJldHVybiByZXZlcnNlID8gb2Jqcy5yZXZlcnNlKCkgOiBvYmpzO1xufTtcblxuQ2x1bXAucHJvdG90eXBlLnNhbWUgPSBmdW5jdGlvbigpIHtcblx0dmFyIHNlbGYgPSB0aGlzO1xuXG5cdHZhciBjbG9uZSA9IGZ1bmN0aW9uKG9iaikge1xuICAgIHZhciB0YXJnZXQgPSB7fTtcbiAgICBmb3IgKHZhciBpIGluIG9iaikge1xuICAgIFx0aWYgKG9iai5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgIFx0XHRpZih0eXBlb2Ygb2JqW2ldID09PSBcIm9iamVjdFwiKSB7XG4gICAgXHRcdFx0dGFyZ2V0W2ldID0gY2xvbmUob2JqW2ldKTtcbiAgICBcdFx0fVxuICAgIFx0XHRlbHNlIHtcbiAgICAgIFx0XHR0YXJnZXRbaV0gPSBvYmpbaV07XG4gICAgICBcdH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRhcmdldDtcbiAgfTtcblxuXHR2YXIgdGVtcGxhdGUgPSBjbG9uZSh0aGlzLmdldCgwKS5hdHRyaWJzKTtcblxuXHRmb3IodmFyIGlkIGluIHRoaXMuaXRlbXMpIHtcblx0XHR2YXIgb3RoZXJPYmogPSB0aGlzLml0ZW1zW2lkXS5hdHRyaWJzO1xuXHRcdGZvcih2YXIga2V5IGluIHRlbXBsYXRlKSB7XG5cdFx0XHRpZih0ZW1wbGF0ZVtrZXldICE9PSBvdGhlck9ialtrZXldKSB7XG5cdFx0XHRcdGRlbGV0ZSh0ZW1wbGF0ZVtrZXldKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gdGVtcGxhdGU7XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuZGlzdGluY3QgPSBmdW5jdGlvbihmaWVsZCkge1xuXHR2YXIgc2FtcGxlVmFsdWVzID0ge307XG5cdHRoaXMuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XG5cdFx0dmFyIHZhbHVlID0gaXRlbVtmaWVsZF07XG5cdFx0c2FtcGxlVmFsdWVzW3ZhbHVlXSA9IHZhbHVlO1x0Ly8gQ2hlYXAgZGUtZHVwaW5nIHdpdGggYSBoYXNoXG5cdH0pO1xuXHRyZXR1cm4gT2JqZWN0LmtleXMoc2FtcGxlVmFsdWVzKS5tYXAoZnVuY3Rpb24oa2V5KSB7IHJldHVybiBzYW1wbGVWYWx1ZXNba2V5XTsgfSk7XG59O1xuXG5DbHVtcC5wcm90b3R5cGUuZGlzdGluY3RSYXcgPSBmdW5jdGlvbihmaWVsZCkge1xuXHR2YXIgc2FtcGxlVmFsdWVzID0ge307XG5cdHRoaXMuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XG5cdFx0dmFyIHZhbHVlID0gaXRlbS5hdHRyaWJzW2ZpZWxkXTtcblx0XHRzYW1wbGVWYWx1ZXNbdmFsdWVdID0gdmFsdWU7XHQvLyBDaGVhcCBkZS1kdXBpbmcgd2l0aCBhIGhhc2hcblx0fSk7XG5cdHJldHVybiBPYmplY3Qua2V5cyhzYW1wbGVWYWx1ZXMpLm1hcChmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHNhbXBsZVZhbHVlc1trZXldOyB9KTtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS5xdWVyeSA9IGZ1bmN0aW9uKGZpZWxkLCB2YWx1ZSkge1xuXHR2YXIgbWF0Y2hlcyA9IFtdO1xuXHR2YXIgdGVzdDtcblxuXHQvLyBXb3JrIG91dCB3aGF0IHNvcnQgb2YgY29tcGFyaXNvbiB0byBkbzpcblxuXHRpZih0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1x0Ly8gSWYgdmFsdWUgaXMgYSBmdW5jdGlvbiwgcGFzcyBpdCB0aGUgY2FuZGlkYXRlIGFuZCByZXR1cm4gdGhlIHJlc3VsdFxuXHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcblx0XHRcdHJldHVybiAhIXZhbHVlKGNhbmRpZGF0ZSk7XG5cdFx0fTtcblx0fVxuXHRlbHNlIGlmKHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIikge1xuXHRcdGlmKHZhbHVlIGluc3RhbmNlb2YgUmVnRXhwKSB7XG5cdFx0XHR0ZXN0ID0gZnVuY3Rpb24oY2FuZGlkYXRlKSB7XG5cdFx0XHRcdHJldHVybiB2YWx1ZS50ZXN0KGNhbmRpZGF0ZSk7XG5cdFx0XHR9O1xuXHRcdH1cblx0XHRlbHNlIGlmKHZhbHVlIGluc3RhbmNlb2YgQXJyYXkpIHtcdC8vIElmIHZhbHVlIGlzIGFuIGFycmF5LCB0ZXN0IGZvciB0aGUgcHJlc2VuY2Ugb2YgdGhlIGNhbmRpZGF0ZSB2YWx1ZSBpbiB0aGUgYXJyYXlcblx0XHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcblx0XHRcdFx0cmV0dXJuIHZhbHVlLmluZGV4T2YoY2FuZGlkYXRlKSAhPT0gLTE7XG5cdFx0XHR9O1xuXHRcdH1cblx0XHRlbHNlIHtcblx0XHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcblx0XHRcdFx0cmV0dXJuIGNhbmRpZGF0ZSA9PT0gdmFsdWU7XHQvLyBIYW5kbGUgbnVsbCwgdW5kZWZpbmVkIG9yIG9iamVjdC1yZWZlcmVuY2UgY29tcGFyaXNvblxuXHRcdFx0fTtcblx0XHR9XG5cdH1cblx0ZWxzZSB7XHQvLyBFbHNlIGlmIGl0J3MgYSBzaW1wbGUgdHlwZSwgdHJ5IGEgc3RyaWN0IGVxdWFsaXR5IGNvbXBhcmlzb25cblx0XHR0ZXN0ID0gZnVuY3Rpb24oY2FuZGlkYXRlKSB7XG5cdFx0XHRyZXR1cm4gY2FuZGlkYXRlID09PSB2YWx1ZTtcblx0XHR9O1xuXHR9XG5cdFxuXHQvLyBOb3cgaXRlcmF0ZSBvdmVyIHRoZSBpdGVtcywgZmlsdGVyaW5nIHVzaW5nIHRoZSB0ZXN0IGZ1bmN0aW9uIHdlIGRlZmluZWRcblx0dGhpcy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0pIHtcblx0XHRpZihcblx0XHRcdChmaWVsZCAhPT0gbnVsbCAmJiB0ZXN0KGl0ZW1bZmllbGRdKSkgfHxcblx0XHRcdChmaWVsZCA9PT0gbnVsbCAmJiB0ZXN0KGl0ZW0pKVxuXHRcdCkge1xuXHRcdFx0bWF0Y2hlcy5wdXNoKGl0ZW0pO1xuXHRcdH1cblx0fSk7XG5cdHJldHVybiBuZXcgQ2x1bXAobWF0Y2hlcywgdGhpcy50eXBlKTtcdC8vIEFuZCB3cmFwIHRoZSByZXN1bHRpbmcgYXJyYXkgb2Ygb2JqZWN0cyBpbiBhIG5ldyBDbHVtcCBvYmplY3QgZm9yIHNleHkgbWV0aG9kIGNoYWluaW5nIGxpa2UgeC5xdWVyeSgpLmZvckVhY2goKSBvciB4LnF1ZXJ5KCkucXVlcnkoKVxufTtcblxuQ2x1bXAucHJvdG90eXBlLnF1ZXJ5UmF3ID0gZnVuY3Rpb24oZmllbGQsIHZhbHVlKSB7XG5cdHZhciBtYXRjaGVzID0gW107XG5cdHZhciB0ZXN0O1xuXG5cdC8vIFdvcmsgb3V0IHdoYXQgc29ydCBvZiBjb21wYXJpc29uIHRvIGRvOlxuXG5cdGlmKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XHQvLyBJZiB2YWx1ZSBpcyBhIGZ1bmN0aW9uLCBwYXNzIGl0IHRoZSBjYW5kaWRhdGUgYW5kIHJldHVybiB0aGUgcmVzdWx0XG5cdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xuXHRcdFx0cmV0dXJuICEhdmFsdWUoY2FuZGlkYXRlKTtcblx0XHR9O1xuXHR9XG5cdGVsc2UgaWYodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiKSB7XG5cdFx0aWYodmFsdWUgaW5zdGFuY2VvZiBSZWdFeHApIHtcblx0XHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcblx0XHRcdFx0cmV0dXJuIHZhbHVlLnRlc3QoY2FuZGlkYXRlKTtcblx0XHRcdH07XG5cdFx0fVxuXHRcdGVsc2UgaWYodmFsdWUgaW5zdGFuY2VvZiBBcnJheSkge1x0Ly8gSWYgdmFsdWUgaXMgYW4gYXJyYXksIHRlc3QgZm9yIHRoZSBwcmVzZW5jZSBvZiB0aGUgY2FuZGlkYXRlIHZhbHVlIGluIHRoZSBhcnJheVxuXHRcdFx0dGVzdCA9IGZ1bmN0aW9uKGNhbmRpZGF0ZSkge1xuXHRcdFx0XHRyZXR1cm4gdmFsdWUuaW5kZXhPZihjYW5kaWRhdGUpICE9PSAtMTtcblx0XHRcdH07XG5cdFx0fVxuXHRcdGVsc2Uge1x0Ly8gSWYgdmFsdWUgaXMgYSBoYXNoLi4uIHdoYXQgZG8gd2UgZG8/XG5cdFx0XHQvLyBDaGVjayB0aGUgY2FuZGlkYXRlIGZvciBlYWNoIGZpZWxkIGluIHRoZSBoYXNoIGluIHR1cm4sIGFuZCBpbmNsdWRlIHRoZSBjYW5kaWRhdGUgaWYgYW55L2FsbCBvZiB0aGVtIGhhdmUgdGhlIHNhbWUgdmFsdWUgYXMgdGhlIGNvcnJlc3BvbmRpbmcgdmFsdWUtaGFzaCBmaWVsZD9cblx0XHRcdHRocm93IFwiTm8gaWRlYSB3aGF0IHRvIGRvIHdpdGggYW4gb2JqZWN0IGFzIHRoZSB2YWx1ZVwiO1xuXHRcdH1cblx0fVxuXHRlbHNlIHtcdC8vIEVsc2UgaWYgaXQncyBhIHNpbXBsZSB0eXBlLCB0cnkgYSBzdHJpY3QgZXF1YWxpdHkgY29tcGFyaXNvblxuXHRcdHRlc3QgPSBmdW5jdGlvbihjYW5kaWRhdGUpIHtcblx0XHRcdHJldHVybiBjYW5kaWRhdGUgPT09IHZhbHVlO1xuXHRcdH07XG5cdH1cblx0XG5cdC8vIE5vdyBpdGVyYXRlIG92ZXIgdGhlbSBhbGwsIGZpbHRlcmluZyB1c2luZyB0aGUgdGVzdCBmdW5jdGlvbiB3ZSBkZWZpbmVkXG5cdHRoaXMuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XG5cdFx0aWYoXG5cdFx0XHQoZmllbGQgIT09IG51bGwgJiYgdGVzdChpdGVtLmF0dHJpYnNbZmllbGRdKSkgfHxcblx0XHRcdChmaWVsZCA9PT0gbnVsbCAmJiB0ZXN0KGl0ZW0uYXR0cmlicykpXG5cdFx0KSB7XG5cdFx0XHRtYXRjaGVzLnB1c2goaXRlbSk7XG5cdFx0fVxuXHR9KTtcblx0cmV0dXJuIG5ldyBDbHVtcChtYXRjaGVzLCB0aGlzLnR5cGUpO1x0Ly8gQW5kIHdyYXAgdGhlIHJlc3VsdGluZyBhcnJheSBvZiBvYmplY3RzIGluIGEgbmV3IENsdW1wIG9iamVjdCBmb3Igc2V4eSBtZXRob2QgY2hhaW5pbmcgbGlrZSB4LnF1ZXJ5KCkuZm9yRWFjaCgpIG9yIHgucXVlcnkoKS5xdWVyeSgpXG59O1xuXG5DbHVtcC5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMudHlwZS5uYW1lICsgXCIgQ2x1bXAgKFwiICsgdGhpcy5zaXplKCkgKyBcIiBpdGVtcylcIjtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnLCBmaXJzdENoaWxkKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0dGFnID0gdGFnIHx8IFwidWxcIjtcblxuXHR2YXIgZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSB0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1saXN0IFwiK3NpemU7XG5cdGlmKGZpcnN0Q2hpbGQpIHtcblx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGZpcnN0Q2hpbGQpO1xuXHR9XG5cdHRoaXMuc29ydEJ5KFwiTmFtZVwiKS5mb3JFYWNoKGZ1bmN0aW9uKGkpIHtcblx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGkudG9Eb20oc2l6ZSwgaW5jbHVkZUNoaWxkcmVuKSk7XG5cdH0pO1xuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbkNsdW1wLnByb3RvdHlwZS5kZXNjcmliZSA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdHJldHVybiBPYmplY3Qua2V5cyh0aGlzLml0ZW1zKS5tYXAoZnVuY3Rpb24oaSkgeyByZXR1cm4gc2VsZi5pdGVtc1tpXS50b1N0cmluZygpOyB9KS5qb2luKFwiIGFuZCBcIik7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IENsdW1wOyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XG5cbnZhciBhcGk7XG5cbmZ1bmN0aW9uIENvbWJhdEF0dGFjayhyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0XHQnTmFtZScsXG5cdFx0J0ltYWdlJyxcblx0XHQnUmFtbWluZ0F0dGFjaycsXG5cdFx0J09ubHlXaGVuRXhwb3NlZCcsXG5cdFx0J1JhbmdlJyxcblx0XHQnT3JpZW50YXRpb24nLFxuXHRcdCdBcmMnLFxuXHRcdCdCYXNlSHVsbERhbWFnZScsXG5cdFx0J0Jhc2VMaWZlRGFtYWdlJyxcblx0XHQnRXhwb3NlZFF1YWxpdHlEYW1hZ2UnLFx0Ly8gVmFsdWUgdG8gYWRkIHRvIHRoZSBleHBvc2VkUXVhbGl0eTogcG9zaXRpdmUgaW5jcmVhc2VzIHF1YWxpdHkgbGV2ZWwgKGVnIFRlcnJvciksIG5lZ2F0aXZlIGRlY3JlYXNlcyBpdCAoZWcgQ3Jldylcblx0XHQnU3RhZ2dlckFtb3VudCcsXG5cdFx0J0Jhc2VXYXJtVXAnLFxuXHRcdCdBbmltYXRpb24nLFxuXHRcdCdBbmltYXRpb25OdW1iZXInXG5cdF07XG5cdHJhdy5JZCA9IHJhdy5OYW1lO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy5xdWFsaXR5UmVxdWlyZWQgPSBudWxsO1xuXHR0aGlzLnF1YWxpdHlDb3N0ID0gbnVsbDtcblx0dGhpcy5leHBvc2VkUXVhbGl0eSA9IG51bGw7XG59XG5cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBDb21iYXRBdHRhY2sucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuQ29tYmF0QXR0YWNrLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy5xdWFsaXR5UmVxdWlyZWQgPSBhcGkuZ2V0KGFwaS50eXBlcy5RdWFsaXR5LCB0aGlzLmF0dHJpYnMuUXVhbGl0eVJlcXVpcmVkSWQsIHRoaXMpO1xuXHR0aGlzLnF1YWxpdHlDb3N0ID0gYXBpLmdldChhcGkudHlwZXMuUXVhbGl0eSwgdGhpcy5hdHRyaWJzLlF1YWxpdHlDb3N0SWQsIHRoaXMpO1xuXHR0aGlzLmV4cG9zZWRRdWFsaXR5ID0gYXBpLmdldChhcGkudHlwZXMuUXVhbGl0eSwgdGhpcy5hdHRyaWJzLkV4cG9zZWRRdWFsaXR5SWQsIHRoaXMpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5Db21iYXRBdHRhY2sucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiBcIiArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5Db21iYXRBdHRhY2sucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSwgaW5jbHVkZUNoaWxkcmVuKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblxuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdFxuXHR2YXIgaHRtbCA9IFwiXCI7XG5cblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0aWYodGhpcy5JbWFnZSAhPT0gbnVsbCAmJiB0aGlzLkltYWdlICE9PSBcIlwiKSB7XG5cdFx0aHRtbCA9IFwiPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCIucG5nJyAvPlwiO1xuXHR9XG5cblx0aHRtbCArPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XG5cblx0aWYodGhpcy5xdWFsaXR5UmVxdWlyZWQgfHwgdGhpcy5xdWFsaXR5Q29zdCkge1xuXHRcdGh0bWwgKz0gXCI8ZGl2IGNsYXNzPSdzaWRlYmFyJz5cIjtcblxuXHRcdGlmKHRoaXMucXVhbGl0eVJlcXVpcmVkKSB7XG5cdFx0XHRodG1sICs9IFwiPGg0PlJlcXVpcmVkPC9oND5cIjtcblx0XHRcdGh0bWwgKz0gKG5ldyBDbHVtcChbdGhpcy5xdWFsaXR5UmVxdWlyZWRdLCBhcGkudHlwZXMuUXVhbGl0eSkpLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xuXHRcdH1cblx0XHRpZih0aGlzLnF1YWxpdHlDb3N0KSB7XG5cdFx0XHRodG1sICs9IFwiPGg0PkNvc3Q8L2g0PlwiO1xuXHRcdFx0aHRtbCArPSAobmV3IENsdW1wKFt0aGlzLnF1YWxpdHlDb3N0XSwgYXBpLnR5cGVzLlF1YWxpdHkpKS50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInVsXCIpLm91dGVySFRNTDtcblx0XHR9XG5cdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xuXHR9XG5cblx0aHRtbCArPSBcIjxkbCBjbGFzcz0nY2x1bXAtbGlzdCBzbWFsbCc+XCI7XG5cdFsnUmFuZ2UnLCAnQXJjJywgJ0Jhc2VIdWxsRGFtYWdlJywgJ0Jhc2VMaWZlRGFtYWdlJywgJ1N0YWdnZXJBbW91bnQnLCAnQmFzZVdhcm1VcCddLmZvckVhY2goZnVuY3Rpb24oa2V5KSB7XG5cdFx0aHRtbCArPSBcIjxkdCBjbGFzcz0naXRlbSc+XCIra2V5K1wiPC9kdD48ZGQgY2xhc3M9J3F1YW50aXR5Jz5cIitzZWxmW2tleV0rXCI8L2RkPlwiO1xuXHR9KTtcblx0aHRtbCArPSBcIjwvZGw+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0aWYoaW5jbHVkZUNoaWxkcmVuKSB7XG5cdFx0ZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oZSkge1xuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblxuXHRcdFx0dmFyIGNoaWxkTGlzdCA9IGVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5jaGlsZC1saXN0XCIpO1xuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR2YXIgc3VjY2Vzc0V2ZW50ID0gc2VsZi5zdWNjZXNzRXZlbnQ7XG5cdFx0XHRcdHZhciBkZWZhdWx0RXZlbnQgPSBzZWxmLmRlZmF1bHRFdmVudDtcblx0XHRcdFx0dmFyIHF1YWxpdGllc1JlcXVpcmVkID0gIHNlbGYucXVhbGl0aWVzUmVxdWlyZWQ7XG5cdFx0XHRcdHZhciBldmVudHMgPSBbXTtcblx0XHRcdFx0aWYoc3VjY2Vzc0V2ZW50ICYmIHF1YWxpdGllc1JlcXVpcmVkICYmIHF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xuXHRcdFx0XHRcdGV2ZW50cy5wdXNoKHN1Y2Nlc3NFdmVudCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYoZGVmYXVsdEV2ZW50KSB7XG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goZGVmYXVsdEV2ZW50KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZihldmVudHMubGVuZ3RoKSB7XG5cdFx0XHRcdFx0dmFyIHdyYXBwZXJDbHVtcCA9IG5ldyBDbHVtcChldmVudHMsIGFwaS50eXBlcy5FdmVudCk7XG5cdFx0XHRcdFx0dmFyIGNoaWxkX2V2ZW50cyA9IHdyYXBwZXJDbHVtcC50b0RvbShzaXplLCB0cnVlKTtcblxuXHRcdFx0XHRcdGNoaWxkX2V2ZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2V2ZW50cyk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdHJldHVybiBlbGVtZW50O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBDb21iYXRBdHRhY2s7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gRXZlbnQocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXG5cdCdOYW1lJyxcblx0J0Rlc2NyaXB0aW9uJyxcblx0J1RlYXNlcicsXG5cdCdJbWFnZScsXG5cdCdDYXRlZ29yeSdcblx0XTtcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG5cdHRoaXMudGFnID0gbnVsbDtcblxuXHR0aGlzLkV4b3RpY0VmZmVjdHMgPSB0aGlzLmdldEV4b3RpY0VmZmVjdCh0aGlzLmF0dHJpYnMuRXhvdGljRWZmZWN0cyk7XG5cblx0dGhpcy5xdWFsaXRpZXNSZXF1aXJlZCA9IG51bGw7XG5cdHRoaXMucXVhbGl0aWVzQWZmZWN0ZWQgPSBudWxsO1xuXHR0aGlzLmludGVyYWN0aW9ucyA9IG51bGw7XG5cdHRoaXMubGlua1RvRXZlbnQgPSBudWxsO1xuXG5cdHRoaXMubGltaXRlZFRvQXJlYSA9IG51bGw7XG5cblx0dGhpcy5zZXR0aW5nID0gbnVsbDtcblx0XG5cdC8vRGVja1xuXHQvL1N0aWNraW5lc3Ncblx0Ly9UcmFuc2llbnRcblx0Ly9VcmdlbmN5XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgRXZlbnQucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuRXZlbnQucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xuXG5cdGFwaSA9IHRoZUFwaTtcblxuXHR0aGlzLnF1YWxpdGllc1JlcXVpcmVkID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5RdWFsaXRpZXNSZXF1aXJlZCB8fCBbXSwgYXBpLnR5cGVzLlF1YWxpdHlSZXF1aXJlbWVudCwgdGhpcyk7XG5cdHRoaXMucXVhbGl0aWVzQWZmZWN0ZWQgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlF1YWxpdGllc0FmZmVjdGVkIHx8IFtdLCBhcGkudHlwZXMuUXVhbGl0eUVmZmVjdCwgdGhpcyk7XG5cdHRoaXMuaW50ZXJhY3Rpb25zID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5DaGlsZEJyYW5jaGVzfHwgW10sIGFwaS50eXBlcy5JbnRlcmFjdGlvbiwgdGhpcyk7XG5cblx0dGhpcy5saW5rVG9FdmVudCA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuRXZlbnQsIHRoaXMuYXR0cmlicy5MaW5rVG9FdmVudCwgdGhpcyk7XG5cblx0dGhpcy5saW1pdGVkVG9BcmVhID0gYXBpLmdldE9yQ3JlYXRlKGFwaS50eXBlcy5BcmVhLCB0aGlzLmF0dHJpYnMuTGltaXRlZFRvQXJlYSwgdGhpcyk7XG5cblx0dGhpcy5zZXR0aW5nID0gYXBpLmdldE9yQ3JlYXRlKGFwaS50eXBlcy5TZXR0aW5nLCB0aGlzLmF0dHJpYnMuU2V0dGluZywgdGhpcyk7XG5cdFxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzLCBhcGkpO1xufTtcblxuRXZlbnQucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyAobG9uZyA/IFwiIFtcIiArIHRoaXMuQ2F0ZWdvcnkgKyBcIl0gXCIgOiBcIlwiKSArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5FdmVudC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4pIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXHRpbmNsdWRlQ2hpbGRyZW4gPSBpbmNsdWRlQ2hpbGRyZW4gPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xuXG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRpZih0aGlzLkltYWdlICE9PSBudWxsICYmIHRoaXMuSW1hZ2UgIT09IFwiXCIpIHtcblx0XHRodG1sID0gXCI8aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5JbWFnZStcInNtYWxsLnBuZycgLz5cIjtcblx0fVxuXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCJcXG5cIisodGhpcy50YWcgPyBcIjxzcGFuIGNsYXNzPSd0YWcgXCIrdGhpcy50YWcrXCInPlwiK3RoaXMudGFnK1wiPC9zcGFuPlwiIDogXCJcIikrXCI8L2gzPlwiO1xuXG5cdGlmKHNpemUgIT0gXCJzbWFsbFwiICYmICh0aGlzLnF1YWxpdGllc1JlcXVpcmVkIHx8IHRoaXMucXVhbGl0aWVzQWZmZWN0ZWQpKSB7XG5cdFx0aHRtbCArPSBcIjxkaXYgY2xhc3M9J3NpZGViYXInPlwiO1xuXHRcdGlmKHRoaXMucXVhbGl0aWVzUmVxdWlyZWQgJiYgdGhpcy5xdWFsaXRpZXNSZXF1aXJlZC5zaXplKCkpIHtcblx0XHRcdGh0bWwgKz0gXCI8aDQ+UmVxdWlyZW1lbnRzPC9oND5cXG5cIjtcblx0XHRcdGh0bWwgKz0gdGhpcy5xdWFsaXRpZXNSZXF1aXJlZC50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInVsXCIpLm91dGVySFRNTDtcblx0XHR9XG5cdFx0aWYodGhpcy5xdWFsaXRpZXNBZmZlY3RlZCAmJiB0aGlzLnF1YWxpdGllc0FmZmVjdGVkLnNpemUoKSkge1xuXHRcdFx0aHRtbCArPSBcIjxoND5FZmZlY3RzPC9oND5cXG5cIjtcblx0XHRcdGh0bWwgKz0gdGhpcy5xdWFsaXRpZXNBZmZlY3RlZC50b0RvbShcInNtYWxsXCIsIGZhbHNlLCBcInVsXCIpLm91dGVySFRNTDtcblx0XHR9XG5cdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xuXHR9XG5cdFxuXHRodG1sICs9IFwiPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xuXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcblxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZyh0cnVlKTtcblxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcblx0XHR2YXIgc2VsZiA9IHRoaXM7XG5cdFx0ZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oZSkge1xuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblxuXHRcdFx0dmFyIGNoaWxkTGlzdCA9IGVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5jaGlsZC1saXN0XCIpO1xuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR2YXIgaW50ZXJhY3Rpb25zID0gc2VsZi5pbnRlcmFjdGlvbnM7XG5cdFx0XHRcdHZhciBsaW5rVG9FdmVudCA9IHNlbGYubGlua1RvRXZlbnQ7XG5cdFx0XHRcdGlmKGxpbmtUb0V2ZW50KSB7XG5cdFx0XHRcdFx0dmFyIHdyYXBwZXJDbHVtcCA9IG5ldyBDbHVtcChbbGlua1RvRXZlbnRdLCBhcGkudHlwZXMuRXZlbnQpO1xuXHRcdFx0XHRcdHZhciBsaW5rVG9FdmVudF9lbGVtZW50ID0gd3JhcHBlckNsdW1wLnRvRG9tKFwibm9ybWFsXCIsIHRydWUpO1xuXG5cdFx0XHRcdFx0bGlua1RvRXZlbnRfZWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGxpbmtUb0V2ZW50X2VsZW1lbnQpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGVsc2UgaWYoaW50ZXJhY3Rpb25zICYmIGludGVyYWN0aW9ucy5zaXplKCkgPiAwKSB7XG5cdFx0XHRcdFx0dmFyIGludGVyYWN0aW9uc19lbGVtZW50ID0gaW50ZXJhY3Rpb25zLnRvRG9tKFwibm9ybWFsXCIsIHRydWUpO1xuXG5cdFx0XHRcdFx0aW50ZXJhY3Rpb25zX2VsZW1lbnQuY2xhc3NMaXN0LmFkZChcImNoaWxkLWxpc3RcIik7XG5cdFx0XHRcdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChpbnRlcmFjdGlvbnNfZWxlbWVudCk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdHJldHVybiBlbGVtZW50O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBFdmVudDsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBFeGNoYW5nZShyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0XHQnSWQnLFxuXHRcdCdOYW1lJyxcblx0XHQnRGVzY3JpcHRpb24nLFxuXHRcdCdJbWFnZScsXG5cdFx0J1NldHRpbmdJZHMnXG5cdF07XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLnNob3BzID0gbnVsbDtcblx0dGhpcy5zZXR0aW5ncyA9IG51bGw7XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgRXhjaGFuZ2UucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuRXhjaGFuZ2UucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xuXG5cdGFwaSA9IHRoZUFwaTtcblxuXHR2YXIgc2VsZiA9IHRoaXM7XG5cblx0dGhpcy5zaG9wcyA9IG5ldyBDbHVtcCh0aGlzLmF0dHJpYnMuU2hvcHMgfHwgW10sIGFwaS50eXBlcy5TaG9wLCB0aGlzKTtcblx0XG5cdHRoaXMuc2V0dGluZ3MgPSBhcGkubGlicmFyeS5TZXR0aW5nLnF1ZXJ5KFwiSWRcIiwgZnVuY3Rpb24oaWQpIHtcblx0XHRyZXR1cm4gc2VsZi5TZXR0aW5nSWRzLmluZGV4T2YoaWQpICE9PSAtMTtcblx0fSk7XG5cdHRoaXMuc2V0dGluZ3MuZm9yRWFjaChmdW5jdGlvbiAocykge1xuXHRcdHNlbGYucGFyZW50cy5wdXNoKHMpO1xuXHR9KTtcblx0XG5cdHRoaXMucG9ydHMgPSBhcGkubGlicmFyeS5Qb3J0LnF1ZXJ5KFwiU2V0dGluZ0lkXCIsIGZ1bmN0aW9uKGlkKSB7XG5cdFx0cmV0dXJuIHNlbGYuU2V0dGluZ0lkcy5pbmRleE9mKGlkKSAhPT0gLTE7XG5cdH0pO1xuXHR0aGlzLnBvcnRzLmZvckVhY2goZnVuY3Rpb24gKHApIHtcblx0XHRzZWxmLnBhcmVudHMucHVzaChwKTtcblx0fSk7XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcyk7XG59O1xuXG5FeGNoYW5nZS5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5OYW1lICsgXCIgKCNcIiArIHRoaXMuSWQgKyBcIilcIjtcbn07XG5cbkV4Y2hhbmdlLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblx0dGFnID0gdGFnIHx8IFwibGlcIjtcblxuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRodG1sID0gXCJcXG48aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5JbWFnZStcIi5wbmcnIC8+XCI7XG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCI8L2gzPlwiO1xuXHRodG1sICs9IFwiXFxuPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xuXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcblxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xuXG5cdGlmKGluY2x1ZGVDaGlsZHJlbikge1xuXHRcdGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uKGUpIHtcblx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XG5cblx0XHRcdHZhciBjaGlsZExpc3QgPSBlbGVtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY2hpbGQtbGlzdFwiKTtcblx0XHRcdGlmKGNoaWxkTGlzdCkge1xuXHRcdFx0XHRlbGVtZW50LnJlbW92ZUNoaWxkKGNoaWxkTGlzdCk7XG5cdFx0XHR9XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0aWYoc2VsZi5zaG9wcykge1xuXG5cdFx0XHRcdFx0dmFyIGNoaWxkX2VsZW1lbnRzID0gc2VsZi5zaG9wcy50b0RvbShcIm5vcm1hbFwiLCB0cnVlKTtcblxuXHRcdFx0XHRcdGNoaWxkX2VsZW1lbnRzLmNsYXNzTGlzdC5hZGQoXCJjaGlsZC1saXN0XCIpO1xuXHRcdFx0XHRcdGVsZW1lbnQuYXBwZW5kQ2hpbGQoY2hpbGRfZWxlbWVudHMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gRXhjaGFuZ2U7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gSW50ZXJhY3Rpb24ocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXG5cdCdOYW1lJyxcblx0J0Rlc2NyaXB0aW9uJyxcblx0J0J1dHRvblRleHQnLFxuXHQnSW1hZ2UnLFxuXG5cdCdPcmRlcmluZydcblx0XTtcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG5cdHRoaXMucXVhbGl0aWVzUmVxdWlyZWQgPSBudWxsO1xuXHR0aGlzLnN1Y2Nlc3NFdmVudCA9IG51bGw7XG5cdHRoaXMuZGVmYXVsdEV2ZW50ID0gbnVsbDtcblxufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IEludGVyYWN0aW9uLnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XG5cbkludGVyYWN0aW9uLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy5xdWFsaXRpZXNSZXF1aXJlZCA9IG5ldyBDbHVtcCh0aGlzLmF0dHJpYnMuUXVhbGl0aWVzUmVxdWlyZWQgfHwgW10sIGFwaS50eXBlcy5RdWFsaXR5UmVxdWlyZW1lbnQsIHRoaXMpO1xuXHR0aGlzLnN1Y2Nlc3NFdmVudCA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuRXZlbnQsIHRoaXMuYXR0cmlicy5TdWNjZXNzRXZlbnQsIHRoaXMpO1xuXHRpZih0aGlzLnN1Y2Nlc3NFdmVudCkge1xuXHRcdHRoaXMuc3VjY2Vzc0V2ZW50LnRhZyA9IFwic3VjY2Vzc1wiO1xuXHR9XG5cdHRoaXMuZGVmYXVsdEV2ZW50ID0gYXBpLmdldE9yQ3JlYXRlKGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLkRlZmF1bHRFdmVudCwgdGhpcyk7XG5cdHZhciBxdWFsaXRpZXNSZXF1aXJlZCA9ICB0aGlzLnF1YWxpdGllc1JlcXVpcmVkO1xuXHRpZih0aGlzLmRlZmF1bHRFdmVudCAmJiB0aGlzLnN1Y2Nlc3NFdmVudCAmJiBxdWFsaXRpZXNSZXF1aXJlZCAmJiBxdWFsaXRpZXNSZXF1aXJlZC5zaXplKCkpIHtcblx0XHR0aGlzLmRlZmF1bHRFdmVudC50YWcgPSBcImZhaWx1cmVcIjtcblx0fVxuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5JbnRlcmFjdGlvbi5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFtcIiArIHRoaXMuT3JkZXJpbmcgKyBcIl0gXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xufTtcblxuSW50ZXJhY3Rpb24ucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSwgaW5jbHVkZUNoaWxkcmVuKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblxuXHR2YXIgaHRtbCA9IFwiXCI7XG5cblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0aWYodGhpcy5JbWFnZSAhPT0gbnVsbCAmJiB0aGlzLkltYWdlICE9PSBcIlwiKSB7XG5cdFx0aHRtbCA9IFwiPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCJzbWFsbC5wbmcnIC8+XCI7XG5cdH1cblxuXHRodG1sICs9IFwiXFxuPGgzIGNsYXNzPSd0aXRsZSc+XCIrdGhpcy5OYW1lK1wiPC9oMz5cIjtcblxuXHRpZihzaXplICE9IFwic21hbGxcIiAmJiB0aGlzLnF1YWxpdGllc1JlcXVpcmVkKSB7XG5cdFx0aHRtbCArPSBcIjxkaXYgY2xhc3M9J3NpZGViYXInPlwiO1xuXHRcdGh0bWwgKz0gXCI8aDQ+UmVxdWlyZW1lbnRzPC9oND5cIjtcblx0XHRodG1sICs9IHRoaXMucXVhbGl0aWVzUmVxdWlyZWQudG9Eb20oXCJzbWFsbFwiLCBmYWxzZSwgXCJ1bFwiKS5vdXRlckhUTUw7XG5cdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xuXHR9XG5cblx0aHRtbCArPSBcIjxwIGNsYXNzPSdkZXNjcmlwdGlvbic+XCIrdGhpcy5EZXNjcmlwdGlvbitcIjwvcD5cIjtcblxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XG5cblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcblx0XHR2YXIgc2VsZiA9IHRoaXM7XG5cdFx0ZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oZSkge1xuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblxuXHRcdFx0dmFyIGNoaWxkTGlzdCA9IGVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5jaGlsZC1saXN0XCIpO1xuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR2YXIgc3VjY2Vzc0V2ZW50ID0gc2VsZi5zdWNjZXNzRXZlbnQ7XG5cdFx0XHRcdHZhciBkZWZhdWx0RXZlbnQgPSBzZWxmLmRlZmF1bHRFdmVudDtcblx0XHRcdFx0dmFyIHF1YWxpdGllc1JlcXVpcmVkID0gIHNlbGYucXVhbGl0aWVzUmVxdWlyZWQ7XG5cdFx0XHRcdHZhciBldmVudHMgPSBbXTtcblx0XHRcdFx0aWYoc3VjY2Vzc0V2ZW50ICYmIHF1YWxpdGllc1JlcXVpcmVkICYmIHF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xuXHRcdFx0XHRcdGV2ZW50cy5wdXNoKHN1Y2Nlc3NFdmVudCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYoZGVmYXVsdEV2ZW50KSB7XG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goZGVmYXVsdEV2ZW50KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZihldmVudHMubGVuZ3RoKSB7XG5cdFx0XHRcdFx0dmFyIHdyYXBwZXJDbHVtcCA9IG5ldyBDbHVtcChldmVudHMsIGFwaS50eXBlcy5FdmVudCk7XG5cdFx0XHRcdFx0dmFyIGNoaWxkX2V2ZW50cyA9IHdyYXBwZXJDbHVtcC50b0RvbShcIm5vcm1hbFwiLCB0cnVlKTtcblxuXHRcdFx0XHRcdGNoaWxkX2V2ZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2V2ZW50cyk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdHJldHVybiBlbGVtZW50O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBJbnRlcmFjdGlvbjsiLCJ2YXIgbGlicmFyeSA9IHJlcXVpcmUoJy4uL2xpYnJhcnknKTtcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gTHVtcChyYXcsIHBhcmVudCkge1xuXHRpZihwYXJlbnQpIHtcblx0XHR0aGlzLnBhcmVudHMgPSBwYXJlbnQgaW5zdGFuY2VvZiBBcnJheSA/IHBhcmVudCA6IFtwYXJlbnRdO1xuXHR9XG5cdGVsc2Uge1xuXHRcdHRoaXMucGFyZW50cyA9IFtdO1xuXHR9XG5cblx0aWYoIXRoaXMuc3RyYWlnaHRDb3B5KSB7XG5cdFx0dGhpcy5zdHJhaWdodENvcHkgPSBbXTtcblx0fVxuXHR0aGlzLnN0cmFpZ2h0Q29weS51bnNoaWZ0KCdJZCcpO1xuXG5cdHRoaXMuYXR0cmlicyA9IHJhdztcblxuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdHRoaXMuc3RyYWlnaHRDb3B5LmZvckVhY2goZnVuY3Rpb24oYXR0cmliKSB7XG5cdFx0c2VsZlthdHRyaWJdID0gcmF3W2F0dHJpYl07XG5cdFx0aWYodHlwZW9mIHNlbGZbYXR0cmliXSA9PT0gXCJ1bmRlZmluZWRcIikge1xuXHRcdFx0c2VsZlthdHRyaWJdID0gbnVsbDtcblx0XHR9XG5cdH0pO1xuXHRkZWxldGUodGhpcy5zdHJhaWdodENvcHkpO1xuXG5cdHRoaXMud2lyZWQgPSBmYWxzZTtcblxuXHRpZighbGlicmFyeVt0aGlzLmNvbnN0cnVjdG9yLm5hbWVdKSB7XG5cdFx0bGlicmFyeVt0aGlzLmNvbnN0cnVjdG9yLm5hbWVdID0gbmV3IENsdW1wKFtdLCB0aGlzKTtcblx0fVxuXHRsaWJyYXJ5W3RoaXMuY29uc3RydWN0b3IubmFtZV0uaXRlbXNbdGhpcy5JZF0gPSB0aGlzO1xufVxuXG5MdW1wLnByb3RvdHlwZSA9IHtcblx0d2lyZVVwOiBmdW5jdGlvbih0aGVBcGkpIHtcblx0XHRhcGkgPSB0aGVBcGk7XG5cdFx0dGhpcy53aXJlZCA9IHRydWU7XG5cdH0sXG5cblx0Z2V0U3RhdGVzOiBmdW5jdGlvbihlbmNvZGVkKSB7XG5cdFx0aWYodHlwZW9mIGVuY29kZWQgPT09IFwic3RyaW5nXCIgJiYgZW5jb2RlZCAhPT0gXCJcIikge1xuXHRcdFx0dmFyIG1hcCA9IHt9O1xuXHRcdFx0ZW5jb2RlZC5zcGxpdChcIn5cIikuZm9yRWFjaChmdW5jdGlvbihzdGF0ZSkge1xuXHRcdFx0XHR2YXIgcGFpciA9IHN0YXRlLnNwbGl0KFwifFwiKTtcblx0XHRcdFx0bWFwW3BhaXJbMF1dID0gcGFpclsxXTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIG1hcDtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHRyZXR1cm4gbnVsbDtcblx0XHR9XG5cdH0sXG5cblx0Z2V0RXhvdGljRWZmZWN0OiBmdW5jdGlvbihlbmNvZGVkKSB7XG5cdFx0aWYodHlwZW9mIGVuY29kZWQgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdHZhciBlZmZlY3Q9e30sIGZpZWxkcz1bXCJvcGVyYXRpb25cIiwgXCJmaXJzdFwiLCBcInNlY29uZFwiXTtcblx0XHRcdGVuY29kZWQuc3BsaXQoXCIsXCIpLmZvckVhY2goZnVuY3Rpb24odmFsLCBpbmRleCkge1xuXHRcdFx0XHRlZmZlY3RbZmllbGRzW2luZGV4XV0gPSB2YWw7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBlZmZlY3Q7XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHR9LFxuXG5cdGV2YWxBZHZhbmNlZEV4cHJlc3Npb246IGZ1bmN0aW9uKGV4cHIpIHtcblx0XHRleHByID0gZXhwci5yZXBsYWNlKC9cXFtkOihcXGQrKVxcXS9naSwgXCJNYXRoLmZsb29yKChNYXRoLnJhbmRvbSgpKiQxKSsxKVwiKTtcdC8vIFJlcGxhY2UgW2Q6eF0gd2l0aCBKUyB0byBjYWxjdWxhdGUgcmFuZG9tIG51bWJlciBvbiBhIER4IGRpZVxuXHRcdC8qanNoaW50IC1XMDYxICovXG5cdFx0cmV0dXJuIGV2YWwoZXhwcik7XG5cdFx0Lypqc2hpbnQgK1cwNjEgKi9cblx0fSxcblxuXHRpc0E6IGZ1bmN0aW9uKHR5cGUpIHtcblx0XHRyZXR1cm4gdGhpcyBpbnN0YW5jZW9mIHR5cGU7XG5cdH0sXG5cblx0aXNPbmVPZjogZnVuY3Rpb24odHlwZXMpIHtcblx0XHR2YXIgc2VsZiA9IHRoaXM7XG5cdFx0cmV0dXJuIHR5cGVzLm1hcChmdW5jdGlvbih0eXBlKSB7XG5cdFx0XHRyZXR1cm4gc2VsZi5pc0EodHlwZSk7XG5cdFx0fSkucmVkdWNlKGZ1bmN0aW9uKHByZXZpb3VzVmFsdWUsIGN1cnJlbnRWYWx1ZSwgaW5kZXgsIGFycmF5KXtcblx0XHRcdHJldHVybiBwcmV2aW91c1ZhbHVlIHx8IGN1cnJlbnRWYWx1ZTtcblx0XHR9LCBmYWxzZSk7XG5cdH0sXG5cblx0dG9TdHJpbmc6IGZ1bmN0aW9uKCkge1xuXHRcdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xuXHR9XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEx1bXA7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gUG9ydChyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0XHQnTmFtZScsXG5cdFx0J1JvdGF0aW9uJyxcblx0XHQnUG9zaXRpb24nLFxuXHRcdCdEaXNjb3ZlcnlWYWx1ZScsXG5cdFx0J0lzU3RhcnRpbmdQb3J0J1xuXHRdO1xuXG5cblx0cmF3LklkID0gcmF3Lk5hbWU7XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLlNldHRpbmdJZCA9IHJhdy5TZXR0aW5nLklkO1xuXHR0aGlzLnNldHRpbmcgPSBudWxsO1xuXG5cdHRoaXMuYXJlYSA9IG51bGw7XG5cblx0dGhpcy5leGNoYW5nZXMgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFBvcnQucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuUG9ydC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cdFxuXHRhcGkgPSB0aGVBcGk7XG5cdHZhciBzZWxmID0gdGhpcztcblxuXHR0aGlzLnNldHRpbmcgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLlNldHRpbmcsIHRoaXMuYXR0cmlicy5TZXR0aW5nLCB0aGlzKTtcblx0XG5cdHRoaXMuYXJlYSA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuQXJlYSwgdGhpcy5hdHRyaWJzLkFyZWEsIHRoaXMpO1xuXG5cdHRoaXMuZXhjaGFuZ2VzID0gYXBpLmxpYnJhcnkuRXhjaGFuZ2UucXVlcnkoXCJTZXR0aW5nSWRzXCIsIGZ1bmN0aW9uKGlkcykgeyByZXR1cm4gaWRzLmluZGV4T2Yoc2VsZi5TZXR0aW5nSWQpICE9PSAtMTsgfSk7XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcbn07XG5cblBvcnQucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XG59O1xuXG5Qb3J0LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIHRhZykge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdHRhZyA9IHRhZyB8fCBcImxpXCI7XG5cblx0dmFyIGh0bWwgPSBcIlwiO1xuXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdGh0bWwgPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFBvcnQ7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gUXVhbGl0eUVmZmVjdChyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcIkxldmVsXCIsIFwiU2V0VG9FeGFjdGx5XCJdO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0Ly8gTWF5IGludm9sdmUgUXVhbGl0eSBvYmplY3QgcmVmZXJlbmNlcywgc28gY2FuJ3QgcmVzb2x2ZSB1bnRpbCBhZnRlciBhbGwgb2JqZWN0cyBhcmUgd2lyZWQgdXBcblx0dGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCA9IG51bGw7XG5cdHRoaXMuY2hhbmdlQnlBZHZhbmNlZCA9IG51bGw7XHRcblxuXHR0aGlzLmFzc29jaWF0ZWRRdWFsaXR5ID0gbnVsbDtcblx0XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgUXVhbGl0eUVmZmVjdC5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy5hc3NvY2lhdGVkUXVhbGl0eSA9IGFwaS5nZXQoYXBpLnR5cGVzLlF1YWxpdHksIHRoaXMuYXR0cmlicy5Bc3NvY2lhdGVkUXVhbGl0eUlkLCB0aGlzKTtcblx0dGhpcy5zZXRUb0V4YWN0bHlBZHZhbmNlZCA9IGFwaS5kZXNjcmliZUFkdmFuY2VkRXhwcmVzc2lvbih0aGlzLmF0dHJpYnMuU2V0VG9FeGFjdGx5QWR2YW5jZWQpO1xuXHR0aGlzLmNoYW5nZUJ5QWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLkNoYW5nZUJ5QWR2YW5jZWQpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS5nZXRRdWFudGl0eSA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgY29uZGl0aW9uID0gXCJcIjtcblx0XG5cdGlmKHRoaXMuc2V0VG9FeGFjdGx5QWR2YW5jZWQgIT09IG51bGwpIHtcblx0XHRjb25kaXRpb24gPSBcIisoXCIgKyB0aGlzLnNldFRvRXhhY3RseUFkdmFuY2VkICsgXCIpXCI7XG5cdH1cblx0ZWxzZSBpZih0aGlzLlNldFRvRXhhY3RseSAhPT0gbnVsbCkge1xuXHRcdGNvbmRpdGlvbiA9IFwiPSBcIiArIHRoaXMuU2V0VG9FeGFjdGx5O1xuXHR9XG5cdGVsc2UgaWYodGhpcy5jaGFuZ2VCeUFkdmFuY2VkICE9PSBudWxsKSB7XG5cdFx0Y29uZGl0aW9uID0gXCIrKFwiICsgdGhpcy5jaGFuZ2VCeUFkdmFuY2VkICsgXCIpXCI7XG5cdH1cblx0ZWxzZSBpZih0aGlzLkxldmVsICE9PSBudWxsKSB7XG5cdFx0aWYodGhpcy5MZXZlbCA8IDApIHtcblx0XHRcdGNvbmRpdGlvbiA9IHRoaXMuTGV2ZWw7XG5cdFx0fVxuXHRcdGVsc2UgaWYodGhpcy5MZXZlbCA+IDApIHtcblx0XHRcdGNvbmRpdGlvbiA9IFwiK1wiICsgdGhpcy5MZXZlbDtcblx0XHR9XG5cdH1cblx0XG5cdHJldHVybiBjb25kaXRpb247XG59O1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS5pc0FkZGl0aXZlID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiB0aGlzLnNldFRvRXhhY3RseUFkdmFuY2VkIHx8IHRoaXMuU2V0VG9FeGFjdGx5IHx8IHRoaXMuY2hhbmdlQnlBZHZhbmNlZCB8fCAodGhpcy5MZXZlbCA+IDApO1xufTtcblxuUXVhbGl0eUVmZmVjdC5wcm90b3R5cGUuaXNTdWJ0cmFjdGl2ZSA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gIXRoaXMuc2V0VG9FeGFjdGx5QWR2YW5jZWQgJiYgIXRoaXMuU2V0VG9FeGFjdGx5ICYmICF0aGlzLmNoYW5nZUJ5QWR2YW5jZWQgJiYgKHRoaXMuTGV2ZWwgPD0gMCk7XG59O1xuXG5RdWFsaXR5RWZmZWN0LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgcXVhbGl0eSA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoXCIrdGhpcy5JZCtcIikgb24gXCIgKyBxdWFsaXR5ICsgdGhpcy5nZXRRdWFudGl0eSgpO1xufTtcblxuUXVhbGl0eUVmZmVjdC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJzbWFsbFwiO1xuXG5cdHZhciBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0dmFyIHF1YWxpdHlfZWxlbWVudCA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XG5cblx0aWYoIXF1YWxpdHlfZWxlbWVudCkge1xuXHRcdHF1YWxpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRcdHF1YWxpdHlfZWxlbWVudC5pbm5lckhUTUwgPSBcIltJTlZBTElEXVwiO1xuXHR9XG5cdGVsc2Uge1xuXHRcdHF1YWxpdHlfZWxlbWVudCA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHkudG9Eb20oc2l6ZSwgZmFsc2UsIFwic3BhblwiKTtcblx0fVxuXG5cdHZhciBxdWFudGl0eV9lbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG5cdHF1YW50aXR5X2VsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIHF1YW50aXR5XCI7XG5cdHF1YW50aXR5X2VsZW1lbnQuaW5uZXJIVE1MID0gdGhpcy5nZXRRdWFudGl0eSgpO1xuXHRxdWFudGl0eV9lbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xuXG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQocXVhbGl0eV9lbGVtZW50KTtcblx0ZWxlbWVudC5hcHBlbmRDaGlsZChxdWFudGl0eV9lbGVtZW50KTtcblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gUXVhbGl0eUVmZmVjdDsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBRdWFsaXR5UmVxdWlyZW1lbnQocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbJ01pbkxldmVsJywgJ01heExldmVsJ107XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLmRpZmZpY3VsdHlBZHZhbmNlZCA9IG51bGw7XG5cdHRoaXMubWluQWR2YW5jZWQgPSBudWxsO1xuXHR0aGlzLm1heEFkdmFuY2VkID0gbnVsbDtcblxuXHR0aGlzLmFzc29jaWF0ZWRRdWFsaXR5ID0gbnVsbDtcblx0dGhpcy5jaGFuY2VRdWFsaXR5ID0gbnVsbDtcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBRdWFsaXR5UmVxdWlyZW1lbnQucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuUXVhbGl0eVJlcXVpcmVtZW50LnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy5kaWZmaWN1bHR5QWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLkRpZmZpY3VsdHlBZHZhbmNlZCk7XG5cdHRoaXMubWluQWR2YW5jZWQgPSBhcGkuZGVzY3JpYmVBZHZhbmNlZEV4cHJlc3Npb24odGhpcy5hdHRyaWJzLk1pbkFkdmFuY2VkKTtcblx0dGhpcy5tYXhBZHZhbmNlZCA9IGFwaS5kZXNjcmliZUFkdmFuY2VkRXhwcmVzc2lvbih0aGlzLmF0dHJpYnMuTWF4QWR2YW5jZWQpO1xuXG5cdHRoaXMuYXNzb2NpYXRlZFF1YWxpdHkgPSBhcGkuZ2V0KGFwaS50eXBlcy5RdWFsaXR5LCB0aGlzLmF0dHJpYnMuQXNzb2NpYXRlZFF1YWxpdHlJZCwgdGhpcyk7XG5cblx0dGhpcy5jaGFuY2VRdWFsaXR5ID0gdGhpcy5nZXRDaGFuY2VDYXAoKTtcblxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzLCBhcGkpO1xufTtcblxuUXVhbGl0eVJlcXVpcmVtZW50LnByb3RvdHlwZS5nZXRDaGFuY2VDYXAgPSBmdW5jdGlvbigpIHtcblx0dmFyIHF1YWxpdHkgPSBudWxsO1xuXHRpZighdGhpcy5hdHRyaWJzLkRpZmZpY3VsdHlMZXZlbCkge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdHF1YWxpdHkgPSB0aGlzLmFzc29jaWF0ZWRRdWFsaXR5O1xuXHRpZighcXVhbGl0eSkge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdFxuXHRyZXR1cm4gTWF0aC5yb3VuZCh0aGlzLmF0dHJpYnMuRGlmZmljdWx0eUxldmVsICogKCgxMDAgKyBxdWFsaXR5LkRpZmZpY3VsdHlTY2FsZXIgKyA3KS8xMDApKTtcbn07XG5cblF1YWxpdHlSZXF1aXJlbWVudC5wcm90b3R5cGUuZ2V0UXVhbnRpdHkgPSBmdW5jdGlvbigpIHtcblx0dmFyIGNvbmRpdGlvbiA9IFwiXCI7XG5cbiAgaWYodGhpcy5kaWZmaWN1bHR5QWR2YW5jZWQgIT09IG51bGwpIHtcbiAgXHRjb25kaXRpb24gPSB0aGlzLmRpZmZpY3VsdHlBZHZhbmNlZDtcbiAgfVxuICBlbHNlIGlmKHRoaXMubWluQWR2YW5jZWQgIT09IG51bGwpIHtcbiAgXHRjb25kaXRpb24gPSB0aGlzLm1pbkFkdmFuY2VkO1xuICB9XG4gIGVsc2UgaWYodGhpcy5tYXhBZHZhbmNlZCAhPT0gbnVsbCkge1xuICBcdGNvbmRpdGlvbiA9IHRoaXMubWF4QWR2YW5jZWQ7XG4gIH1cblx0ZWxzZSBpZih0aGlzLmNoYW5jZVF1YWxpdHkgIT09IG51bGwpIHtcblx0XHRjb25kaXRpb24gPSB0aGlzLmNoYW5jZVF1YWxpdHkgKyBcIiBmb3IgMTAwJVwiO1xuXHR9XG5cdGVsc2UgaWYodGhpcy5NYXhMZXZlbCAhPT0gbnVsbCAmJiB0aGlzLk1pbkxldmVsICE9PSBudWxsKSB7XG5cdFx0aWYodGhpcy5NYXhMZXZlbCA9PT0gdGhpcy5NaW5MZXZlbCkge1xuXHRcdFx0Y29uZGl0aW9uID0gXCI9IFwiICsgdGhpcy5NaW5MZXZlbDtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25kaXRpb24gPSB0aGlzLk1pbkxldmVsICsgXCItXCIgKyB0aGlzLk1heExldmVsO1xuXHRcdH1cblx0fVxuXHRlbHNlIHtcblx0XHRpZih0aGlzLk1pbkxldmVsICE9PSBudWxsKSB7XG5cdFx0XHRjb25kaXRpb24gPSBcIiZnZTsgXCIgKyB0aGlzLk1pbkxldmVsO1xuXHRcdH1cblx0XHRpZih0aGlzLk1heExldmVsICE9PSBudWxsKSB7XG5cdFx0XHRjb25kaXRpb24gPSBcIiZsZTsgXCIgKyB0aGlzLk1heExldmVsO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gY29uZGl0aW9uO1xufTtcblxuUXVhbGl0eVJlcXVpcmVtZW50LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHR2YXIgcXVhbGl0eSA9IHRoaXMuYXNzb2NpYXRlZFF1YWxpdHk7XG5cdHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUgKyBcIiAoXCIrdGhpcy5JZCtcIikgb24gXCIgKyBxdWFsaXR5ICsgXCIgXCIgKyB0aGlzLmdldFF1YW50aXR5KCk7XG59O1xuXG5RdWFsaXR5UmVxdWlyZW1lbnQucHJvdG90eXBlLnRvRG9tID0gZnVuY3Rpb24oc2l6ZSkge1xuXG5cdHNpemUgPSBzaXplIHx8IFwic21hbGxcIjtcblxuXHR2YXIgZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdHZhciBxdWFsaXR5X2VsZW1lbnQgPSB0aGlzLmFzc29jaWF0ZWRRdWFsaXR5O1xuXG5cdGlmKCFxdWFsaXR5X2VsZW1lbnQpIHtcblx0XHRxdWFsaXR5X2VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcblx0XHRxdWFsaXR5X2VsZW1lbnQuaW5uZXJIVE1MID0gXCJbSU5WQUxJRF1cIjtcblx0fVxuXHRlbHNlIHtcblx0XHRxdWFsaXR5X2VsZW1lbnQgPSB0aGlzLmFzc29jaWF0ZWRRdWFsaXR5LnRvRG9tKHNpemUsIGZhbHNlLCBcInNwYW5cIik7XG5cdH1cblxuXHR2YXIgcXVhbnRpdHlfZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRxdWFudGl0eV9lbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBxdWFudGl0eVwiO1xuXHRxdWFudGl0eV9lbGVtZW50LmlubmVySFRNTCA9IHRoaXMuZ2V0UXVhbnRpdHkoKTtcblx0cXVhbnRpdHlfZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRlbGVtZW50LmFwcGVuZENoaWxkKHF1YWxpdHlfZWxlbWVudCk7XG5cdGVsZW1lbnQuYXBwZW5kQ2hpbGQocXVhbnRpdHlfZWxlbWVudCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFF1YWxpdHlSZXF1aXJlbWVudDsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBRdWFsaXR5KHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdOYW1lJyxcblx0XHQnRGVzY3JpcHRpb24nLFxuXHRcdCdJbWFnZScsXG5cblx0XHQnQ2F0ZWdvcnknLFxuXHRcdCdOYXR1cmUnLFxuXHRcdCdUYWcnLFxuXG5cdFx0XCJJc1Nsb3RcIixcblxuXHRcdCdBbGxvd2VkT24nLFxuXHRcdFwiQXZhaWxhYmxlQXRcIixcblxuXHRcdCdDYXAnLFxuXHRcdCdEaWZmaWN1bHR5U2NhbGVyJyxcblx0XHQnRW5oYW5jZW1lbnRzJ1xuXHRdO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy5TdGF0ZXMgPSB0aGlzLmdldFN0YXRlcyhyYXcuQ2hhbmdlRGVzY3JpcHRpb25UZXh0KTtcblx0dGhpcy5MZXZlbERlc2NyaXB0aW9uVGV4dCA9IHRoaXMuZ2V0U3RhdGVzKHJhdy5MZXZlbERlc2NyaXB0aW9uVGV4dCk7XG5cdHRoaXMuTGV2ZWxJbWFnZVRleHQgPSB0aGlzLmdldFN0YXRlcyhyYXcuTGV2ZWxJbWFnZVRleHQpO1xuXG5cdHRoaXMudXNlRXZlbnQgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFF1YWxpdHkucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuUXVhbGl0eS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHRoaXMudXNlRXZlbnQgPSBhcGkuZ2V0T3JDcmVhdGUoYXBpLnR5cGVzLkV2ZW50LCB0aGlzLmF0dHJpYnMuVXNlRXZlbnQsIHRoaXMpO1xuXHRpZih0aGlzLnVzZUV2ZW50KSB7XG5cdFx0dGhpcy51c2VFdmVudC50YWcgPSBcInVzZVwiO1xuXHR9XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcywgYXBpKTtcbn07XG5cblF1YWxpdHkucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyAobG9uZyA/IFwiIFtcIiArIHRoaXMuTmF0dXJlICsgXCIgPiBcIiArIHRoaXMuQ2F0ZWdvcnkgKyBcIiA+IFwiICsgdGhpcy5UYWcgKyBcIl0gXCIgOiBcIlwiKSArIHRoaXMuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5RdWFsaXR5LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblx0dGFnID0gdGFnIHx8IFwibGlcIjtcblxuXHR2YXIgaHRtbCA9IFwiXCI7XG5cblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0aHRtbCA9IFwiXFxuPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCJzbWFsbC5wbmcnIC8+XCI7XG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLk5hbWUrXCI8L2gzPlwiO1xuXHRodG1sICs9IFwiXFxuPHAgY2xhc3M9J2Rlc2NyaXB0aW9uJz5cIit0aGlzLkRlc2NyaXB0aW9uK1wiPC9wPlwiO1xuXG5cdGVsZW1lbnQuaW5uZXJIVE1MID0gaHRtbDtcblxuXHRlbGVtZW50LnRpdGxlID0gdGhpcy50b1N0cmluZygpO1xuXG5cdGlmKGluY2x1ZGVDaGlsZHJlbikge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XG5cdFx0XHRpZihjaGlsZExpc3QpIHtcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGlmKHNlbGYudXNlRXZlbnQpIHtcblxuXHRcdFx0XHRcdHZhciB3cmFwcGVyQ2x1bXAgPSBuZXcgQ2x1bXAoW3NlbGYudXNlRXZlbnRdLCBhcGkudHlwZXMuRXZlbnQpO1xuXHRcdFx0XHRcdHZhciBjaGlsZF9ldmVudHMgPSB3cmFwcGVyQ2x1bXAudG9Eb20oc2l6ZSwgdHJ1ZSk7XG5cblx0XHRcdFx0XHRjaGlsZF9ldmVudHMuY2xhc3NMaXN0LmFkZChcImNoaWxkLWxpc3RcIik7XG5cdFx0XHRcdFx0ZWxlbWVudC5hcHBlbmRDaGlsZChjaGlsZF9ldmVudHMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gUXVhbGl0eTsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBTZXR0aW5nKHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdJZCdcblx0XTtcblx0THVtcC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG5cdHRoaXMuc2hvcHMgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFNldHRpbmcucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuU2V0dGluZy5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMpO1xufTtcblxuU2V0dGluZy5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiICNcIiArIHRoaXMuSWQ7XG59O1xuXG5TZXR0aW5nLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbiwgdGFnKSB7XG5cblx0c2l6ZSA9IHNpemUgfHwgXCJub3JtYWxcIjtcblx0aW5jbHVkZUNoaWxkcmVuID0gaW5jbHVkZUNoaWxkcmVuID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblx0dGFnID0gdGFnIHx8IFwibGlcIjtcblxuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRodG1sID0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLklkK1wiPC9oMz5cIjtcblxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XG5cblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRyZXR1cm4gZWxlbWVudDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gU2V0dGluZzsiLCJ2YXIgTHVtcCA9IHJlcXVpcmUoJy4vbHVtcCcpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi9jbHVtcCcpO1xuXG52YXIgYXBpO1xuXG5mdW5jdGlvbiBTaG9wKHJhdywgcGFyZW50KSB7XG5cdHRoaXMuc3RyYWlnaHRDb3B5ID0gW1xuXHRcdCdJZCcsXG5cdFx0J05hbWUnLFxuXHRcdCdEZXNjcmlwdGlvbicsXG5cdFx0J0ltYWdlJyxcblx0XHQnT3JkZXJpbmcnXG5cdF07XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLmF2YWlsYWJpbGl0aWVzID0gbnVsbDtcblx0dGhpcy51bmxvY2tDb3N0ID0gbnVsbDtcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBTaG9wLnByb3RvdHlwZVttZW1iZXJdID0gTHVtcC5wcm90b3R5cGVbbWVtYmVyXTsgfSk7XG5cblNob3AucHJvdG90eXBlLndpcmVVcCA9IGZ1bmN0aW9uKHRoZUFwaSkge1xuXG5cdGFwaSA9IHRoZUFwaTtcblxuXHR0aGlzLmF2YWlsYWJpbGl0aWVzID0gbmV3IENsdW1wKHRoaXMuYXR0cmlicy5BdmFpbGFiaWxpdGllcyB8fCBbXSwgYXBpLnR5cGVzLkF2YWlsYWJpbGl0eSwgdGhpcyk7XG5cblx0THVtcC5wcm90b3R5cGUud2lyZVVwLmNhbGwodGhpcyk7XG59O1xuXG5TaG9wLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5JZCArIFwiKVwiO1xufTtcblxuU2hvcC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCBpbmNsdWRlQ2hpbGRyZW4sIHRhZykge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XG5cdHRhZyA9IHRhZyB8fCBcImxpXCI7XG5cblx0dmFyIHNlbGYgPSB0aGlzO1xuXHR2YXIgaHRtbCA9IFwiXCI7XG5cblx0dmFyIGVsZW1lbnQgPSAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xuXHRlbGVtZW50LmNsYXNzTmFtZSA9IFwiaXRlbSBcIit0aGlzLmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKStcIi1pdGVtIFwiK3NpemU7XG5cblx0aHRtbCA9IFwiXFxuPGltZyBjbGFzcz0naWNvbicgc3JjPSdcIithcGkuY29uZmlnLmxvY2F0aW9ucy5pbWFnZXNQYXRoK1wiL1wiK3RoaXMuSW1hZ2UrXCIucG5nJyAvPlwiO1xuXHRodG1sICs9IFwiXFxuPGgzIGNsYXNzPSd0aXRsZSc+XCIrdGhpcy5OYW1lK1wiPC9oMz5cIjtcblx0aHRtbCArPSBcIlxcbjxwIGNsYXNzPSdkZXNjcmlwdGlvbic+XCIrdGhpcy5EZXNjcmlwdGlvbitcIjwvcD5cIjtcblxuXHRlbGVtZW50LmlubmVySFRNTCA9IGh0bWw7XG5cblx0ZWxlbWVudC50aXRsZSA9IHRoaXMudG9TdHJpbmcoKTtcblxuXHRpZihpbmNsdWRlQ2hpbGRyZW4pIHtcblx0XHRlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cdFx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdFx0XHR2YXIgY2hpbGRMaXN0ID0gZWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiLmNoaWxkLWxpc3RcIik7XG5cdFx0XHRpZihjaGlsZExpc3QpIHtcblx0XHRcdFx0ZWxlbWVudC5yZW1vdmVDaGlsZChjaGlsZExpc3QpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGlmKHNlbGYuYXZhaWxhYmlsaXRpZXMpIHtcblxuXHRcdFx0XHRcdHZhciBjaGlsZF9lbGVtZW50cyA9IHNlbGYuYXZhaWxhYmlsaXRpZXMudG9Eb20oXCJub3JtYWxcIiwgdHJ1ZSk7XG5cblx0XHRcdFx0XHRjaGlsZF9lbGVtZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2VsZW1lbnRzKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFNob3A7IiwidmFyIEx1bXAgPSByZXF1aXJlKCcuL2x1bXAnKTtcbnZhciBDbHVtcCA9IHJlcXVpcmUoJy4vY2x1bXAnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gU3Bhd25lZEVudGl0eShyYXcsIHBhcmVudCkge1xuXHR0aGlzLnN0cmFpZ2h0Q29weSA9IFtcblx0XHQnTmFtZScsXG5cdFx0J0h1bWFuTmFtZScsXG5cblx0XHQnTmV1dHJhbCcsXG5cdFx0J1ByZWZhYk5hbWUnLFxuXHRcdCdEb3JtYW50QmVoYXZpb3VyJyxcblx0XHQnQXdhcmVCZWhhdmlvdXInLFxuXG5cdFx0J0h1bGwnLFxuXHRcdCdDcmV3Jyxcblx0XHQnTGlmZScsXG5cdFx0J01vdmVtZW50U3BlZWQnLFxuXHRcdCdSb3RhdGlvblNwZWVkJyxcblx0XHQnQmVhc3RpZUNoYXJhY3RlcmlzdGljc05hbWUnLFxuXHRcdCdDb21iYXRJdGVtcycsXG5cdFx0J0xvb3RQcmVmYWJOYW1lJyxcblx0XHQnR2xlYW1WYWx1ZSdcblx0XTtcblx0cmF3LklkID0gcmF3Lk5hbWU7XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLnBhY2lmeUV2ZW50ID0gbnVsbDtcblx0dGhpcy5raWxsUXVhbGl0eUV2ZW50ID0gbnVsbDtcblx0dGhpcy5jb21iYXRBdHRhY2tOYW1lcyA9IFtdO1xuXG5cdHRoaXMuaW1hZ2UgPSBudWxsO1xufVxuT2JqZWN0LmtleXMoTHVtcC5wcm90b3R5cGUpLmZvckVhY2goZnVuY3Rpb24obWVtYmVyKSB7IFNwYXduZWRFbnRpdHkucHJvdG90eXBlW21lbWJlcl0gPSBMdW1wLnByb3RvdHlwZVttZW1iZXJdOyB9KTtcblxuU3Bhd25lZEVudGl0eS5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHZhciBzZWxmID0gdGhpcztcblx0XG5cdHRoaXMuY29tYmF0QXR0YWNrTmFtZXMgPSAodGhpcy5hdHRyaWJzLkNvbWJhdEF0dGFja05hbWVzIHx8IFtdKS5tYXAoZnVuY3Rpb24obmFtZSkge1xuXHRcdHJldHVybiBhcGkuZ2V0KGFwaS50eXBlcy5Db21iYXRBdHRhY2ssIG5hbWUsIHNlbGYpO1xuXHR9KS5maWx0ZXIoZnVuY3Rpb24oYXR0YWNrKSB7XG5cdFx0cmV0dXJuIHR5cGVvZiBhdHRhY2sgPT09IFwib2JqZWN0XCI7XG5cdH0pO1xuXG5cdHRoaXMucGFjaWZ5RXZlbnQgPSBhcGkuZ2V0KGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLlBhY2lmeUV2ZW50SWQsIHRoaXMpO1xuXHRpZih0aGlzLnBhY2lmeUV2ZW50KSB7XG5cdFx0dGhpcy5wYWNpZnlFdmVudC50YWcgPSBcInBhY2lmaWVkXCI7XG5cdH1cblxuXHR0aGlzLmtpbGxRdWFsaXR5RXZlbnQgPSBhcGkuZ2V0KGFwaS50eXBlcy5FdmVudCwgdGhpcy5hdHRyaWJzLktpbGxRdWFsaXR5RXZlbnRJZCwgdGhpcyk7XG5cdGlmKHRoaXMua2lsbFF1YWxpdHlFdmVudCkge1xuXHRcdHRoaXMua2lsbFF1YWxpdHlFdmVudC50YWcgPSBcImtpbGxlZFwiO1xuXHR9XG5cblx0dGhpcy5pbWFnZSA9ICgodGhpcy5raWxsUXVhbGl0eUV2ZW50ICYmIHRoaXMua2lsbFF1YWxpdHlFdmVudC5JbWFnZSkgfHwgKHRoaXMucGFjaWZ5RXZlbnQgJiYgdGhpcy5wYWNpZnlFdmVudC5JbWFnZSkpO1xuXG5cdEx1bXAucHJvdG90eXBlLndpcmVVcC5jYWxsKHRoaXMsIGFwaSk7XG59O1xuXG5TcGF3bmVkRW50aXR5LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLkh1bWFuTmFtZSArIFwiICgjXCIgKyB0aGlzLklkICsgXCIpXCI7XG59O1xuXG5TcGF3bmVkRW50aXR5LnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIGluY2x1ZGVDaGlsZHJlbikge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdGluY2x1ZGVDaGlsZHJlbiA9IGluY2x1ZGVDaGlsZHJlbiA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XG5cblx0dmFyIHNlbGYgPSB0aGlzO1xuXG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRpZih0aGlzLkltYWdlICE9PSBudWxsICYmIHRoaXMuSW1hZ2UgIT09IFwiXCIpIHtcblx0XHRodG1sID0gXCI8aW1nIGNsYXNzPSdpY29uJyBzcmM9J1wiK2FwaS5jb25maWcubG9jYXRpb25zLmltYWdlc1BhdGgrXCIvXCIrdGhpcy5pbWFnZStcInNtYWxsLnBuZycgLz5cIjtcblx0fVxuXG5cdGh0bWwgKz0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLkh1bWFuTmFtZStcIjwvaDM+XCI7XG5cblx0aWYoc2l6ZSAhPT0gXCJzbWFsbFwiKSB7XG5cdFx0aWYodGhpcy5xdWFsaXRpZXNSZXF1aXJlZCkge1xuXHRcdFx0aHRtbCArPSBcIjxkaXYgY2xhc3M9J3NpZGViYXInPlwiO1xuXHRcdFx0aHRtbCArPSB0aGlzLnF1YWxpdGllc1JlcXVpcmVkLnRvRG9tKFwic21hbGxcIiwgZmFsc2UsIFwidWxcIikub3V0ZXJIVE1MO1xuXHRcdFx0aHRtbCArPSBcIjwvZGl2PlwiO1xuXHRcdH1cblxuXHRcdGh0bWwgKz0gXCI8ZGwgY2xhc3M9J2NsdW1wLWxpc3Qgc21hbGwnPlwiO1xuXG5cdFx0WydIdWxsJywgJ0NyZXcnLCAnTGlmZScsICdNb3ZlbWVudFNwZWVkJywgJ1JvdGF0aW9uU3BlZWQnXS5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xuXHRcdFx0aHRtbCArPSBcIjxkdCBjbGFzcz0naXRlbSc+XCIra2V5K1wiPC9kdD48ZGQgY2xhc3M9J3F1YW50aXR5Jz5cIitzZWxmW2tleV0rXCI8L2RkPlwiO1xuXHRcdH0pO1xuXHRcdGh0bWwgKz0gXCI8L2RsPlwiO1xuXHR9XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0aWYoaW5jbHVkZUNoaWxkcmVuKSB7XG5cdFx0ZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oZSkge1xuXHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblxuXHRcdFx0dmFyIGNoaWxkTGlzdCA9IGVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5jaGlsZC1saXN0XCIpO1xuXHRcdFx0aWYoY2hpbGRMaXN0KSB7XG5cdFx0XHRcdGVsZW1lbnQucmVtb3ZlQ2hpbGQoY2hpbGRMaXN0KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR2YXIgc3VjY2Vzc0V2ZW50ID0gc2VsZi5zdWNjZXNzRXZlbnQ7XG5cdFx0XHRcdHZhciBkZWZhdWx0RXZlbnQgPSBzZWxmLmRlZmF1bHRFdmVudDtcblx0XHRcdFx0dmFyIHF1YWxpdGllc1JlcXVpcmVkID0gIHNlbGYucXVhbGl0aWVzUmVxdWlyZWQ7XG5cdFx0XHRcdHZhciBldmVudHMgPSBbXTtcblx0XHRcdFx0aWYoc3VjY2Vzc0V2ZW50ICYmIHF1YWxpdGllc1JlcXVpcmVkICYmIHF1YWxpdGllc1JlcXVpcmVkLnNpemUoKSkge1xuXHRcdFx0XHRcdGV2ZW50cy5wdXNoKHN1Y2Nlc3NFdmVudCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYoZGVmYXVsdEV2ZW50KSB7XG5cdFx0XHRcdFx0ZXZlbnRzLnB1c2goZGVmYXVsdEV2ZW50KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZihldmVudHMubGVuZ3RoKSB7XG5cdFx0XHRcdFx0dmFyIHdyYXBwZXJDbHVtcCA9IG5ldyBDbHVtcChldmVudHMsIGFwaS50eXBlcy5FdmVudCk7XG5cdFx0XHRcdFx0dmFyIGNoaWxkX2V2ZW50cyA9IHdyYXBwZXJDbHVtcC50b0RvbShzaXplLCB0cnVlKTtcblxuXHRcdFx0XHRcdGNoaWxkX2V2ZW50cy5jbGFzc0xpc3QuYWRkKFwiY2hpbGQtbGlzdFwiKTtcblx0XHRcdFx0XHRlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2V2ZW50cyk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdHJldHVybiBlbGVtZW50O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBTcGF3bmVkRW50aXR5OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XG52YXIgUG9ydCA9IHJlcXVpcmUoJy4vcG9ydCcpO1xudmFyIEFyZWEgPSByZXF1aXJlKCcuL2FyZWEnKTtcblxudmFyIGFwaTtcblxuZnVuY3Rpb24gVGlsZVZhcmlhbnQocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXG5cdFx0J05hbWUnLFxuXHRcdCdIdW1hbk5hbWUnLFxuXHRcdCdEZXNjcmlwdGlvbicsXG5cblx0XHQnTWF4VGlsZVBvcHVsYXRpb24nLFxuXHRcdCdNaW5UaWxlUG9wdWxhdGlvbicsXG5cdFx0XG5cdFx0J1NlYUNvbG91cicsXG5cdFx0J011c2ljVHJhY2tOYW1lJyxcblx0XHQnQ2hhbmNlT2ZXZWF0aGVyJyxcblx0XHQnRm9nUmV2ZWFsVGhyZXNob2xkJ1xuXHRdO1xuXG4vKlxuTGFiZWxEYXRhOiBBcnJheVs2XVxuUGhlbm9tZW5hRGF0YTogQXJyYXlbMV1cblNwYXduUG9pbnRzOiBBcnJheVsyXVxuVGVycmFpbkRhdGE6IEFycmF5WzE0XVxuV2VhdGhlcjogQXJyYXlbMV1cbiovXG5cblx0cmF3LklkID0gcmF3Lk5hbWU7XG5cdEx1bXAuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuXHR0aGlzLlNldHRpbmdJZCA9IHJhdy5TZXR0aW5nLklkO1xuXHR0aGlzLnNldHRpbmcgPSBudWxsO1xuXG5cdHRoaXMucG9ydHMgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlBvcnREYXRhIHx8IFtdLCBQb3J0LCB0aGlzKTtcblxuXHR0aGlzLmFyZWFzID0gbnVsbDtcbn1cbk9iamVjdC5rZXlzKEx1bXAucHJvdG90eXBlKS5mb3JFYWNoKGZ1bmN0aW9uKG1lbWJlcikgeyBUaWxlVmFyaWFudC5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5UaWxlVmFyaWFudC5wcm90b3R5cGUud2lyZVVwID0gZnVuY3Rpb24odGhlQXBpKSB7XG5cblx0YXBpID0gdGhlQXBpO1xuXG5cdHRoaXMuc2V0dGluZyA9IGFwaS5nZXRPckNyZWF0ZShhcGkudHlwZXMuU2V0dGluZywgdGhpcy5hdHRyaWJzLlNldHRpbmcsIHRoaXMpO1xuXG5cdHRoaXMucG9ydHMuZm9yRWFjaChmdW5jdGlvbihwKSB7IHAud2lyZVVwKGFwaSk7IH0pO1xuXG5cdC8vIEFsc28gY3JlYXRlIGEgbGlzdCBvZiBhbGwgdGhlIGFyZWFzIG9mIGVhY2ggb2YgdGhlIHBvcnRzIGluIHRoaXMgb2JqZWN0IGZvciBjb252ZW5pZW5jZVxuXHR0aGlzLmFyZWFzID0gbmV3IENsdW1wKHRoaXMucG9ydHMubWFwKGZ1bmN0aW9uKHApIHsgcmV0dXJuIHAuYXJlYTsgfSksIGFwaS50eXBlcy5BcmVhLCB0aGlzKTtcblxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzKTtcbn07XG5cblRpbGVWYXJpYW50LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKGxvbmcpIHtcblx0cmV0dXJuIHRoaXMuY29uc3RydWN0b3IubmFtZSArIFwiIFwiICsgdGhpcy5IdW1hbk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XG59O1xuXG5UaWxlVmFyaWFudC5wcm90b3R5cGUudG9Eb20gPSBmdW5jdGlvbihzaXplLCB0YWcpIHtcblxuXHRzaXplID0gc2l6ZSB8fCBcIm5vcm1hbFwiO1xuXHR0YWcgPSB0YWcgfHwgXCJsaVwiO1xuXG5cdHZhciBodG1sID0gXCJcIjtcblxuXHR2YXIgZWxlbWVudCA9ICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XG5cdGVsZW1lbnQuY2xhc3NOYW1lID0gXCJpdGVtIFwiK3RoaXMuY29uc3RydWN0b3IubmFtZS50b0xvd2VyQ2FzZSgpK1wiLWl0ZW0gXCIrc2l6ZTtcblxuXHRodG1sID0gXCJcXG48aDMgY2xhc3M9J3RpdGxlJz5cIit0aGlzLkh1bWFuTmFtZStcIjwvaDM+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRpbGVWYXJpYW50OyIsInZhciBMdW1wID0gcmVxdWlyZSgnLi9sdW1wJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuL2NsdW1wJyk7XG52YXIgVGlsZVZhcmlhbnQgPSByZXF1aXJlKCcuL3RpbGUtdmFyaWFudCcpO1xudmFyIFBvcnQgPSByZXF1aXJlKCcuL3BvcnQnKTtcbnZhciBBcmVhID0gcmVxdWlyZSgnLi9hcmVhJyk7XG5cbnZhciBhcGk7XG5cbmZ1bmN0aW9uIFRpbGUocmF3LCBwYXJlbnQpIHtcblx0dGhpcy5zdHJhaWdodENvcHkgPSBbXG5cdFx0J05hbWUnXG5cdF07XG5cdHJhdy5JZCA9IHJhdy5OYW1lO1xuXHRMdW1wLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cblx0dGhpcy50aWxlVmFyaWFudHMgPSBuZXcgQ2x1bXAodGhpcy5hdHRyaWJzLlRpbGVzIHx8IFtdLCBUaWxlVmFyaWFudCwgdGhpcyk7XG59XG5PYmplY3Qua2V5cyhMdW1wLnByb3RvdHlwZSkuZm9yRWFjaChmdW5jdGlvbihtZW1iZXIpIHsgVGlsZS5wcm90b3R5cGVbbWVtYmVyXSA9IEx1bXAucHJvdG90eXBlW21lbWJlcl07IH0pO1xuXG5UaWxlLnByb3RvdHlwZS53aXJlVXAgPSBmdW5jdGlvbih0aGVBcGkpIHtcblxuXHRhcGkgPSB0aGVBcGk7XG5cblx0dGhpcy50aWxlVmFyaWFudHMuZm9yRWFjaChmdW5jdGlvbih0dikgeyB0di53aXJlVXAoYXBpKTsgfSk7XG5cblx0Ly8gQWxzbyBjcmVhdGUgYSBsaXN0IG9mIGFsbCB0aGUgcG9ydHMgYW5kIGFyZWFzIG9mIGVhY2ggb2YgdGhlIHRpbGV2YXJpYW50cyBpbiB0aGlzIG9iamVjdCBmb3IgY29udmVuaWVuY2Vcblx0dmFyIGFsbF9wb3J0cyA9IHt9O1xuXHR2YXIgYWxsX2FyZWFzID0ge307XG5cdHRoaXMudGlsZVZhcmlhbnRzLmZvckVhY2goZnVuY3Rpb24odHYpIHtcblx0XHR0di5wb3J0cy5mb3JFYWNoKGZ1bmN0aW9uKHApIHtcblx0XHRcdGFsbF9wb3J0c1twLklkXSA9IHA7XG5cdFx0XHRhbGxfYXJlYXNbcC5hcmVhLklkXSA9IHAuYXJlYTtcblx0XHR9KTtcblx0fSk7XG5cdHRoaXMucG9ydHMgPSBuZXcgQ2x1bXAoT2JqZWN0LmtleXMoYWxsX3BvcnRzKS5tYXAoZnVuY3Rpb24ocCkgeyByZXR1cm4gYWxsX3BvcnRzW3BdOyB9KSwgYXBpLnR5cGVzLlBvcnQsIHRoaXMpO1xuXHR0aGlzLmFyZWFzID0gbmV3IENsdW1wKE9iamVjdC5rZXlzKGFsbF9hcmVhcykubWFwKGZ1bmN0aW9uKGEpIHsgcmV0dXJuIGFsbF9hcmVhc1thXTsgfSksIGFwaS50eXBlcy5BcmVhLCB0aGlzKTtcblxuXHRMdW1wLnByb3RvdHlwZS53aXJlVXAuY2FsbCh0aGlzKTtcbn07XG5cblRpbGUucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24obG9uZykge1xuXHRyZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lICsgXCIgXCIgKyB0aGlzLk5hbWUgKyBcIiAoI1wiICsgdGhpcy5OYW1lICsgXCIpXCI7XG59O1xuXG5UaWxlLnByb3RvdHlwZS50b0RvbSA9IGZ1bmN0aW9uKHNpemUsIHRhZykge1xuXG5cdHNpemUgPSBzaXplIHx8IFwibm9ybWFsXCI7XG5cdHRhZyA9IHRhZyB8fCBcImxpXCI7XG5cblx0dmFyIGh0bWwgPSBcIlwiO1xuXG5cdHZhciBlbGVtZW50ID0gIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcblx0ZWxlbWVudC5jbGFzc05hbWUgPSBcIml0ZW0gXCIrdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCkrXCItaXRlbSBcIitzaXplO1xuXG5cdGh0bWwgPSBcIlxcbjxoMyBjbGFzcz0ndGl0bGUnPlwiK3RoaXMuTmFtZStcIjwvaDM+XCI7XG5cblx0ZWxlbWVudC5pbm5lckhUTUwgPSBodG1sO1xuXG5cdGVsZW1lbnQudGl0bGUgPSB0aGlzLnRvU3RyaW5nKCk7XG5cblx0cmV0dXJuIGVsZW1lbnQ7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRpbGU7IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4vYXBpJyk7XG52YXIgZHJhZ25kcm9wID0gcmVxdWlyZSgnLi91aS9kcmFnbmRyb3AnKTtcbnZhciBxdWVyeSA9IHJlcXVpcmUoJy4vdWkvcXVlcnknKTtcblxuXG4kKFwiI3RhYnMgLmJ1dHRvbnMgbGlcIikub24oXCJjbGlja1wiLCBmdW5jdGlvbihlKSB7XG5cbiAgdmFyIHR5cGUgPSAkKHRoaXMpLmF0dHIoXCJkYXRhLXR5cGVcIik7XG5cbiAgJChcIiN0YWJzIC5wYW5lcyAucGFuZVwiKS5oaWRlKCk7IC8vIEhpZGUgYWxsIHBhbmVzXG4gICQoXCIjdGFicyAuYnV0dG9ucyBsaVwiKS5yZW1vdmVDbGFzcyhcImFjdGl2ZVwiKTsgLy8gRGVhY3RpdmF0ZSBhbGwgYnV0dG9uc1xuXG4gICQoXCIjdGFicyAucGFuZXMgLlwiK3R5cGUudG9Mb3dlckNhc2UoKSkuc2hvdygpO1xuICAkKFwiI3RhYnMgLmJ1dHRvbnMgW2RhdGEtdHlwZT1cIit0eXBlK1wiXVwiKS5hZGRDbGFzcyhcImFjdGl2ZVwiKTtcbn0pO1xuXG4vLyBTZXR1cCB0aGUgZG5kIGxpc3RlbmVycy5cbnZhciBkcm9wWm9uZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkcm9wLXpvbmUnKTtcblxuZHJvcFpvbmUuYWRkRXZlbnRMaXN0ZW5lcignZHJhZ2VudGVyJywgZHJhZ25kcm9wLmhhbmRsZXJzLmRyYWdPdmVyLCBmYWxzZSk7XG5kcm9wWm9uZS5hZGRFdmVudExpc3RlbmVyKCdkcmFnbGVhdmUnLCBkcmFnbmRyb3AuaGFuZGxlcnMuZHJhZ0VuZCwgZmFsc2UpO1xuZHJvcFpvbmUuYWRkRXZlbnRMaXN0ZW5lcignZHJhZ292ZXInLCBkcmFnbmRyb3AuaGFuZGxlcnMuZHJhZ092ZXIsIGZhbHNlKTtcblxuZHJvcFpvbmUuYWRkRXZlbnRMaXN0ZW5lcignZHJvcCcsIGRyYWduZHJvcC5oYW5kbGVycy5kcmFnRHJvcCwgZmFsc2UpO1xuXG5kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncGF0aHMtdG8tbm9kZScpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgcXVlcnkucGF0aHNUb05vZGVVSSwgZmFsc2UpO1xuXG4vLyBGb3IgY29udmVuaWVuY2VcbndpbmRvdy5hcGkgPSBhcGk7XG53aW5kb3cuYXBpLnF1ZXJ5ID0gcXVlcnk7IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4uL2FwaScpO1xudmFyIENsdW1wID0gcmVxdWlyZSgnLi4vb2JqZWN0cy9jbHVtcCcpO1xudmFyIGlvID0gcmVxdWlyZSgnLi4vaW8nKTtcblxudmFyIHJlbmRlciA9IHJlcXVpcmUoJy4vcmVuZGVyJyk7XG5cbmZ1bmN0aW9uIGhhbmRsZURyYWdPdmVyKGV2dCkge1xuICBldnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gIGV2dC5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICQoXCIjZHJvcC16b25lXCIpLmFkZENsYXNzKFwiZHJvcC10YXJnZXRcIik7XG59XG5cbmZ1bmN0aW9uIGhhbmRsZURyYWdFbmQoZXZ0KSB7XG4gIGV2dC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgZXZ0LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgJChcIiNkcm9wLXpvbmVcIikucmVtb3ZlQ2xhc3MoXCJkcm9wLXRhcmdldFwiKTtcbn1cblxuZnVuY3Rpb24gaGFuZGxlRHJhZ0Ryb3AoZXZ0KSB7XG5cbiAgJChcIiNkcm9wLXpvbmVcIikucmVtb3ZlQ2xhc3MoXCJkcm9wLXRhcmdldFwiKTtcblxuICBldnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gIGV2dC5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gIHZhciBmaWxlcyA9IGV2dC5kYXRhVHJhbnNmZXIuZmlsZXM7IC8vIEZpbGVMaXN0IG9iamVjdC5cblxuICAvLyBGaWxlcyBpcyBhIEZpbGVMaXN0IG9mIEZpbGUgb2JqZWN0cy4gTGlzdCBzb21lIHByb3BlcnRpZXMuXG4gIHZhciBvdXRwdXQgPSBbXTtcbiAgaW8ucmVzZXRGaWxlc1RvTG9hZCgpO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGZpbGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIGYgPSBmaWxlc1tpXTtcbiAgICB2YXIgZmlsZW5hbWUgPSBlc2NhcGUoZi5uYW1lKTtcbiAgICB2YXIgdHlwZU5hbWUgPSBpby5maWxlT2JqZWN0TWFwW2ZpbGVuYW1lXTtcbiAgICB2YXIgVHlwZSA9IGFwaS50eXBlc1t0eXBlTmFtZV07XG4gICAgaWYoVHlwZSkge1xuICAgICAgaW8uaW5jcmVtZW50RmlsZXNUb0xvYWQoKTtcbiAgICAgIGFwaS5yZWFkRnJvbUZpbGUoVHlwZSwgZiwgZnVuY3Rpb24oKSB7XG4gICAgICAgIGlvLmRlY3JlbWVudEZpbGVzVG9Mb2FkKCk7XG5cbiAgICAgICAgaWYoaW8uY291bnRGaWxlc1RvTG9hZCgpID09PSAwKSB7XG4gICAgICAgICAgYXBpLndpcmVVcE9iamVjdHMoKTtcbiAgICAgICAgICByZW5kZXIubGlzdHMoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBvdXRwdXQucHVzaCgnPGxpPjxzdHJvbmc+JywgZXNjYXBlKGYubmFtZSksICc8L3N0cm9uZz4gKCcsIGYudHlwZSB8fCAnbi9hJywgJykgLSAnLFxuICAgICAgICAgICAgICAgIGYuc2l6ZSwgJyBieXRlcywgbGFzdCBtb2RpZmllZDogJyxcbiAgICAgICAgICAgICAgICBmLmxhc3RNb2RpZmllZERhdGUgPyBmLmxhc3RNb2RpZmllZERhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCkgOiAnbi9hJyxcbiAgICAgICAgICAgICAgICAnPC9saT4nKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBvdXRwdXQucHVzaCgnPGxpPkVSUk9SOiBObyBoYW5kbGVyIGZvciBmaWxlIDxzdHJvbmc+JyAsIGVzY2FwZShmLm5hbWUpLCAnPC9zdHJvbmc+PC9saT4nKTtcbiAgICB9XG4gIH1cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xpc3QnKS5pbm5lckhUTUwgPSAnPHVsPicgKyBvdXRwdXQuam9pbignJykgKyAnPC91bD4nO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0aGFuZGxlcnM6IHtcblx0XHRkcmFnT3ZlcjogaGFuZGxlRHJhZ092ZXIsXG5cdFx0ZHJhZ0VuZDogaGFuZGxlRHJhZ0VuZCxcblx0XHRkcmFnRHJvcDogaGFuZGxlRHJhZ0Ryb3Bcblx0fVxufTsiLCJ2YXIgYXBpID0gcmVxdWlyZSgnLi4vYXBpJyk7XG52YXIgQ2x1bXAgPSByZXF1aXJlKCcuLi9vYmplY3RzL2NsdW1wJyk7XG5cbmZ1bmN0aW9uIFJvdXRlTm9kZShub2RlKSB7XG4gIHRoaXMubm9kZSA9IG5vZGU7XG4gIHRoaXMuY2hpbGRyZW4gPSBbXTtcbn1cblxuZnVuY3Rpb24gcGF0aHNUb05vZGVVSSgpIHtcblxuICB2YXIgdHlwZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0eXBlJyk7XG4gIHR5cGUgPSB0eXBlLm9wdGlvbnNbdHlwZS5zZWxlY3RlZEluZGV4XS52YWx1ZTtcblxuICB2YXIgb3BlcmF0aW9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ29wZXJhdGlvbicpO1xuICBvcGVyYXRpb24gPSBvcGVyYXRpb24ub3B0aW9uc1tvcGVyYXRpb24uc2VsZWN0ZWRJbmRleF0udmFsdWU7XG5cbiAgdmFyIGlkID0gcHJvbXB0KFwiSWQgb2YgXCIrdHlwZSk7XG5cbiAgaWYoIWlkKSB7ICAvLyBDYW5jZWxsZWQgZGlhbG9ndWVcbiAgICByZXR1cm47XG4gIH1cblxuICB2YXIgaXRlbSA9IGFwaS5saWJyYXJ5W3R5cGVdLmlkKGlkKTtcblxuICBpZighaXRlbSkge1xuICAgIGFsZXJ0KFwiQ291bGQgbm90IGZpbmQgXCIrdHlwZStcIiBcIitpZCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgdmFyIHJvb3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInF1ZXJ5LXRyZWVcIik7XG4gIHJvb3QuaW5uZXJIVE1MID0gXCJcIjtcblxuICB2YXIgdGl0bGUgPSAkKCcucGFuZS5xdWVyeSAucGFuZS10aXRsZScpLnRleHQoXCJRdWVyeTogXCIraXRlbS50b1N0cmluZygpKTtcblxuICB2YXIgcm91dGVzID0gcGF0aHNUb05vZGUoaXRlbSwge30pO1xuXG4gIGlmKHJvdXRlcyAmJiByb3V0ZXMuY2hpbGRyZW4ubGVuZ3RoKSB7XG5cbiAgICByb3V0ZXMgPSBmaWx0ZXJQYXRoc1RvTm9kZShyb3V0ZXMsIG9wZXJhdGlvbik7XG5cbiAgICB2YXIgdG9wX2NoaWxkcmVuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInVsXCIpO1xuICAgIHRvcF9jaGlsZHJlbi5jbGFzc05hbWUgKz0gXCJjbHVtcC1saXN0IHNtYWxsXCI7XG5cbiAgICByb3V0ZXMuY2hpbGRyZW4uZm9yRWFjaChmdW5jdGlvbihjaGlsZF9yb3V0ZSkge1xuICAgICAgdmFyIHRyZWUgPSByZW5kZXJQYXRoc1RvTm9kZShjaGlsZF9yb3V0ZSwgW10pO1xuICAgICAgdG9wX2NoaWxkcmVuLmFwcGVuZENoaWxkKHRyZWUpO1xuICAgIH0pO1xuXG4gICAgcm9vdC5hcHBlbmRDaGlsZCh0b3BfY2hpbGRyZW4pO1xuICB9XG4gIGVsc2Uge1xuICAgIGFsZXJ0KFwiVGhpcyBcIit0eXBlK1wiIGlzIGEgcm9vdCBub2RlIHdpdGggbm8gcGFyZW50cyB0aGF0IHNhdGlzZnkgdGhlIGNvbmRpdGlvbnNcIik7XG4gIH1cbiAgXG59XG5cbmZ1bmN0aW9uIHBhdGhzVG9Ob2RlKG5vZGUsIHNlZW4sIHBhcmVudCkge1xuXG4gIGlmKHNlZW5bbm9kZS5JZF0pIHsgICAvLyBEb24ndCByZWN1cnNlIGludG8gbm9kZXMgd2UndmUgYWxyZWFkeSBzZWVuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgdmFyIGFuY2VzdHJ5ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShzZWVuKSk7XG4gIGFuY2VzdHJ5W25vZGUuSWRdID0gdHJ1ZTtcblxuICB2YXIgdGhpc19ub2RlID0gbmV3IFJvdXRlTm9kZSgvKm5vZGUubGlua1RvRXZlbnQgPyBub2RlLmxpbmtUb0V2ZW50IDoqLyBub2RlKTsgLy8gSWYgdGhpcyBub2RlIGlzIGp1c3QgYSBsaW5rIHRvIGFub3RoZXIgb25lLCBza2lwIG92ZXIgdGhlIHVzZWxlc3MgbGlua1xuXG4gIGlmKG5vZGUgaW5zdGFuY2VvZiBhcGkudHlwZXMuU3Bhd25lZEVudGl0eSkge1xuICAgIHJldHVybiB0aGlzX25vZGU7ICAgLy8gTGVhZiBub2RlIGluIHRyZWVcbiAgfVxuICBlbHNlIGlmKG5vZGUgaW5zdGFuY2VvZiBhcGkudHlwZXMuRXZlbnQgJiYgbm9kZS50YWcgPT09IFwidXNlXCIpIHtcbiAgICByZXR1cm4gdGhpc19ub2RlOyAgIC8vIExlYWYgbm9kZSBpbiB0cmVlXG4gIH1cbiAgZWxzZSBpZihub2RlIGluc3RhbmNlb2YgYXBpLnR5cGVzLkV2ZW50ICYmIHBhcmVudCBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCAmJiAocGFyZW50LnRhZyA9PT0gXCJraWxsZWRcIiB8fCBwYXJlbnQudGFnID09PSBcInBhY2lmaWVkXCIpKSB7IC8vIElmIHRoaXMgaXMgYW4gZXZlbnQgdGhhdCdzIHJlYWNoYWJsZSBieSBraWxsaW5nIGEgbW9uc3RlciwgZG9uJ3QgcmVjdXJzZSBhbnkgb3RoZXIgY2F1c2VzIChhcyB0aGV5J3JlIHVzdWFsbHkgbWlzbGVhZGluZy9jaXJjdWxhcilcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZWxzZSBpZihub2RlIGluc3RhbmNlb2YgYXBpLnR5cGVzLlNldHRpbmcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZWxzZSBpZiAobm9kZSBpbnN0YW5jZW9mIGFwaS50eXBlcy5Qb3J0KSB7XG4gICAgcmV0dXJuIG5ldyBSb3V0ZU5vZGUobm9kZS5hcmVhKTtcbiAgfVxuICBlbHNlIGlmKG5vZGUubGltaXRlZFRvQXJlYSAmJiBub2RlLmxpbWl0ZWRUb0FyZWEuSWQgIT09IDEwMTk1Nikge1xuICAgIHZhciBhcmVhX25hbWUgPSBub2RlLmxpbWl0ZWRUb0FyZWEuTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIHZhciBldmVudF9uYW1lID0gKG5vZGUuTmFtZSAmJiBub2RlLk5hbWUudG9Mb3dlckNhc2UoKSkgfHwgXCJcIjtcbiAgICBpZihhcmVhX25hbWUuaW5kZXhPZihldmVudF9uYW1lKSAhPT0gLTEgfHwgZXZlbnRfbmFtZS5pbmRleE9mKGFyZWFfbmFtZSkgIT09IC0xKSB7ICAvLyBJZiBBcmVhIGhhcyBzaW1pbGFyIG5hbWUgdG8gRXZlbnQsIGlnbm9yZSB0aGUgZXZlbnQgYW5kIGp1c3Qgc3Vic3RpdHV0ZSB0aGUgYXJlYVxuICAgICAgcmV0dXJuIG5ldyBSb3V0ZU5vZGUobm9kZS5saW1pdGVkVG9BcmVhKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICB0aGlzX25vZGUuY2hpbGRyZW4ucHVzaChuZXcgUm91dGVOb2RlKG5vZGUubGltaXRlZFRvQXJlYSkpOyAgIC8vIEVsc2UgaW5jbHVkZSBib3RoIHRoZSBBcmVhIGFuZCB0aGUgRXZlbnRcbiAgICAgIHJldHVybiB0aGlzX25vZGU7XG4gICAgfVxuICAgIFxuICB9XG4gIGVsc2Uge1xuICAgIGZvcih2YXIgaT0wOyBpPG5vZGUucGFyZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHRoZV9wYXJlbnQgPSBub2RlLnBhcmVudHNbaV07XG4gICAgICB2YXIgc3VidHJlZSA9IHBhdGhzVG9Ob2RlKHRoZV9wYXJlbnQsIGFuY2VzdHJ5LCBub2RlKTtcbiAgICAgIGlmKHN1YnRyZWUpIHtcbiAgICAgICAgdGhpc19ub2RlLmNoaWxkcmVuLnB1c2goc3VidHJlZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmKCF0aGlzX25vZGUuY2hpbGRyZW4ubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRoaXNfbm9kZTtcbn1cblxuZnVuY3Rpb24gZmlsdGVyUGF0aHNUb05vZGUocm91dGVzLCBvcGVyYXRpb24pIHtcbiAgLy8gRmlsdGVyIHJvdXRlcyBieSBvcGVyYXRpb25cbiAgaWYocm91dGVzICYmIHJvdXRlcy5jaGlsZHJlbiAmJiBvcGVyYXRpb24gIT09IFwiYW55XCIpIHtcbiAgICByb3V0ZXMuY2hpbGRyZW4gPSByb3V0ZXMuY2hpbGRyZW4uZmlsdGVyKGZ1bmN0aW9uKHJvdXRlX25vZGUpIHtcblxuICAgICAgbHVtcCA9IHJvdXRlX25vZGUubm9kZTtcblxuICAgICAgaWYob3BlcmF0aW9uID09PSBcImFkZGl0aXZlXCIpIHtcbiAgICAgICAgcmV0dXJuIGx1bXAuaXNPbmVPZihbYXBpLnR5cGVzLlF1YWxpdHlFZmZlY3QsIGFwaS50eXBlcy5BdmFpbGFiaWxpdHldKSAmJiBsdW1wLmlzQWRkaXRpdmUoKTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYob3BlcmF0aW9uID09PSBcInN1YnRyYWN0aXZlXCIpIHtcbiAgICAgICAgcmV0dXJuIGx1bXAuaXNPbmVPZihbYXBpLnR5cGVzLlF1YWxpdHlFZmZlY3QsIGFwaS50eXBlcy5BdmFpbGFiaWxpdHldKSAmJiBsdW1wLmlzU3VidHJhY3RpdmUoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiByb3V0ZXM7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclBhdGhzVG9Ob2RlKHJvdXRlTm9kZSwgYW5jZXN0cnkpIHtcbiAgXG4gIGlmKCEocm91dGVOb2RlIGluc3RhbmNlb2YgUm91dGVOb2RlKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgdmFyIGVsZW1lbnQgPSByb3V0ZU5vZGUubm9kZS50b0RvbShcInNtYWxsXCIsIGZhbHNlKTtcbiAgXG4gIHZhciBjaGlsZF9saXN0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInVsXCIpO1xuICBjaGlsZF9saXN0LmNsYXNzTmFtZSArPSBcImNsdW1wLWxpc3Qgc21hbGwgY2hpbGQtbGlzdFwiO1xuXG4gIHZhciBuZXdfYW5jZXN0cnkgPSBhbmNlc3RyeS5zbGljZSgpO1xuICBuZXdfYW5jZXN0cnkucHVzaChyb3V0ZU5vZGUubm9kZSk7XG4gIHJvdXRlTm9kZS5jaGlsZHJlbi5mb3JFYWNoKGZ1bmN0aW9uKGNoaWxkX3JvdXRlLCBpbmRleCwgY2hpbGRyZW4pIHtcbiAgICB2YXIgY2hpbGRfY29udGVudCA9IHJlbmRlclBhdGhzVG9Ob2RlKGNoaWxkX3JvdXRlLCBuZXdfYW5jZXN0cnkpO1xuICAgIGNoaWxkX2xpc3QuYXBwZW5kQ2hpbGQoY2hpbGRfY29udGVudCk7XG4gIH0pO1xuXG4gIGlmKHJvdXRlTm9kZS5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICBlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkX2xpc3QpO1xuICB9XG4gIGVsc2Uge1xuICAgIHZhciBkZXNjcmlwdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcbiAgICBkZXNjcmlwdGlvbi5pbm5lckhUTUwgPSAnPHNwYW4gY2xhc3M9XCJyb3V0ZS1kZXNjcmlwdGlvblwiPkhJTlQ6ICcgKyBkZXNjcmliZVJvdXRlKG5ld19hbmNlc3RyeSkgKyAnPC9zcGFuPic7XG5cbiAgICB2YXIgcmVxc1RpdGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDUnKTtcbiAgICByZXFzVGl0bGUuaW5uZXJIVE1MID0gXCJSZXF1aXJlbWVudHNcIjtcbiAgICBkZXNjcmlwdGlvbi5hcHBlbmRDaGlsZChyZXFzVGl0bGUpO1xuXG4gICAgdmFyIHRvdGFsX3JlcXVpcmVtZW50cyA9IGdldFJvdXRlUmVxdWlyZW1lbnRzKG5ld19hbmNlc3RyeSk7XG4gICAgXG4gICAgZGVzY3JpcHRpb24uYXBwZW5kQ2hpbGQodG90YWxfcmVxdWlyZW1lbnRzLnRvRG9tKFwic21hbGxcIiwgZmFsc2UpKTtcbiAgICBlbGVtZW50LmFwcGVuZENoaWxkKGRlc2NyaXB0aW9uKTtcbiAgfVxuXG4gIHJldHVybiBlbGVtZW50O1xufVxuXG5mdW5jdGlvbiBsb3dlcih0ZXh0KSB7XG4gIHJldHVybiB0ZXh0LnNsaWNlKDAsMSkudG9Mb3dlckNhc2UoKSt0ZXh0LnNsaWNlKDEpO1xufVxuXG5mdW5jdGlvbiBkZXNjcmliZVJvdXRlKGFuY2VzdHJ5KSB7XG4gIHZhciBhID0gYW5jZXN0cnkuc2xpY2UoKS5yZXZlcnNlKCk7XG5cbiAgdmFyIGd1aWRlID0gXCJcIjtcbiAgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5BcmVhKSB7XG4gICAgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCkge1xuICAgICAgZ3VpZGUgPSBcIlNlZWsgXCIrYVsxXS5OYW1lK1wiIGluIFwiK2FbMF0uTmFtZTtcbiAgICAgIGlmKGFbMl0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIgYW5kIFwiO1xuICAgICAgICBpZihcIlxcXCInXCIuaW5kZXhPZihhWzJdLk5hbWVbMF0pICE9PSAtMSkge1xuICAgICAgICAgIGd1aWRlICs9IFwiZXhjbGFpbSBcIjtcbiAgICAgICAgfVxuICAgICAgICBndWlkZSArPSBsb3dlcihhWzJdLk5hbWUpO1xuICAgICAgfVxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZ3VpZGUgPSBcIlRyYXZlbCB0byBcIithWzBdLk5hbWU7XG5cbiAgICAgIGlmKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIgYW5kIFwiK2xvd2VyKGFbMV0uTmFtZSk7XG4gICAgICB9XG4gICAgICBlbHNlIGlmKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuRXhjaGFuZ2UgJiYgYVsyXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5TaG9wKSB7XG4gICAgICAgIGd1aWRlICs9IFwiIGFuZCBsb29rIGZvciB0aGUgXCIrYVsyXS5OYW1lK1wiIEVtcG9yaXVtIGluIFwiK2FbMV0uTmFtZTtcbiAgICAgIH1cblxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICB9XG4gIGVsc2UgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5TcGF3bmVkRW50aXR5KSB7XG4gICAgZ3VpZGUgPSBcIkZpbmQgYW5kIGJlc3QgYSBcIithWzBdLkh1bWFuTmFtZTtcbiAgICBpZihhWzJdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkludGVyYWN0aW9uKSB7XG4gICAgICBndWlkZSArPSBcIiwgdGhlbiBcIiArIGxvd2VyKGFbMl0uTmFtZSk7XG4gICAgfVxuICAgIGd1aWRlICs9IFwiLlwiO1xuICB9XG4gIGVsc2UgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCAmJiBhWzBdLnRhZyA9PT0gXCJ1c2VcIiAmJiAhKGFbMV0gaW5zdGFuY2VvZiBhcGkudHlwZXMuUXVhbGl0eVJlcXVpcmVtZW50KSkge1xuICAgIGlmKGFbMF0uTmFtZS5tYXRjaCgvXlxccypTcGVhay9pKSkge1xuICAgICAgZ3VpZGUgPSBhWzBdLk5hbWU7XG4gICAgfVxuICAgIGVsc2UgaWYoYVswXS5OYW1lLm1hdGNoKC9eXFxzKkEvaSkpIHtcbiAgICAgIGd1aWRlID0gXCJBY3F1aXJlIFwiK2xvd2VyKGFbMF0uTmFtZSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZ3VpZGUgPSBcIkZpbmQgYSBcIitsb3dlcihhWzBdLk5hbWUpO1xuICAgIH1cbiAgICBndWlkZSArPSBcIiBhbmQgXCIgKyBsb3dlcihhWzFdLk5hbWUpICsgXCIuXCI7XG4gIH1cblxuICByZXR1cm4gZ3VpZGU7XG59XG5cbmZ1bmN0aW9uIGRldGFpbFJvdXRlKGFuY2VzdHJ5KSB7XG4gIHZhciBhID0gYW5jZXN0cnkuc2xpY2UoKS5yZXZlcnNlKCk7XG5cbiAgdmFyIGd1aWRlID0gXCJcIjtcbiAgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5BcmVhKSB7XG4gICAgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FdmVudCkge1xuICAgICAgZ3VpZGUgPSBcIllvdSBtdXN0IHRyYXZlbCB0byBcIithWzBdLk5hbWUrXCIgYW5kIGxvb2sgZm9yIFwiK2FbMV0uTmFtZStcIi5cIjtcbiAgICAgIGlmKGFbMl0gaW5zdGFuY2VvZiBhcGkudHlwZXMuSW50ZXJhY3Rpb24pIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIgIFdoZW4geW91IGZpbmQgaXQgeW91IHNob3VsZCBcIjtcbiAgICAgICAgaWYoXCJcXFwiJ1wiLmluZGV4T2YoYVsyXS5OYW1lWzBdKSAhPT0gLTEpIHtcbiAgICAgICAgICBndWlkZSArPSBcInNheSBcIjtcbiAgICAgICAgfVxuICAgICAgICBndWlkZSArPSBsb3dlcihhWzJdLk5hbWUpO1xuICAgICAgfVxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZ3VpZGUgPSBcIk1ha2UgZm9yIFwiK2FbMF0uTmFtZTtcblxuICAgICAgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5JbnRlcmFjdGlvbikge1xuICAgICAgICBndWlkZSArPSBcIiBhbmQgXCIrbG93ZXIoYVsxXS5OYW1lKTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5FeGNoYW5nZSAmJiBhWzJdIGluc3RhbmNlb2YgYXBpLnR5cGVzLlNob3ApIHtcbiAgICAgICAgZ3VpZGUgKz0gXCIuICBVcG9uIGFycml2YWwgZ28gdG8gXCIrYVsxXS5OYW1lK1wiLCBhbmQgbG9vayBmb3IgdGhlIHNob3AgXCIrYVsyXS5OYW1lcztcbiAgICAgIH1cblxuICAgICAgZ3VpZGUgKz0gXCIuXCI7XG4gICAgfVxuICB9XG4gIGVsc2UgaWYoYVswXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5TcGF3bmVkRW50aXR5KSB7XG4gICAgZ3VpZGUgPSBcIllvdSBtdXN0IGh1bnQgdGhlIG15dGhpY2FsIHplZS1wZXJpbCBrbm93biBhcyB0aGUgXCIrYVswXS5IdW1hbk5hbWUrXCIsIGVuZ2FnZSBpdCBpbiBiYXR0bGUgYW5kIGRlZmVhdCBpdC5cIjtcbiAgICBpZihhWzJdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkludGVyYWN0aW9uKSB7XG4gICAgICBndWlkZSArPSBcIiAgT25jZSB5b3UgaGF2ZSBjb25xdWVyZWQgaXQgeW91IG11c3QgXCIgKyBsb3dlcihhWzJdLk5hbWUpICsgXCIgdG8gaGVscCBzZWN1cmUgeW91ciBwcml6ZS5cIjtcbiAgICB9XG4gIH1cbiAgZWxzZSBpZihhWzBdIGluc3RhbmNlb2YgYXBpLnR5cGVzLkV2ZW50ICYmIGFbMF0udGFnID09PSBcInVzZVwiICYmICEoYVsxXSBpbnN0YW5jZW9mIGFwaS50eXBlcy5RdWFsaXR5UmVxdWlyZW1lbnQpKSB7XG4gICAgaWYoYVswXS5OYW1lLm1hdGNoKC9eXFxzKlNwZWFrL2kpKSB7XG4gICAgICBndWlkZSA9IFwiRmlyc3QgeW91IG11c3QgXCIrbG93ZXIoYVswXS5OYW1lKTtcbiAgICB9XG4gICAgZWxzZSBpZihhWzBdLk5hbWUubWF0Y2goL15cXHMqQS9pKSkge1xuICAgICAgZ3VpZGUgPSBcIlNvdXJjZSBcIitsb3dlcihhWzBdLk5hbWUpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGd1aWRlID0gXCJUcnkgdG8gbG9jYXRlIGEgXCIrbG93ZXIoYVswXS5OYW1lKTtcbiAgICB9XG4gICAgZ3VpZGUgKz0gXCIsIGFuZCB0aGVuIFwiICsgbG93ZXIoYVsxXS5OYW1lKSArIFwiLlwiO1xuICB9XG5cbiAgcmV0dXJuIGd1aWRlO1xufVxuXG5mdW5jdGlvbiBnZXRSb3V0ZVJlcXVpcmVtZW50cyhhbmNlc3RyeSkge1xuXG4gIHZhciByZXFzID0ge307XG5cbiAgLy8gQW5jZXN0cnkgaXMgb3JkZXJlZCBmcm9tIGxhc3QtPmZpcnN0LCBzbyBpdGVyYXRlIGJhY2t3YXJkcyBmcm9tIGZpbmFsIGVmZmVjdCAtPiBpbml0aWFsIGNhdXNlXG4gIGFuY2VzdHJ5LmZvckVhY2goZnVuY3Rpb24oc3RlcCkge1xuICAgIC8qIFNpbXBsaWZpY2F0aW9uOiBpZiBhbiBldmVudCBtb2RpZmllcyBhIHF1YWxpdHkgdGhlbiBhc3N1bWUgdGhhdCBsYXRlciByZXF1aXJlbWVudHNcbiAgICBvbiB0aGUgc2FtZSBxdWFsaXR5IGFyZSBwcm9iYWJseSBzYXRpc2ZpZWQgYnkgdGhhdCBtb2RpZmljYXRpb24gKGVnLCB3aGVuIHF1YWxpdGllc1xuICAgIGFyZSBpbmNyZW1lbnRlZC9kZWNyZW1lbnRlZCB0byBjb250cm9sIHN0b3J5LXF1ZXN0IHByb2dyZXNzKS4gKi9cbiAgICBpZihzdGVwLnF1YWxpdGllc0FmZmVjdGVkKSB7XG4gICAgICBzdGVwLnF1YWxpdGllc0FmZmVjdGVkLmZvckVhY2goZnVuY3Rpb24oZWZmZWN0KSB7XG4gICAgICAgIGRlbGV0ZShyZXFzW2VmZmVjdC5hc3NvY2lhdGVkUXVhbGl0eS5JZF0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIE5vdyBhZGQgYW55IHJlcXVpcmVtZW50cyBmb3IgdGhlIGN1cnJlbnQgc3RhZ2UgKGVhcmxpZXIgcmVxdWlyZW1lbnRzIG92ZXJ3cml0ZSBsYXRlciBvbmVzIG9uIHRoZSBzYW1lIHF1YWxpdHkpXG4gICAgaWYoc3RlcC5xdWFsaXRpZXNSZXF1aXJlZCkge1xuICAgICAgc3RlcC5xdWFsaXRpZXNSZXF1aXJlZC5mb3JFYWNoKGZ1bmN0aW9uKHJlcSkge1xuICAgICAgICBpZihyZXEuYXNzb2NpYXRlZFF1YWxpdHkpIHsgLy8gQ2hlY2sgdGhpcyBpcyBhIHZhbGlkIFF1YWxpdHlSZXF1aXJlbWVudCwgYW5kIG5vdCBvbmUgb2YgdGhlIGhhbGYtZmluaXNoZWQgZGVidWcgZWxlbWVudHMgcmVmZXJyaW5nIHRvIGFub24tZXhpc3RhbnQgUXVhbGl0eVxuICAgICAgICAgIHJlcXNbcmVxLmFzc29jaWF0ZWRRdWFsaXR5LklkXSA9IHJlcTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcblxuICB2YXIgcmVzdWx0ID0gT2JqZWN0LmtleXMocmVxcykubWFwKGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gcmVxc1trZXldOyB9KTtcblxuICByZXR1cm4gbmV3IENsdW1wKHJlc3VsdCwgYXBpLnR5cGVzLlF1YWxpdHlSZXF1aXJlbWVudCk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBSb3V0ZU5vZGU6IFJvdXRlTm9kZSxcbiAgcGF0aHNUb05vZGVVSTogcGF0aHNUb05vZGVVSSxcbiAgcGF0aHNUb05vZGU6IHBhdGhzVG9Ob2RlLFxuICBmaWx0ZXJQYXRoc1RvTm9kZTogZmlsdGVyUGF0aHNUb05vZGUsXG4gIHJlbmRlclBhdGhzVG9Ob2RlOiByZW5kZXJQYXRoc1RvTm9kZSxcbiAgZGVzY3JpYmVSb3V0ZTogZGVzY3JpYmVSb3V0ZSxcbiAgZGV0YWlsUm91dGU6IGRldGFpbFJvdXRlLFxuICBnZXRSb3V0ZVJlcXVpcmVtZW50czogZ2V0Um91dGVSZXF1aXJlbWVudHNcbn07IiwidmFyIGFwaSA9IHJlcXVpcmUoJy4uL2FwaScpO1xuXG5mdW5jdGlvbiByZW5kZXJMaXN0cygpIHtcbiAgT2JqZWN0LmtleXMoYXBpLmxvYWRlZCkuZm9yRWFjaChmdW5jdGlvbih0eXBlKSB7XG4gICAgcmVuZGVyTGlzdChhcGkubG9hZGVkW3R5cGVdKTsgLy8gT25seSBkaXNwbGF5IGRpcmVjdGx5IGxvYWRlZCAocm9vdC1sZXZlbCkgTHVtcHMsIHRvIHByZXZlbnQgdGhlIGxpc3QgYmVjb21pbmcgdW53aWVsZHlcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckxpc3QoY2x1bXApIHtcblx0dmFyIHJvb3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChjbHVtcC50eXBlLm5hbWUudG9Mb3dlckNhc2UoKStcIi1saXN0XCIpO1xuICBpZihyb290KSB7XG5cdCByb290LmFwcGVuZENoaWxkKGNsdW1wLnRvRG9tKCkpO1xuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXHRsaXN0OiByZW5kZXJMaXN0LFxuXHRsaXN0czogcmVuZGVyTGlzdHNcbn07Il19
